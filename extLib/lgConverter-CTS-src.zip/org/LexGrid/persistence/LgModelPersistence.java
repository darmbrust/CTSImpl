/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence;

import org.LexGrid.emf.base.LgModelObj;
import org.LexGrid.managedobj.HomeServiceIF;
import org.LexGrid.managedobj.ManagedObjException;
import org.LexGrid.managedobj.ManagedObjIterator;
import org.LexGrid.managedobj.QueryException;

/**
 * Defines common support required of classes
 * fulfilling the persistence interface to LexGrid model objects.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public interface LgModelPersistence extends HomeServiceIF {

	/**
	 * Synchronizes the given object with the repository.
	 * <p>
	 * The object is added if not present, and updated if present.
	 * @param obj the model object to synchronize
	 * @param recurse true if the operation should be extended to
	 * descendent objects. If so, deleted descendents are removed
	 * from the repository, new descendents are inserted, and
	 * modified descendents are updated.
	 * @exception ManagedObjException
	 */
	void synchronize(LgModelObj obj, boolean recurse) throws ManagedObjException;

	/**
	 * Returns an iterator over all available objects.
	 * <p>
	 * Note: Results may be paged on demand depending on the nature of the returned iterator.
	 * The iterator must be closed to guarantee that associated resources are freed.
	 * Closure is automatic once all elements are processed, but should be guaranteed in a
	 * try/catch block by the caller.
	 * 
	 * @return ManagedObjIterator
	 * @exception QueryException
	 */
	ManagedObjIterator query() throws QueryException;
	
}