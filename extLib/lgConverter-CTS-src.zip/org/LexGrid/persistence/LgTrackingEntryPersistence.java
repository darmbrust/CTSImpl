/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence;

import org.LexGrid.emf.base.LgTrackingEntry;
import org.LexGrid.managedobj.ManagedObjIterator;
import org.LexGrid.managedobj.OIDBasedObjServiceIF;
import org.LexGrid.managedobj.QueryException;
import org.LexGrid.managedobj.RemoveException;
import org.LexGrid.managedobj.ServiceInitException;

/**
 * Defines common support required of classes
 * fulfilling the persistence interface to LexGrid model objects.
 * <p>
 * Note: For now, services are expected to abide by a loose 
 * contract of preserving local tracking information in files
 * with the same name and location as the modified resource and
 * an extension beginning with ".history". This provides for
 * the use of common cleanup routines on deletion of the
 * resource being tracked.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public interface LgTrackingEntryPersistence extends OIDBasedObjServiceIF {

	/**
	 * Instructs the service to create the repository and prepare
	 * for entries to be added. No action is taken if the repository
	 * is already initialized.
	 * @throws ServiceInitException
	 */
	void createRepository() throws ServiceInitException;

	/**
	 * Instructs the service to destroy the repository and perform
	 * any associated cleanup. No action is taken if the repository does
	 * not exist.
	 * @throws RemoveException
	 */
	void destroyRepository() throws RemoveException;

	/**
	 * Returns the most recent entry registered for the given context and ID,
	 * or null if not available.
	 * @param context The context to qualify the given identifier,
	 * or null to check the exist of entries registered with no context.
	 * @param id The unqualified identifier to check.
	 * @return LgTrackingEntry
	 * @exception QueryException
	 */
	LgTrackingEntry getMostRecent(String context, String id) throws QueryException;

	/**
	 * Returns an iterator over all available entries (chronological order).
	 * @return ManagedObjIterator
	 * @exception QueryException
	 */
	ManagedObjIterator query() throws QueryException;

	/**
	 * Returns an iterator over all entries registered with
	 * the given commit status (chronological order).
	 * @param isCommitted true to return committed entries;
	 * false to return uncommitted entries.
	 * @return ManagedObjIterator
	 * @exception QueryException
	 */
	ManagedObjIterator queryByCommitState(boolean isCommitted) throws QueryException;

	/**
	 * Returns an iterator over all entries registered with
	 * the given context (chronological order).
	 * @param context The context for returned items, or null to
	 * return items with no registered context.
	 * @return ManagedObjIterator
	 * @exception QueryException
	 */
	ManagedObjIterator queryByContext(String context) throws QueryException;

	/**
	 * Returns an iterator over all entries registered with
	 * the given type and context (chronological order).
	 * @param context The context for returned items, or null to
	 * return items with no registered context.
	 * @param type The type for returned items.
	 * @return ManagedObjIterator
	 * @exception QueryException
	 */
	ManagedObjIterator queryByContext(String context, String type) throws QueryException;

	/**
	 * Returns an iterator over all entries registered with
	 * the given event (unordered).
	 * @param event The event type for returned entries; well-known values are
	 * defined as constants on the LgTrackingEntry interface.
	 * @return ManagedObjIterator
	 * @exception QueryException
	 */
	ManagedObjIterator queryByEventType(int event) throws QueryException;

	/**
	 * Returns an iterator over all entries registered with
	 * the given identifier (chronological order).
	 * @param id The unqualified identifier for returned items.
	 * @return ManagedObjIterator
	 * @exception QueryException
	 */
	ManagedObjIterator queryByItemID(String id) throws QueryException;

	/**
	 * Returns an iterator over entries registered with
	 * the given type (chronological order).
	 * @param type The type for returned items.
	 * @return ManagedObjIterator
	 * @exception QueryException
	 */
	ManagedObjIterator queryByItemType(String type) throws QueryException;

	/**
	 * Returns an iterator over all entries registered with
	 * the given context and identifier (chronological order).
	 * @param context The context for returned items, or null to
	 * return items with no registered context.
	 * @param id The unqualified identifier for returned items.
	 * @return ManagedObjIterator
	 * @exception QueryException
	 */
	ManagedObjIterator queryByQualifiedID(String context, String id) throws QueryException;

	/**
	 * Returns an iterator over all entries registered with
	 * the given context and identifier (chronological order).
	 * @param context The context for returned items, or null to
	 * return items with no registered context.
	 * @param id The unqualified identifier for returned items.
	 * @param type The type for returned items.
	 * @return ManagedObjIterator
	 * @exception QueryException
	 */
	ManagedObjIterator queryByQualifiedID(String context, String id, String type) throws QueryException;

	/**
	 * Returns an iterator over all entries that occur within a
	 * specified time range (chronological order).
	 * @param msStart Time of the earliest entry to return (measured in milliseconds,
	 * between time of entry and midnight, January 1, 1970 UTC),
	 * or 0 to return up to and including the first available record.
	 * @param msEnd Time of the latest entry to return (measured in milliseconds,
	 * between time of entry and midnight, January 1, 1970 UTC),
	 * or 0 to return up to and including the last available record.
	 * @return ManagedObjIterator
	 * @exception QueryException
	 */
	ManagedObjIterator queryByTimestamp(long msStart, long msEnd) throws QueryException;

	/**
	 * Clears all entries from the registry.
	 * @throws RemoveException
	 */
	void removeAll() throws RemoveException;

}