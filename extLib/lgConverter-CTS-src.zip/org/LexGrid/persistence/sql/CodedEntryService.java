/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence.sql;
//TODO add support for codingSchemeProp table, coding scheme prop multi attributes table
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import org.LexGrid.emf.base.LgConstraint;
import org.LexGrid.emf.base.LgModelObj;
import org.LexGrid.emf.base.LgPagedList;
import org.LexGrid.emf.base.LgStagedObj;
import org.LexGrid.emf.base.LgUnsupportedConstraintException;
import org.LexGrid.emf.base.impl.LgBasicEListImpl;
import org.LexGrid.emf.base.impl.LgEnhancedEListImpl;
import org.LexGrid.emf.codingSchemes.CodingSchemeType;
import org.LexGrid.emf.commonTypes.Property;
import org.LexGrid.emf.concepts.CodedEntry;
import org.LexGrid.emf.concepts.Concepts;
import org.LexGrid.emf.concepts.ConceptsFactory;
import org.LexGrid.emf.concepts.PropertyLink;
import org.LexGrid.emf.concepts.impl.CodedEntryImpl;
import org.LexGrid.managedobj.FindException;
import org.LexGrid.managedobj.InsertException;
import org.LexGrid.managedobj.ManagedObjIF;
import org.LexGrid.managedobj.ManagedObjIterator;
import org.LexGrid.managedobj.ManagedObjIteratorWrapper;
import org.LexGrid.managedobj.ObjectAlreadyExistsException;
import org.LexGrid.managedobj.QueryException;
import org.LexGrid.managedobj.ResolveException;
import org.LexGrid.managedobj.ServiceInitException;
import org.LexGrid.managedobj.jdbc.JDBCBaseService;
import org.LexGrid.util.sql.lgTables.SQLTableConstants;
import org.eclipse.emf.ecore.EStructuralFeature;

/**
 * <pre>
 *        Title:        CodedEntryService.java
 *        Description:  Class that handles CodedEntries to the database.
 * </pre>
 * 
 * @author <A HREF="mailto:armbrust.daniel@mayo.edu">Dan Armbrust </A>
 * @version 1.0 - cvs $Revision: 1.19 $ checked in on $Date: 2005/10/06 19:11:56 $
 */
public class CodedEntryService extends LGBaseService
{
    private PropertyService     properties_;
    private PropertyLinkService propertyLinks_;

    public CodedEntryService(JDBCBaseService anchorService) throws ServiceInitException
    {
        super(anchorService);
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.managedobj.service.BaseService#initNestedServices()
     */
    protected void initNestedServices() throws ServiceInitException
    {
        properties_ = new PropertyService(this);
        propertyLinks_ = new PropertyLinkService(this);
    }

    public ManagedObjIterator queryConcepts(LgConstraint[] constraints, int limit) throws QueryException
    {
        LgBasicEListImpl list = new LgBasicEListImpl();
        list.setConstraints(constraints);
        list.setPageSize(limit);

        PreparedStatement searchForConcept = null;
        PreparedStatement getConcept = null;
        PreparedStatement selectFromConceptMultiAttributes = null;

        LgConstraint currentConstraint = constraints[0];
        // TODO - find out how to hanlde multiple constraints.

        try
        {
            if (currentConstraint.getModelFeature().getName().equals("conceptCode"))
            {
                if (currentConstraint.getRelationType() == LgConstraint.RELATION_equals)
                {
                    searchForConcept = null;
                }
                else
                {
                    searchForConcept = checkOutPreparedStatement("SELECT conceptCode FROM " + getTableName(SQLTableConstants.CONCEPT) + " WHERE codingSchemeName = ? and conceptCode "
                                                                 + wrapQueryForSearch(currentConstraint.getRelationType(), currentConstraint.getCompareValue()));
                }
               
                //don't need to search for the concept code when they pass it in...
            }
            else if (currentConstraint.getModelFeature().getName().equals("entityDescription"))
            {
                searchForConcept = checkOutPreparedStatement("SELECT conceptCode FROM " + getTableName(SQLTableConstants.CONCEPT_PROPERTY) + " WHERE codingSchemeName = ? AND property = 'textualPresentation' and propertyValue "
                        + wrapQueryForSearch(currentConstraint.getRelationType(), currentConstraint.getCompareValue()));
            }
            else if (currentConstraint.getModelFeature().getName().equals("text"))
            {
                searchForConcept = checkOutPreparedStatement("SELECT conceptCode FROM " + getTableName(SQLTableConstants.CONCEPT_PROPERTY) + " WHERE codingSchemeName = ? and propertyValue "
                        + wrapQueryForSearch(currentConstraint.getRelationType(), currentConstraint.getCompareValue()));
            }
            else
            {
                throw new QueryException("Unsupported search feature type "
                        + currentConstraint.getModelFeature().getName());
            }

            ArrayList conceptCodes = new ArrayList();
            if (searchForConcept != null)
            {
                searchForConcept.setString(1, ((CodingSchemeType) getEContainer()).getCodingScheme());
                searchForConcept.setMaxRows(limit);
                
                ResultSet results = searchForConcept.executeQuery();
                while (results.next())
                {
                    conceptCodes.add(results.getString("conceptCode"));
                }
                results.close();
            }
            else
            {
                conceptCodes.add(currentConstraint.getCompareValue().toString());
            }

            getConcept = checkOutPreparedStatement("SELECT * FROM " + getTableName(SQLTableConstants.CONCEPT) + " WHERE codingSchemeName = ? AND conceptCode = ? ");

            for (int i = 0; i < conceptCodes.size(); i++)
            {
                getConcept.setString(1, ((CodingSchemeType) getEContainer()).getCodingScheme());
                getConcept.setString(2, (String)conceptCodes.get(i));
                ResultSet results = getConcept.executeQuery();
                if (results.next())
                {
                    list.add(conceptsRowToCodedEntry(results, ((CodingSchemeType) getEContainer()).getConcepts()));
                }
            }
        }
        catch (SQLException e)
        {
            throw new QueryException("Problem during query", e);
        }
        catch (FindException e)
        {
            throw new QueryException("Problem populating results", e);
        }
        finally
        {
            checkInPreparedStatement(searchForConcept);
            checkInPreparedStatement(getConcept);
        }

        return new ManagedObjIteratorWrapper(list.iterator());
    }

    private String wrapQueryForSearch(int type, Object value)
    {
        StringBuffer sb = new StringBuffer();
        switch (type)
        {
            case LgConstraint.RELATION_beginsWith :
                sb.append("LIKE '").append(value).append("%'");
                break;
            case LgConstraint.RELATION_contains :
                sb.append("LIKE '%").append(value).append("%'");
                break;
            case LgConstraint.RELATION_endsWith :
                sb.append("LIKE '%").append(value).append("'");
                break;
            case LgConstraint.RELATION_equals :
                sb.append("= '").append(value).append("'");
                break;
            default :
                throw new LgUnsupportedConstraintException();
        }
        return sb.toString();
    }

    public void resolveAll() throws FindException
    {
        PreparedStatement count = null;
        PreparedStatement selectFromConcepts = null;
        Concepts concepts = ConceptsFactory.eINSTANCE.createConcepts();
        concepts.setDc("concepts");
        concepts.setContainer(getEContainer(), getEContainmentFeature(), true);

        if (isStagingEnabled())
        {
            ((LgStagedObj) concepts).setStagingService(this);
        }
        else
        {
            try
            {
                count = checkOutPreparedStatement("SELECT count(conceptCode) as cnt FROM " + getTableName(SQLTableConstants.CONCEPT) + " WHERE codingSchemeName = ?");
                count.setString(1, ((CodingSchemeType) getEContainer()).getCodingScheme());

                ResultSet results = count.executeQuery();
                results.next();
                int total = results.getInt("cnt");
                results.close();
                checkInPreparedStatement(count);
                selectFromConcepts = checkOutPreparedStatement(modifySql("SELECT * FROM " + getTableName(SQLTableConstants.CONCEPT) + " WHERE codingSchemeName = ? {LIMIT}"));

                // This while loop is for mysql - it gets results by a batch at a
                // time.
                // this loop will only run once with other databases.
                int start = 0;
                int conceptCount = 0;
                while (start < total)
                {
                    selectFromConcepts.setString(1, ((CodingSchemeType) getEContainer()).getCodingScheme());

                    // mysql doesn't stream results - the {LIMIT} above and this is
                    // for getting limits on mysql code}
                    if (isMySQL())
                    {
                        // Sometimes, the page size is 0. Asking mysql for 0 results is bad.
                        int end = resolvePageSize();
                        if (end == 0)
                        {
                            end = total;
                        }
                        selectFromConcepts.setInt(2, start);
                        selectFromConcepts.setInt(3, end);
                        start += end;
                    }
                    else if (isPostgreSQL())
                    {
                        // postgres properly streams results, we can just set the fetch size, and only loop once
                        selectFromConcepts.setFetchSize(resolvePageSize());
                        selectFromConcepts.getConnection().setAutoCommit(false);
                        start = total;
                    }
                    else
                    {
                        start = total;
                    }

                    results = selectFromConcepts.executeQuery();

                    while (results.next())
                    {
                        concepts.getConcept().add(
                                                  conceptsRowToCodedEntry(results, concepts));
                        if (++conceptCount % 5000 == 0)
                        {
                            // TODO status stuff
                            // System.out.println("On " + conceptCount + " out of " + total);
                        }
                    }
                    results.close();
                }

            }
            catch (SQLException e)
            {
                throw new FindException(e);
            }
            finally
            {
                checkInPreparedStatement(count);
                checkInPreparedStatement(selectFromConcepts);
            }
        }

    }

    public void stageFeature(LgStagedObj obj, EStructuralFeature feature) throws ResolveException
    {
        if (obj instanceof Concepts)
        {
            if (feature.getName().equals("concept"))
            {
                setEContext(obj.eContainer(), obj.eContainingFeature());
                Concepts concepts = (Concepts) obj;
                PreparedStatement selectFromConcepts = null;
                PreparedStatement selectFromConceptMultiAttributes = null;
                try
                {
                    selectFromConcepts = checkOutPreparedStatement(modifySql("SELECT * FROM " + getTableName(SQLTableConstants.CONCEPT) + " WHERE codingSchemeName = ? {LIMIT}"));

                    // This while loop is for mysql - it gets results by a batch at a
                    // time.
                    // this loop will only run once with other databases.
                    int start = 0;
                    int conceptCount = 0;

                    selectFromConcepts.setString(1, ((CodingSchemeType) getEContainer()).getCodingScheme());

                    // mysql doesn't stream results - the {LIMIT} above and this is
                    // for getting limits on mysql code}
                    if (isMySQL())
                    {
                        selectFromConcepts.setInt(2, start);
                        selectFromConcepts.setInt(3, resolvePageSize());
                        start += resolvePageSize();
                    }
                    else if (isPostgreSQL())
                    {
                        // postgres properly streams results, we can just set the fetch size, and only loop once
                        selectFromConcepts.setFetchSize(resolvePageSize());
                        selectFromConcepts.getConnection().setAutoCommit(false);
                    }

                    ResultSet results = selectFromConcepts.executeQuery();

                    while (results.next())
                    {
                        // if we have reached the page size, stop iterating the results.
                        // assume that the sql driver is smart enough to pull results on demand,
                        // so they are not all in memory.
                        if (conceptCount == resolvePageSize())
                        {
                            PageCookie cookie = new PageCookie();
                            cookie.setSqlStatement(selectFromConcepts);
                            cookie.setResults(results);
                            ((LgEnhancedEListImpl) concepts.getConcept()).setPageCookie(cookie);
                            ((LgEnhancedEListImpl) concepts.getConcept()).setPageSize(resolvePageSize());
                            ((LgEnhancedEListImpl) concepts.getConcept()).setPagingService(this);

                            obj.stageComplete(feature);
                            return;
                        }

                        concepts.getConcept().add(
                                                  conceptsRowToCodedEntry(results, concepts));
                        conceptCount++;

                    }
                    results.close();

                    // only check in this statement if we completed. otherwise, it needs to stay open
                    // and go in the cookie.
                    checkInPreparedStatement(selectFromConcepts);

                    // if we get here, and we are not mysql, then we have all of the results.
                    // if we are mysql, we could have all the results, or there just may be another page.
                    if (isMySQL())
                    {
                        PageCookie cookie = new PageCookie();
                        cookie.setStartPoint(start);
                        ((LgEnhancedEListImpl) concepts.getConcept()).setPageCookie(cookie);
                        ((LgEnhancedEListImpl) concepts.getConcept()).setPageSize(resolvePageSize());
                        ((LgEnhancedEListImpl) concepts.getConcept()).setPagingService(this);
                    }
                    obj.stageComplete(feature);
                }
                catch (SQLException e)
                {
                    checkInPreparedStatement(selectFromConcepts);
                    throw new ResolveException(e);
                }
                catch (FindException e)
                {
                    checkInPreparedStatement(selectFromConcepts);
                    throw new ResolveException("", e);
                }
                finally
                {
                    checkInPreparedStatement(selectFromConceptMultiAttributes);
                }
            }
        }
        else if (obj instanceof CodedEntry)
        {
            if (feature.getName().equals("property"))
            {
                try
                {
                    properties_.setEContext(obj, null);
                    properties_.resolveAll();
                    
                }
                catch (FindException e)
                {
                    throw new ResolveException("Problem resolving properties", e);
                }

            }
            else if (feature.getName().equals("propertyLink"))
            {
                try
                {
                	propertyLinks_.setEContext(obj, null);
                    propertyLinks_.resolveAll();
                }
                catch (FindException e)
                {
                    throw new ResolveException("Problem resolving property links", e);
                }
            }
            
            //All of these features are either already loaded, or are complete when we get here.
            obj.stageComplete(feature);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.plugin.base.LgPagedListService#resolveNextPage(org.LexGrid.plugin.base.LgPagedList)
     */
    public void resolveNextPage(LgPagedList pagedList) throws ResolveException
    {
        int conceptCount = 0;
        LgModelObj lmo = pagedList.getPagingContext();
        setEContext(lmo.eContainer(), lmo.eContainingFeature());
        PageCookie cookie = (PageCookie) pagedList.getPageCookie();
        PreparedStatement selectFromConcepts = null;

        try                                              
        {
            if (isMySQL())
            {
                int start = cookie.getStartPoint();

                try
                {
                    selectFromConcepts = checkOutPreparedStatement(modifySql("SELECT * FROM " + getTableName(SQLTableConstants.CONCEPT) + " WHERE codingSchemeName = ? {LIMIT}"));

                    selectFromConcepts.setString(1, ((CodingSchemeType) getEContainer()).getCodingScheme());
                    selectFromConcepts.setInt(2, start);
                    selectFromConcepts.setInt(3, resolvePageSize());
                    start += resolvePageSize();

                    ResultSet results = selectFromConcepts.executeQuery();

                    while (results.next())
                    {
                        pagedList.add(conceptsRowToCodedEntry(results, pagedList.getPagingContext()));
                        conceptCount++;
                    }
                    results.close();
                    if (conceptCount == 0)
                    {
                        pagedList.setPageCookie(null);
                        cookie = null;
                    }
                    else
                    {
                        cookie.setStartPoint(start);
                        pagedList.setPageCookie(cookie);
                    }
                }
                finally
                {
                    checkInPreparedStatement(selectFromConcepts);
                }
            }
            else
            {
                ResultSet results = cookie.getResults();
                selectFromConcepts = cookie.getSqlStatement();

                while (results.next())
                {
                    // if we have reached the page size, stop iterating the results.
                    // assume that the sql driver is smart enough to pull results on demand,
                    // so they are not all in memory.
                    if (conceptCount == pagedList.getPageSize())
                    {
                        return;
                    }
                    pagedList.add(conceptsRowToCodedEntry(results, pagedList.getPagingContext()));
                    conceptCount++;
                }

                // if we get here, means we have all the results. Close resources.
                results.close();
                checkInPreparedStatement(selectFromConcepts);
                pagedList.setPageCookie(null);
                cookie = null;
            }
        }
        catch (SQLException e)
        {
            checkInPreparedStatement(selectFromConcepts);
            throw new ResolveException(e);
        }
        catch (FindException e)
        {
            checkInPreparedStatement(selectFromConcepts);
            throw new ResolveException("", e);
        }
        finally
        {
            // we do not always want to check in the selectFromConcepts statement...
        }
    }

    private CodedEntry conceptsRowToCodedEntry(ResultSet results, LgModelObj parent) throws FindException,
            SQLException
    {

        CodedEntry currCodedEntry = ConceptsFactory.eINSTANCE.createCodedEntry();
        
        if (isStagingEnabled())
        {
            ((LgStagedObj) currCodedEntry).setStagingService(this);
        }

        currCodedEntry.setConceptCode(results.getString("conceptCode"));
        currCodedEntry.setConceptStatus(results.getString("conceptStatus"));
        currCodedEntry.setEntityDescription(results.getString("entityDescription"));
        Boolean temp = getBooleanFromResultSet(results, supports2006Model() ? "firstRelease" : "firstVersion");
        if (temp != null)
        {
            currCodedEntry.setFirstRelease(temp);
        }
        temp = getBooleanFromResultSet(results, "isActive");
        if (temp != null)
        {
            currCodedEntry.setIsActive(temp);
        }
        temp = getBooleanFromResultSet(results, "isAnonymous");
        if (temp != null)
        {
            currCodedEntry.setIsAnonymous(temp);
        }
        temp = getBooleanFromResultSet(results, supports2006Model() ? "deprecated" : "lastVersion");
        if (temp != null)
        {
            currCodedEntry.setDeprecated(temp);
        }
        if (supports2006Model())
        {
            temp = getBooleanFromResultSet(results, "modifiedInRelease");
            if (temp != null)
            {
                currCodedEntry.setModifiedInRelease(temp);
            }
        }
        
        ((Concepts) parent).getConcept().add(currCodedEntry);

        if (!isStagingEnabled())
        {
            properties_.setEContext(currCodedEntry, null);
            properties_.resolveAll();

            propertyLinks_.setEContext(currCodedEntry, null);
            propertyLinks_.resolveAll();
        }

        return currCodedEntry;
    }
    
    public void insert(ManagedObjIF obj) throws InsertException, ObjectAlreadyExistsException
    {
        PreparedStatement insertIntoConcepts = null;
        try
        {
            CodedEntry currCodedEntry = (CodedEntry) (obj);
            CodingSchemeType codingScheme = (CodingSchemeType) currCodedEntry.getContainer(CodingSchemeType.class, -1);
            insertIntoConcepts = getKeyedInsertStatement(SQLTableConstants.CONCEPT);

            int k = 1;
            insertIntoConcepts.setString(k++, codingScheme.getCodingScheme());
            insertIntoConcepts.setString(k++, currCodedEntry.getConceptCode());
            setBooleanOnPreparedStatment(insertIntoConcepts, k++, currCodedEntry.getFirstRelease());
            if (supports2006Model())
            {
                setBooleanOnPreparedStatment(insertIntoConcepts, k++, currCodedEntry.getModifiedInRelease());
            }
            setBooleanOnPreparedStatment(insertIntoConcepts, k++, currCodedEntry.getDeprecated());
            setBooleanOnPreparedStatment(insertIntoConcepts, k++, currCodedEntry.getIsActive());
            insertIntoConcepts.setString(k++, currCodedEntry.getConceptStatus());
            setBooleanOnPreparedStatment(insertIntoConcepts, k++, currCodedEntry.getIsAnonymous());
            insertIntoConcepts.setString(k++, currCodedEntry.getEntityDescription());
            insertIntoConcepts.executeUpdate();

            Iterator propertyIter = currCodedEntry.getConceptProperty().iterator();
            while (propertyIter.hasNext())
            {
                properties_.insert((Property) propertyIter.next());
            }
            
            propertyIter = currCodedEntry.getComment().iterator();
            while (propertyIter.hasNext())
            {
                properties_.insert((Property) propertyIter.next());
            }
            
            propertyIter = currCodedEntry.getDefinition().iterator();
            while (propertyIter.hasNext())
            {
                properties_.insert((Property) propertyIter.next());
            }
            
            propertyIter = currCodedEntry.getInstruction().iterator();
            while (propertyIter.hasNext())
            {
                properties_.insert((Property) propertyIter.next());
            }
            
            propertyIter = currCodedEntry.getPresentation().iterator();
            while (propertyIter.hasNext())
            {
                properties_.insert((Property) propertyIter.next());
            }

            Iterator propertyLinksIter = currCodedEntry.getPropertyLink().iterator();
            while (propertyLinksIter.hasNext())
            {
                propertyLinks_.insert((PropertyLink) propertyLinksIter.next());
            }
        }
        catch (SQLException e)
        {
            throw new ObjectAlreadyExistsException("Error inserting concept code "
                    + ((CodedEntry) (obj)).getConceptCode(), e);
        }
        catch (InsertException e)
        {
            throw e;
        }
        catch (ObjectAlreadyExistsException e)
        {
            throw e;
        }
        catch (Exception e)
        {
            throw new InsertException("Error inserting concept code " + ((CodedEntry) (obj)).getConceptCode(), e);
        }
        finally
        {
            try
            {
                insertIntoConcepts.close();
            }
            catch (Exception e)
            {
                // do nothing
            }
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.persistence.ldap.LdapBaseService#getInstanceClass()
     */

    protected Class getInstanceClass()
    {
        return CodedEntryImpl.class;
    }
}