/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence.sql;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;

import org.LexGrid.emf.base.LgConstraint;
import org.LexGrid.emf.base.LgModelObj;
import org.LexGrid.emf.base.LgStagedObj;
import org.LexGrid.emf.codingSchemes.CodingSchemeType;
import org.LexGrid.emf.codingSchemes.CodingschemesFactory;
import org.LexGrid.emf.codingSchemes.CodingschemesPackage;
import org.LexGrid.emf.codingSchemes.Mappings;
import org.LexGrid.emf.codingSchemes.impl.CodingSchemeTypeImpl;
import org.LexGrid.emf.codingSchemes.persistence.CodingSchemePersistence;
import org.LexGrid.emf.commonTypes.CommontypesFactory;
import org.LexGrid.emf.commonTypes.Source;
import org.LexGrid.emf.concepts.CodedEntry;
import org.LexGrid.emf.naming.NamingFactory;
import org.LexGrid.emf.naming.SupportedAssociation;
import org.LexGrid.emf.naming.SupportedAssociationQualifier;
import org.LexGrid.emf.naming.SupportedCodingScheme;
import org.LexGrid.emf.naming.SupportedConceptStatus;
import org.LexGrid.emf.naming.SupportedContext;
import org.LexGrid.emf.naming.SupportedFormat;
import org.LexGrid.emf.naming.SupportedLanguage;
import org.LexGrid.emf.naming.SupportedProperty;
import org.LexGrid.emf.naming.SupportedPropertyLink;
import org.LexGrid.emf.naming.SupportedPropertyQualifier;
import org.LexGrid.emf.naming.SupportedRepresentationalForm;
import org.LexGrid.emf.naming.SupportedSource;
import org.LexGrid.emf.naming.impl.SupportedAssociationImpl;
import org.LexGrid.emf.naming.impl.SupportedAssociationQualifierImpl;
import org.LexGrid.emf.naming.impl.SupportedContextImpl;
import org.LexGrid.emf.naming.impl.SupportedPropertyImpl;
import org.LexGrid.emf.naming.impl.SupportedSourceImpl;
import org.LexGrid.emf.relations.Relations;
import org.LexGrid.managedobj.FindException;
import org.LexGrid.managedobj.HomeServiceBroker;
import org.LexGrid.managedobj.InsertException;
import org.LexGrid.managedobj.ManagedObjException;
import org.LexGrid.managedobj.ManagedObjIF;
import org.LexGrid.managedobj.ManagedObjIterator;
import org.LexGrid.managedobj.ObjectAlreadyExistsException;
import org.LexGrid.managedobj.ObjectNotFoundException;
import org.LexGrid.managedobj.QueryException;
import org.LexGrid.managedobj.RemoveException;
import org.LexGrid.managedobj.ResolveException;
import org.LexGrid.managedobj.ServiceInitException;
import org.LexGrid.managedobj.UpdateException;
import org.LexGrid.managedobj.jdbc.JDBCBaseService;
import org.LexGrid.managedobj.jdbc.JDBCConnectionDescriptor;
import org.LexGrid.util.sql.lgTables.SQLTableConstants;
import org.LexGrid.util.sql.lgTables.SQLTableUtilities;
import org.eclipse.emf.ecore.EStructuralFeature;

/**
 * <pre>
 * 
 *  Title:        CodingSchemeService.java
 *  Description:  Handles a CodingSchemeService object to and from the database.
 * </pre>
 * 
 * @author <A HREF="mailto:armbrust.daniel@mayo.edu">Dan Armbrust </A>
 */
public class CodingSchemeService extends LGBaseService implements CodingSchemePersistence
{
    private RelationsService  relationsService_;
    private CodedEntryService conceptsService_;
    
    public CodingSchemeService(JDBCBaseService anchorService) throws ServiceInitException
    {
        super(anchorService);
    }

    public CodingSchemeService(HomeServiceBroker broker, JDBCConnectionDescriptor desc, boolean stagedRetrievalEnabled, String prefix)
            throws ServiceInitException
    {
        super(broker, desc, stagedRetrievalEnabled, prefix);
    }
    
    public CodingSchemeService(HomeServiceBroker broker, JDBCConnectionDescriptor desc, boolean stagedRetrievalEnabled, String prefix, boolean failOnAllErrors, MessageIF messages)
            throws ServiceInitException
    {
        super(broker, desc, stagedRetrievalEnabled, prefix);
        SingletonVariables.instance(getConnectionDescriptor().toString()).messages = messages;
        SingletonVariables.instance(getConnectionDescriptor().toString()).failOnAllErrors = failOnAllErrors;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.managedobj.HomeServiceIF#findByPrimaryKey(java.lang.Object)
     */
    public ManagedObjIF findByPrimaryKey(Object key) throws FindException
    {
        PreparedStatement selectFromCodingScheme = null;
        

        try
        {
            String codingSchemeString = (String) key;

            selectFromCodingScheme = checkOutPreparedStatement("SELECT * FROM " + getTableName(SQLTableConstants.CODING_SCHEME) + " WHERE codingSchemeName = ?");
            selectFromCodingScheme.setString(1, codingSchemeString);

            ResultSet results = selectFromCodingScheme.executeQuery();

            if (results.next())
            {
                CodingSchemeType codingScheme = CodingschemesFactory.eINSTANCE.createCodingSchemeType();
                codingScheme.setCodingScheme(codingSchemeString);
                codingScheme.setFormalName(results.getString("formalName"));
                codingScheme.setRegisteredName(results.getString("registeredName"));
                codingScheme.setDefaultLanguage(results.getString("defaultLanguage"));
                codingScheme.setRepresentsVersion(results.getString("representsVersion"));
                Boolean isNative = getBooleanFromResultSet(results, "isNative");
                if (isNative != null)
                {
                	codingScheme.setIsNative(isNative);
                }
                codingScheme.setApproxNumConcepts(getIntFromSQLResult(results.getString("approxNumConcepts")));
                codingScheme.setEntityDescription(results.getString("entityDescription"));
                codingScheme.setCopyrightText(results.getString("copyright"));
                
                if (supports2006Model())
                {
                    codingScheme.setFirstRelease(getBooleanFromResultSet(results, "firstRelease"));
                    codingScheme.setDeprecated(getBooleanFromResultSet(results, "deprecated"));
                    codingScheme.setModifiedInRelease(getBooleanFromResultSet(results, "modifiedInRelease"));
                }

                results.close();
                
                if (isStagingEnabled())
                {
                    ((LgStagedObj) codingScheme).setStagingService(this);
                }
                else
                {
                    getSubProperties(codingScheme);
                }

                return codingScheme;
            }
            else
            {
                throw new FindException("Could not find coding scheme " + codingSchemeString);
            }
        }
        catch (FindException e)
        {
            throw e;
        }
        catch (Exception e)
        {
            throw new FindException("Problem", e);
        }
        finally
        {
            checkInPreparedStatement(selectFromCodingScheme);
        }
    }
    
    protected Mappings getMappings(CodingSchemeType codingScheme)
    {
    	Mappings mappings = codingScheme.getMappings();
    	if (mappings == null)
    	{
    		mappings = CodingschemesFactory.eINSTANCE.createMappings();
    		codingScheme.setMappings(mappings);
    	}
    	return mappings;
    }
    
    private void getSubProperties(CodingSchemeType codingScheme) throws SQLException, FindException
    {
        PreparedStatement selectFromCodingSchemeMultiAttributes = null;
        PreparedStatement selectFromCodingSchemeSupportedAttributes = null;
        
        try
        {
            String codingSchemeString = codingScheme.getCodingScheme();
            selectFromCodingSchemeMultiAttributes = checkOutPreparedStatement("SELECT * FROM " + getTableName(SQLTableConstants.CODING_SCHEME_MULTI_ATTRIBUTES) + " WHERE codingSchemeName = ?");
            selectFromCodingSchemeMultiAttributes.setString(1, codingSchemeString);

            ResultSet results = selectFromCodingSchemeMultiAttributes.executeQuery();

            while (results.next())
            {
                String attributeName = results.getString(supports2006Model() ? "typeName" : "attributeName").toLowerCase();
                if (attributeName.equals("localname"))
                {
                    codingScheme.getLocalName().add(results.getString("attributeValue"));
                }
                else if (attributeName.equals("source"))
                {
                	Source src = CommontypesFactory.eINSTANCE.createSource();
                	src.setValue(results.getString("attributeValue"));
                    if (supports2006Model())
                    {
                        src.setRole(results.getString("val2"));
                        src.setSubRef(results.getString("val1"));
                    }
                    codingScheme.getSource().add(src);
                }
                else
                {
                    System.out.println("INVALID DATA IN CODING SCHEME MULTI-ATTRIBUTES-TABLE");
                }
            }

            results.close();

            selectFromCodingSchemeSupportedAttributes = checkOutPreparedStatement("SELECT * FROM " + getTableName(SQLTableConstants.CODING_SCHEME_SUPPORTED_ATTRIBUTES) + " WHERE codingSchemeName = ?");
            selectFromCodingSchemeSupportedAttributes.setString(1, codingSchemeString);

            results = selectFromCodingSchemeSupportedAttributes.executeQuery();

            while (results.next())
            {
                String value;
                String attributeName = results.getString("supportedAttributeTag");
                String id = results.getString(supports2006Model() ? "id" : "supportedAttributeValue");
                String urn = results.getString("urn");
                if (supports2006Model())
                {
                    value = results.getString("idValue");
                }
                else
                {
                    value = id;
                }
                Mappings mappings = getMappings(codingScheme);
                
                if (attributeName.equals("Association"))
                {
                    SupportedAssociation temp = new SupportedAssociationImpl();
                    temp.setUrn(urn);
                    temp.setLocalId(id);
                    temp.setValue(value);
                    mappings.getSupportedAssociation().add(temp);
                }
                else if (attributeName.equals("Context"))
                {
                    SupportedContext temp = new SupportedContextImpl();
                    temp.setUrn(urn);
                    temp.setLocalId(id);
                    temp.setValue(value);
                    mappings.getSupportedContext().add(temp);
                }
                else if (attributeName.equals("Source"))
                {
                    SupportedSource temp = new SupportedSourceImpl();
                    temp.setUrn(urn);
                    temp.setLocalId(id);
                    temp.setValue(value);
                    if (supports2006Model())
                    {
                        temp.setAgentRole(results.getString("val2"));
                        temp.setAssemblyRule(results.getString("val1"));
                    }
                    mappings.getSupportedSource().add(temp);
                }
                else if (attributeName.equals("AssociationQualifier"))
                {
                    SupportedAssociationQualifier temp = new SupportedAssociationQualifierImpl();
                    temp.setUrn(urn);
                    temp.setLocalId(id);
                    temp.setValue(value);
                    mappings.getSupportedAssociationQualifier().add(temp);
                }
                else if (attributeName.equals("Property"))
                {
                    SupportedProperty temp = new SupportedPropertyImpl();
                    temp.setUrn(urn);
                    temp.setLocalId(id);
                    temp.setValue(value);
                    mappings.getSupportedProperty().add(temp);
                }
                else if (attributeName.equals("Language"))
                {
                    SupportedLanguage temp = NamingFactory.eINSTANCE.createSupportedLanguage();
                    temp.setUrn(urn);
                    temp.setLocalId(id);
                    temp.setValue(value);
                    mappings.getSupportedLanguage().add(temp);
                }
                else if (attributeName.equals("Format"))
                {
                    SupportedFormat temp = NamingFactory.eINSTANCE.createSupportedFormat();
                    temp.setUrn(urn);
                    temp.setLocalId(id);
                    temp.setValue(value);
                    mappings.getSupportedFormat().add(temp);
                }
                else if (attributeName.equals("CodingScheme"))
                {
                    SupportedCodingScheme temp = NamingFactory.eINSTANCE.createSupportedCodingScheme();
                    temp.setUrn(urn);
                    temp.setLocalId(id);
                    temp.setValue(value);
                    mappings.getSupportedCodingScheme().add(temp);
                }
                else if (attributeName.equals("RepresentationalForm"))
                {
                    SupportedRepresentationalForm temp = NamingFactory.eINSTANCE.createSupportedRepresentationalForm();
                    temp.setUrn(urn);
                    temp.setLocalId(id);
                    temp.setValue(value);
                    mappings.getSupportedRepresentationalForm().add(temp);
                }
                else if (attributeName.equals("ConceptStatus"))
                {
                    SupportedConceptStatus temp = NamingFactory.eINSTANCE.createSupportedConceptStatus();
                    temp.setUrn(urn);
                    temp.setLocalId(id);
                    temp.setValue(value);
                    mappings.getSupportedConceptStatus().add(temp);
                }
                else if (attributeName.equals("PropertyLink"))
                {
                    SupportedPropertyLink temp = NamingFactory.eINSTANCE.createSupportedPropertyLink();
                    temp.setUrn(urn);
                    temp.setLocalId(id);
                    temp.setValue(value);
                    mappings.getSupportedPropertyLink().add(temp);
                }
                else if (attributeName.equals("PropertyQualifier"))
                {
                    SupportedPropertyQualifier temp = NamingFactory.eINSTANCE.createSupportedPropertyQualifier();
                    temp.setUrn(urn);
                    temp.setLocalId(id);
                    temp.setValue(value);
                    mappings.getSupportedPropertyQualifier().add(temp);
                }
                else
                {
                    System.out.println("INVALID DATA '" + attributeName
                            + "' IN CODING-SCHEME-SUPPORTED-ATTRIBUTES-TABLE");
                }
            }

            results.close();

            conceptsService_.setEContext(codingScheme, CodingschemesPackage.eINSTANCE.getCodingSchemeType_Concepts());
            conceptsService_.resolveAll();

            relationsService_.setEContext(codingScheme, CodingschemesPackage.eINSTANCE.getCodingSchemeType_Relations());
            relationsService_.resolveAll();
        }
        finally
        {
            checkInPreparedStatement(selectFromCodingSchemeMultiAttributes);
            checkInPreparedStatement(selectFromCodingSchemeSupportedAttributes);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.managedobj.HomeServiceIF#findBySecondaryKey(java.lang.Object)
     */
    public ManagedObjIF findBySecondaryKey(Object key) throws FindException
    {
        // TODO: Implement findBySecondaryKey
        throw new java.lang.UnsupportedOperationException("Method findBySecondaryKey not yet implemented.");
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.managedobj.HomeServiceIF#insert(org.LexGrid.managedobj.ManagedObjIF)
     */
    public void insert(ManagedObjIF obj) throws InsertException, ObjectAlreadyExistsException
    {
        PreparedStatement insertIntoCodingScheme = null;
        PreparedStatement insertIntoCodingSchemeMultiAttributes = null;
        PreparedStatement insertIntoCodingSchemeSupportedAttributes = null;
        try
        {
            CodingSchemeType csl = (CodingSchemeType) (obj);

            insertIntoCodingScheme = getKeyedInsertStatement(SQLTableConstants.CODING_SCHEME);
            int i = 1;
            insertIntoCodingScheme.setString(i++, csl.getCodingScheme());
            insertIntoCodingScheme.setString(i++, csl.getFormalName());
            insertIntoCodingScheme.setString(i++, csl.getRegisteredName());
            insertIntoCodingScheme.setString(i++, csl.getDefaultLanguage());
            insertIntoCodingScheme.setString(i++, csl.getRepresentsVersion());
            setBooleanOnPreparedStatment(insertIntoCodingScheme, i++, csl.getIsNative());
            insertIntoCodingScheme.setInt(i++, csl.getApproxNumConcepts());
            if (supports2006Model())
            {
                setBooleanOnPreparedStatment(insertIntoCodingScheme, i++, csl.getFirstRelease());
                setBooleanOnPreparedStatment(insertIntoCodingScheme, i++, csl.getModifiedInRelease());
                setBooleanOnPreparedStatment(insertIntoCodingScheme, i++, csl.getDeprecated());
            }
            insertIntoCodingScheme.setString(i++, csl.getEntityDescription() == null ? "MISSING"
                    : csl.getEntityDescription());
            insertIntoCodingScheme.setString(i++,
                    csl.getCopyrightText() == null ? null : csl
                            .getCopyrightText());

            insertIntoCodingScheme.executeUpdate();
            insertIntoCodingScheme.clearParameters();
            insertIntoCodingScheme.close();
            insertIntoCodingScheme = null;

            insertIntoCodingSchemeMultiAttributes = getKeyedInsertStatement(SQLTableConstants.CODING_SCHEME_MULTI_ATTRIBUTES);

            Iterator localNameIter = csl.getLocalName().iterator();
            while (localNameIter.hasNext())
            {
                String currLocalName = (String) localNameIter.next();
                insertIntoCodingSchemeMultiAttributes.setString(1, csl.getCodingScheme());
                insertIntoCodingSchemeMultiAttributes.setString(2, "localName");
                insertIntoCodingSchemeMultiAttributes.setString(3, currLocalName);
                if (supports2006Model())
                {
                    insertIntoCodingSchemeMultiAttributes.setString(4, null);
                    insertIntoCodingSchemeMultiAttributes.setString(5, null);
                }

                insertIntoCodingSchemeMultiAttributes.executeUpdate();
            }

            Iterator sourceIter = csl.getSource().iterator();
            while (sourceIter.hasNext())
            {
            	Object o = sourceIter.next();
                insertIntoCodingSchemeMultiAttributes.setString(1, csl.getCodingScheme());
                insertIntoCodingSchemeMultiAttributes.setString(2, "source");
                insertIntoCodingSchemeMultiAttributes.setString(3, ((Source) o).getValue());
                if (supports2006Model())
                {
                    insertIntoCodingSchemeMultiAttributes.setString(4, setBlankStringsNull(((Source) o).getSubRef()));
                    insertIntoCodingSchemeMultiAttributes.setString(5, setBlankStringsNull(((Source) o).getRole()));
                }

                insertIntoCodingSchemeMultiAttributes.executeUpdate();
            }
            insertIntoCodingSchemeMultiAttributes.close();

            insertIntoCodingSchemeSupportedAttributes = getKeyedInsertStatement(SQLTableConstants.CODING_SCHEME_SUPPORTED_ATTRIBUTES);

            Mappings mappings = getMappings(csl);
            Iterator supportedAttribute = mappings.getSupportedAssociation().iterator();
            while (supportedAttribute.hasNext())
            {
                SupportedAssociationImpl currSupportedAssociation = (SupportedAssociationImpl) supportedAttribute
                        .next();
                insertIntoCodingSchemeSupportedAttributes.setString(1, csl.getCodingScheme());
                insertIntoCodingSchemeSupportedAttributes.setString(2, "Association");
                insertIntoCodingSchemeSupportedAttributes.setString(3, currSupportedAssociation.getLocalId());
                insertIntoCodingSchemeSupportedAttributes.setString(4, setBlankStringsNull(currSupportedAssociation
                        .getUrn()));
                if (supports2006Model())
                {
                    insertIntoCodingSchemeSupportedAttributes.setString(5, setBlankStringsNull(currSupportedAssociation.getValue()));
                    insertIntoCodingSchemeSupportedAttributes.setString(6, null);
                    insertIntoCodingSchemeSupportedAttributes.setString(7, null);
                }

                insertIntoCodingSchemeSupportedAttributes.executeUpdate();
            }

            supportedAttribute = mappings.getSupportedAssociationQualifier().iterator();
            while (supportedAttribute.hasNext())
            {
                SupportedAssociationQualifier currSupportedAssociationQualifier = (SupportedAssociationQualifier) supportedAttribute
                        .next();
                insertIntoCodingSchemeSupportedAttributes.setString(1, csl.getCodingScheme());
                insertIntoCodingSchemeSupportedAttributes.setString(2, "AssociationQualifier");
                insertIntoCodingSchemeSupportedAttributes
                        .setString(3, currSupportedAssociationQualifier.getLocalId());
                insertIntoCodingSchemeSupportedAttributes.setString(4, setBlankStringsNull(currSupportedAssociationQualifier.getUrn()));
                if (supports2006Model())
                {
                    insertIntoCodingSchemeSupportedAttributes.setString(5, setBlankStringsNull(currSupportedAssociationQualifier.getValue()));
                    insertIntoCodingSchemeSupportedAttributes.setString(6, null);
                    insertIntoCodingSchemeSupportedAttributes.setString(7, null);
                }
                
                insertIntoCodingSchemeSupportedAttributes.executeUpdate();
            }

            supportedAttribute = mappings.getSupportedCodingScheme().iterator();
            while (supportedAttribute.hasNext())
            {
                SupportedCodingScheme currSupportedVal = (SupportedCodingScheme) supportedAttribute.next();
                insertIntoCodingSchemeSupportedAttributes.setString(1, csl.getCodingScheme());
                insertIntoCodingSchemeSupportedAttributes.setString(2, "CodingScheme");
                insertIntoCodingSchemeSupportedAttributes.setString(3, currSupportedVal.getLocalId());
                insertIntoCodingSchemeSupportedAttributes.setString(4, setBlankStringsNull(currSupportedVal.getUrn()));
                if (supports2006Model())
                {
                    insertIntoCodingSchemeSupportedAttributes.setString(5, setBlankStringsNull(currSupportedVal.getValue()));
                    insertIntoCodingSchemeSupportedAttributes.setString(6, null);
                    insertIntoCodingSchemeSupportedAttributes.setString(7, null);
                }
                
                insertIntoCodingSchemeSupportedAttributes.executeUpdate();
            }

            supportedAttribute = mappings.getSupportedConceptStatus().iterator();
            while (supportedAttribute.hasNext())
            {
                SupportedConceptStatus currSupportedVal = (SupportedConceptStatus) supportedAttribute.next();
                insertIntoCodingSchemeSupportedAttributes.setString(1, csl.getCodingScheme());
                insertIntoCodingSchemeSupportedAttributes.setString(2, "ConceptStatus");
                insertIntoCodingSchemeSupportedAttributes.setString(3, currSupportedVal.getLocalId());
                insertIntoCodingSchemeSupportedAttributes.setString(4, setBlankStringsNull(currSupportedVal.getUrn()));
                if (supports2006Model())
                {
                    insertIntoCodingSchemeSupportedAttributes.setString(5, setBlankStringsNull(currSupportedVal.getValue()));
                    insertIntoCodingSchemeSupportedAttributes.setString(6, null);
                    insertIntoCodingSchemeSupportedAttributes.setString(7, null);
                }
                
                insertIntoCodingSchemeSupportedAttributes.executeUpdate();
            }

            supportedAttribute = mappings.getSupportedContext().iterator();
            while (supportedAttribute.hasNext())
            {
                SupportedContext currSupportedVal = (SupportedContext) supportedAttribute.next();
                insertIntoCodingSchemeSupportedAttributes.setString(1, csl.getCodingScheme());
                insertIntoCodingSchemeSupportedAttributes.setString(2, "Context");
                insertIntoCodingSchemeSupportedAttributes.setString(3, currSupportedVal.getLocalId());
                insertIntoCodingSchemeSupportedAttributes.setString(4, setBlankStringsNull(currSupportedVal.getUrn()));
                if (supports2006Model())
                {
                    insertIntoCodingSchemeSupportedAttributes.setString(5, setBlankStringsNull(currSupportedVal.getValue()));
                    insertIntoCodingSchemeSupportedAttributes.setString(6, null);
                    insertIntoCodingSchemeSupportedAttributes.setString(7, null);
                }
                
                insertIntoCodingSchemeSupportedAttributes.executeUpdate();
            }

            supportedAttribute = mappings.getSupportedFormat().iterator();
            while (supportedAttribute.hasNext())
            {
                SupportedFormat currSupportedVal = (SupportedFormat) supportedAttribute.next();
                insertIntoCodingSchemeSupportedAttributes.setString(1, csl.getCodingScheme());
                insertIntoCodingSchemeSupportedAttributes.setString(2, "Format");
                insertIntoCodingSchemeSupportedAttributes.setString(3, currSupportedVal.getLocalId());
                insertIntoCodingSchemeSupportedAttributes.setString(4, setBlankStringsNull(currSupportedVal.getUrn()));
                if (supports2006Model())
                {
                    insertIntoCodingSchemeSupportedAttributes.setString(5, setBlankStringsNull(currSupportedVal.getValue()));
                    insertIntoCodingSchemeSupportedAttributes.setString(6, null);
                    insertIntoCodingSchemeSupportedAttributes.setString(7, null);
                }
                
                insertIntoCodingSchemeSupportedAttributes.executeUpdate();
            }

            supportedAttribute = mappings.getSupportedLanguage().iterator();
            while (supportedAttribute.hasNext())
            {
                SupportedLanguage currSupportedVal = (SupportedLanguage) supportedAttribute.next();
                insertIntoCodingSchemeSupportedAttributes.setString(1, csl.getCodingScheme());
                insertIntoCodingSchemeSupportedAttributes.setString(2, "Language");
                insertIntoCodingSchemeSupportedAttributes.setString(3, currSupportedVal.getLocalId());
                insertIntoCodingSchemeSupportedAttributes.setString(4, setBlankStringsNull(currSupportedVal.getUrn()));
                if (supports2006Model())
                {
                    insertIntoCodingSchemeSupportedAttributes.setString(5, setBlankStringsNull(currSupportedVal.getValue()));
                    insertIntoCodingSchemeSupportedAttributes.setString(6, null);
                    insertIntoCodingSchemeSupportedAttributes.setString(7, null);
                }
                
                insertIntoCodingSchemeSupportedAttributes.executeUpdate();
            }

            supportedAttribute = mappings.getSupportedProperty().iterator();
            while (supportedAttribute.hasNext())
            {
                SupportedProperty currSupportedVal = (SupportedProperty) supportedAttribute.next();
                insertIntoCodingSchemeSupportedAttributes.setString(1, csl.getCodingScheme());
                insertIntoCodingSchemeSupportedAttributes.setString(2, "Property");
                insertIntoCodingSchemeSupportedAttributes.setString(3, currSupportedVal.getLocalId());
                insertIntoCodingSchemeSupportedAttributes.setString(4, setBlankStringsNull(currSupportedVal.getUrn()));
                if (supports2006Model())
                {
                    insertIntoCodingSchemeSupportedAttributes.setString(5, setBlankStringsNull(currSupportedVal.getValue()));
                    insertIntoCodingSchemeSupportedAttributes.setString(6, null);
                    insertIntoCodingSchemeSupportedAttributes.setString(7, null);
                }
                
                insertIntoCodingSchemeSupportedAttributes.executeUpdate();
            }

            supportedAttribute = mappings.getSupportedRepresentationalForm().iterator();
            while (supportedAttribute.hasNext())
            {
                SupportedRepresentationalForm currSupportedVal = (SupportedRepresentationalForm) supportedAttribute
                        .next();
                insertIntoCodingSchemeSupportedAttributes.setString(1, csl.getCodingScheme());
                insertIntoCodingSchemeSupportedAttributes.setString(2, "RepresentationalForm");
                insertIntoCodingSchemeSupportedAttributes.setString(3, currSupportedVal.getLocalId());
                insertIntoCodingSchemeSupportedAttributes.setString(4, setBlankStringsNull(currSupportedVal.getUrn()));
                if (supports2006Model())
                {
                    insertIntoCodingSchemeSupportedAttributes.setString(5, setBlankStringsNull(currSupportedVal.getValue()));
                    insertIntoCodingSchemeSupportedAttributes.setString(6, null);
                    insertIntoCodingSchemeSupportedAttributes.setString(7, null);
                }
                
                insertIntoCodingSchemeSupportedAttributes.executeUpdate();
            }

            supportedAttribute = mappings.getSupportedSource().iterator();
            while (supportedAttribute.hasNext())
            {
                SupportedSource currSupportedVal = (SupportedSource) supportedAttribute.next();
                insertIntoCodingSchemeSupportedAttributes.setString(1, csl.getCodingScheme());
                insertIntoCodingSchemeSupportedAttributes.setString(2, "Source");
                insertIntoCodingSchemeSupportedAttributes.setString(3, currSupportedVal.getLocalId());
                insertIntoCodingSchemeSupportedAttributes.setString(4, setBlankStringsNull(currSupportedVal.getUrn()));
                if (supports2006Model())
                {
                    insertIntoCodingSchemeSupportedAttributes.setString(5, setBlankStringsNull(currSupportedVal.getValue()));
                    insertIntoCodingSchemeSupportedAttributes.setString(6, setBlankStringsNull(currSupportedVal.getAssemblyRule()));
                    insertIntoCodingSchemeSupportedAttributes.setString(7, setBlankStringsNull(currSupportedVal.getAgentRole()));
                }
                
                insertIntoCodingSchemeSupportedAttributes.executeUpdate();
            }
            
            supportedAttribute = mappings.getSupportedPropertyLink().iterator();
            while (supportedAttribute.hasNext())
            {
                SupportedPropertyLink currSupportedVal = (SupportedPropertyLink) supportedAttribute.next();
                insertIntoCodingSchemeSupportedAttributes.setString(1, csl.getCodingScheme());
                insertIntoCodingSchemeSupportedAttributes.setString(2, "PropertyLink");
                insertIntoCodingSchemeSupportedAttributes.setString(3, currSupportedVal.getLocalId());
                insertIntoCodingSchemeSupportedAttributes.setString(4, setBlankStringsNull(currSupportedVal.getUrn()));
                if (supports2006Model())
                {
                    insertIntoCodingSchemeSupportedAttributes.setString(5, setBlankStringsNull(currSupportedVal.getValue()));
                    insertIntoCodingSchemeSupportedAttributes.setString(6, null);
                    insertIntoCodingSchemeSupportedAttributes.setString(7, null);
                }    
                
                insertIntoCodingSchemeSupportedAttributes.executeUpdate();
            }
            
            supportedAttribute = mappings.getSupportedPropertyQualifier().iterator();
            while (supportedAttribute.hasNext())
            {
                SupportedPropertyQualifier currSupportedVal = (SupportedPropertyQualifier) supportedAttribute.next();
                insertIntoCodingSchemeSupportedAttributes.setString(1, csl.getCodingScheme());
                insertIntoCodingSchemeSupportedAttributes.setString(2, "PropertyQualifier");
                insertIntoCodingSchemeSupportedAttributes.setString(3, currSupportedVal.getLocalId());
                insertIntoCodingSchemeSupportedAttributes.setString(4, setBlankStringsNull(currSupportedVal.getUrn()));
                if (supports2006Model())
                {
                    insertIntoCodingSchemeSupportedAttributes.setString(5, setBlankStringsNull(currSupportedVal.getValue()));
                    insertIntoCodingSchemeSupportedAttributes.setString(6, null);
                    insertIntoCodingSchemeSupportedAttributes.setString(7, null);
                }   
                
                insertIntoCodingSchemeSupportedAttributes.executeUpdate();
            }

            Iterator conceptsIterator = csl.getConcepts().getConcept().iterator();
            while (conceptsIterator.hasNext())
            {
                conceptsService_.insert((CodedEntry) conceptsIterator.next());
            }

            Iterator relationsIter = csl.getRelations().iterator();
            while (relationsIter.hasNext())
            {
                relationsService_.insert((Relations) relationsIter.next());
            }
        }
        catch (SQLException e)
        {
            throw new ObjectAlreadyExistsException(e);
        }
        catch (Exception e)
        {
            throw new InsertException(e);
        }
        finally
        {
            try
            {
                if (insertIntoCodingScheme != null)
                {
                    insertIntoCodingScheme.close();
                }
                insertIntoCodingSchemeMultiAttributes.close();
                insertIntoCodingSchemeSupportedAttributes.close();
            }
            catch (Exception e)
            {
                // do nothing
            }
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.managedobj.HomeServiceIF#remove(org.LexGrid.managedobj.ManagedObjIF)
     */
    public void remove(ManagedObjIF obj) throws RemoveException, ObjectNotFoundException
    {
	   try
	    {
	        CodingSchemeTypeImpl csl = (CodingSchemeTypeImpl) (obj);
	
	        SQLTableUtilities utilities = new SQLTableUtilities(getWriteConnection(), getPrefix());
	
	        utilities.cleanTables(csl.getCodingScheme());
	
	    }
	    catch (Exception e)
	    {
	        throw new RemoveException("Problem while doing the remove", e);
	    }
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.managedobj.HomeServiceIF#update(org.LexGrid.managedobj.ManagedObjIF)
     */
    public void update(ManagedObjIF obj) throws UpdateException, ObjectNotFoundException
    {
        // TODO: Implement update
        throw new java.lang.UnsupportedOperationException("Method update not yet implemented.");
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.plugin.base.service.LgModelPersistence#query()
     */
    public ManagedObjIterator query() throws QueryException
    {
        // TODO: Implement query
        throw new java.lang.UnsupportedOperationException("Method query not yet implemented.");
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.persistence.ldap.LdapBaseService#getInstanceClass()
     */
    protected Class getInstanceClass()
    {
        return CodingSchemeTypeImpl.class;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.plugin.base.service.LgModelPersistence#synchronize(org.LexGrid.plugin.base.LgModelObj,
     *      boolean)
     */
    public void synchronize(LgModelObj obj, boolean recurse) throws ManagedObjException
    {
        // TODO: Implement synchronize
        throw new java.lang.UnsupportedOperationException("Method synchronize not yet implemented.");
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.plugin.base.LgSearchable#queryConcepts(org.LexGrid.plugin.base.LgModelObj,
     *      org.LexGrid.plugin.base.LgConstraint[], int)
     */
    public ManagedObjIterator queryConcepts(LgModelObj root, LgConstraint[] constraints, int limit)
            throws QueryException
    {
        conceptsService_.setEContext(root, CodingschemesPackage.eINSTANCE.getCodingSchemeType_Concepts());
        return conceptsService_.queryConcepts(constraints, limit);
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.plugin.base.LgSearchable#queryRelationSources(org.LexGrid.plugin.base.LgModelObj,
     *      java.lang.String, int)
     */
    public ManagedObjIterator queryRelationSources(LgModelObj root, String code, int limit) throws QueryException
    {
    	relationsService_.setEContext(root, CodingschemesPackage.eINSTANCE.getCodingSchemeType_Relations());
        return relationsService_.queryRelationSources(code, limit);
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.plugin.base.LgSearchable#queryRelationTargets(org.LexGrid.plugin.base.LgModelObj,
     *      java.lang.String, java.lang.String, int)
     */
    public ManagedObjIterator queryRelationTargets(LgModelObj root, String targetContext, String targetCode, int limit)
            throws QueryException
    {
    	relationsService_.setEContext(root, CodingschemesPackage.eINSTANCE.getCodingSchemeType_Relations());
        return relationsService_.queryRelationTargets(targetContext, targetCode, limit);
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.org.LexGrid.commons.managedobj.service.BaseService#initNestedServices()
     */
    protected void initNestedServices() throws ServiceInitException
    {
        conceptsService_ = new CodedEntryService(this);
        relationsService_ = new RelationsService(this);
    }

    public void stageFeature(LgStagedObj obj, EStructuralFeature feature) throws ResolveException
    {
        try
        {
            if (obj instanceof CodingSchemeType)
            {
                //mark everything as complete
                Iterator iterator = ((CodingSchemeType)obj).eClass().getEAllStructuralFeatures().iterator();
                while (iterator.hasNext())
                {
                    EStructuralFeature temp = (EStructuralFeature)iterator.next();
                    obj.stageComplete(temp);
                }
                
                obj.stageComplete(feature);

                //I have to call this after setting everything to feature complete.
                //this loads all other missing features.
                getSubProperties((CodingSchemeType)obj);
            }
        }
        catch (Exception e)
        {
            throw new ResolveException("Problem getting the sub-details for the coding scheme", e);
        }
    }
}