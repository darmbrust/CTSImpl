/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence.sql;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;

import org.LexGrid.emf.base.LgCodedObj;
import org.LexGrid.emf.commonTypes.CommontypesFactory;
import org.LexGrid.emf.commonTypes.Property;
import org.LexGrid.emf.commonTypes.PropertyQualifier;
import org.LexGrid.emf.commonTypes.Source;
import org.LexGrid.emf.commonTypes.impl.PropertyImpl;
import org.LexGrid.emf.concepts.CodedEntry;
import org.LexGrid.emf.concepts.ConceptsFactory;
import org.LexGrid.emf.concepts.impl.CommentImpl;
import org.LexGrid.emf.concepts.impl.DefinitionImpl;
import org.LexGrid.emf.concepts.impl.InstructionImpl;
import org.LexGrid.emf.concepts.impl.PresentationImpl;
import org.LexGrid.emf.concepts.util.ConceptsUtil;
import org.LexGrid.managedobj.FindException;
import org.LexGrid.managedobj.InsertException;
import org.LexGrid.managedobj.ManagedObjIF;
import org.LexGrid.managedobj.ObjectAlreadyExistsException;
import org.LexGrid.managedobj.ServiceInitException;
import org.LexGrid.managedobj.jdbc.JDBCBaseService;
import org.LexGrid.util.sql.lgTables.SQLTableConstants;

/**
 * <pre>
 * Title:        PropertyService.java
 * Description:  Class that handles properties to and from the database.
 * </pre>
 * 
 * @author <A HREF="mailto:armbrust.daniel@mayo.edu">Dan Armbrust </A>
 * @version 1.0 - cvs $Revision: 1.9 $ checked in on $Date: 2005/06/16 16:48:46 $
 */
public class PropertyService extends LGBaseService
{
    public PropertyService(JDBCBaseService anchorService) throws ServiceInitException
    {
        super(anchorService);
    }
    
    public void resolveAll() throws FindException
    {
        PreparedStatement selectFromConceptProperty = null;
        PreparedStatement selectFromConceptPropertyMultiAttributes = null;
        PreparedStatement selectFromConceptPropertyQualifiers = null;

        try
        {
            int propertyCount = 0;
            selectFromConceptProperty = checkOutPreparedStatement("SELECT * FROM " + getTableName(SQLTableConstants.CONCEPT_PROPERTY) + " WHERE codingSchemeName = ? AND conceptCode = ?");
            selectFromConceptPropertyMultiAttributes = checkOutPreparedStatement("SELECT * FROM " + getTableName(SQLTableConstants.CONCEPT_PROPERTY_MULTI_ATTRIBUTES) + " WHERE codingSchemeName = ? AND conceptCode = ? AND propertyId = ?");
            
            if (supportsPropertyQualifiers() && !supports2006Model())
            {
                selectFromConceptPropertyQualifiers = checkOutPreparedStatement("SELECT qualifierName, qualifierValue FROM " + getTableName(SQLTableConstants.CONCEPT_PROPERTY_QUALIFIERS) + " WHERE codingSchemeName = ? AND conceptCode = ? AND propertyId = ?");
            }
            
            selectFromConceptProperty.setString(1, getCodingSchemeName());
            selectFromConceptProperty.setString(2, getConceptCode());

            ResultSet results = selectFromConceptProperty.executeQuery();

            while (results.next())
            {
                Property currConceptProperty = null;
                String property = results.getString("property");
                String propertyType;
                if (supports2006Model())
                {
                    propertyType = results.getString("propertyType");
                }
                else
                {
                    if (property.equals("textualPresentation"))
                    {
                        propertyType = "presentation";
                    }
                    else if (property.equals("definition"))
                    {
                        propertyType = "definition";
                    }
                    else if (property.equals("comment"))
                    {
                        propertyType = "comment";
                    }
                    else if (property.equals("instruction"))
                    {
                        propertyType = "instruction";
                    }
                    else
                    {
                        propertyType = "property";
                    }
                }

                if (propertyType.equals("definition"))
                {
                    currConceptProperty = ConceptsFactory.eINSTANCE.createDefinition();
                    Boolean temp = getBooleanFromResultSet(results, "isPreferred");
                    if (temp != null)
                    {
                    	((DefinitionImpl) currConceptProperty).setIsPreferred(temp);
                    }
                }
                else if (propertyType.equals("presentation"))
                {
                    currConceptProperty = ConceptsFactory.eINSTANCE.createPresentation();
                    Boolean temp = getBooleanFromResultSet(results, "isPreferred");
                    if (temp != null)
                    {
                    	((PresentationImpl) currConceptProperty).setIsPreferred(temp);
                    }
                    ((PresentationImpl) currConceptProperty).setDegreeOfFidelity(results.getString("degreeOfFidelity"));
                    
                    temp = getBooleanFromResultSet(results, "matchIfNoContext");
                    if (temp != null)
                    {                    
                    	((PresentationImpl) currConceptProperty).setMatchIfNoContext(temp);
                    }
                    ((PresentationImpl) currConceptProperty).setRepresentationalForm(results
                            .getString("representationalForm"));

                }
                else if (propertyType.equals("comment"))
                {
                    currConceptProperty = ConceptsFactory.eINSTANCE.createComment();
                }
                else if (propertyType.equals("instruction"))
                {
                    currConceptProperty = ConceptsFactory.eINSTANCE.createInstruction();
                }
                else
                {
                    currConceptProperty = ConceptsFactory.eINSTANCE.createConceptProperty();
                }

                
                currConceptProperty.setLanguage(results.getString("language"));
                currConceptProperty.setProperty(property);
                currConceptProperty.setPresentationFormat(results.getString("presentationFormat"));
                currConceptProperty.setPropertyId(results.getString("propertyId"));
                currConceptProperty.setText(results.getString("propertyValue"));

                selectFromConceptPropertyMultiAttributes.setString(1, getCodingSchemeName());
                selectFromConceptPropertyMultiAttributes.setString(2, getConceptCode());
                selectFromConceptPropertyMultiAttributes.setString(3, currConceptProperty.getPropertyId());
                ResultSet results2 = selectFromConceptPropertyMultiAttributes.executeQuery();
                while (results2.next())
                {
                    String attrName = results2.getString(supports2006Model() ? "typeName" : "attributeName");
                    String attrValue = results2.getString("attributeValue");
                    if (attrName.equalsIgnoreCase("source"))
                    {
                        Source s = CommontypesFactory.eINSTANCE.createSource();
                        s.setValue(attrValue);
                        if (supports2006Model())
                        {
                            s.setRole(results2.getString("val2"));
                            s.setSubRef(results2.getString("val1"));
                        }
                        currConceptProperty.getSource().add(s);
                    }
                    else if (attrName.equalsIgnoreCase("usageContext"))
                    {
                        currConceptProperty.getUsageContext().add(attrValue);
                    }
                    else if (attrName.equalsIgnoreCase("qualifier") && supports2006Model())
                    {
                        PropertyQualifier pq = CommontypesFactory.eINSTANCE.createPropertyQualifier();
                        pq.setPropertyQualifierId(attrValue);
                        pq.setValue(results2.getString("val1"));
                        currConceptProperty.getPropertyQualifier().add(pq);
                    }

                }
                results2.close();
                
                if (supportsPropertyQualifiers() && !supports2006Model())
                {
                    selectFromConceptPropertyQualifiers.setString(1, getCodingSchemeName());
                    selectFromConceptPropertyQualifiers.setString(2, getConceptCode());
                    selectFromConceptPropertyQualifiers.setString(3, currConceptProperty.getPropertyId());
                    results2 = selectFromConceptPropertyQualifiers.executeQuery();
                    while (results2.next())
                    {
                        PropertyQualifier pq = CommontypesFactory.eINSTANCE.createPropertyQualifier();
                        pq.setPropertyQualifierId(results2.getString("qualifierName"));
                        pq.setValue(results2.getString("qualifierValue"));
                        currConceptProperty.getPropertyQualifier().add(pq);
                    }
                    results2.close();
                }
                
                ConceptsUtil.addProperty((CodedEntry) getEContainer(), currConceptProperty);
                propertyCount++;

            }
            results.close();
        }
        catch (SQLException e)
        {
            throw new FindException(e);
        }
        finally
        {
            checkInPreparedStatement(selectFromConceptProperty);
            checkInPreparedStatement(selectFromConceptPropertyMultiAttributes);
            checkInPreparedStatement(selectFromConceptPropertyQualifiers);
        }

    }

    public void insert(ManagedObjIF obj) throws InsertException, ObjectAlreadyExistsException
    {
        PreparedStatement insertIntoConceptProperty = null;
        PreparedStatement insertIntoConceptPropertyMultiAttributes = null;
        PreparedStatement insertIntoConceptPropertyQualifiers = null;
        try
        {
            Property currProperty = (Property) (obj);
            String codingSchemeName = getCodingScheme(currProperty).getCodingScheme();
            String conceptCode = ((LgCodedObj) currProperty.eContainer()).getConceptCode();
            
            insertIntoConceptProperty = getKeyedInsertStatement(SQLTableConstants.CONCEPT_PROPERTY);

            if (currProperty instanceof PresentationImpl)
            {
                PresentationImpl temp = (PresentationImpl) (currProperty);
                int k = 1;
                insertIntoConceptProperty.setString(k++, codingSchemeName);
                insertIntoConceptProperty.setString(k++, conceptCode);
                insertIntoConceptProperty.setString(k++, temp.getPropertyId());
                if (supports2006Model())
                {
                    insertIntoConceptProperty.setString(k++, "presentation");
                }
                insertIntoConceptProperty.setString(k++, supports2006Model() ? temp.getProperty() : "textualPresentation");
                insertIntoConceptProperty.setString(k++, temp.getLanguage());
                insertIntoConceptProperty.setString(k++, temp.getPresentationFormat());
                if (!supports2006Model())
                {
                    insertIntoConceptProperty.setString(k++, "");
                }
                setBooleanOnPreparedStatment(insertIntoConceptProperty, k++, temp.getIsPreferred());
                insertIntoConceptProperty.setString(k++, temp.getDegreeOfFidelity());
                setBooleanOnPreparedStatment(insertIntoConceptProperty, k++, temp.getMatchIfNoContext());
                insertIntoConceptProperty.setString(k++, temp.getRepresentationalForm());
                insertIntoConceptProperty.setString(k++, temp.getText());
            }
            else if (currProperty instanceof DefinitionImpl)
            {
                int k = 1;
                DefinitionImpl temp = (DefinitionImpl) (currProperty);
                insertIntoConceptProperty.setString(k++, codingSchemeName);
                insertIntoConceptProperty.setString(k++, conceptCode);
                insertIntoConceptProperty.setString(k++, temp.getPropertyId());
                if (supports2006Model())
                {
                    insertIntoConceptProperty.setString(k++, "definition");
                }
                insertIntoConceptProperty.setString(k++, supports2006Model() ? temp.getProperty() : "definition");
                insertIntoConceptProperty.setString(k++, temp.getLanguage());
                insertIntoConceptProperty.setString(k++, temp.getPresentationFormat());
                if (!supports2006Model())
                {
                    insertIntoConceptProperty.setString(k++, "");
                }
                setBooleanOnPreparedStatment(insertIntoConceptProperty, k++, temp.getIsPreferred());//preferred
                insertIntoConceptProperty.setString(k++, null);
                setBooleanOnPreparedStatment(insertIntoConceptProperty, k++, new Boolean(null));//match if no
                // context
                insertIntoConceptProperty.setString(k++, null);
                insertIntoConceptProperty.setString(k++, temp.getText());
            }
            else if (currProperty instanceof CommentImpl)
            {
                int k = 1;
                CommentImpl temp = (CommentImpl) (currProperty);
                insertIntoConceptProperty.setString(k++, codingSchemeName);
                insertIntoConceptProperty.setString(k++, conceptCode);
                insertIntoConceptProperty.setString(k++, temp.getPropertyId());
                if (supports2006Model())
                {
                    insertIntoConceptProperty.setString(k++, "comment");
                }
                insertIntoConceptProperty.setString(k++, supports2006Model() ? temp.getProperty() : "comment");
                insertIntoConceptProperty.setString(k++, temp.getLanguage());
                insertIntoConceptProperty.setString(k++, temp.getPresentationFormat());
                if (!supports2006Model())
                {
                    insertIntoConceptProperty.setString(k++, null);
                }
                setBooleanOnPreparedStatment(insertIntoConceptProperty, k++, new Boolean(null));
                insertIntoConceptProperty.setString(k++, null);
                setBooleanOnPreparedStatment(insertIntoConceptProperty, k++, new Boolean(null));
                insertIntoConceptProperty.setString(k++, null);
                insertIntoConceptProperty.setString(k++, temp.getText());
            }
            else if (currProperty instanceof InstructionImpl)
            {
                int k = 1;
                InstructionImpl temp = (InstructionImpl) (currProperty);
                insertIntoConceptProperty.setString(k++, codingSchemeName);
                insertIntoConceptProperty.setString(k++, conceptCode);
                insertIntoConceptProperty.setString(k++, temp.getPropertyId());
                if (supports2006Model())
                {
                    insertIntoConceptProperty.setString(k++, "instruction");
                }
                insertIntoConceptProperty.setString(k++, supports2006Model() ? temp.getProperty() : "instruction");
                insertIntoConceptProperty.setString(k++, temp.getLanguage());
                insertIntoConceptProperty.setString(k++, temp.getPresentationFormat());
                if (!supports2006Model())
                {
                    insertIntoConceptProperty.setString(k++, null);
                }
                setBooleanOnPreparedStatment(insertIntoConceptProperty, k++, new Boolean(null));
                insertIntoConceptProperty.setString(k++, null);
                setBooleanOnPreparedStatment(insertIntoConceptProperty, k++, new Boolean(null));
                insertIntoConceptProperty.setString(k++, null);
                insertIntoConceptProperty.setString(k++, temp.getText());
            }

            else
            {
                int k = 1;
                String propName = currProperty.getProperty();
                if (propName == null || propName.length() == 0)
                {
                    propName = "property";
                }
                insertIntoConceptProperty.setString(k++, codingSchemeName);
                insertIntoConceptProperty.setString(k++, conceptCode);
                insertIntoConceptProperty.setString(k++, currProperty.getPropertyId());
                if (supports2006Model())
                {
                    insertIntoConceptProperty.setString(k++, "property");
                }
                insertIntoConceptProperty.setString(k++, propName);
                insertIntoConceptProperty.setString(k++, currProperty.getLanguage());
                insertIntoConceptProperty.setString(k++, currProperty.getPresentationFormat());
                if (!supports2006Model())
                {
                    insertIntoConceptProperty.setString(k++, null);
                }
                setBooleanOnPreparedStatment(insertIntoConceptProperty, k++, new Boolean(null));//is preferred
                insertIntoConceptProperty.setString(k++, null);
                setBooleanOnPreparedStatment(insertIntoConceptProperty, k++, new Boolean(null));//is match if no
                // context
                insertIntoConceptProperty.setString(k++, null);
                insertIntoConceptProperty.setString(k++, currProperty.getText());
            }
            insertIntoConceptProperty.executeUpdate();
            insertIntoConceptProperty.close();
            
            
            insertIntoConceptPropertyMultiAttributes = getKeyedInsertStatement(SQLTableConstants.CONCEPT_PROPERTY_MULTI_ATTRIBUTES);

            Iterator sourceIterator = currProperty.getSource().iterator();
            while (sourceIterator.hasNext())
            {
                Source currSource = (Source)sourceIterator.next();
                insertIntoConceptPropertyMultiAttributes.setString(1, codingSchemeName);
                insertIntoConceptPropertyMultiAttributes.setString(2, conceptCode);
                insertIntoConceptPropertyMultiAttributes.setString(3, currProperty.getPropertyId());
                insertIntoConceptPropertyMultiAttributes.setString(4, "source");
                insertIntoConceptPropertyMultiAttributes.setString(5, currSource.getValue());
                if (supports2006Model())
                {
                    insertIntoConceptPropertyMultiAttributes.setString(6, currSource.getSubRef());
                    insertIntoConceptPropertyMultiAttributes.setString(7, currSource.getRole());
                }
                insertIntoConceptPropertyMultiAttributes.executeUpdate();
            }

            Iterator usageContextIterator = currProperty.getUsageContext().iterator();
            while (usageContextIterator.hasNext())
            {
                String currUsageContext = usageContextIterator.next().toString();
                insertIntoConceptPropertyMultiAttributes.setString(1, codingSchemeName);
                insertIntoConceptPropertyMultiAttributes.setString(2, conceptCode);
                insertIntoConceptPropertyMultiAttributes.setString(3, currProperty.getPropertyId());
                insertIntoConceptPropertyMultiAttributes.setString(4, "usageContext");
                insertIntoConceptPropertyMultiAttributes.setString(5, currUsageContext);
                if (supports2006Model())
                {
                    insertIntoConceptPropertyMultiAttributes.setString(6, null);
                    insertIntoConceptPropertyMultiAttributes.setString(7, null);
                }
                insertIntoConceptPropertyMultiAttributes.executeUpdate();
            }
            
            if (!supports2006Model())
            {
                insertIntoConceptPropertyMultiAttributes.close();
                insertIntoConceptPropertyQualifiers = getKeyedInsertStatement(SQLTableConstants.CONCEPT_PROPERTY_QUALIFIERS);
                
                Iterator propertyQualifierIterator = currProperty.getPropertyQualifier().iterator();
                while (propertyQualifierIterator.hasNext())
                {
                    PropertyQualifier currentQualifier = (PropertyQualifier) propertyQualifierIterator.next();
                    insertIntoConceptPropertyQualifiers.setString(1, codingSchemeName);
                    insertIntoConceptPropertyQualifiers.setString(2, conceptCode);
                    insertIntoConceptPropertyQualifiers.setString(3, currProperty.getPropertyId());
                    insertIntoConceptPropertyQualifiers.setString(4, currentQualifier.getPropertyQualifierId());
                    insertIntoConceptPropertyQualifiers.setString(5, currentQualifier.getValue());         
                    insertIntoConceptPropertyQualifiers.executeUpdate();
                }
            }
            else
            {
                Iterator propertyQualifierIterator = currProperty.getPropertyQualifier().iterator();
                while (propertyQualifierIterator.hasNext())
                {
                    PropertyQualifier currentQualifier = (PropertyQualifier) propertyQualifierIterator.next();
                    insertIntoConceptPropertyMultiAttributes.setString(1, codingSchemeName);
                    insertIntoConceptPropertyMultiAttributes.setString(2, conceptCode);
                    insertIntoConceptPropertyMultiAttributes.setString(3, currProperty.getPropertyId());
                    insertIntoConceptPropertyMultiAttributes.setString(4, "qualifier");
                    insertIntoConceptPropertyMultiAttributes.setString(5, currentQualifier.getPropertyQualifierId());
                    insertIntoConceptPropertyMultiAttributes.setString(6, currentQualifier.getValue());
                    insertIntoConceptPropertyMultiAttributes.setString(7, null);
                    insertIntoConceptPropertyMultiAttributes.executeUpdate();
                }
                insertIntoConceptPropertyMultiAttributes.close();
            }
            
        }
        catch (SQLException e)
        {
            throw new ObjectAlreadyExistsException("Error inserting property " + ((Property) (obj)).getPropertyId()
                    + " on concept " + ((CodedEntry)(((Property) obj).eContainer())).getConceptCode(), e);
        }
        catch (Exception e)
        {
            throw new InsertException("Error inserting property " + ((Property) (obj)).getPropertyId() + " on concept "
                    + ((CodedEntry)(((Property) obj).eContainer())).getConceptCode(), e);
        }
        finally
        {
            try
            {
                insertIntoConceptProperty.close();
                insertIntoConceptPropertyMultiAttributes.close();
                if (insertIntoConceptPropertyQualifiers != null)
                {
                    insertIntoConceptPropertyQualifiers.close();
                }
                
            }
            catch (Exception e)
            {
                // do nothing
                
            }
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.managedobj.service.BaseService#getInstanceClass()
     */
    protected Class getInstanceClass()
    {
        return PropertyImpl.class;
    }
}