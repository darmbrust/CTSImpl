/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence.sql;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;

import org.LexGrid.emf.base.impl.LgBasicEListImpl;
import org.LexGrid.emf.codingSchemes.CodingSchemeType;
import org.LexGrid.emf.commonTypes.CommontypesFactory;
import org.LexGrid.emf.commonTypes.Source;
import org.LexGrid.emf.relations.Association;
import org.LexGrid.emf.relations.Relations;
import org.LexGrid.emf.relations.RelationsFactory;
import org.LexGrid.emf.relations.RelationsPackage;
import org.LexGrid.emf.relations.impl.RelationsImpl;
import org.LexGrid.managedobj.FindException;
import org.LexGrid.managedobj.InsertException;
import org.LexGrid.managedobj.ManagedObjIF;
import org.LexGrid.managedobj.ManagedObjIterator;
import org.LexGrid.managedobj.ManagedObjIteratorWrapper;
import org.LexGrid.managedobj.ObjectAlreadyExistsException;
import org.LexGrid.managedobj.QueryException;
import org.LexGrid.managedobj.ServiceInitException;
import org.LexGrid.managedobj.jdbc.JDBCBaseService;
import org.LexGrid.util.sql.lgTables.SQLTableConstants;

/**
 * <pre>
 * Title:        RelationsService.java
 * Description:  Class that handles the relations objects to and from the database.
 * </pre>
 * 
 * @author <A HREF="mailto:armbrust.daniel@mayo.edu">Dan Armbrust </A>
 * @version 1.0 - cvs $Revision: 1.11 $ checked in on $Date: 2005/06/16 16:48:45 $
 */
public class RelationsService extends LGBaseService
{
	private AssociationsService associationsService_;

	public RelationsService(JDBCBaseService anchorService) throws ServiceInitException
	{
		super(anchorService);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.LexGrid.managedobj.service.BaseService#getInstanceClass()
	 */
	protected Class getInstanceClass()
	{
		return RelationsImpl.class;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.LexGrid.managedobj.service.BaseService#initNestedServices()
	 */
	protected void initNestedServices() throws ServiceInitException
	{
		associationsService_ = new AssociationsService(this);
	}

	public ManagedObjIterator queryRelationSources(String code, int limit) throws QueryException
	{
		LgBasicEListImpl list = new LgBasicEListImpl();
		list.setPageSize(limit);

		Iterator iterator = ((CodingSchemeType) getEContainer()).getRelations().iterator();
		boolean noLimit = limit == 0;

		while (iterator.hasNext())
		{
			int remainingLimit = noLimit ? 0
					: limit - list.size();
			if (noLimit || remainingLimit > 0)
			{
				Relations temp = (Relations) iterator.next();
				associationsService_.setEContext(temp, RelationsPackage.eINSTANCE.getRelations_Association());
				list.addAll(associationsService_.queryRelationSources(code, remainingLimit));
			}
		}
		return new ManagedObjIteratorWrapper(list.iterator());
	}

	public ManagedObjIterator queryRelationTargets(String targetContext, String targetCode, int limit)
	throws QueryException
	{
		LgBasicEListImpl list = new LgBasicEListImpl();
		list.setPageSize(limit);

		Iterator iterator = ((CodingSchemeType) getEContainer()).getRelations().iterator();
		boolean noLimit = limit == 0;

		while (iterator.hasNext())
		{
			int remainingLimit = noLimit ? 0
					: limit - list.size();
			if (noLimit || remainingLimit > 0)
			{
				Relations temp = (Relations) iterator.next();
				associationsService_.setEContext(temp, RelationsPackage.eINSTANCE.getRelations_Association());
				list.addAll(associationsService_.queryRelationTargets(targetContext, targetCode, remainingLimit));
			}
		}
		return new ManagedObjIteratorWrapper(list.iterator());
	}

	public void resolveAll() throws FindException
	{
		PreparedStatement selectFromRelations = null;
		PreparedStatement selectFromRelationsMultiAttributes = null;
		CodingSchemeType codingScheme = (CodingSchemeType) getEContainer();

		try
		{
			selectFromRelations = checkOutPreparedStatement(modifySql("SELECT * FROM " + getTableName(SQLTableConstants.RELATION) + " WHERE codingSchemeName = ?"));
			selectFromRelationsMultiAttributes = checkOutPreparedStatement("SELECT * FROM " + getTableName(SQLTableConstants.RELATION_MULTI_ATTRIBUTES) + " WHERE codingSchemeName = ? AND relationName = ?");

			selectFromRelations.setString(1, codingScheme.getCodingScheme());
			ResultSet results = selectFromRelations.executeQuery();

			while (results.next())
			{
				Relations currRelation = RelationsFactory.eINSTANCE.createRelations();
				currRelation.setEntityDescription(results.getString("entityDescription"));
				Boolean temp = getBooleanFromResultSet(results, "isNative");
				if (temp != null)
				{
					currRelation.setIsNative(temp);
				}
				currRelation.setDc(results.getString("relationName"));

				selectFromRelationsMultiAttributes.setString(1, codingScheme.getCodingScheme());
				selectFromRelationsMultiAttributes.setString(2, currRelation.getDc());
				ResultSet results2 = selectFromRelationsMultiAttributes.executeQuery();
				while (results2.next())
				{
					String attrName = results2.getString(supports2006Model() ? "typeName" : "attributeName");
					String attrValue = results2.getString("attributeValue");
					if (attrName.equals("source"))
					{
                        Source s = CommontypesFactory.eINSTANCE.createSource();
                        s.setValue(attrValue);
                        if (supports2006Model())
                        {
                            s.setRole(results2.getString("val2"));
                            s.setSubRef(results2.getString("val1"));
                        }
						currRelation.getSource().add(s);
					}
				}
				results2.close();
				codingScheme.getRelations().add(currRelation);
			}
			results.close();
			// don't need to hold these open while we do the expensive part
			checkInPreparedStatement(selectFromRelations);
			checkInPreparedStatement(selectFromRelationsMultiAttributes);

			// do the expensive part
			Iterator iterator = codingScheme.getRelations().iterator();
			while (iterator.hasNext())
			{
				Relations temp = (Relations) iterator.next();
				//TODO status stuff
				//System.out.println("Populating " + temp.getDc());
				associationsService_.setEContext(temp, RelationsPackage.eINSTANCE.getRelations_Association());
				associationsService_.resolveAll();
			}

		}

		catch (SQLException e)
		{
			throw new FindException(e);
		}
		finally
		{
			checkInPreparedStatement(selectFromRelations);
			checkInPreparedStatement(selectFromRelationsMultiAttributes);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.LexGrid.managedobj.HomeServiceIF#insert(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public void insert(ManagedObjIF obj) throws InsertException, ObjectAlreadyExistsException
	{
		PreparedStatement insertIntoRelations = null;
		PreparedStatement insertIntoRelationsMultiAttributes = null;
		try
		{
			Relations relations = (Relations) obj;
			CodingSchemeType codingScheme = getCodingScheme(relations);

			insertIntoRelations = getKeyedInsertStatement(SQLTableConstants.RELATION);

			insertIntoRelations.setString(1, codingScheme.getCodingScheme());
			insertIntoRelations.setString(2, relations.getDc());
			setBooleanOnPreparedStatment(insertIntoRelations, 3, relations.getIsNative());
			insertIntoRelations.setString(4, relations.getEntityDescription() == null ? "MISSING"
					: relations.getEntityDescription());
			insertIntoRelations.executeUpdate();

			insertIntoRelationsMultiAttributes = getKeyedInsertStatement(SQLTableConstants.RELATION_MULTI_ATTRIBUTES);

			Iterator sourceIter = relations.getSource().iterator();
			while (sourceIter.hasNext())
			{
				Source source = (Source) sourceIter.next();
				insertIntoRelationsMultiAttributes.setString(1, codingScheme.getCodingScheme());
				insertIntoRelationsMultiAttributes.setString(2, relations.getDc());
				insertIntoRelationsMultiAttributes.setString(3, "source");
				insertIntoRelationsMultiAttributes.setString(4, source.getValue());
                if (supports2006Model())
                {
                    insertIntoRelationsMultiAttributes.setString(5, source.getSubRef());
                    insertIntoRelationsMultiAttributes.setString(6, source.getRole());
                }
				insertIntoRelationsMultiAttributes.executeUpdate();
			}

			Iterator associationsIter = relations.getAssociation().iterator();
			while (associationsIter.hasNext())
			{
				associationsService_.insert((Association) associationsIter.next());
			}
		}
		catch (SQLException e)
		{
			throw new ObjectAlreadyExistsException("Problem loading " +  ((Relations) obj).getDc(),  e);
		}
		catch (Exception e)
		{
			throw new InsertException("Problem loading " +  ((Relations) obj).getDc(),  e);
		}
		finally
		{
			try
			{
				insertIntoRelations.close();
				insertIntoRelationsMultiAttributes.close();
			}
			catch (Exception e)
			{
				// do nothing
			}
		}
	}
}