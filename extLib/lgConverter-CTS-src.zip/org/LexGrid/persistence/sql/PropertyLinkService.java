/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence.sql;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.LexGrid.emf.codingSchemes.CodingSchemeType;
import org.LexGrid.emf.concepts.CodedEntry;
import org.LexGrid.emf.concepts.ConceptsFactory;
import org.LexGrid.emf.concepts.PropertyLink;
import org.LexGrid.emf.concepts.impl.PropertyLinkImpl;
import org.LexGrid.managedobj.FindException;
import org.LexGrid.managedobj.InsertException;
import org.LexGrid.managedobj.ManagedObjIF;
import org.LexGrid.managedobj.ObjectAlreadyExistsException;
import org.LexGrid.managedobj.ServiceInitException;
import org.LexGrid.managedobj.jdbc.JDBCBaseService;
import org.LexGrid.util.sql.lgTables.SQLTableConstants;

/**
 * <pre>
 * Title:        PropertyLinkService.java
 * Description:  Class that handles propertyLinks to and from the database.
 * </pre>
 * 
 * @author <A HREF="mailto:armbrust.daniel@mayo.edu">Dan Armbrust </A>
 * @version 1.0 - cvs $Revision: 1.9 $ checked in on $Date: 2005/06/16 16:48:46 $
 */
public class PropertyLinkService extends LGBaseService
{
    public PropertyLinkService(JDBCBaseService anchorService) throws ServiceInitException
    {
        super(anchorService);
    }

    public void resolveAll() throws FindException
    {
        PreparedStatement selectFromConceptPropertyLinks = null;

        try
        {
            selectFromConceptPropertyLinks = checkOutPreparedStatement("SELECT * FROM " + getTableName(SQLTableConstants.CONCEPT_PROPERTY_LINKS) + " WHERE conceptCode = ? AND codingSchemeName = ?");

            selectFromConceptPropertyLinks.setString(1, getConceptCode());
            selectFromConceptPropertyLinks.setString(2, getCodingSchemeName());

            ResultSet results = selectFromConceptPropertyLinks.executeQuery();

            while (results.next())
            {
                PropertyLink currConceptPropertyLink = ConceptsFactory.eINSTANCE.createPropertyLink();
                currConceptPropertyLink.setSourceProperty(results.getString("sourcePropertyId"));
                currConceptPropertyLink.setLink(results.getString("link"));
                currConceptPropertyLink.setTargetProperty(results.getString("targetPropertyId"));
                ((CodedEntry) getEContainer()).getPropertyLink().add(currConceptPropertyLink);
            }
            results.close();
        }
        catch (SQLException e)
        {
            throw new FindException(e);
        }
        finally
        {
            checkInPreparedStatement(selectFromConceptPropertyLinks);
        }

    }

    public void insert(ManagedObjIF obj) throws InsertException, ObjectAlreadyExistsException
    {
        PreparedStatement insertIntoConceptPropertyLinks = null;
        try
        {
            PropertyLink currPropertyLink = (PropertyLink) (obj);
            insertIntoConceptPropertyLinks = getKeyedInsertStatement(SQLTableConstants.CONCEPT_PROPERTY_LINKS);

            insertIntoConceptPropertyLinks.setString(1, ((CodingSchemeType)((CodedEntry) currPropertyLink).getContainer(CodingSchemeType.class, -1)).getCodingScheme());
            insertIntoConceptPropertyLinks.setString(2, ((CodedEntry) currPropertyLink.eContainer()).getConceptCode());
            insertIntoConceptPropertyLinks.setString(3, currPropertyLink.getSourceProperty());
            insertIntoConceptPropertyLinks.setString(4, currPropertyLink.getLink());
            insertIntoConceptPropertyLinks.setString(5, currPropertyLink.getTargetProperty());

            insertIntoConceptPropertyLinks.executeUpdate();

        }
        catch (SQLException e)
        {
            throw new ObjectAlreadyExistsException("Error inserting property link "
                    + ((PropertyLink) (obj)).getLink()
                    + " on concept "
                    + ((CodedEntry) ((PropertyLink) (obj)).eContainer()).getConceptCode(), e);
        }
        catch (Exception e)
        {
            throw new InsertException("Error inserting property "
                    + ((PropertyLink) (obj)).getLink()
                    + " on concept "
                    + ((CodedEntry) ((PropertyLink) (obj)).eContainer()).getConceptCode(), e);
        }
        finally
        {
            try
            {
                insertIntoConceptPropertyLinks.close();
            }
            catch (Exception e)
            {
                // do nothing
            }
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.managedobj.service.BaseService#getInstanceClass()
     */
    protected Class getInstanceClass()
    {
        return PropertyLinkImpl.class;
    }
}