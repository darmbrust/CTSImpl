/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence.sql;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * <pre>
 * Title:        PageCookie.java
 * Description:  Class to hold the things necessary to page results.
 * </pre>
 *
 * @author <A HREF="mailto:armbrust.daniel@mayo.edu">Dan Armbrust</A>
 * @version 1.0 - cvs $Revision: 1.1 $ checked in on $Date: 2005/03/11 23:00:33 $
 */
public class PageCookie
{
    PreparedStatement sqlStatement;
    ResultSet results;
    int startPoint;
    /**
     * @return Returns the results.
     */
    public ResultSet getResults()
    {
        return results;
    }
    /**
     * @param results The results to set.
     */
    public void setResults(ResultSet results)
    {
        this.results = results;
    }
    /**
     * @return Returns the sqlStatement.
     */
    public PreparedStatement getSqlStatement()
    {
        return sqlStatement;
    }
    /**
     * @param sqlStatement The sqlStatement to set.
     */
    public void setSqlStatement(PreparedStatement sqlStatement)
    {
        this.sqlStatement = sqlStatement;
    }
    /**
     * @return Returns the startPoint.
     */
    public int getStartPoint()
    {
        return startPoint;
    }
    /**
     * @param startPoint The startPoint to set.
     */
    public void setStartPoint(int startPoint)
    {
        this.startPoint = startPoint;
    }
}