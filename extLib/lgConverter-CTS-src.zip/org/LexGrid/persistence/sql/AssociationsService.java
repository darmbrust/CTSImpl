/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence.sql;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.Iterator;

import org.LexGrid.emf.base.impl.LgBasicEListImpl;
import org.LexGrid.emf.relations.Association;
import org.LexGrid.emf.relations.Relations;
import org.LexGrid.emf.relations.RelationsFactory;
import org.LexGrid.emf.relations.RelationsPackage;
import org.LexGrid.emf.relations.impl.AssociationImpl;
import org.LexGrid.emf.relations.impl.AssociationInstanceImpl;
import org.LexGrid.managedobj.FindException;
import org.LexGrid.managedobj.InsertException;
import org.LexGrid.managedobj.ManagedObjIF;
import org.LexGrid.managedobj.ObjectAlreadyExistsException;
import org.LexGrid.managedobj.QueryException;
import org.LexGrid.managedobj.ServiceInitException;
import org.LexGrid.managedobj.jdbc.JDBCBaseService;
import org.LexGrid.util.sql.lgTables.SQLTableConstants;

/**
 * <pre>
 * Title:        AssociationsService.java
 * Description:  Class that handles the Associations Objects to and from the database.
 * </pre>
 * 
 * @author <A HREF="mailto:armbrust.daniel@mayo.edu">Dan Armbrust </A>
 * @version 1.0 - cvs $Revision: 1.10 $ checked in on $Date: 2005/06/16 16:48:45 $
 */
public class AssociationsService extends LGBaseService
{
    private SourceConceptService sourceConceptService_;

    public AssociationsService(JDBCBaseService anchorService) throws ServiceInitException
    {
        super(anchorService);
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.managedobj.service.BaseService#getInstanceClass()
     */
    protected Class getInstanceClass()
    {
        return AssociationImpl.class;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.managedobj.service.BaseService#initNestedServices()
     */
    protected void initNestedServices() throws ServiceInitException
    {
        sourceConceptService_ = new SourceConceptService(this);
    }

    public LgBasicEListImpl queryRelationTargets(String targetContext, String targetCode, int limit)
            throws QueryException
    {
        LgBasicEListImpl list = new LgBasicEListImpl();
        list.setPageSize(limit);

        Iterator iterator = ((Relations) getEContainer()).getAssociation().iterator();
        Hashtable associations = new Hashtable();

        while (iterator.hasNext())
        {
            Association temp = (Association) iterator.next();
            associations.put(temp.getAssociation(), temp);
        }
        
        Iterator iter = sourceConceptService_.queryRelationTargets(getCodingSchemeName(), getRelationsName(), associations, targetContext, targetCode, limit);
        while (iter.hasNext())
        {
            list.add(iter.next());
        }
        return list;
    }

    public LgBasicEListImpl queryRelationSources(String code, int limit) throws QueryException
    {
        LgBasicEListImpl list = new LgBasicEListImpl();
        list.setPageSize(limit);

        Iterator iterator = ((Relations) getEContainer()).getAssociation().iterator();
        
        Hashtable associations = new Hashtable();
        while (iterator.hasNext())
        {
            Association temp = (Association) iterator.next();
            associations.put(temp.getAssociation(), temp);

        }
        Iterator iter = sourceConceptService_.queryRelationSources(
        	getCodingSchemeName(), getRelationsName(), associations, code, limit);
        while (iter.hasNext())
        {
            list.add(iter.next());
        }
        return list;
    }

    public void resolveAll() throws FindException
    {
        PreparedStatement selectFromAssociation = null;

        try
        {
            selectFromAssociation = checkOutPreparedStatement(modifySql("SELECT * FROM " + getTableName(SQLTableConstants.ASSOCIATION) + " WHERE codingSchemeName = ? AND relationName = ?"));

            selectFromAssociation.setString(1, getCodingSchemeName());
            selectFromAssociation.setString(2, getRelationsName());

            ResultSet results = selectFromAssociation.executeQuery();

            while (results.next())
            {
                Association currAssociation = RelationsFactory.eINSTANCE.createAssociation();
                currAssociation.setAssociation(results.getString("association"));
                currAssociation.setForwardName(results.getString("forwardName"));
                currAssociation.setReverseName(results.getString("reverseName"));
                currAssociation.setInverse(results.getString("inverse"));
                Boolean temp = getBooleanFromResultSet(results, "isNavigable");
                if (temp != null)
                {
                	currAssociation.setIsNavigable(temp);
                }
                temp = getBooleanFromResultSet(results, "isTransitive");
                if (temp != null)
                {
                	currAssociation.setIsTransitive(temp);
                }
                temp = getBooleanFromResultSet(results, "isAntiTransitive");
                if (temp != null)
                {
                	currAssociation.setIsAntiTransitive(temp);
                }
                temp = getBooleanFromResultSet(results, "isSymmetric");
                if (temp != null)
                {
                	currAssociation.setIsSymmetric(temp);
                }
                temp = getBooleanFromResultSet(results, "isAntiSymmetric");
                if (temp != null)
                {
                	currAssociation.setIsAntiSymmetric(temp);
                }
                temp = getBooleanFromResultSet(results, "isReflexive");
                if (temp != null)
                {
                	currAssociation.setIsReflexive(temp);
                }
                temp = getBooleanFromResultSet(results, "isAntiReflexive");
                if (temp != null)
                {
                	currAssociation.setIsAntiReflexive(temp);
                }
                temp = getBooleanFromResultSet(results, "isFunctional");
                if (temp != null)
                {
                	currAssociation.setIsFunctional(temp);
                }
                temp = getBooleanFromResultSet(results, "isReverseFunctional");
                if (temp != null)
                {
                	currAssociation.setIsReverseFunctional(temp);
                }
                temp = getBooleanFromResultSet(results, "isTranslationAssociation");
                if (temp != null)
                {
                	currAssociation.setIsTranslationAssociation(temp);
                }

                currAssociation.setTargetCodingScheme(results.getString("targetCodingScheme"));
                currAssociation.setEntityDescription(results.getString("entityDescription"));

                ((Relations) getEContainer()).getAssociation().add(currAssociation);
            }
            results.close();
            // don't need to hold these open while we do the expensive part
            checkInPreparedStatement(selectFromAssociation);

            // do the expensive part
            Iterator iterator = ((Relations) getEContainer()).getAssociation().iterator();
            while (iterator.hasNext())
            {
                Association temp = (Association) iterator.next();
                //TODO status stuff
                //System.out.println(" Populating " + temp.getAssociation());
                sourceConceptService_.setEContext(temp, RelationsPackage.eINSTANCE.getAssociation_SourceConcept());
                sourceConceptService_.resolveAll();
            }

        }

        catch (SQLException e)
        {
            throw new FindException(e);
        }
        finally
        {
            checkInPreparedStatement(selectFromAssociation);
        }

    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.managedobj.HomeServiceIF#insert(org.LexGrid.managedobj.ManagedObjIF)
     */
    public void insert(ManagedObjIF obj) throws InsertException, ObjectAlreadyExistsException
    {
        PreparedStatement insertIntoAssociations = null;
        try
        {
            Association association = (Association) obj;

            insertIntoAssociations = getKeyedInsertStatement(SQLTableConstants.ASSOCIATION);

            insertIntoAssociations.setString(1, getCodingScheme(association).getCodingScheme());
            insertIntoAssociations.setString(2, ((Relations) association.eContainer()).getDc());
            insertIntoAssociations.setString(3, association.getAssociation());
            insertIntoAssociations.setString(4, association.getForwardName());
            insertIntoAssociations.setString(5, association.getReverseName());
            insertIntoAssociations.setString(6, association.getInverse());
            setBooleanOnPreparedStatment(insertIntoAssociations, 7, association.getIsNavigable());
            setBooleanOnPreparedStatment(insertIntoAssociations, 8, association.getIsTransitive());
            setBooleanOnPreparedStatment(insertIntoAssociations, 9, association.getIsAntiTransitive());
            setBooleanOnPreparedStatment(insertIntoAssociations, 10, association.getIsSymmetric());
            setBooleanOnPreparedStatment(insertIntoAssociations, 11, association.getIsAntiSymmetric());
            setBooleanOnPreparedStatment(insertIntoAssociations, 12, association.getIsReflexive());
            setBooleanOnPreparedStatment(insertIntoAssociations, 13, association.getIsAntiReflexive());
            setBooleanOnPreparedStatment(insertIntoAssociations, 14, association.getIsFunctional());
            setBooleanOnPreparedStatment(insertIntoAssociations, 15, association.getIsReverseFunctional());
            setBooleanOnPreparedStatment(insertIntoAssociations, 16, association.getIsTranslationAssociation());
            insertIntoAssociations.setString(17, association.getTargetCodingScheme());
            insertIntoAssociations.setString(18, association.getEntityDescription());
            insertIntoAssociations.executeUpdate();

            Iterator sourceIterator = association.getSourceConcept().iterator();
            while (sourceIterator.hasNext())
            {
                sourceConceptService_.insert((AssociationInstanceImpl) sourceIterator.next());
            }

        }
        catch (SQLException e)
        {
        	Association assoc = (Association) obj;
            throw new ObjectAlreadyExistsException("Problem loading association "
                    + assoc.getAssociation() + " in relations container "
                    + ((Relations)assoc.eContainer()).getDc(), e);
        }
        catch (Exception e)
        {
           	Association assoc = (Association) obj;
            throw new InsertException("Problem loading association "
            		+ assoc.getAssociation() + " in relations container "
            		+ ((Relations)assoc.eContainer()).getDc(), e);
        }
        finally
        {
            try
            {
                insertIntoAssociations.close();
            }
            catch (Exception e)
            {
                // do nothing
            }
        }
    }
}