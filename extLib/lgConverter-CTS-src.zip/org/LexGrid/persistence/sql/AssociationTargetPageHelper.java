/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence.sql;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.LexGrid.emf.base.LgStagedObj;
import org.LexGrid.emf.codingSchemes.CodingSchemeType;
import org.LexGrid.emf.relations.Association;
import org.LexGrid.emf.relations.AssociationData;
import org.LexGrid.emf.relations.AssociationInstance;
import org.LexGrid.emf.relations.AssociationQualification;
import org.LexGrid.emf.relations.AssociationTarget;
import org.LexGrid.emf.relations.RelationsFactory;
import org.LexGrid.emf.relations.impl.AssociationInstanceImpl;
import org.LexGrid.managedobj.ResolveException;
import org.LexGrid.managedobj.ServiceInitException;
import org.LexGrid.managedobj.jdbc.JDBCBaseService;
import org.LexGrid.util.sql.lgTables.SQLTableConstants;
import org.eclipse.emf.ecore.EStructuralFeature;

/**
 * <pre>
 * Title:        AssociationTargetPageHelper.java
 * Description:  Class that handles getting pages for association targets.
 * </pre>
 * 
 * @author <A HREF="mailto:armbrust.daniel@mayo.edu">Dan Armbrust </A>
 * @version 1.0 - cvs $Revision: 1.3 $ checked in on $Date: 2005/09/22 20:54:31 $
 */
public class AssociationTargetPageHelper extends LGBaseService
{
    public AssociationTargetPageHelper(JDBCBaseService anchorService) throws ServiceInitException
    {
        super(anchorService);
    }

    private String getAssociationName(AssociationInstance associationInstance)
    {
        return ((Association) associationInstance.eContainer()).getAssociation();
    }

    protected Class getInstanceClass()
    {
        return AssociationInstanceImpl.class;
    }

    public void stageFeature(LgStagedObj obj, EStructuralFeature feature) throws ResolveException
    {
        // The rest of the model does not currently support paging of targets - it only supports
        // staging. So this stage method will return everything.
        if (obj instanceof AssociationInstanceImpl && feature.getName().equals("targetConcept"))
        {
            AssociationInstance associationInstance = (AssociationInstance) obj;
            PreparedStatement selectFromConAssnToConcept = null;
            PreparedStatement selectFromConAssnToCMultiAttributes = null;
            try
            {
                selectFromConAssnToConcept = checkOutPreparedStatement(modifySql("SELECT targetCodingSchemeName, targetConceptCode, " + (supports2006Model() ? "firstRelease, deprecated, modifiedInRelease" : "firstVersion, lastVersion") + ", multiAttributesKey FROM " + getTableName(SQLTableConstants.CONCEPT_ASSOCIATION_TO_CONCEPT) + " WHERE codingSchemeName = ? AND relationName = ? AND association = ? AND sourceCodingSchemeName = ? AND sourceConceptCode =?"));
                selectFromConAssnToCMultiAttributes = checkOutPreparedStatement("SELECT * FROM " + getTableName(SQLTableConstants.CONCEPT_ASSOCIATION_TO_C_QUALS) + " WHERE codingSchemeName = ? AND multiAttributesKey = ?");

                selectFromConAssnToConcept.setString(1, getCodingScheme(associationInstance).getCodingScheme());
                selectFromConAssnToConcept.setString(2, getRelations(associationInstance).getDc());
                selectFromConAssnToConcept.setString(3, getAssociationName(associationInstance));
                selectFromConAssnToConcept.setString(4, associationInstance.getSourceCodingScheme());
                selectFromConAssnToConcept.setString(5, associationInstance.getSourceConcept());

                ResultSet results = selectFromConAssnToConcept.executeQuery();

                while (results.next())
                {
                    processPagedConceptToConceptTargetResultRow(results, associationInstance,
                                                                selectFromConAssnToCMultiAttributes);
                }
                results.close();

                checkInPreparedStatement(selectFromConAssnToConcept);

                obj.stageComplete(feature);
            }
            catch (SQLException e)
            {
                checkInPreparedStatement(selectFromConAssnToConcept);
                throw new ResolveException(e);
            }
            finally
            {
                // always check this one in.
                checkInPreparedStatement(selectFromConAssnToCMultiAttributes);
            }
        }
        else if (obj instanceof AssociationInstanceImpl && feature.getName().equals("targetDataValue"))
        {
            AssociationInstance associationInstance = (AssociationInstance) obj;
            PreparedStatement selectFromConAssnToData = null;
            PreparedStatement selectFromConAssnToDMultiAttributes = null;
            try
            {
                selectFromConAssnToData = checkOutPreparedStatement(modifySql("SELECT id, multiAttributesKey, dataType, dataValue, " + (supports2006Model() ? "firstRelease, modifiedInRelease, deprecated" : "firstVersion, lastVersion") + " FROM " + getTableName(SQLTableConstants.CONCEPT_ASSOCIATION_TO_DATA) + " WHERE codingSchemeName = ? AND relationName = ? AND association = ? AND sourceCodingSchemeName = ? AND sourceConceptCode =?"));
                selectFromConAssnToDMultiAttributes = checkOutPreparedStatement("SELECT * FROM " + getTableName(SQLTableConstants.CONCEPT_ASSOCIATION_TO_D_QUALS) + " WHERE codingSchemeName = ? AND multiAttributesKey = ?");

                selectFromConAssnToData.setString(1, getCodingScheme(associationInstance).getCodingScheme());
                selectFromConAssnToData.setString(2, getRelations(associationInstance).getDc());
                selectFromConAssnToData.setString(3, getAssociationName(associationInstance));
                selectFromConAssnToData.setString(4, associationInstance.getSourceCodingScheme());
                selectFromConAssnToData.setString(5, associationInstance.getSourceConcept());

                ResultSet results = selectFromConAssnToData.executeQuery();

                while (results.next())
                {
                    processPagedConceptToDataTargetResultRow(results, associationInstance,
                                                             selectFromConAssnToDMultiAttributes);
                }
                results.close();

                checkInPreparedStatement(selectFromConAssnToData);
                obj.stageComplete(feature);
            }
            catch (SQLException e)
            {
                checkInPreparedStatement(selectFromConAssnToData);
                throw new ResolveException(e);
            }
            finally
            {
                // always check this one in.
                checkInPreparedStatement(selectFromConAssnToDMultiAttributes);
            }
        }
        else
        {
            System.out.println("Dan messed up - its asking for " + feature.getName());
            obj.stageComplete(feature);
        }

    }

    private void processPagedConceptToConceptTargetResultRow(ResultSet results,
            AssociationInstance associationInstance, PreparedStatement selectFromConAssnToCMultiAttributes)
            throws SQLException
    {
        AssociationTarget associationTarget = RelationsFactory.eINSTANCE.createAssociationTarget();
        Boolean temp = getBooleanFromResultSet(results, supports2006Model() ? "firstRelease" : "firstVersion");
        if (temp != null)
        {
        	associationTarget.setFirstRelease(temp);
        }
        temp = getBooleanFromResultSet(results, supports2006Model() ? "deprecated" : "lastVersion");
        if (temp != null)
        {
        	associationTarget.setDeprecated(temp);
        }
        if (supports2006Model())
        {
            temp = getBooleanFromResultSet(results, "modifiedInRelease");
            if (temp != null)
            {
                associationTarget.setModifiedInRelease(temp);
            }
        }
        associationTarget.setTargetCodingScheme(results.getString("targetCodingSchemeName"));
        associationTarget.setTargetConcept(results.getString("targetConceptCode"));

        String key = results.getString("multiAttributesKey");

        if (key != null && key.length() > 0)
        {
            selectFromConAssnToCMultiAttributes
            	.setString(1, ((CodingSchemeType) associationInstance.getContainer(CodingSchemeType.class, -1)).getCodingScheme());
            selectFromConAssnToCMultiAttributes.setString(2, key);
            ResultSet results2 = selectFromConAssnToCMultiAttributes.executeQuery();
            while (results2.next())
            {
                String qualifierName = null;
                String qualifierValue = null;
                if (supports2006Model())
                {
                    qualifierName = results2.getString("qualifierName");
                    qualifierValue = results2.getString("qualifierValue");
                }
                else
                {
                    String attrName = results2.getString("attributeName");
                    if (attrName.equals("qualifier"))
                    {
                        qualifierName = results2.getString("attributeValue");
                        qualifierValue = results2.getString("associationQualifierValue");
                    }
                }
                if (qualifierName != null)
                {
                    AssociationQualification qualifier = RelationsFactory.eINSTANCE.createAssociationQualification();
                    qualifier.setAssociationQualifierValue(qualifierValue);
                    qualifier.setAssociationQualifier(qualifierName);

                    associationTarget.getAssociationQualification().add(qualifier);
                }
            }
            results2.close();
        }

        associationInstance.getTargetConcept().add(associationTarget);
    }

    private void processPagedConceptToDataTargetResultRow(ResultSet results, AssociationInstance associationInstance,
            PreparedStatement selectFromConAssnToDMultiAttributes) throws SQLException
    {
        AssociationData associationTarget = RelationsFactory.eINSTANCE.createAssociationData();
        Boolean temp = getBooleanFromResultSet(results, supports2006Model() ? "firstRelease" : "firstVersion");
        if (temp != null)
        {
        	associationTarget.setFirstRelease(temp);
        }
        temp = getBooleanFromResultSet(results, supports2006Model() ? "deprecated" : "lastVersion");
        if (temp != null)
        {
        	associationTarget.setDeprecated(temp);
        }
        if (supports2006Model())
        {
            temp = getBooleanFromResultSet(results, "modifiedInRelease");
            if (temp != null)
            {
                associationTarget.setModifiedInRelease(temp);
            }
        }
        associationTarget.setDataValue(results.getString("dataValue"));
        associationTarget.setId(results.getString("id"));

        String key = results.getString("multiAttributesKey");

        if (key != null && key.length() > 0)
        {
            selectFromConAssnToDMultiAttributes
            	.setString(1, ((CodingSchemeType) associationInstance.getContainer(CodingSchemeType.class, -1)).getCodingScheme());
            selectFromConAssnToDMultiAttributes.setString(2, key);
            ResultSet results2 = selectFromConAssnToDMultiAttributes.executeQuery();
            while (results2.next())
            {
                String qualifierName = null;
                String qualifierValue = null;
                if (supports2006Model())
                {
                    qualifierName = results2.getString("qualifierName");
                    qualifierValue = results2.getString("qualifierValue");
                }
                else
                {
                    String attrName = results2.getString("attributeName");
                    if (attrName.equalsIgnoreCase("qualifier"))
                    {
                        qualifierName = results2.getString("attributeValue");
                        qualifierValue = results2.getString("associationQualifierValue");
                    }
                }
                if (qualifierName != null)
                {
                    AssociationQualification qualifier = RelationsFactory.eINSTANCE.createAssociationQualification();
                    qualifier.setAssociationQualifierValue(qualifierValue);
                    qualifier.setAssociationQualifier(qualifierName);

                    associationTarget.getAssociationQualification().add(qualifier);
                }
            }
            results2.close();
        }

        associationInstance.getTargetDataValue().add(associationTarget);
    }
}