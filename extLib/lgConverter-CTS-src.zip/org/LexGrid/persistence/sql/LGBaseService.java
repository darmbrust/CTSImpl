/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence.sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.LexGrid.emf.base.LgCodedObj;
import org.LexGrid.emf.base.LgModelObj;
import org.LexGrid.emf.base.LgPagedList;
import org.LexGrid.emf.base.LgPagedListService;
import org.LexGrid.emf.base.LgStagedObj;
import org.LexGrid.emf.base.LgStagingService;
import org.LexGrid.emf.codingSchemes.CodingSchemeType;
import org.LexGrid.emf.concepts.Concepts;
import org.LexGrid.emf.relations.Relations;
import org.LexGrid.managedobj.FindException;
import org.LexGrid.managedobj.HomeServiceBroker;
import org.LexGrid.managedobj.ManagedObjIF;
import org.LexGrid.managedobj.ResolveException;
import org.LexGrid.managedobj.ServiceInitException;
import org.LexGrid.managedobj.jdbc.JDBCBaseService;
import org.LexGrid.managedobj.jdbc.JDBCConnectionDescriptor;
import org.LexGrid.managedobj.jdbc.JDBCConnectionPoolPolicy;
import org.LexGrid.util.sql.DBUtility;
import org.LexGrid.util.sql.GenericSQLModifier;
import org.LexGrid.util.sql.lgTables.SQLTableConstants;
import org.LexGrid.util.sql.lgTables.SQLTableUtilities;
import org.apache.commons.pool.impl.GenericObjectPool;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

/**
 * <pre>
 * Title:        LGBaseService.java
 * Description:  The base of the SQL implementations.
 * </pre>
 * 
 * @author <A HREF="mailto:armbrust.daniel@mayo.edu">Dan Armbrust </A>
 * @version 1.0 - cvs $Revision: 1.27 $ checked in on $Date: 2005/09/26 21:29:01 $
 */
public class LGBaseService extends JDBCBaseService implements LgStagingService, LgPagedListService
{
	protected ThreadLocal eContext_;
	private boolean       stagedRetrievalEnabled_ = false;
	private int           pageSize_               = 0;
	private String prefix_ = "";

	/**
	 * Encapsulates container information for newly resolved objects;
	 * remembered on a per-thread basis.
	 */
	public class LgContextStruct {
		EObject container = null;
		EStructuralFeature containerFeature = null;
	}

	protected LGBaseService(JDBCBaseService anchorService) throws ServiceInitException
	{
		super();
		stagedRetrievalEnabled_ = ((LGBaseService) anchorService).isStagingEnabled();
		pageSize_ = ((LGBaseService) anchorService).getPageSize();

		setBroker(anchorService.getBroker());

		setSQLRegistry(((LGBaseService) anchorService).getSQLRegistry());
		setConnectionPool(((LGBaseService) anchorService).getConnectionPool());

		anchorService.internalRegisterNestedService(this);
		setAnchorService(anchorService);
		setConnectionDescriptor((anchorService).getConnectionDescriptor());
		setConnectionPoolPolicy((anchorService).getConnectionPoolPolicy());
		init();
	}

	public LGBaseService(HomeServiceBroker broker, JDBCConnectionDescriptor desc, boolean stagedRetrievalEnabled, String prefix)
	throws ServiceInitException
	{
		this.prefix_ = prefix;
		stagedRetrievalEnabled_ = pageSize_ > 0 ? stagedRetrievalEnabled : false;

		try
		{
			setConnectionDescriptor(desc);
			setBroker(broker);
			desc.setAutoCommit(true);
			// This sets it up to verify that the connection is up and working before a statement
			// is executed, among other things.
			JDBCConnectionPoolPolicy pol = getConnectionPoolPolicy();
			pol.maxActive = 10;
			pol.maxIdle = -1;
			pol.maxWait = -1;
			pol.minEvictableIdleTimeMillis = -1;
			pol.numTestsPerEvictionRun = 1;
			pol.testOnBorrow = false;
			pol.testOnReturn = false;
			pol.testWhileIdle = false;
			pol.timeBetweenEvictionRunsMillis = -1;
			pol.whenExhaustedAction = GenericObjectPool.WHEN_EXHAUSTED_FAIL;
			desc.setPingSQL(null);

			Connection c = (Connection) getConnectionPool().borrowObject();

			String sqlServerUrl = getConnectionDescriptor().toString();
			SQLTableUtilities stu = new SQLTableUtilities(c, prefix);

			if (!stu.doTablesExist())
			{
				stu.createDefaultTables();
				stu.createDefaultTableConstraints();
			}

			// Set up some of the singleton tools.

			String dbProductName = c.getMetaData().getDatabaseProductName();
			SingletonVariables.instance(sqlServerUrl).databaseName_ = dbProductName;
			SingletonVariables.instance(sqlServerUrl).sqlModifier_ = new GenericSQLModifier(dbProductName, false);
			SingletonVariables.instance(sqlServerUrl).stc_ = stu.getSQLTableConstants();
			getConnectionPool().returnObject(c);

			initStatements();
			init();
		}
		catch (Exception e)
		{
			throw new ServiceInitException("Error creating LGBaseService", e);
		}
	}

	/**
	 * Initializes the thread localized parent for resolved objects.
	 * <p>
	 * Note: Separated into separate sync method (instead of lazy init in getter) due to concerns over integrity of
	 * approaches using double-checked locking.
	 */
	protected synchronized void initContext()
	{
		if (eContext_ == null)
			eContext_ = new ThreadLocal();
	}

	/**
	 * Returns the container to directly include resolved objects;
	 * null if not applicable or available.
	 * @return EObject
	 */
	protected EObject getEContainer() {
		initContext();
		Object o = eContext_.get();
		if (o instanceof LgContextStruct)
			return ((LgContextStruct) o).container;
		return null;
	}

	/**
	 * Returns the feature on the container that will be associated with
	 * resolved objects, if applicable.
	 * @return EStructuralFeature
	 */
	protected EStructuralFeature getEContainmentFeature() {
		initContext();
		Object o = eContext_.get();
		if (o instanceof LgContextStruct)
			return ((LgContextStruct) o).containerFeature;
		return null;
	}

	/**
	 * Sets the EMF container to be applied to resolved objects, optionally
	 * adding the model to the contents of the container when resolved.
	 * @param container EObject
	 * @param containerFeature EStructuralFeature
	 */
	protected void setEContext(EObject container, EStructuralFeature containerFeature) {
		initContext();
		LgContextStruct eStruct = new LgContextStruct();
		eStruct.container = container;
		eStruct.containerFeature = containerFeature;

		eContext_.set(eStruct);
	}

	/**
	 * Returns the coding scheme which, either directly or at a sub-level,
	 * contains the given item.
	 * @param containedItem
	 * @return The coding scheme; null if not available.
	 */
	protected CodingSchemeType getCodingScheme(EObject containedItem)
	{
		CodingSchemeType cs = null;
		if (containedItem instanceof LgModelObj)
		{
			cs = (CodingSchemeType)
				((LgModelObj) containedItem).getContainer(CodingSchemeType.class, -1);
		}
		return cs;
	}

	/**
	 * Returns the name of the coding scheme which, either directly or at
	 * a sub-level, contains the currently assigned eContext item.
	 * @return The name; null if not available.
	 */
	protected String getCodingSchemeName()
	{
		CodingSchemeType cs = getCodingScheme(getEContainer());
		if (cs != null)
			return cs.getCodingScheme();
		return null;
	}

	/**
	 * Returns the code associated with the currently assigned eContext item.
	 * @return The code; null if not available.
	 */
	protected String getConceptCode()
	{
		String code = null;
		EObject startAt = getEContainer();
		if (startAt instanceof LgModelObj)
		{
			LgCodedObj codedItem =
				(startAt instanceof LgModelObj)
					? (LgCodedObj) startAt
					: (LgCodedObj) ((LgModelObj) startAt).getContainer(LgCodedObj.class, -1);
			if (codedItem != null)
				code = codedItem.getConceptCode();
		}
		return code;
	}

	/**
	 * Returns the concept container which, either directly or at a sub-level,
	 * contains the given item.
	 * @param containedItem
	 * @return The concepts container; null if not available.
	 */
	protected Concepts getConcepts(EObject containedItem)
	{
		Concepts conceptContainer = null;
		if (containedItem instanceof LgModelObj)
		{
			conceptContainer =
				(containedItem instanceof Concepts)
					? (Concepts) containedItem
					: (Concepts) ((LgModelObj) containedItem).getContainer(Concepts.class, -1);
		}
		return conceptContainer;
	}

	/**
	 * Returns the relations container which, either directly or at a sub-level,
	 * contains the given item.
	 * @param containedItem
	 * @return The relations container; null if not available.
	 */
	protected Relations getRelations(EObject containedItem)
	{
		Relations relationContainer = null;
		if (containedItem instanceof LgModelObj)
		{
			relationContainer =
				(containedItem instanceof Relations)
					? (Relations) containedItem
					: (Relations) ((LgModelObj) containedItem).getContainer(Relations.class, -1);
		}
		return relationContainer;
	}

	/**
	 * Returns the name of the relations container which, either directly or
	 * at a sub-level, contains the currently assigned eContext item.
	 * @param containedItem
	 * @return The name; null if not available.
	 */
	protected String getRelationsName()
	{
		Relations rels = getRelations(getEContainer());
		if (rels != null)
			return rels.getDc();
		return null;
	}

	private String getDatabaseName()
	{
		return SingletonVariables.instance(getConnectionDescriptor().toString()).databaseName_;
	}

	protected boolean isMySQL()
	{
		return getDatabaseName().equals("MySQL");
	}

	protected boolean isPostgreSQL()
	{
		return getDatabaseName().equals("PostgreSQL");
	}
    
    protected boolean supports2006Model()
    {
        return SingletonVariables.instance(getConnectionDescriptor().toString()).stc_.supports2006Model();
    }

	protected String modifySql(String sql)
	{
		return SingletonVariables.instance(getConnectionDescriptor().toString()).sqlModifier_.modifySQL(sql, false);
	}

	protected String getTableName(String tableNameKey)
	{
		return SingletonVariables.instance(getConnectionDescriptor().toString()).stc_.getTableName(tableNameKey);
	}

	/**
	 * This method is for created prepared statements on the "insert" connection. MSAccess only allows one connection to
	 * write at a time. Do not check this statement back in. Simply close it. Also do not close the underlying SQL
	 * connection.
	 * 
	 * @param key - the key to the registered SQL.
	 * @return - The prepared statement
	 * @throws Exception
	 */
	protected PreparedStatement getKeyedInsertStatement(String key) throws Exception
	{
		String statement = getRegisteredSQL(key);
		Connection insertConn = getWriteConnection();
		return insertConn.prepareStatement(statement);
	}

	protected Connection getWriteConnection() throws Exception
	{
		Connection insertConn = SingletonVariables.instance(getConnectionDescriptor().toString()).insertConn_;
		if (insertConn == null)
		{
			insertConn = getConnection();
			SingletonVariables.instance(getConnectionDescriptor().toString()).insertConn_ = insertConn;
		}
		return insertConn;
	}

	public Connection getConnection() throws Exception
	{
		return (Connection) getConnectionPool().borrowObject();
	}

	public void returnConnection(Connection conn) throws Exception
	{
		getConnectionPool().returnObject(conn);
	}

	public void initStatements() throws Exception
	{
		Connection temp = getConnection();
		SQLTableConstants tables = SingletonVariables.instance(getConnectionDescriptor().toString()).stc_;
		returnConnection(temp);

		String[] tableKeys = tables.getTableKeys();

		// register all of the insert statements from the SQLTableConstants class
		// these are in the ldapSQLConverter project
		for (int i = 0; i < tableKeys.length; i++)
		{
			registerSQL(tableKeys[i], tables.getInsertStatementSQL(tableKeys[i]));
		}
	}

	public void setBooleanOnPreparedStatment(PreparedStatement statement, int colNumber, Boolean value)
	throws SQLException
	{
		DBUtility.setBooleanOnPreparedStatment(statement, colNumber, value, false, getDatabaseName());
	}

	protected Boolean getBooleanFromResultSet(ResultSet results, String columnName) throws SQLException
	{
		return DBUtility.getBooleanFromResultSet(results, columnName);
	}

	protected String setBlankStringsNull(String string)
	{
		if (string == null)
		{
			return null;
		}
		else if (string.length() == 0)
		{
			return null;
		}
		else
		{
			return string;
		}
	}

	protected int getIntFromSQLResult(String result)
	{
		if (result == null)
		{
			return 0;
		}
		// has a ".0" in it sometimes.. chop off everything after any decimal
		if (result.indexOf(".") != -1)
		{
			result = result.substring(0, result.indexOf("."));
		}
		return Integer.parseInt(result);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.LexGrid.managedobj.service.BaseService#closePrim()
	 */
	public void closePrim()
	{
		try
		{
			returnConnection(SingletonVariables.instance(getConnectionDescriptor().toString()).insertConn_);
		}
		catch (Exception e)
		{
			// do nothing
		}
		eContext_ = null;
		super.closePrim();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.LexGrid.plugin.base.LgStagingService#stageFeature(org.LexGrid.plugin.base.LgStagedObj,
	 *      org.eclipse.emf.ecore.EStructuralFeature)
	 */
	public void stageFeature(LgStagedObj obj, EStructuralFeature feature) throws ResolveException
	{
		// this is implemented in the necessary subclasses
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.LexGrid.plugin.base.LgStagingService#isStagingEnabled()
	 */
	public boolean isStagingEnabled()
	{
		return stagedRetrievalEnabled_;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.LexGrid.plugin.base.LgPagedListService#resolveNextPage(org.LexGrid.plugin.base.LgPagedList)
	 */
	public void resolveNextPage(LgPagedList pagedList) throws ResolveException
	{
		// this is implemented in the necessary subclasses
	}

	/**
	 * Returns the maximum number of entries to be retrieved in each page
	 * for paged lists that are resolved by the service.
	 * @return The page size; 0 for unpaged content (everything
	 * resolved in single pass); -1 to attempt to resolve the page size
	 * from the plugin preference store (not available outside of the
	 * eclipse runtime).
	 */
	public int getPageSize() {
		return pageSize_;
	}

	public String getPrefix()
	{
		return prefix_;
	}

	/**
	 * Assigns the maximum number of entries to be retrieved in each page
	 * for paged lists that are resolved by the service.
	 * @param pageSize The page size; 0 for unpaged content (everything
	 * resolved in single pass); -1 to attempt to resolve the page size
	 * from the plugin preference store (not available outside of the
	 * eclipse runtime).
	 */
	public void setPageSize(int pageSize) {
		pageSize_ = pageSize;
	}

	/**
	 * Returns the maximum number of entries to be retrieved in each page
	 * for paged lists that are resolved by the service, resolving from the
	 * plugin preference store if indicated and available.
	 * @return The page size; 0 for unpaged content (everything
	 * resolved in single pass).
	 */
	protected int resolvePageSize() {
		return (pageSize_ < 0) ? 256 : pageSize_;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.LexGrid.plugin.base.LgPagedListService#pagedListDisposed(org.LexGrid.plugin.base.LgPagedList)
	 */
	public void pagedListDisposed(LgPagedList pagedList)
	{
		PageCookie cookie = (PageCookie) pagedList.getPageCookie();
		if (cookie != null)
		{
			if (cookie.getResults() != null)
			{
				try
				{
					cookie.getResults().close();
				}
				catch (SQLException e)
				{
				}
				cookie.setResults(null);
			}

			if (cookie.getSqlStatement() != null)
			{
				checkInPreparedStatement(cookie.getSqlStatement());
				cookie.setSqlStatement(null);
			}
			cookie = null;
			pagedList.setPageCookie(null);
		}
	}

	public boolean supportsPropertyQualifiers()
	{
		return SingletonVariables.instance(getConnectionDescriptor().toString()).stc_.supportsPropertyQualifiers();
	}

	// Unneeded methods...
	protected String getDbTableName()
	{
		throw new java.lang.UnsupportedOperationException("Method getDbTableName not yet implemented.");
	}

	protected ManagedObjIF findByPrimaryKeyPrim(Object key) throws FindException
	{
		throw new java.lang.UnsupportedOperationException("Method findByPrimaryKeyPrim not yet implemented.");
	}

	protected Class getInstanceClass()
	{
		throw new java.lang.UnsupportedOperationException("Method getInstanceClass not yet implemented.");
	}

	public ManagedObjIF row2ManagedObj(ResultSet rs) throws SQLException
	{
		throw new java.lang.UnsupportedOperationException("Method row2ManagedObj not yet implemented.");
	}
}