/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence.sql;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.Iterator;

import org.LexGrid.emf.base.LgModelObj;
import org.LexGrid.emf.base.LgPagedList;
import org.LexGrid.emf.base.LgStagedObj;
import org.LexGrid.emf.base.impl.LgEnhancedEListImpl;
import org.LexGrid.emf.relations.AssociatableElement;
import org.LexGrid.emf.relations.Association;
import org.LexGrid.emf.relations.AssociationData;
import org.LexGrid.emf.relations.AssociationInstance;
import org.LexGrid.emf.relations.AssociationQualification;
import org.LexGrid.emf.relations.AssociationTarget;
import org.LexGrid.emf.relations.RelationsFactory;
import org.LexGrid.emf.relations.RelationsPackage;
import org.LexGrid.emf.relations.impl.AssociationDataImpl;
import org.LexGrid.emf.relations.impl.AssociationImpl;
import org.LexGrid.emf.relations.impl.AssociationInstanceImpl;
import org.LexGrid.emf.relations.impl.AssociationQualificationImpl;
import org.LexGrid.emf.relations.impl.AssociationTargetImpl;
import org.LexGrid.managedobj.FindException;
import org.LexGrid.managedobj.InsertException;
import org.LexGrid.managedobj.ManagedObjIF;
import org.LexGrid.managedobj.ObjectAlreadyExistsException;
import org.LexGrid.managedobj.QueryException;
import org.LexGrid.managedobj.ResolveException;
import org.LexGrid.managedobj.ServiceInitException;
import org.LexGrid.managedobj.jdbc.JDBCBaseService;
import org.LexGrid.util.sql.lgTables.SQLTableConstants;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EStructuralFeature;

/**
 * <pre>
 * Title:        SourceConceptsService.java
 * Description:  Class that handles the actual Relations to and from the database.
 * </pre>
 * 
 * @author <A HREF="mailto:armbrust.daniel@mayo.edu">Dan Armbrust </A>
 * @version 1.0 - cvs $Revision: 1.23 $ checked in on $Date: 2005/10/06 19:11:56 $
 */
public class SourceConceptService extends LGBaseService
{
	private AssociationTargetPageHelper associationTargetPageHelper_;

	public SourceConceptService(JDBCBaseService anchorService) throws ServiceInitException
	{
		super(anchorService);
	}

	private String getAssociationName()
	{
		return ((Association) getEContainer()).getAssociation();
	}

	protected void initNestedServices() throws ServiceInitException
	{
		associationTargetPageHelper_ = new AssociationTargetPageHelper(this);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.LexGrid.managedobj.service.BaseService#getInstanceClass()
	 */
	protected Class getInstanceClass()
	{
		return AssociationInstanceImpl.class;
	}

	private String generateCKey()
	{
		// TODO - figure out how I want to do this.
		return System.currentTimeMillis() + "" + ((int)Math.floor((Math.random() * 10000000)));
	}

	private String generateDKey()
	{
		// TODO - figure out how I want to do this.
		return System.currentTimeMillis() + "" + ((int)Math.floor((Math.random() * 10000000)));
	}

	public Iterator queryRelationTargets(String codingSchemeName, String relationName, Hashtable associations, String targetContext, String targetCode, int limit)
	throws QueryException
	{
		Association association = RelationsFactory.eINSTANCE.createAssociation();

		PreparedStatement selectFromConAssnToConcept = null;
		PreparedStatement selectFromConAssnToCMultiAttributes = null;

		BasicEList temp = new BasicEList();

		try
		{
			selectFromConAssnToConcept = checkOutPreparedStatement(modifySql("SELECT * FROM " + getTableName(SQLTableConstants.CONCEPT_ASSOCIATION_TO_CONCEPT) + " WHERE codingSchemeName = ? AND relationName = ? AND targetCodingSchemeName = ? AND targetConceptCode = ?"));
            selectFromConAssnToCMultiAttributes = checkOutPreparedStatement("SELECT * FROM " + getTableName(SQLTableConstants.CONCEPT_ASSOCIATION_TO_C_QUALS) + " WHERE codingSchemeName = ? AND multiAttributesKey = ?");

			selectFromConAssnToConcept.setString(1, codingSchemeName);
			selectFromConAssnToConcept.setString(2, relationName);
			selectFromConAssnToConcept.setString(3, targetContext);
			selectFromConAssnToConcept.setString(4, targetCode);
			selectFromConAssnToConcept.setMaxRows(limit);

			ResultSet results = selectFromConAssnToConcept.executeQuery();
			while (results.next())
			{
				String associationName = results.getString("association");
				processConceptToConceptResultRow(results, association, (Association)associations.get(associationName), selectFromConAssnToCMultiAttributes);
			}
			results.close();

			Iterator iter = association.getSourceConcept().iterator();
			while (iter.hasNext())
			{
				temp.addAll(((AssociationInstance)iter.next()).getTargetConcept());
			}

		}
		catch (SQLException e)
		{
			throw new QueryException("Problem during search", e);
		}
		finally
		{
			checkInPreparedStatement(selectFromConAssnToConcept);
			checkInPreparedStatement(selectFromConAssnToCMultiAttributes);
		}
		return temp.iterator();
	}

	public Iterator queryRelationSources(String codingSchemeName, String relationName, Hashtable associations, String code, int limit) throws QueryException
	{
		Association association = RelationsFactory.eINSTANCE.createAssociation();

		PreparedStatement selectFromConAssnToConcept = null;
		PreparedStatement selectFromConAssnToCMultiAttributes = null;
		PreparedStatement selectFromConAssnToData = null;
		PreparedStatement selectFromConAssnToDMultiAttributes = null;
		int count = 0;

		try
		{
			//sources to concepts
			selectFromConAssnToConcept = checkOutPreparedStatement(modifySql("SELECT * FROM " + getTableName(SQLTableConstants.CONCEPT_ASSOCIATION_TO_CONCEPT) + " WHERE codingSchemeName = ? AND relationName = ? AND sourceConceptCode = ?"));
            selectFromConAssnToCMultiAttributes = checkOutPreparedStatement("SELECT * FROM " + getTableName(SQLTableConstants.CONCEPT_ASSOCIATION_TO_C_QUALS) + " WHERE codingSchemeName = ? AND multiAttributesKey = ?");

			selectFromConAssnToConcept.setString(1, codingSchemeName);
			selectFromConAssnToConcept.setString(2, relationName);
			selectFromConAssnToConcept.setString(3, code);
			selectFromConAssnToConcept.setMaxRows(limit);

			ResultSet results = selectFromConAssnToConcept.executeQuery();

			while (results.next())
			{
				String associationName = results.getString("association");

				processConceptToConceptResultRow(results, association, (Association)associations.get(associationName), selectFromConAssnToCMultiAttributes);
				count++;
			}
			results.close();

			//sources to data
			selectFromConAssnToData = checkOutPreparedStatement(modifySql("SELECT * FROM " + getTableName(SQLTableConstants.CONCEPT_ASSOCIATION_TO_DATA) + " WHERE codingSchemeName = ? AND relationName = ? AND sourceConceptCode = ?"));
            selectFromConAssnToDMultiAttributes = checkOutPreparedStatement("SELECT * FROM " + getTableName(SQLTableConstants.CONCEPT_ASSOCIATION_TO_D_QUALS) + " WHERE codingSchemeName = ? AND multiAttributesKey = ?");

			selectFromConAssnToData.setString(1, codingSchemeName);
			selectFromConAssnToData.setString(2, relationName);
			selectFromConAssnToData.setString(3, code);
			selectFromConAssnToData.setMaxRows((limit - count < 0 ? 0 : limit - count));

			results = selectFromConAssnToData.executeQuery();

			while (results.next())
			{
				processConceptToDataResultRow(results, association,
						selectFromConAssnToDMultiAttributes);
				count++;
			}
			results.close();
		}
		catch (SQLException e)
		{
			throw new QueryException("Problem during search", e);
		}
		finally
		{
			checkInPreparedStatement(selectFromConAssnToConcept);
			checkInPreparedStatement(selectFromConAssnToCMultiAttributes);
			checkInPreparedStatement(selectFromConAssnToData);
			checkInPreparedStatement(selectFromConAssnToDMultiAttributes);
		}

		return association.getSourceConcept().iterator();
	}

	public void resolveAll() throws FindException
	{
		if (isStagingEnabled())
		{
			((LgStagedObj) getEContainer()).setStagingService(this);
		}
		else
		{
			try
			{
				resolveConceptsToConcepts((Association) getEContainer());
				resolveConceptsToData((Association) getEContainer());
			}
			catch (SQLException e)
			{
				throw new FindException(e);
			}
		}
	}

	public void stageFeature(LgStagedObj obj, EStructuralFeature feature) throws ResolveException
	{
		if (obj instanceof AssociationImpl && feature.getName().equals("association"))
		{
			obj.stageComplete(feature);
		}
		else if (obj instanceof AssociationImpl && feature.getName().equals("sourceConcept"))
		{
			Association association = (Association) obj;
			PreparedStatement selectFromConAssnToConcept = null;
			setEContext(obj.eContainer(), RelationsPackage.eINSTANCE.getAssociationInstance_SourceConcept());

			try
			{
				// TODO - distinct could cause performance issues here....

				selectFromConAssnToConcept = checkOutPreparedStatement(modifySql("SELECT DISTINCT sourceCodingSchemeName, sourceConceptCode FROM " + getTableName(SQLTableConstants.CONCEPT_ASSOCIATION_TO_CONCEPT) + " WHERE codingSchemeName = ? AND relationName = ? AND association = ? {LIMIT}"));

				int start = 0;
				int conceptCount = 0;

				selectFromConAssnToConcept.setString(1, getCodingScheme(association).getCodingScheme());
				selectFromConAssnToConcept.setString(2, getRelations(association).getDc());
				selectFromConAssnToConcept.setString(3, association.getAssociation());

				// mysql doesn't stream results - the {LIMIT} above and this is
				// for getting limits on mysql code}
				if (isMySQL())
				{
					selectFromConAssnToConcept.setInt(4, start);
					selectFromConAssnToConcept.setInt(5, resolvePageSize());
					start += resolvePageSize();
				}
				else if (isPostgreSQL())
				{
					//postgres properly streams results, we can just set the fetch size, and only loop once
					selectFromConAssnToConcept.setFetchSize(resolvePageSize());
					selectFromConAssnToConcept.getConnection().setAutoCommit(false);
				}

				ResultSet results = selectFromConAssnToConcept.executeQuery();

				while (results.next())
				{
					// if we have reached the page size, stop iterating the results.
					// assume that the sql driver is smart enough to pull results on demand,
					// so they are not all in memory.
					if (conceptCount == resolvePageSize())
					{
						PageCookie cookie = new PageCookie();
						cookie.setSqlStatement(selectFromConAssnToConcept);
						cookie.setResults(results);
						((LgEnhancedEListImpl) association.getSourceConcept()).setPageCookie(cookie);
						((LgEnhancedEListImpl) association.getSourceConcept()).setPageSize(resolvePageSize());
						((LgEnhancedEListImpl) association.getSourceConcept()).setPagingService(this);

						obj.stageComplete(feature);
						return;
					}

					processPagedConceptToConceptSourceResultRow(results, association);
					conceptCount++;

				}
				results.close();

				// only check in this statement if we completed. otherwise, it needs to stay open
				// and go in the cookie.
				checkInPreparedStatement(selectFromConAssnToConcept);

				// if we get here, and we are not mysql, then we have all of the results.
				// if we are mysql, we could have all the results, or there just may be another page.
				if (isMySQL() && conceptCount > 0)
				{
					PageCookie cookie = new PageCookie();
					cookie.setStartPoint(start);
					((LgEnhancedEListImpl) association.getSourceConcept()).setPageCookie(cookie);
					((LgEnhancedEListImpl) association.getSourceConcept()).setPageSize(resolvePageSize());
					((LgEnhancedEListImpl) association.getSourceConcept()).setPagingService(this);
				}
				obj.stageComplete(feature);
			}
			catch (SQLException e)
			{
				checkInPreparedStatement(selectFromConAssnToConcept);
				throw new ResolveException(e);
			}
		}
		else
		{
			//should be ok, just say complete.
			obj.stageComplete(feature);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.LexGrid.plugin.base.LgPagedListService#resolveNextPage(org.LexGrid.plugin.base.LgPagedList)
	 */
	public void resolveNextPage(LgPagedList pagedList) throws ResolveException
	{
		int conceptCount = 0;
		LgModelObj lmo = pagedList.getPagingContext();
		setEContext(lmo.eContainer(), RelationsPackage.eINSTANCE.getAssociationInstance_SourceConcept());
		PageCookie cookie = (PageCookie) pagedList.getPageCookie();
		PreparedStatement selectFromConAssnToConcept = null;
		Association association = (Association) lmo;

		try
		{
			if (isMySQL())
			{
				int start = cookie.getStartPoint();

				try
				{
					selectFromConAssnToConcept = checkOutPreparedStatement(modifySql("SELECT DISTINCT sourceCodingSchemeName, sourceConceptCode FROM " + getTableName(SQLTableConstants.CONCEPT_ASSOCIATION_TO_CONCEPT) + " WHERE codingSchemeName = ? AND relationName = ? AND association = ? {LIMIT}"));
					selectFromConAssnToConcept.setString(1, getCodingScheme(lmo).getCodingScheme());
					selectFromConAssnToConcept.setString(2, getRelations(lmo).getDc());
					selectFromConAssnToConcept.setString(3, association.getAssociation());
					selectFromConAssnToConcept.setInt(4, start);
					selectFromConAssnToConcept.setInt(5, resolvePageSize());
					start += resolvePageSize();

					ResultSet results = selectFromConAssnToConcept.executeQuery();

					while (results.next())
					{
						processPagedConceptToConceptSourceResultRow(results, association);
						conceptCount++;
					}
					results.close();
					if (conceptCount == 0)
					{
						pagedList.setPageCookie(null);
						cookie = null;
					}
					else
					{
						cookie.setStartPoint(start);
						pagedList.setPageCookie(cookie);
					}
				}
				finally
				{
					checkInPreparedStatement(selectFromConAssnToConcept);
				}
			}
			else
			{
				ResultSet results = cookie.getResults();
				selectFromConAssnToConcept = cookie.getSqlStatement();

				while (results.next())
				{
					// if we have reached the page size, stop iterating the results.
					// assume that the sql driver is smart enough to pull results on demand,
					// so they are not all in memory.
					if (conceptCount == pagedList.getPageSize())
					{
						return;
					}
					processPagedConceptToConceptSourceResultRow(results, association);
					conceptCount++;
				}

				// if we get here, means we have all the results. Close resources.
				results.close();
				checkInPreparedStatement(selectFromConAssnToConcept);
				pagedList.setPageCookie(null);
				cookie = null;
			}
		}
		catch (SQLException e)
		{
			checkInPreparedStatement(selectFromConAssnToConcept);
			throw new ResolveException(e);
		}
	}

	private void processPagedConceptToConceptSourceResultRow(ResultSet results, Association association)
	throws SQLException
	{
		String sourceCodingScheme = results.getString("sourceCodingSchemeName");
		String sourceConceptCode = results.getString("sourceConceptCode");

		AssociationInstance currentSource = RelationsFactory.eINSTANCE.createAssociationInstance();
		currentSource.setSourceCodingScheme(sourceCodingScheme);
		currentSource.setSourceConcept(sourceConceptCode);

		AssociationInstance existingAssociation = (AssociationInstance) ((LgEnhancedEListImpl) association
				.getSourceConcept()).getByPrimaryKey(currentSource.getPrimaryKey());

		if (existingAssociation == null)
		{
			association.getSourceConcept().add(currentSource);
			((LgStagedObj) currentSource).setStagingService(associationTargetPageHelper_);
		}
	}

	private void resolveConceptsToConcepts(Association association) throws SQLException
	{
		PreparedStatement count = null;
		PreparedStatement selectFromConAssnToConcept = null;
		PreparedStatement selectFromConAssnToCMultiAttributes = null;
		try
		{
			count = checkOutPreparedStatement("SELECT count(*) as cnt FROM " + getTableName(SQLTableConstants.CONCEPT_ASSOCIATION_TO_CONCEPT) + " WHERE codingSchemeName = ? AND relationName = ? AND association = ?");
			count.setString(1, getCodingSchemeName());
			count.setString(2, getRelationsName());
			count.setString(3, getAssociationName());

			ResultSet results = count.executeQuery();
			results.next();
			int total = results.getInt("cnt");
			results.close();
			checkInPreparedStatement(count);

			// This while loop is for mysql - it gets results by a batch at a time.
			// this loop will only run once with other databases.
			int start = 0;
			int relationCount = 0;

			selectFromConAssnToConcept = checkOutPreparedStatement(modifySql("SELECT * FROM " + getTableName(SQLTableConstants.CONCEPT_ASSOCIATION_TO_CONCEPT) + " WHERE codingSchemeName = ? AND relationName = ? AND association = ? {LIMIT}"));
			selectFromConAssnToCMultiAttributes = checkOutPreparedStatement("SELECT * FROM " + getTableName(SQLTableConstants.CONCEPT_ASSOCIATION_TO_C_QUALS) + " WHERE codingSchemeName = ? AND multiAttributesKey = ?");

			while (start < total)
			{
				selectFromConAssnToConcept.setString(1, getCodingSchemeName());
				selectFromConAssnToConcept.setString(2, getRelationsName());
				selectFromConAssnToConcept.setString(3, getAssociationName());

				// mysql doesn't stream results - the {LIMIT} above and this is for getting limits on mysql code}
				if (isMySQL())
				{
					//Sometimes, the page size is 0.  Asking mysql for 0 results is bad.
					int end = resolvePageSize();
					if (end == 0)
					{
						end = total;
					}
					selectFromConAssnToConcept.setInt(4, start);
					selectFromConAssnToConcept.setInt(5, end);
					start += end;
				}
				else if (isPostgreSQL())
				{
					//postgres properly streams results, we can just set the fetch size, and only loop once
					selectFromConAssnToConcept.setFetchSize(resolvePageSize());
					selectFromConAssnToConcept.getConnection().setAutoCommit(false);
					start = total;
				}
				else
				{
					start = total;
				}

				results = selectFromConAssnToConcept.executeQuery();

				while (results.next())
				{
					processConceptToConceptResultRow(results, association, null, selectFromConAssnToCMultiAttributes);
					if (++relationCount % 5000 == 0)
					{
						//TODO status stuff
						//System.out.println("On " + relationCount + " out of " + total);
					}
				}
				results.close();
			}
		}
		finally
		{
			checkInPreparedStatement(count);
			checkInPreparedStatement(selectFromConAssnToConcept);
			checkInPreparedStatement(selectFromConAssnToCMultiAttributes);
		}

	}

	private void processConceptToConceptResultRow(ResultSet results, Association association, Association parentAssociation,
			PreparedStatement selectFromConAssnToCMultiAttributes) throws SQLException
			{
		String sourceCodingScheme = results.getString("sourceCodingSchemeName");
		String sourceConceptCode = results.getString("sourceConceptCode");

		AssociationInstance currentSource = RelationsFactory.eINSTANCE.createAssociationInstance();
		currentSource.setSourceCodingScheme(sourceCodingScheme);
		currentSource.setSourceConcept(sourceConceptCode);

		AssociationInstance existingAssociation = (AssociationInstance) ((LgEnhancedEListImpl) association
				.getSourceConcept()).getByPrimaryKey(currentSource.getPrimaryKey());

		if (existingAssociation == null)
		{
			association.getSourceConcept().add(currentSource);
		}
		else
		{
			currentSource = existingAssociation;
		}

		AssociationTarget associationTarget = RelationsFactory.eINSTANCE.createAssociationTarget();
		Boolean temp = getBooleanFromResultSet(results, supports2006Model() ? "firstRelease" : "firstVersion");
		if (temp != null)
		{
			associationTarget.setFirstRelease(temp);
		}
		temp = getBooleanFromResultSet(results, supports2006Model() ? "deprecated" : "lastVersion");
		if (temp != null)
		{
			associationTarget.setDeprecated(temp);
		}
        if (supports2006Model())
        {
            temp = getBooleanFromResultSet(results, "modifiedInRelease");
            if (temp != null)
            {
                associationTarget.setModifiedInRelease(temp);
            }
        }
        
		associationTarget.setTargetCodingScheme(results.getString("targetCodingSchemeName"));
		associationTarget.setTargetConcept(results.getString("targetConceptCode"));

		String key = results.getString("multiAttributesKey");
		populateTargetMultiAttributes(results.getString("CodingSchemeName"), key, associationTarget, selectFromConAssnToCMultiAttributes);

		currentSource.getTargetConcept().add(associationTarget);
	}

	private void processConceptToDataResultRow(ResultSet results, Association association, 
			PreparedStatement selectFromConAssnToDMultiAttributes) throws SQLException
	{
		String sourceCodingScheme = results.getString("sourceCodingSchemeName");
		String sourceConceptCode = results.getString("sourceConceptCode");

		AssociationInstance currentSource = RelationsFactory.eINSTANCE.createAssociationInstance();
		currentSource.setSourceCodingScheme(sourceCodingScheme);
		currentSource.setSourceConcept(sourceConceptCode);

		AssociationInstance existingAssociation = (AssociationInstance) ((LgEnhancedEListImpl) association
				.getSourceConcept()).getByPrimaryKey(currentSource.getPrimaryKey());

		if (existingAssociation == null)
		{
			association.getSourceConcept().add(currentSource);
		}
		else
		{
			currentSource = existingAssociation;
		}

		AssociationData associationTarget = RelationsFactory.eINSTANCE.createAssociationData();
		Boolean temp = getBooleanFromResultSet(results, supports2006Model() ? "firstRelease" : "firstVersion");
		if (temp != null)
		{
			associationTarget.setFirstRelease(temp);
		}
		temp = getBooleanFromResultSet(results, supports2006Model() ? "deprecated" : "lastVersion");
		if (temp != null)
		{
			associationTarget.setDeprecated(temp);
		}
        if (supports2006Model())
        {
            temp = getBooleanFromResultSet(results, "modifiedInRelease");
            if (temp != null)
            {
                associationTarget.setModifiedInRelease(temp);
            }
        }
		associationTarget.setId(results.getString("id"));
		associationTarget.setDataValue(results.getString("dataValue"));

		String key = results.getString("multiAttributesKey");
		populateTargetMultiAttributes(results.getString("codingSchemeName"), key, associationTarget, selectFromConAssnToDMultiAttributes);

		currentSource.getTargetDataValue().add(associationTarget);
	}

	private void populateTargetMultiAttributes(String codingSchemeName, String key, AssociatableElement associationTarget, PreparedStatement selectFromConAssnToMultiAttributes) throws SQLException
	{
		if (key != null && key.length() > 0)
		{
			selectFromConAssnToMultiAttributes.setString(1, codingSchemeName);
			selectFromConAssnToMultiAttributes.setString(2, key);
			ResultSet results2 = selectFromConAssnToMultiAttributes.executeQuery();
			while (results2.next())
			{
                String qualifierName = null;
                String qualifierValue = null;
                if (supports2006Model())
                {
                    qualifierName = results2.getString("qualifierName");
                    qualifierValue = results2.getString("qualifierValue");
                }
                else
                {
                    String attrName = results2.getString("attributeName");
                    if (attrName.equalsIgnoreCase("qualifier"))
                    {
                        qualifierName = results2.getString("attributeValue");
                        qualifierValue = results2.getString("associationQualifierValue");
                    }
                }
				if (qualifierName != null)
				{
					AssociationQualification qualifier = RelationsFactory.eINSTANCE.createAssociationQualification();
					qualifier.setAssociationQualifierValue(qualifierValue);
					qualifier.setAssociationQualifier(qualifierName);

					associationTarget.getAssociationQualification().add(qualifier);
				}
			}
			results2.close();
		}
	}

	private void resolveConceptsToData(Association association) throws SQLException
	{
		PreparedStatement count = null;
		PreparedStatement selectFromConAssnToData = null;
		PreparedStatement selectFromConAssnToDMultiAttributes = null;
		try
		{
			count = checkOutPreparedStatement("SELECT count(*) as cnt FROM " + getTableName(SQLTableConstants.CONCEPT_ASSOCIATION_TO_DATA) + " WHERE codingSchemeName = ? AND relationName = ? AND association = ?");
			count.setString(1, getCodingSchemeName());
			count.setString(2, getRelationsName());
			count.setString(3, getAssociationName());

			ResultSet results = count.executeQuery();
			results.next();
			int total = results.getInt("cnt");
			results.close();
			checkInPreparedStatement(count);

			// This while loop is for mysql - it gets results by a batch at a time.
			// this loop will only run once with other databases.
			int start = 0;
			selectFromConAssnToData = checkOutPreparedStatement(modifySql("SELECT * FROM " + getTableName(SQLTableConstants.CONCEPT_ASSOCIATION_TO_DATA) + " WHERE codingSchemeName = ? AND relationName = ? AND association = ? {LIMIT}"));
            selectFromConAssnToDMultiAttributes = checkOutPreparedStatement("SELECT * FROM " + getTableName(SQLTableConstants.CONCEPT_ASSOCIATION_TO_D_QUALS) + " WHERE codingSchemeName = ? AND multiAttributesKey = ?");


			while (start < total)
			{
				selectFromConAssnToData.setString(1, getCodingSchemeName());
				selectFromConAssnToData.setString(2, getRelationsName());
				selectFromConAssnToData.setString(3, getAssociationName());

				// mysql doesn't stream results - the {LIMIT} above and this is for getting limits on mysql code}
				if (isMySQL())
				{
					//Sometimes, the page size is 0.  Asking mysql for 0 results is bad.
					int end = resolvePageSize();
					if (end == 0)
					{
						end = total;
					}                       
					selectFromConAssnToData.setInt(4, start);
					selectFromConAssnToData.setInt(5, end);
					start += end;
				}
				else if (isPostgreSQL())
				{
					//postgres properly streams results, we can just set the fetch size, and only loop once
					selectFromConAssnToData.setFetchSize(resolvePageSize());
					selectFromConAssnToData.getConnection().setAutoCommit(false);
					start = total;
				}
				else
				{
					start = total;
				}

				results = selectFromConAssnToData.executeQuery();

				while (results.next())
				{
					processConceptToDataResultRow(results, association, selectFromConAssnToDMultiAttributes);
				}
				results.close();
			}
		}
		finally
		{
			checkInPreparedStatement(count);
			checkInPreparedStatement(selectFromConAssnToData);
			checkInPreparedStatement(selectFromConAssnToDMultiAttributes);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.LexGrid.managedobj.HomeServiceIF#insert(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public void insert(ManagedObjIF obj) throws InsertException, ObjectAlreadyExistsException
	{
		PreparedStatement insertIntoConceptAssociationsToConcept = null;
		PreparedStatement insertIntoConceptAssociationsToCMultiAttrib = null;
		PreparedStatement insertIntoConceptAssociationsToData = null;
		PreparedStatement insertIntoConceptAssociationsToDMultiAttrib = null;
		try
		{
			AssociationInstance source = (AssociationInstance) obj;
			Association association = (Association) source.eContainer();

			// insert items that go to concepts
			Iterator targetConceptIter = source.getTargetConcept().iterator();

			insertIntoConceptAssociationsToConcept = getKeyedInsertStatement(SQLTableConstants.CONCEPT_ASSOCIATION_TO_CONCEPT);
            insertIntoConceptAssociationsToCMultiAttrib = getKeyedInsertStatement(SQLTableConstants.CONCEPT_ASSOCIATION_TO_C_QUALS);
			insertIntoConceptAssociationsToData = getKeyedInsertStatement(SQLTableConstants.CONCEPT_ASSOCIATION_TO_DATA);
            insertIntoConceptAssociationsToDMultiAttrib = getKeyedInsertStatement(SQLTableConstants.CONCEPT_ASSOCIATION_TO_D_QUALS);

			String sourceCodingScheme = source.getSourceCodingScheme();
			if (sourceCodingScheme == null || sourceCodingScheme.length() == 0)
			{
				// not specified means use the one you are in.
				sourceCodingScheme = getCodingScheme(source).getCodingScheme();
			}

			while (targetConceptIter.hasNext())
			{
				AssociationTargetImpl associationTarget = (AssociationTargetImpl) targetConceptIter.next();
				String key = null;
				String targetCodingScheme = associationTarget.getTargetCodingScheme();
                
                if (associationTarget.getAssociationQualification().size() > 0)
                {
                    key = generateCKey();
                }
                
				if (targetCodingScheme == null || targetCodingScheme.length() == 0)
				{
					//not specified - see if there is a default
					targetCodingScheme = getCodingScheme(source).getCodingScheme();

					if (targetCodingScheme == null || targetCodingScheme.length() == 0)
					{
						// still not specified means use the one you are in.
						targetCodingScheme = getCodingScheme(source).getCodingScheme();
					}
				}
				try
				{
                    int k = 1;
					insertIntoConceptAssociationsToConcept.setString(k++, getCodingScheme(source).getCodingScheme());
					insertIntoConceptAssociationsToConcept.setString(k++, (getRelations(source)).getDc());
					insertIntoConceptAssociationsToConcept.setString(k++, association.getAssociation());
					insertIntoConceptAssociationsToConcept.setString(k++, sourceCodingScheme);
					insertIntoConceptAssociationsToConcept.setString(k++, source.getSourceConcept());
					insertIntoConceptAssociationsToConcept.setString(k++, targetCodingScheme);
					insertIntoConceptAssociationsToConcept.setString(k++, associationTarget.getTargetConcept());
					insertIntoConceptAssociationsToConcept.setString(k++, key);
					setBooleanOnPreparedStatment(insertIntoConceptAssociationsToConcept, k++, associationTarget.getFirstRelease());
                    if (supports2006Model())
                    {
                        setBooleanOnPreparedStatment(insertIntoConceptAssociationsToConcept, k++, associationTarget.getModifiedInRelease());
                    }
					setBooleanOnPreparedStatment(insertIntoConceptAssociationsToConcept, k++, associationTarget.getDeprecated());
					insertIntoConceptAssociationsToConcept.executeUpdate();
					if (key != null)
					{
						Iterator qualifierIter = associationTarget.getAssociationQualification().iterator();
						while (qualifierIter.hasNext())
						{
							AssociationQualificationImpl qualifier = (AssociationQualificationImpl) qualifierIter.next();
                            int l = 1;
							insertIntoConceptAssociationsToCMultiAttrib.setString(l++, getCodingScheme(source).getCodingScheme());
							insertIntoConceptAssociationsToCMultiAttrib.setString(l++, key);
                            if (!supports2006Model())
                            {
                                insertIntoConceptAssociationsToCMultiAttrib.setString(l++, "qualifier");
                            }
							insertIntoConceptAssociationsToCMultiAttrib.setString(l++, qualifier.getAssociationQualifier());
							if (!supports2006Model())
                            {
							    insertIntoConceptAssociationsToCMultiAttrib.setString(l++, "");
                            }
							insertIntoConceptAssociationsToCMultiAttrib.setString(l++, qualifier.getAssociationQualifierValue());
							insertIntoConceptAssociationsToCMultiAttrib.executeUpdate();
						}
					}
				}
				//This is to allow us to optionally continue even if there is a duplicate, or some other sql insert error.
				catch (SQLException e1)
				{
					if (SingletonVariables.instance(getConnectionDescriptor().toString()).failOnAllErrors)
					{
						throw e1;
					}
					else
					{
						if (SingletonVariables.instance(getConnectionDescriptor().toString()).messages != null)
						{
							SingletonVariables.instance(getConnectionDescriptor().toString()).messages
							.message("There was a problem with the insert of the relationship between '"
									+ source.getSourceConcept() + "' and '"
									+ associationTarget.getTargetConcept()
									+ "' or one of its qualifications in the association '"
									+ association.getAssociation() + "' in the relationship container'"
									+ getRelations(association).getDc(), e1);
						}
					}
				}
			}

			// insert items that go to data
			Iterator targetDataIter = ((EList) source.eGet(RelationsPackage.eINSTANCE
					.getAssociationInstance_TargetDataValue())).iterator();
			while (targetDataIter.hasNext())
			{
				AssociationDataImpl associationTarget = (AssociationDataImpl) targetDataIter.next();

				String key = null;

				if (associationTarget.getAssociationQualification().size() > 0)
				{
					key = generateDKey();
				}

				try
				{
                    int k = 1;
					insertIntoConceptAssociationsToData.setString(k++, getCodingScheme(source).getCodingScheme());
					insertIntoConceptAssociationsToData.setString(k++, getRelations(source).getDc());
					insertIntoConceptAssociationsToData.setString(k++, association.getAssociation());
					insertIntoConceptAssociationsToData.setString(k++, sourceCodingScheme);
					insertIntoConceptAssociationsToData.setString(k++, source.getSourceConcept());
					insertIntoConceptAssociationsToData.setString(k++, associationTarget.getId());
					insertIntoConceptAssociationsToData.setString(k++, "");
					insertIntoConceptAssociationsToData.setString(k++, associationTarget.getDataValue());
					insertIntoConceptAssociationsToData.setString(k++, key);
					setBooleanOnPreparedStatment(insertIntoConceptAssociationsToData, k++, associationTarget.getFirstRelease());
                    if (supports2006Model())
                    {
                        setBooleanOnPreparedStatment(insertIntoConceptAssociationsToData, k++, associationTarget.getModifiedInRelease());
                    }
					setBooleanOnPreparedStatment(insertIntoConceptAssociationsToData, k++, associationTarget.getDeprecated());
					insertIntoConceptAssociationsToData.executeUpdate();

					// access only allows one inserting connection - so have to check in once per loop.

					if (key != null)
					{
						Iterator qualifierIter = associationTarget.getAssociationQualification().iterator();
						while (qualifierIter.hasNext())
						{
							AssociationQualificationImpl qualifier = (AssociationQualificationImpl) qualifierIter.next();
							int m = 1;
                            insertIntoConceptAssociationsToDMultiAttrib.setString(m++, getCodingScheme(source).getCodingScheme());
							insertIntoConceptAssociationsToDMultiAttrib.setString(m++, key);
                            if (!supports2006Model())
                            {
                                insertIntoConceptAssociationsToDMultiAttrib.setString(m++, "qualifier");
                            }
							insertIntoConceptAssociationsToDMultiAttrib.setString(m++, qualifier.getAssociationQualifier());
							if (!supports2006Model())
                            {
							    insertIntoConceptAssociationsToDMultiAttrib.setString(m++, "");
                            }
							insertIntoConceptAssociationsToDMultiAttrib.setString(m++, qualifier.getAssociationQualifierValue());
							insertIntoConceptAssociationsToDMultiAttrib.executeUpdate();
						}
					}
				}
				// This is to allow us to optionally continue even if there is a duplicate, or some other sql insert
				// error.
				catch (SQLException e1)
				{
					if (SingletonVariables.instance(getConnectionDescriptor().toString()).failOnAllErrors)
					{
						throw e1;
					}
					else
					{
						if (SingletonVariables.instance(getConnectionDescriptor().toString()).messages != null)
						{
							SingletonVariables.instance(getConnectionDescriptor().toString()).messages
							.message("There was a problem with the insert of the relationship between '"
									+ source.getSourceConcept() + "' and '" + associationTarget.getId()
									+ "' or one of its qualifications in the association '"
									+ ((Association)source.eContainer()).getAssociation() + "' in the relations container '"
									+ getRelations(source).getDc(), e1);
						}
					}
				}
			}
		}
		catch (SQLException e)
		{
			throw new ObjectAlreadyExistsException("Problem loading " + ((AssociationInstanceImpl) obj).getSourceConcept() + " in " + ((AssociationInstanceImpl) obj).eContainer(), e);
		}
		catch (Exception e)
		{
			throw new InsertException(e);
		}
		finally
		{
			try
			{
				insertIntoConceptAssociationsToCMultiAttrib.close();
				insertIntoConceptAssociationsToConcept.close();
				insertIntoConceptAssociationsToData.close();
				insertIntoConceptAssociationsToDMultiAttrib.close();
			}
			catch (Exception e)
			{
				// do nothing
			}
		}
	}
}