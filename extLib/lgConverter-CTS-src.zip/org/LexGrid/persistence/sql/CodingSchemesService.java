/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence.sql;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.LexGrid.emf.base.LgConstraint;
import org.LexGrid.emf.base.LgModelObj;
import org.LexGrid.emf.base.LgSearchable;
import org.LexGrid.emf.codingSchemes.CodingSchemeType;
import org.LexGrid.emf.codingSchemes.CodingSchemesType;
import org.LexGrid.emf.codingSchemes.CodingschemesFactory;
import org.LexGrid.emf.codingSchemes.CodingschemesPackage;
import org.LexGrid.emf.codingSchemes.impl.CodingSchemesTypeImpl;
import org.LexGrid.emf.codingSchemes.persistence.CodingSchemesPersistence;
import org.LexGrid.managedobj.FindException;
import org.LexGrid.managedobj.HomeServiceBroker;
import org.LexGrid.managedobj.InsertException;
import org.LexGrid.managedobj.ManagedObjException;
import org.LexGrid.managedobj.ManagedObjIF;
import org.LexGrid.managedobj.ManagedObjIterator;
import org.LexGrid.managedobj.ManagedObjIteratorWrapper;
import org.LexGrid.managedobj.ObjectAlreadyExistsException;
import org.LexGrid.managedobj.ObjectNotFoundException;
import org.LexGrid.managedobj.QueryException;
import org.LexGrid.managedobj.RemoveException;
import org.LexGrid.managedobj.ServiceInitException;
import org.LexGrid.managedobj.jdbc.JDBCConnectionDescriptor;
import org.LexGrid.util.sql.lgTables.SQLTableConstants;

/**
 * <pre>
 * 
 *  Title:        CodedEntryService.java
 *  Description:  Class that handles CodedEntries to the database.
 * </pre>
 * 
 * @author <A HREF="mailto:armbrust.daniel@mayo.edu">Dan Armbrust </A>
 */
public class CodingSchemesService extends LGBaseService implements
        CodingSchemesPersistence
{
    private CodingSchemeService codingSchemeService_;

    public CodingSchemesService(HomeServiceBroker broker,
            JDBCConnectionDescriptor desc, boolean stagedRetrievalEnabled, String prefix) throws ServiceInitException
    {
        super(broker, desc, stagedRetrievalEnabled, prefix);
    }
    
    public CodingSchemesService(HomeServiceBroker broker, JDBCConnectionDescriptor desc, boolean stagedRetrievalEnabled, String prefix, boolean failOnAllErrors, MessageIF messages) throws ServiceInitException
    {
        super(broker, desc, stagedRetrievalEnabled, prefix);
        SingletonVariables.instance(getConnectionDescriptor().toString()).messages = messages;
        SingletonVariables.instance(getConnectionDescriptor().toString()).failOnAllErrors = failOnAllErrors;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.managedobj.service.BaseService#initNestedServices()
     */
    protected void initNestedServices() throws ServiceInitException
    {
        codingSchemeService_ = new CodingSchemeService(this);
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.managedobj.service.CachedService#findByPrimaryKeyPrim(java.lang.Object)
     */
    protected ManagedObjIF findByPrimaryKeyPrim(Object key)
            throws FindException
    {
        CodingSchemesType codingSchemes = CodingschemesFactory.eINSTANCE.createCodingSchemesType();
        codingSchemes.setDc("codingSchemes");
        codingSchemeService_.setEContext(codingSchemes, CodingschemesPackage.eINSTANCE.getCodingSchemesType_CodingScheme());

        PreparedStatement getCodingSchemes = null;
        try
        {
            getCodingSchemes = checkOutPreparedStatement("SELECT codingSchemeName FROM " + getTableName(SQLTableConstants.CODING_SCHEME));

            ResultSet results = getCodingSchemes.executeQuery();

            // put the results in an array list so we don't have to hold this
            // result set
            // open for so long.
            ArrayList codingSchemeNames = new ArrayList();
            while (results.next())
            {
                codingSchemeNames.add(results.getString("codingSchemeName"));
            }
            checkInPreparedStatement(getCodingSchemes);

            for (int i = 0; i < codingSchemeNames.size(); i++)
            {
                CodingSchemeType codingScheme = (CodingSchemeType) codingSchemeService_
                        .findByPrimaryKey(codingSchemeNames.get(i));
                codingSchemes.getCodingScheme().add(codingScheme);
            }
            return codingSchemes;
        } catch (SQLException e)
        {
            throw new FindException(e);
        } finally
        {
            checkInPreparedStatement(getCodingSchemes);
        }

    }

    public void insert(ManagedObjIF obj) throws InsertException,
            ObjectAlreadyExistsException
    {
        try
        {
            CodingSchemesType codingSchemes = (CodingSchemesType) (obj);
            codingSchemeService_.setEContext(codingSchemes, CodingschemesPackage.eINSTANCE.getCodingSchemesType_CodingScheme());

            Iterator codingSchemesIter = codingSchemes.getCodingScheme()
                    .iterator();
            while (codingSchemesIter.hasNext())
            {
                CodingSchemeType temp = (CodingSchemeType) codingSchemesIter.next();
                codingSchemeService_.insert(temp);
            }
        }

        catch (InsertException e)
        {
            throw e;
        } catch (ObjectAlreadyExistsException e)
        {
            throw e;
        } catch (Exception e)
        {
            throw new InsertException(e);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.managedobj.HomeServiceIF#remove(org.LexGrid.managedobj.ManagedObjIF)
     */
    public void remove(ManagedObjIF obj) throws RemoveException,
            ObjectNotFoundException
    {
        try
        {
            CodingSchemesType codingSchemes = (CodingSchemesType) (obj);
            codingSchemeService_.setEContext(codingSchemes, CodingschemesPackage.eINSTANCE.getCodingSchemesType_CodingScheme());

            Iterator codingSchemesIter = codingSchemes.getCodingScheme()
                    .iterator();
            while (codingSchemesIter.hasNext())
            {
                codingSchemeService_.remove((CodingSchemeType) codingSchemesIter
                        .next());
            }
        }

        catch (RemoveException e)
        {
            throw e;
        } catch (ObjectNotFoundException e)
        {
            throw e;
        } catch (Exception e)
        {
            throw new RemoveException(e);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.persistence.ldap.LdapBaseService#getInstanceClass()
     */

    protected Class getInstanceClass()
    {
        return CodingSchemesTypeImpl.class;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.plugin.base.service.LgModelPersistence#synchronize(org.LexGrid.plugin.base.LgModelObj,
     *      boolean)
     */
    public void synchronize(LgModelObj obj, boolean recurse)
            throws ManagedObjException
    {
        // TODO: Implement synchronize
        throw new java.lang.UnsupportedOperationException(
                "Method synchronize not yet implemented.");
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.plugin.base.LgSearchable#queryConcepts(org.LexGrid.plugin.base.LgModelObj,
     *      org.LexGrid.plugin.base.LgConstraint[], int)
     */
    public ManagedObjIterator queryConcepts(LgModelObj root,
            LgConstraint[] constraints, int limit) throws QueryException
    {
        int count = 0;
        boolean noLimit = limit == 0;
        List result = new ArrayList();

        if (root instanceof CodingSchemeType)
        {
            int remainingLimit = noLimit ? 0
                    : limit - count;
            Iterator found = ((LgSearchable) codingSchemeService_).queryConcepts(root, constraints,
                                                                                 remainingLimit);
            while (found.hasNext() && (noLimit || count++ < limit))
                result.add(found.next());
        }
        else if (root instanceof CodingSchemesType)
        {
            codingSchemeService_.setEContext(root, CodingschemesPackage.eINSTANCE.getCodingSchemesType_CodingScheme());
            Iterator schemes = root.getContent(CodingSchemeType.class, 0);

            while (schemes.hasNext() && (noLimit || count < limit))
            {
                CodingSchemeType scheme = (CodingSchemeType) schemes.next();
                int remainingLimit = noLimit ? 0
                        : limit - count;
                Iterator found = ((LgSearchable) codingSchemeService_).queryConcepts(scheme, constraints,
                                                                                     remainingLimit);
                while (found.hasNext() && (noLimit || count++ < limit))
                    result.add(found.next());
            }
        }
        else
        {
            throw new QueryException("Unknown root type");
        }
        return new ManagedObjIteratorWrapper(result.iterator());
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.plugin.base.LgSearchable#queryRelationSources(org.LexGrid.plugin.base.LgModelObj,
     *      java.lang.String, int)
     */
    public ManagedObjIterator queryRelationSources(LgModelObj root, String code, int limit) throws QueryException
    {
        if (!(root instanceof CodingSchemesType || root instanceof CodingSchemeType))
        {
            throw new IllegalArgumentException("root");
        }

        if (root instanceof CodingSchemeType)
        {
            return codingSchemeService_.queryRelationSources(root, code, limit);
        }

        else
        {
            Iterator schemes = root.getContent(CodingSchemeType.class, 0);
            int count = 0;
            boolean noLimit = limit == 0;
            List result = new ArrayList();
            while (schemes.hasNext() && (noLimit || count < limit))
            {
                CodingSchemeType scheme = (CodingSchemeType) schemes.next();
                int remainingLimit = noLimit ? 0
                        : limit - count;
                Iterator found = codingSchemeService_.queryRelationSources(scheme, code, remainingLimit);

                while (found.hasNext() && (noLimit || count++ < limit))
                {
                    result.add(found.next());
                }
            }
            return new ManagedObjIteratorWrapper(result.iterator());
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.LexGrid.plugin.base.LgSearchable#queryRelationTargets(org.LexGrid.plugin.base.LgModelObj,
     *      java.lang.String, java.lang.String, int)
     */
    public ManagedObjIterator queryRelationTargets(LgModelObj root,
            String targetContext, String targetCode, int limit)
            throws QueryException
    {
        if (!(root instanceof CodingSchemesType || root instanceof CodingSchemeType))
        {
            throw new IllegalArgumentException("root");
        }

        if (root instanceof CodingSchemeType)
        {
            return codingSchemeService_.queryRelationTargets(root, targetContext, targetCode, limit);
        }

        else
        {
            Iterator schemes = root.getContent(CodingSchemeType.class, 0);
            int count = 0;
            boolean noLimit = limit == 0;
            List result = new ArrayList();
            while (schemes.hasNext() && (noLimit || count < limit))
            {
                CodingSchemeType scheme = (CodingSchemeType) schemes.next();
                int remainingLimit = noLimit ? 0
                        : limit - count;
                Iterator found = codingSchemeService_.queryRelationTargets(scheme, targetContext, targetCode, remainingLimit);

                while (found.hasNext() && (noLimit || count++ < limit))
                {
                    result.add(found.next());
                }
            }
            return new ManagedObjIteratorWrapper(result.iterator());
        }
    }
}