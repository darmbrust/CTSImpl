/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence.sql;

import java.sql.Connection;
import java.util.Hashtable;

import org.LexGrid.util.sql.GenericSQLModifier;
import org.LexGrid.util.sql.lgTables.SQLTableConstants;

public class SingletonVariables

{
    private static Hashtable     singletonHolder_ = new Hashtable();
    protected String             databaseName_    = null;
    protected GenericSQLModifier sqlModifier_     = null;
    protected SQLTableConstants  stc_             = null;
    
    public MessageIF             messages         = null;
    public boolean               failOnAllErrors  = true;

    // ms access requires that you only use one connection
    // for inserts - so I will always use this connection for inserts.
    protected Connection         insertConn_      = null;

    /**
     * I needed a place to store things that I want to share across all of the services. Mostly because I keep breaking
     * all the rules that Tom assumed when he wrote this package.
     * The reason that there is a hashtable of these "singletons" is because I need one set of variables
     * per pool of sql connections - not one per jvm.
     * 
     * @return
     */
    public static SingletonVariables instance(String sqlServerURL)
    {
        if (singletonHolder_.get(sqlServerURL) == null)
        {
            singletonHolder_.put(sqlServerURL, new SingletonVariables());
        }
        return (SingletonVariables)singletonHolder_.get(sqlServerURL);
    }

    private SingletonVariables()
    {
    }
}