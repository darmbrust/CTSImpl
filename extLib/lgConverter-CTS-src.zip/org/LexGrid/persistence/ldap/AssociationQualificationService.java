/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence.ldap;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;

import org.LexGrid.emf.relations.RelationsFactory;
import org.LexGrid.emf.relations.RelationsPackage;
import org.LexGrid.emf.relations.impl.AssociationQualificationImpl;
import org.LexGrid.managedobj.ManagedObjIF;
import org.LexGrid.managedobj.ServiceInitException;
import org.LexGrid.managedobj.jndi.LdapBaseService;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EFactory;

/**
 * Handles LDAP persistence for the corresponding type of managed object.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class AssociationQualificationService extends LgBaseService {

	static Map _feature2level, _level2attrs;
	static {
		// Information model to stage mappings ...
		_feature2level = new HashMap(4);
		_feature2level.put(RelationsPackage.eINSTANCE.getAssociationQualification_AssociationQualifier(), STAGE_Initial);
		_feature2level.put(RelationsPackage.eINSTANCE.getAssociationQualification_AssociationQualifierValue(), STAGE_Initial);

		// Stage to LDAP mappings ...
		_level2attrs = new HashMap(2);
		_level2attrs.put(STAGE_Initial, new String[] {
			RelationsSchemaDef.ATTR_associationQualifier,
			RelationsSchemaDef.ATTR_associationQualifierValue,
			RelationsSchemaDef.ATTR_dataType
			});
	}

	public AssociationQualificationService(LdapBaseService anchorService) throws ServiceInitException {
		super(anchorService);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.jndiJndiDirService#attrs2obj(org.LexGrid.managedobj.ManagedObjIF, javax.naming.directory.Attributes)
	 */
	protected void attrs2obj(ManagedObjIF obj, Attributes attrs) throws NamingException {
		AssociationQualificationImpl impl = (AssociationQualificationImpl) obj;
		Attribute attr;
		if ((attr = attrs.get(RelationsSchemaDef.ATTR_associationQualifier)) != null)
			impl.eSet(RelationsPackage.eINSTANCE.getAssociationQualification_AssociationQualifier(), attr.get());
		if ((attr = attrs.get(RelationsSchemaDef.ATTR_associationQualifierValue)) != null)
			impl.eSet(RelationsPackage.eINSTANCE.getAssociationQualification_AssociationQualifierValue(), attr.get());
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getEClass()
	 */
	protected EClass getEClass() {
		return RelationsPackage.eINSTANCE.getAssociationQualification();
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getEFactory()
	 */
	protected EFactory getEFactory() {
		return RelationsFactory.eINSTANCE;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#getInstanceClass()
	 */
	protected Class getInstanceClass() {
		return AssociationQualificationImpl.class;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#getManagedClasses()
	 */
	public List getManagedClasses() {
		List clazz = super.getManagedClasses();
		clazz.add(RelationsSchemaDef.CLASS_associationQualification);
		return clazz;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getStagingFeature2LevelMap()
	 */
	protected Map getStagingFeature2LevelMap() {
		return _feature2level;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getStagingLevel2AttrsMap()
	 */
	protected Map getStagingLevel2AttrsMap() {
		return _level2attrs;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#obj2attrs(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public Attributes obj2attrs(ManagedObjIF obj) {
		// Invoke superclass to pick up generic attributes (objectClass)
		Attributes attrs = super.obj2attrs(obj);

		// Add attributes unique to the given object
		AssociationQualificationImpl impl = (AssociationQualificationImpl) obj;
		attrs.put(new BasicAttribute(RelationsSchemaDef.ATTR_associationQualifier, impl.eGet(RelationsPackage.eINSTANCE.getAssociationQualification_AssociationQualifier())));
		attrs.put(new BasicAttribute(RelationsSchemaDef.ATTR_associationQualifierValue, impl.eGet(RelationsPackage.eINSTANCE.getAssociationQualification_AssociationQualifierValue())));
		return attrs;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#primaryKey2rdn(java.lang.Object)
	 */
	public String primaryKey2rdn(Object key) {
		return "associationQualifier=" + (String) key;
	}

}