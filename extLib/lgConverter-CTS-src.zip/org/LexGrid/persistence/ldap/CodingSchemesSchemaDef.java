/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence.ldap;

/**
 * Constants defining the LDAP schema referenced by local services.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public interface CodingSchemesSchemaDef {
	public static final String ATTR_approxNumConcepts = "approxNumConcepts";
	public static final String ATTR_codingScheme = "codingScheme";
	public static final String ATTR_copyright = "copyright";
	public static final String ATTR_dc = "dc";
	public static final String ATTR_defaultLanguage = "defaultLanguage";
	public static final String ATTR_entityDescription = "entityDescription";
	public static final String ATTR_formalName = "formalName";
	public static final String ATTR_isComplete = "isComplete";
	public static final String ATTR_isDefault = "isDefault";
	public static final String ATTR_isLatest = "isLatest";
	public static final String ATTR_isNative = "isNative";
	public static final String ATTR_localName = "localName";
	public static final String ATTR_releaseAgency = "releaseAgency";
	public static final String ATTR_releaseDate = "releaseDate";
	public static final String ATTR_releaseId = "releaseId";
	public static final String ATTR_releaseOrder = "releaseOrder";
	public static final String ATTR_releaseURN = "releaseURN";
	public static final String ATTR_registeredName = "registeredName";
	public static final String ATTR_representsVersion = "representsVersion";
	public static final String ATTR_service = "service";
	public static final String ATTR_source = "source";
	public static final String ATTR_supportedAssociation = "supportedAssociation";
	public static final String ATTR_supportedAssociationQualifier = "supportedAssociationQualifier";
	public static final String ATTR_supportedCodingScheme = "supportedCodingScheme";
	public static final String ATTR_supportedConceptStatus = "supportedConceptStatus";
	public static final String ATTR_supportedContext = "supportedContext";
	public static final String ATTR_supportedDataType = "supportedDataType";
	public static final String ATTR_supportedFormat = "supportedFormat";
	public static final String ATTR_supportedLanguage = "supportedLanguage";
	public static final String ATTR_supportedProperty = "supportedProperty";
	public static final String ATTR_supportedRepresentationalForm = "supportedRepresentationalForm";
	public static final String ATTR_supportedSource = "supportedSource";
	public static final String ATTR_version = "version";
	public static final String ATTR_versionOrder = "versionOrder";

	public static final String CLASS_codingSchemeType = "codingSchemeClass";
	public static final String CLASS_codingSchemesType = "codingSchemes";
	public static final String CLASS_codingSchemeVersion = "codingSchemeVersion";
	public static final String CLASS_service = "serviceClass";
	public static final String CLASS_versions = "versions";
}