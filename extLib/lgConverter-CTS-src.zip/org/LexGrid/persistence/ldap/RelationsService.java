/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence.ldap;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;

import org.LexGrid.emf.base.LgModelObj;
import org.LexGrid.emf.commonTypes.CommontypesPackage;
import org.LexGrid.emf.relations.Relations;
import org.LexGrid.emf.relations.RelationsFactory;
import org.LexGrid.emf.relations.RelationsPackage;
import org.LexGrid.emf.relations.impl.RelationsImpl;
import org.LexGrid.managedobj.ManagedObjIF;
import org.LexGrid.managedobj.ServiceInitException;
import org.LexGrid.managedobj.jndi.LdapBaseService;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EFactory;

/**
 * Handles LDAP persistence for the corresponding type of managed object.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class RelationsService extends LgBaseService {

	protected static Map _feature2level, _level2attrs;
	static {
		// Information model to stage mappings ...
		_feature2level = new HashMap(8);
		_feature2level.put(RelationsPackage.eINSTANCE.getRelations_Association(), STAGE_Content);
		_feature2level.put(RelationsPackage.eINSTANCE.getRelations_Dc(), STAGE_Initial);
		_feature2level.put(RelationsPackage.eINSTANCE.getRelations_IsNative(), STAGE_Initial);
		_feature2level.put(CommontypesPackage.eINSTANCE.getDescribable_EntityDescription(), STAGE_Initial);
		_feature2level.put(RelationsPackage.eINSTANCE.getRelations_Source(), STAGE_Extended);

		// Stage to LDAP mappings ...
		_level2attrs = new HashMap(2);
		_level2attrs.put( STAGE_Initial, new String[] {
			RelationsSchemaDef.ATTR_dc,
			RelationsSchemaDef.ATTR_entityDescription,
			RelationsSchemaDef.ATTR_isNative
			});
		_level2attrs.put(STAGE_Extended, new String[] {
			RelationsSchemaDef.ATTR_source
			});
	}

	protected AssociationClassService _assocService;

	public RelationsService(LdapBaseService anchorService) throws ServiceInitException {
		super(anchorService);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.jndiJndiDirService#attrs2obj(org.LexGrid.managedobj.ManagedObjIF, javax.naming.directory.Attributes)
	 */
	protected void attrs2obj(ManagedObjIF obj, Attributes attrs) throws NamingException {
		RelationsImpl impl = (RelationsImpl) obj;
		Attribute attr;
		// Dc attribute value is fixed... allow the default to be used
		// as dictated by the schema regardless of assigned values.
//		if ((attr = attrs.get(RelationsSchemaDef.ATTR_dc)) != null)
//			impl.eSet(RelationsPackage.eINSTANCE.getRelations_Dc(), attr.get());
		if ((attr = attrs.get(RelationsSchemaDef.ATTR_entityDescription)) != null)
			impl.eSet(CommontypesPackage.eINSTANCE.getDescribable_EntityDescription(), attr.get());
		if ((attr = attrs.get(RelationsSchemaDef.ATTR_isNative)) != null)
			impl.eSet(RelationsPackage.eINSTANCE.getRelations_IsNative(), str2Bool((String) attr.get()));
		if ((attr = attrs.get(RelationsSchemaDef.ATTR_source)) != null)
			impl.eSet(RelationsPackage.eINSTANCE.getRelations_Source(), attr2list(attr));
	}

	/* (non-Javadoc)
	 * @see org.org.LexGrid.commons.managedobj.service.BaseService#closePrim()
	 */
	public void closePrim() {
		try {
			super.closePrim();
		} finally {
			_assocService = null;
		}
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#dcResolveContent(org.LexGrid.plugin.base.LgModelObj)
	 */
	public void dcResolveContent(LgModelObj obj) throws NamingException {
		if (obj instanceof Relations) {
			_assocService.setContextEntryPoint(qualifyRdn(obj2rdn(obj)));
			_assocService.setEContext(obj, null, false);
			_assocService.dcResolveContent("", ((Relations) obj).getAssociation());
		}
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getEClass()
	 */
	protected EClass getEClass() {
		return RelationsPackage.eINSTANCE.getRelations();
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getEFactory()
	 */
	protected EFactory getEFactory() {
		return RelationsFactory.eINSTANCE;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#getInstanceClass()
	 */
	protected Class getInstanceClass() {
		return RelationsImpl.class;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#getManagedClasses()
	 */
	public List getManagedClasses() {
		List clazz = super.getManagedClasses();
		clazz.add(RelationsSchemaDef.CLASS_relations);
		return clazz;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getStagingFeature2LevelMap()
	 */
	protected Map getStagingFeature2LevelMap() {
		return _feature2level;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getStagingLevel2AttrsMap()
	 */
	protected Map getStagingLevel2AttrsMap() {
		return _level2attrs;
	}

	/* (non-Javadoc)
	 * @see org.org.LexGrid.commons.managedobj.service.BaseService#initNestedServices()
	 */
	protected void initNestedServices() throws ServiceInitException {
		_assocService = new AssociationClassService(this);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#obj2attrs(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public Attributes obj2attrs(ManagedObjIF obj) {
		// Invoke superclass to pick up generic attributes (objectClass)
		Attributes attrs = super.obj2attrs(obj);

		// Add attributes unique to the given object
		Relations impl = (Relations) obj;
		attrs.put(new BasicAttribute(RelationsSchemaDef.ATTR_dc, impl.eGet(RelationsPackage.eINSTANCE.getRelations_Dc())));
		attrs.put(new BasicAttribute(RelationsSchemaDef.ATTR_entityDescription, impl.eGet(CommontypesPackage.eINSTANCE.getDescribable_EntityDescription())));
		attrs.put(new BasicAttribute(RelationsSchemaDef.ATTR_isNative, bool2str((Boolean) impl.eGet(RelationsPackage.eINSTANCE.getRelations_IsNative()))));
		attrs.put(newMultiValAttr(RelationsSchemaDef.ATTR_source, (List) impl.eGet(RelationsPackage.eINSTANCE.getRelations_Source())));
		return attrs; 
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#postResolve(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public void postResolve(ManagedObjIF obj) throws NamingException {
		super.postResolve(obj);
		RelationsImpl impl = (RelationsImpl) obj;

		// Resolve the associated coded entries (if not staging retrieval) ...
		if (!isStagingEnabled())
			dcResolveContent(impl);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#primaryKey2rdn(java.lang.Object)
	 */
	public String primaryKey2rdn(Object key) {
		return "dc=" + (String) key;
	}

}