/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence.ldap;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;

import org.LexGrid.emf.base.LgModelObj;
import org.LexGrid.emf.relations.AssociationInstance;
import org.LexGrid.emf.relations.RelationsFactory;
import org.LexGrid.emf.relations.RelationsPackage;
import org.LexGrid.emf.relations.impl.AssociationInstanceImpl;
import org.LexGrid.managedobj.ManagedObjIF;
import org.LexGrid.managedobj.ResolveException;
import org.LexGrid.managedobj.ServiceInitException;
import org.LexGrid.managedobj.jndi.LdapBaseService;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EFactory;

/**
 * Handles LDAP persistence for the corresponding type of managed object.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class AssociationInstanceService extends LgBaseService {

	static Integer STAGE_Data = new Integer(1234);
	static Map _feature2level, _level2attrs;
	static {
		// Information model to stage mappings ...
		_feature2level = new HashMap(8);
		_feature2level.put(RelationsPackage.eINSTANCE.getAssociationInstance_SourceCodingScheme(), STAGE_Initial);
		_feature2level.put(RelationsPackage.eINSTANCE.getAssociationInstance_SourceConcept(), STAGE_Initial);
		_feature2level.put(RelationsPackage.eINSTANCE.getAssociationInstance_TargetConcept(), STAGE_Content);
		_feature2level.put(RelationsPackage.eINSTANCE.getAssociationInstance_TargetDataValue(), STAGE_Data);

		// Stage to LDAP mappings ...
		_level2attrs = new HashMap(2);
		_level2attrs.put( STAGE_Initial, new String[] {
			RelationsSchemaDef.ATTR_sourceConcept,
			RelationsSchemaDef.ATTR_sourceCodingScheme,
			});
	}
	
	protected AssociationTargetService _targetService;
	protected AssociationDataService _targetDataService;

	public AssociationInstanceService(LdapBaseService anchorService)
		throws ServiceInitException {
		super(anchorService);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.jndiJndiDirService#attrs2obj(org.LexGrid.managedobj.ManagedObjIF, javax.naming.directory.Attributes)
	 */
	protected void attrs2obj(ManagedObjIF obj, Attributes attrs) throws NamingException {
		AssociationInstanceImpl impl = (AssociationInstanceImpl) obj;
		Attribute attr;
		if ((attr = attrs.get(RelationsSchemaDef.ATTR_sourceConcept)) != null)
			impl.eSet(RelationsPackage.eINSTANCE.getAssociationInstance_SourceConcept(), attr.get());
		// Pick out the non-ldap scheme name, or default to the encapsulating scheme if no value is specified.
		if ((attr = attrs.get(RelationsSchemaDef.ATTR_sourceCodingScheme)) != null) {
			String dn = (String) attr.get();
			String dnLower = dn.toLowerCase();
			String keyLower = org.LexGrid.persistence.ldap.CodingSchemesSchemaDef.ATTR_codingScheme.toLowerCase()+'=';
			int i;
			String scheme = ((i = dnLower.indexOf(keyLower)) >= 0)
				? dn.substring(i+keyLower.length())
				: dn;
			impl.eSet(RelationsPackage.eINSTANCE.getAssociationInstance_SourceCodingScheme(),
				scheme);
// ***  Don't explicitly assign default; value will be inferred dynamically ...
//		} else {
//			Object p = getParent();
//			if (p instanceof LgModelObj) {
//				CodingSchemeType schemeClass = (CodingSchemeType) ((LgModelObj) p).getAncestor(CodingSchemeType.class);
//				if (schemeClass != null)
//					impl.eSet(RelationsPackage.eINSTANCE.getAssociationInstance_SourceCodingScheme(),
//							schemeClass.getCodingScheme());
//			}
		}
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#dcResolveContent(org.LexGrid.plugin.base.LgModelObj)
	 */
	public void dcResolveContent(LgModelObj obj) throws NamingException {
		if (obj instanceof AssociationInstance) {
			_targetService.setContextEntryPoint(qualifyRdn(obj2rdn(obj)));
			_targetService.setEContext(obj, null, false);
			_targetService.dcResolveContent("", ((AssociationInstance) obj).getTargetConcept());
		}
	}

	public void dcResolveData(LgModelObj obj) throws NamingException {
		if (obj instanceof AssociationInstance) {
			_targetDataService.setContextEntryPoint(qualifyRdn(obj2rdn(obj)));
			_targetDataService.setEContext(obj, null, false);
			_targetDataService.dcResolveContent("", ((AssociationInstance) obj).getTargetDataValue());
		}
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getEClass()
	 */
	protected EClass getEClass() {
		return RelationsPackage.eINSTANCE.getAssociationInstance();
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getEFactory()
	 */
	protected EFactory getEFactory() {
		return RelationsFactory.eINSTANCE;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#getInstanceClass()
	 */
	protected Class getInstanceClass() {
		return AssociationInstanceImpl.class;
	}

	/**
	 * @see org.LexGrid.managedobj.jndi.LdapBaseService#getManagedClasses()
	 */
	public List getManagedClasses() {
		List clazz = super.getManagedClasses();
		clazz.add(RelationsSchemaDef.CLASS_associationInstance);
		return clazz;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getStagingFeature2LevelMap()
	 */
	protected Map getStagingFeature2LevelMap() {
		return _feature2level;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getStagingLevel2AttrsMap()
	 */
	protected Map getStagingLevel2AttrsMap() {
		return _level2attrs;
	}

	/* (non-Javadoc)
	 * @see org.org.LexGrid.commons.managedobj.service.BaseService#initNestedServices()
	 */
	protected void initNestedServices() throws ServiceInitException {
		_targetService = new AssociationTargetService(this);
		_targetDataService = new AssociationDataService(this);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#obj2attrs(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public Attributes obj2attrs(ManagedObjIF obj) {
		// Invoke superclass to pick up generic attributes (objectClass)
		Attributes attrs = super.obj2attrs(obj);

		// Add attributes unique to the given object
		AssociationInstanceImpl impl = (AssociationInstanceImpl) obj;
		attrs.put(new BasicAttribute(RelationsSchemaDef.ATTR_sourceConcept, impl.eGet(RelationsPackage.eINSTANCE.getAssociationInstance_SourceConcept())));
		// Put the scheme in ldap-specific form ...
		{
			Object schemeO = impl.eGet(RelationsPackage.eINSTANCE.getAssociationInstance_SourceCodingScheme());
			if (schemeO != null) {
				String scheme = schemeO.toString();
                //Dan commented out the following, because it broke things (forge bug 383)...
                //not sure why it was done in the first place?
//				String schemeLower = scheme.toLowerCase();
//				String key = org.LexGrid.persistence.ldap.codingSchemes.CodingSchemesSchemaDef.ATTR_codingScheme+'=';
//				String keyLower = key.toLowerCase();
//				String dn = (schemeLower.indexOf(keyLower) < 0)
//					? key + scheme
//					: scheme;
				attrs.put(new BasicAttribute(RelationsSchemaDef.ATTR_sourceCodingScheme,
					scheme));
			}
		}
		return attrs;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#postResolve(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public void postResolve(ManagedObjIF obj) throws NamingException {
		super.postResolve(obj);
		AssociationInstanceImpl impl = (AssociationInstanceImpl) obj;

		// Resolve association targets (if not staging retrieval) ...
		if (!isStagingEnabled()) {
			dcResolveContent(impl);
			dcResolveData(impl);
		}
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#primaryKey2rdn(java.lang.Object)
	 */
	public String primaryKey2rdn(Object key) {
		return "sourceConcept=" + (String) key;
	}

	protected void stageFeaturesByLevel(LgModelObj obj, Object levelID) throws ResolveException {
		if (!levelID.equals(STAGE_Data)) {
			super.stageFeaturesByLevel(obj, levelID);
			return;
		}
		try {
			setStagingContext(obj);
			dcResolveData(obj);
		} catch (NamingException e) {
			throw new ResolveException(e);
		}
	}
}