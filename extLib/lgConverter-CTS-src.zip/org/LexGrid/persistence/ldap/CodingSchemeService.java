/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence.ldap;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.naming.Context;
import javax.naming.NameAlreadyBoundException;
import javax.naming.NameNotFoundException;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import org.LexGrid.emf.base.LgConstraint;
import org.LexGrid.emf.base.LgModelObj;
import org.LexGrid.emf.base.impl.LgBasicEListImpl;
import org.LexGrid.emf.codingSchemes.CodingSchemeType;
import org.LexGrid.emf.codingSchemes.CodingSchemeVersion;
import org.LexGrid.emf.codingSchemes.CodingschemesFactory;
import org.LexGrid.emf.codingSchemes.CodingschemesPackage;
import org.LexGrid.emf.codingSchemes.Mappings;
import org.LexGrid.emf.codingSchemes.Versions;
import org.LexGrid.emf.codingSchemes.impl.CodingSchemeTypeImpl;
import org.LexGrid.emf.codingSchemes.impl.CodingSchemeVersionImpl;
import org.LexGrid.emf.codingSchemes.persistence.CodingSchemePersistence;
import org.LexGrid.emf.codingSchemes.util.CodingschemesUtil;
import org.LexGrid.emf.commonTypes.CommontypesPackage;
import org.LexGrid.emf.concepts.Concepts;
import org.LexGrid.emf.concepts.impl.CodedEntryImpl;
import org.LexGrid.emf.concepts.impl.ConceptsImpl;
import org.LexGrid.emf.naming.SupportedRepresentationalForm;
import org.LexGrid.emf.naming.SupportedSource;
import org.LexGrid.emf.naming.impl.SupportedAssociationImpl;
import org.LexGrid.emf.naming.impl.SupportedAssociationQualifierImpl;
import org.LexGrid.emf.naming.impl.SupportedCodingSchemeImpl;
import org.LexGrid.emf.naming.impl.SupportedConceptStatusImpl;
import org.LexGrid.emf.naming.impl.SupportedContextImpl;
import org.LexGrid.emf.naming.impl.SupportedFormatImpl;
import org.LexGrid.emf.naming.impl.SupportedLanguageImpl;
import org.LexGrid.emf.naming.impl.SupportedPropertyImpl;
import org.LexGrid.emf.relations.Association;
import org.LexGrid.emf.relations.AssociationInstance;
import org.LexGrid.emf.relations.Relations;
import org.LexGrid.emf.relations.impl.AssociationImpl;
import org.LexGrid.emf.relations.impl.AssociationInstanceImpl;
import org.LexGrid.emf.relations.impl.AssociationTargetImpl;
import org.LexGrid.emf.relations.impl.RelationsImpl;
import org.LexGrid.emf.relations.util.RelationsUtil;
import org.LexGrid.managedobj.BaseService;
import org.LexGrid.managedobj.HomeServiceBroker;
import org.LexGrid.managedobj.ManagedObjIF;
import org.LexGrid.managedobj.ManagedObjIterator;
import org.LexGrid.managedobj.ManagedObjIteratorWrapper;
import org.LexGrid.managedobj.QueryException;
import org.LexGrid.managedobj.ServiceInitException;
import org.LexGrid.managedobj.jndi.LdapBaseService;
import org.LexGrid.managedobj.jndi.LdapContextDescriptor;
import org.LexGrid.managedobj.jndi.LdapContextPoolPolicy;
import org.apache.log4j.Logger;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EFactory;

/**
 * Handles LDAP persistence for the corresponding type of managed object.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class CodingSchemeService
	extends LgBaseService
	implements CodingSchemePersistence {

    protected final static Logger logger = Logger.getLogger("org.LexGrid.managedobj.ldap.CodingSchemeService");

    static Map _feature2level, _level2attrs;
	static {
		// Information model to stage mappings ...
		_feature2level = new HashMap(32);
		_feature2level.put(CodingschemesPackage.eINSTANCE.getCodingSchemeType_ApproxNumConcepts(), STAGE_Initial);
		_feature2level.put(CodingschemesPackage.eINSTANCE.getCodingSchemeType_CodingScheme(), STAGE_Initial);
		_feature2level.put(CodingschemesPackage.eINSTANCE.getCodingSchemeType_CopyrightText(), STAGE_Extended);
		_feature2level.put(CodingschemesPackage.eINSTANCE.getCodingSchemeType_DefaultLanguage(), STAGE_Extended);
		_feature2level.put(CodingschemesPackage.eINSTANCE.getCodingSchemeType_FormalName(), STAGE_Initial);
		_feature2level.put(CodingschemesPackage.eINSTANCE.getCodingSchemeType_IsNative(), STAGE_Initial);
		_feature2level.put(CodingschemesPackage.eINSTANCE.getCodingSchemeType_LocalName(), STAGE_Initial);
		_feature2level.put(CodingschemesPackage.eINSTANCE.getCodingSchemeType_RegisteredName(), STAGE_Initial);
		_feature2level.put(CodingschemesPackage.eINSTANCE.getCodingSchemeType_RepresentsVersion(), STAGE_Extended);
		_feature2level.put(CodingschemesPackage.eINSTANCE.getCodingSchemeType_Source(), STAGE_Initial);
		_feature2level.put(CodingschemesPackage.eINSTANCE.getCodingSchemeType_Mappings(), STAGE_Initial);
		_feature2level.put(CommontypesPackage.eINSTANCE.getDescribable_EntityDescription(), STAGE_Initial);

		// Stage to LDAP mappings ...
		_level2attrs = new HashMap(2);
		_level2attrs.put( STAGE_Initial, new String[] {
			CodingSchemesSchemaDef.ATTR_approxNumConcepts,
			CodingSchemesSchemaDef.ATTR_codingScheme,
			CodingSchemesSchemaDef.ATTR_entityDescription,
			CodingSchemesSchemaDef.ATTR_formalName,
			CodingSchemesSchemaDef.ATTR_isNative,
			CodingSchemesSchemaDef.ATTR_localName,
			CodingSchemesSchemaDef.ATTR_registeredName,
			CodingSchemesSchemaDef.ATTR_source,
			CodingSchemesSchemaDef.ATTR_supportedAssociation,
			CodingSchemesSchemaDef.ATTR_supportedAssociationQualifier,
			CodingSchemesSchemaDef.ATTR_supportedCodingScheme,
			CodingSchemesSchemaDef.ATTR_supportedConceptStatus,
			CodingSchemesSchemaDef.ATTR_supportedContext,
			CodingSchemesSchemaDef.ATTR_supportedDataType,
			CodingSchemesSchemaDef.ATTR_supportedFormat,
			CodingSchemesSchemaDef.ATTR_supportedLanguage,
			CodingSchemesSchemaDef.ATTR_supportedProperty,
			CodingSchemesSchemaDef.ATTR_supportedSource
			});
		_level2attrs.put(STAGE_Extended, new String[] {
			CodingSchemesSchemaDef.ATTR_copyright,
			CodingSchemesSchemaDef.ATTR_defaultLanguage,
			CodingSchemesSchemaDef.ATTR_representsVersion
			});
	}

	protected ConceptsService _conceptsService;
	protected RelationsService _relationsService;
	protected VersionsService _versionsService;

	/**
	 * @param broker
	 * @param xmlFile
	 * @param ctxDescriptor
	 * @param ctxPoolPolicy
	 * @throws ServiceInitException
	 */
	public CodingSchemeService(
		HomeServiceBroker broker,
		File xmlFile,
		LdapContextDescriptor ctxDescriptor,
		LdapContextPoolPolicy ctxPoolPolicy)
		throws ServiceInitException {
		super(broker, xmlFile, ctxDescriptor, ctxPoolPolicy);
	}

	/**
	 * @param broker
	 * @param xmlFile
	 * @param ctxDescriptor
	 * @param ctxPoolPolicy
	 * @param resolveLinksEnabled
	 * @param stagedRetrievalEnabled
	 * @throws ServiceInitException
	 */
	public CodingSchemeService(
		HomeServiceBroker broker,
		File xmlFile,
		LdapContextDescriptor ctxDescriptor,
		LdapContextPoolPolicy ctxPoolPolicy,
		boolean stagedRetrievalEnabled)
		throws ServiceInitException {
		super(
			broker,
			xmlFile,
			ctxDescriptor,
			ctxPoolPolicy,
			stagedRetrievalEnabled);
	}

	/**
	 * @param anchorService
	 * @throws ServiceInitException
	 */
	public CodingSchemeService(LdapBaseService anchorService) throws ServiceInitException {
		super(anchorService);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.jndiJndiDirService#attrs2obj(org.LexGrid.managedobj.ManagedObjIF, javax.naming.directory.Attributes)
	 */
	protected void attrs2obj(ManagedObjIF obj, Attributes attrs) throws NamingException {
		CodingSchemeTypeImpl impl = (CodingSchemeTypeImpl) obj;
		Attribute attr;
		if ((attr = attrs.get(CodingSchemesSchemaDef.ATTR_approxNumConcepts)) != null)
			impl.eSet(CodingschemesPackage.eINSTANCE.getCodingSchemeType_ApproxNumConcepts(), Integer.valueOf((String) attr.get()));
		if ((attr = attrs.get(CodingSchemesSchemaDef.ATTR_codingScheme)) != null)
			impl.eSet(CodingschemesPackage.eINSTANCE.getCodingSchemeType_CodingScheme(), attr.get());
		if ((attr = attrs.get(CodingSchemesSchemaDef.ATTR_copyright)) != null)
			impl.eSet(CodingschemesPackage.eINSTANCE.getCodingSchemeType_CopyrightText(), attr.get());
		if ((attr = attrs.get(CodingSchemesSchemaDef.ATTR_defaultLanguage)) != null)
			impl.eSet(CodingschemesPackage.eINSTANCE.getCodingSchemeType_DefaultLanguage(), attr.get());
		if ((attr = attrs.get(CodingSchemesSchemaDef.ATTR_entityDescription)) != null)
			impl.eSet(CommontypesPackage.eINSTANCE.getDescribable_EntityDescription(), attr.get());
		if ((attr = attrs.get(CodingSchemesSchemaDef.ATTR_formalName)) != null)
			impl.eSet(CodingschemesPackage.eINSTANCE.getCodingSchemeType_FormalName(), attr.get());
		if ((attr = attrs.get(CodingSchemesSchemaDef.ATTR_isNative)) != null)
			impl.eSet(CodingschemesPackage.eINSTANCE.getCodingSchemeType_IsNative(), str2Bool((String) attr.get()));
		if ((attr = attrs.get(CodingSchemesSchemaDef.ATTR_localName)) != null)
			impl.eSet(CodingschemesPackage.eINSTANCE.getCodingSchemeType_LocalName(), attr2list(attr));
		if ((attr = attrs.get(CodingSchemesSchemaDef.ATTR_registeredName)) != null)
			impl.eSet(CodingschemesPackage.eINSTANCE.getCodingSchemeType_RegisteredName(), attr.get());
		if ((attr = attrs.get(CodingSchemesSchemaDef.ATTR_representsVersion)) != null)
			impl.eSet(CodingschemesPackage.eINSTANCE.getCodingSchemeType_RepresentsVersion(), attr.get());
		if ((attr = attrs.get(CodingSchemesSchemaDef.ATTR_source)) != null)
			impl.eSet(CodingschemesPackage.eINSTANCE.getCodingSchemeType_Source(), attr2sourceList(attr));
		
		Mappings implMap = impl.getMappings();
		if (implMap == null)
			impl.setMappings(implMap = CodingschemesFactory.eINSTANCE.createMappings());
		if ((attr = attrs.get(CodingSchemesSchemaDef.ATTR_supportedAssociation)) != null)
			implMap.eSet(CodingschemesPackage.eINSTANCE.getMappings_SupportedAssociation(), attr2urnMaps(attr, SupportedAssociationImpl.class));
		if ((attr = attrs.get(CodingSchemesSchemaDef.ATTR_supportedAssociationQualifier)) != null)
			implMap.eSet(CodingschemesPackage.eINSTANCE.getMappings_SupportedAssociationQualifier(), attr2urnMaps(attr, SupportedAssociationQualifierImpl.class));
		if ((attr = attrs.get(CodingSchemesSchemaDef.ATTR_supportedCodingScheme)) != null)
			implMap.eSet(CodingschemesPackage.eINSTANCE.getMappings_SupportedCodingScheme(), attr2urnMaps(attr, SupportedCodingSchemeImpl.class));
		if ((attr = attrs.get(CodingSchemesSchemaDef.ATTR_supportedConceptStatus)) != null)
			implMap.eSet(CodingschemesPackage.eINSTANCE.getMappings_SupportedConceptStatus(), attr2urnMaps(attr, SupportedConceptStatusImpl.class));
		if ((attr = attrs.get(CodingSchemesSchemaDef.ATTR_supportedContext)) != null)
			implMap.eSet(CodingschemesPackage.eINSTANCE.getMappings_SupportedContext(), attr2urnMaps(attr, SupportedContextImpl.class));
		if ((attr = attrs.get(CodingSchemesSchemaDef.ATTR_supportedFormat)) != null)
			implMap.eSet(CodingschemesPackage.eINSTANCE.getMappings_SupportedFormat(), attr2urnMaps(attr, SupportedFormatImpl.class));
		if ((attr = attrs.get(CodingSchemesSchemaDef.ATTR_supportedLanguage)) != null)
			implMap.eSet(CodingschemesPackage.eINSTANCE.getMappings_SupportedLanguage(), attr2urnMaps(attr, SupportedLanguageImpl.class));
		if ((attr = attrs.get(CodingSchemesSchemaDef.ATTR_supportedProperty)) != null)
			implMap.eSet(CodingschemesPackage.eINSTANCE.getMappings_SupportedProperty(), attr2urnMaps(attr, SupportedPropertyImpl.class));
		if ((attr = attrs.get(CodingSchemesSchemaDef.ATTR_supportedRepresentationalForm)) != null)
			implMap.eSet(CodingschemesPackage.eINSTANCE.getMappings_SupportedRepresentationalForm(), attr2urnMaps(attr, SupportedRepresentationalForm.class));
		if ((attr = attrs.get(CodingSchemesSchemaDef.ATTR_supportedSource)) != null)
			implMap.eSet(CodingschemesPackage.eINSTANCE.getMappings_SupportedSource(), attr2urnMaps(attr, SupportedSource.class));
	}

	/* (non-Javadoc)
	 * @see org.org.LexGrid.commons.managedobj.service.BaseService#closePrim()
	 */
	public void closePrim() {
		try {
			super.closePrim();
		} finally {
			_conceptsService = null;
			_relationsService = null;
			_versionsService = null;
		}
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#getInstanceClass()
	 */
	protected Class getInstanceClass() {
		return CodingSchemeTypeImpl.class;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#getManagedClasses()
	 */
	public List getManagedClasses() {
		List clazz = super.getManagedClasses();
		clazz.add(CodingSchemesSchemaDef.CLASS_codingSchemeType);
		return clazz;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getStagingFeature2LevelMap()
	 */
	protected Map getStagingFeature2LevelMap() {
		return _feature2level;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getStagingLevel2AttrsMap()
	 */
	protected Map getStagingLevel2AttrsMap() {
		return _level2attrs;
	}

	/* (non-Javadoc)
	 * @see org.org.LexGrid.commons.managedobj.service.BaseService#initNestedServices()
	 */
	protected void initNestedServices() throws ServiceInitException {
		_conceptsService = new ConceptsService(this);
		_relationsService = new RelationsService(this);
		_versionsService = new VersionsService(this);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#obj2attrs(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public Attributes obj2attrs(ManagedObjIF obj) {
		// Invoke superclass to pick up generic attributes (objectClass)
		Attributes attrs = super.obj2attrs(obj);

		// Add attributes unique to the given object
		CodingSchemeTypeImpl impl = (CodingSchemeTypeImpl) obj;
		attrs.put(new BasicAttribute(CodingSchemesSchemaDef.ATTR_approxNumConcepts, ((Integer) impl.eGet(CodingschemesPackage.eINSTANCE.getCodingSchemeType_ApproxNumConcepts())).toString()));
		attrs.put(new BasicAttribute(CodingSchemesSchemaDef.ATTR_codingScheme, impl.eGet(CodingschemesPackage.eINSTANCE.getCodingSchemeType_CodingScheme())));
		attrs.put(new BasicAttribute(CodingSchemesSchemaDef.ATTR_copyright, impl.eGet(CodingschemesPackage.eINSTANCE.getCodingSchemeType_CopyrightText())));
		attrs.put(new BasicAttribute(CodingSchemesSchemaDef.ATTR_defaultLanguage, impl.eGet(CodingschemesPackage.eINSTANCE.getCodingSchemeType_DefaultLanguage())));
		attrs.put(new BasicAttribute(CodingSchemesSchemaDef.ATTR_entityDescription, impl.eGet(CommontypesPackage.eINSTANCE.getDescribable_EntityDescription())));
		attrs.put(new BasicAttribute(CodingSchemesSchemaDef.ATTR_formalName, impl.eGet(CodingschemesPackage.eINSTANCE.getCodingSchemeType_FormalName())));
		attrs.put(new BasicAttribute(CodingSchemesSchemaDef.ATTR_isNative, bool2str((Boolean) impl.eGet(CodingschemesPackage.eINSTANCE.getCodingSchemeType_IsNative()))));
		attrs.put(newMultiValAttr(CodingSchemesSchemaDef.ATTR_localName, (List) impl.eGet(CodingschemesPackage.eINSTANCE.getCodingSchemeType_LocalName())));
		attrs.put(new BasicAttribute(CodingSchemesSchemaDef.ATTR_registeredName, impl.eGet(CodingschemesPackage.eINSTANCE.getCodingSchemeType_RegisteredName())));
		attrs.put(new BasicAttribute(CodingSchemesSchemaDef.ATTR_representsVersion, impl.eGet(CodingschemesPackage.eINSTANCE.getCodingSchemeType_RepresentsVersion())));
		attrs.put(newMultiValAttr(CodingSchemesSchemaDef.ATTR_source, (List) impl.eGet(CodingschemesPackage.eINSTANCE.getCodingSchemeType_Source())));

		Mappings implMap = impl.getMappings();
		List vals;
		vals = (List) implMap.eGet(CodingschemesPackage.eINSTANCE.getMappings_SupportedAssociation());
		if (!vals.isEmpty()) attrs.put(urnMaps2attr(CodingSchemesSchemaDef.ATTR_supportedAssociation, vals));
		vals = (List) implMap.eGet(CodingschemesPackage.eINSTANCE.getMappings_SupportedAssociationQualifier());
		if (!vals.isEmpty()) attrs.put(urnMaps2attr(CodingSchemesSchemaDef.ATTR_supportedAssociationQualifier, vals));
		vals = (List) implMap.eGet(CodingschemesPackage.eINSTANCE.getMappings_SupportedCodingScheme());
		if (!vals.isEmpty()) attrs.put(urnMaps2attr(CodingSchemesSchemaDef.ATTR_supportedCodingScheme, vals));
		vals = (List) implMap.eGet(CodingschemesPackage.eINSTANCE.getMappings_SupportedContext());
		if (!vals.isEmpty()) attrs.put(urnMaps2attr(CodingSchemesSchemaDef.ATTR_supportedContext, vals));
		vals = (List) implMap.eGet(CodingschemesPackage.eINSTANCE.getMappings_SupportedFormat());
		if (!vals.isEmpty()) attrs.put(urnMaps2attr(CodingSchemesSchemaDef.ATTR_supportedFormat, vals));
		vals = (List) implMap.eGet(CodingschemesPackage.eINSTANCE.getMappings_SupportedLanguage());
		if (!vals.isEmpty()) attrs.put(urnMaps2attr(CodingSchemesSchemaDef.ATTR_supportedLanguage, vals));
		vals = (List) implMap.eGet(CodingschemesPackage.eINSTANCE.getMappings_SupportedProperty());
		if (!vals.isEmpty()) attrs.put(urnMaps2attr(CodingSchemesSchemaDef.ATTR_supportedProperty, vals));
		vals = (List) implMap.eGet(CodingschemesPackage.eINSTANCE.getMappings_SupportedRepresentationalForm());
		if (!vals.isEmpty()) attrs.put(urnMaps2attr(CodingSchemesSchemaDef.ATTR_supportedRepresentationalForm, vals));
		vals = (List) implMap.eGet(CodingschemesPackage.eINSTANCE.getMappings_SupportedSource());
		if (!vals.isEmpty()) attrs.put(urnMaps2attr(CodingSchemesSchemaDef.ATTR_supportedSource, vals));

		return attrs;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#postResolve(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public void postResolve(ManagedObjIF obj) throws NamingException {
		super.postResolve(obj);
		CodingSchemeTypeImpl impl = (CodingSchemeTypeImpl) obj;
		String implQdn = qualifyRdn(obj2rdn(obj));

		// Resolve the associated concepts (unstaged) ...
		_conceptsService.setContextEntryPoint(implQdn);
		_conceptsService.setEContext(impl, null, false);
		impl.eSet(CodingschemesPackage.eINSTANCE.getCodingSchemeType_Concepts(),
			_conceptsService.dcResolveFirst());

		// Resolve the associated versions (unstaged) ...
		_versionsService.setContextEntryPoint(implQdn);
		_versionsService.setEContext(impl, null, false);
		impl.eSet(CodingschemesPackage.eINSTANCE.getCodingSchemeType_Versions(),
			_versionsService.dcResolveFirst());

		// Resolve the associated relations (unstaged) ...
		// Note: resolve relations last since full resolution of
		// imbedded references may rely on pre-resolution of concepts.
		_relationsService.setContextEntryPoint(implQdn);
		_relationsService.setEContext(impl, null, false);
		impl.eSet(CodingschemesPackage.eINSTANCE.getCodingSchemeType_Relations(),
			new BasicEList(_relationsService.dcResolveAllToList("", null)));
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#primaryKey2rdn(java.lang.Object)
	 */
	public String primaryKey2rdn(Object key) {
		return "codingScheme=" + (String) key;
	}
	
	/* (non-Javadoc)
	 * @see org.LexGrid.plugin.base.LgSearchableIF#queryConcepts(org.LexGrid.plugin.base.LgModelObj, org.LexGrid.plugin.base.LgConstraint[], int)
	 */
	public ManagedObjIterator queryConcepts(LgModelObj root, LgConstraint[] constraints, int limit) throws QueryException {
		if (!(root instanceof CodingSchemeType))
			throw new IllegalArgumentException("root");
		if (limit < 0)
			throw new IllegalArgumentException("limit");
		
		LgBasicEListImpl list = new LgBasicEListImpl();
		list.setConstraints(constraints);
		list.setPageSize(limit);
		boolean noLimit = limit == 0;
		try {
			BaseService s1, s2, s3;
			CodingSchemeType scheme = (CodingSchemeType) root;

			// Search the primary concepts container ...
			_conceptsService.setContextEntryPoint(qualifyRdn(obj2rdn(scheme)));
			_conceptsService.setEContext(scheme, null, false);
			
			s1 = _conceptsService.getNestedService(CodedEntryImpl.class);
			if (s1 instanceof LgBaseService) {
				Concepts concepts = scheme.getConcepts();
				if (concepts != null) {
					LgBaseService conceptService = (LgBaseService) s1;
					conceptService.setContextEntryPoint(_conceptsService.qualifyRdn(_conceptsService.obj2rdn(concepts)));
					conceptService.setEContext(concepts, null, false);
					conceptService.dcEnhancedResolve("", list);
				}
			}
			
			// Search concept changes in each available version ...
			int remainingLimit = noLimit ? 0 : limit - list.size();
			if (noLimit || remainingLimit > 0) {
				Versions versions = scheme.getVersions();
				if (versions != null) {
					_versionsService.setContextEntryPoint(qualifyRdn(obj2rdn(scheme)));
					_versionsService.setEContext(scheme, null, false);
					
					s1 = _versionsService.getNestedService(CodingSchemeVersionImpl.class);
					s2 = s1.getNestedService(ConceptsImpl.class);
					s3 = s2.getNestedService(CodedEntryImpl.class);
					if (s1 instanceof LgBaseService && s2 instanceof LgBaseService && s3 instanceof LgBaseService) {
						LgBaseService versionService = (LgBaseService) s1;
						LgBaseService conceptsService = (LgBaseService) s2;
						LgBaseService conceptService = (LgBaseService) s3;
						versionService.setContextEntryPoint(_versionsService.qualifyRdn(_versionsService.obj2rdn(versions)));
						versionService.setEContext(versions, null, false);
		
						Iterator versionIt = scheme.getVersions().getContent(CodingSchemeVersion.class, 0);
						while (versionIt.hasNext() && (noLimit || remainingLimit > 0)) {
							CodingSchemeVersion version = (CodingSchemeVersion) versionIt.next();
							Concepts concepts = version.getConcepts();
							if (concepts != null) {
								LgBasicEListImpl list2 = new LgBasicEListImpl();
								list2.setConstraints(constraints);
								list2.setPageSize(remainingLimit);

								conceptsService.setContextEntryPoint(versionService.qualifyRdn(versionService.obj2rdn(version)));
								conceptService.setContextEntryPoint(conceptsService.qualifyRdn(conceptsService.obj2rdn(concepts)));
								conceptService.setEContext(concepts, null, false);
								conceptService.dcEnhancedResolve("", list2);
								
								list.addAll(list2);
								remainingLimit = noLimit ? 0 : limit - list.size();
							}
						}
					}
				}
			}
		} catch (NamingException e) {
			throw new QueryException(e);
		}
		return new ManagedObjIteratorWrapper(list.iterator());
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.plugin.base.LgSearchableIF#queryRelationSources(org.LexGrid.plugin.base.LgModelObj, java.lang.String, int)
	 */
	public ManagedObjIterator queryRelationSources(LgModelObj root, String code, int limit) throws QueryException {
		if (!(root instanceof CodingSchemeType))
			throw new IllegalArgumentException("root");
		if (limit < 0)
			throw new IllegalArgumentException("limit");
		
		List list = new ArrayList();
		CodingSchemeType scheme = (CodingSchemeType) root;
		BaseService s1, s2, s3, s4;
		boolean noLimit = limit == 0;
		int remainingLimit = limit;
		try {
			// Init immediately nested services ...
			_relationsService.setContextEntryPoint(qualifyRdn(obj2rdn(scheme)));
			_relationsService.setEContext(scheme, null, false);
			_versionsService.setContextEntryPoint(qualifyRdn(obj2rdn(scheme)));
			_versionsService.setEContext(scheme, null, false);
			
			// Init search controls ...
			SearchControls sc = new SearchControls();
			sc.setDerefLinkFlag(true);
			sc.setReturningObjFlag(false);
			sc.setSearchScope(SearchControls.SUBTREE_SCOPE);
			sc.setReturningAttributes(null);

			// Search all non-versioned relation containers ...
			s1 = _relationsService.getNestedService(AssociationImpl.class);
			s2 = s1.getNestedService(AssociationInstanceImpl.class);
			if (s1 instanceof LgBaseService && s1 instanceof LgBaseService) {
				LgBaseService acService = (LgBaseService) s1;
				LgBaseService aiService = (LgBaseService) s2;

				// Init search filter ...
				StringBuffer sb = new StringBuffer(256);
				sb.append("(&");
				sb.append("(|(");
				String[] classes = aiService.getResolveClasses();
				for (int i = 0; i < classes.length; i++)
					sb.append("(objectClass=").append(classes[i]).append(')');
				sb.append("))(");
				sb.append(org.LexGrid.persistence.ldap.RelationsSchemaDef.ATTR_sourceConcept);
				sb.append("=").append(code).append("))");

				String expr = sb.toString();

				Map dn2ac = new HashMap();

				// Perform the search ...
				LdapContext ctx = checkOutLdapContext();
				try {
					for (Iterator containers = scheme.getRelations().iterator(); containers.hasNext() && (noLimit || remainingLimit > 0); ) {
						Relations container = (Relations) containers.next();
						String searchRdn = _relationsService.qualifyRdn(_relationsService.obj2rdn(container));
						acService.setContextEntryPoint(searchRdn);
						acService.setEContext(container, null, false);

						NamingEnumeration ne = ctx.search(searchRdn, expr, null, sc);
						while (ne.hasMoreElements() && (noLimit || remainingLimit > 0)) {
							// Extract names for association instance and class ...
							SearchResult sr = (SearchResult) ne.next();
							String srName = unwrapName(sr);
							int i = srName.indexOf(',');
							String aiName = srName.substring(0, i);
							String acName = srName.substring(i+1);
							String acNameQ = acService.qualifyRdn(acName);

							// Resolve the names, reusing parent objects when possible ...
							Association ac = (Association) dn2ac.get(acNameQ);
							if (ac == null) {
								acService.setEContext(container, null, false);
								ac = (Association) acService.dcResolve(acName);
								dn2ac.put(acNameQ, ac);
							}
							// Add the instance, with resolved ancestors, to the list ...
							aiService.setContextEntryPoint(acNameQ);
							aiService.setEContext(ac, null, false);
							list.add(aiService.dcResolve(aiName));
							remainingLimit--;		
						}
					}
				} finally {
					checkInContext(ctx);
				}
			}

			// Also search all versioned relation containers ...
			Versions versions = scheme.getVersions();
			if (versions != null && (noLimit || remainingLimit > 0)) {
				s1 = _versionsService.getNestedService(CodingSchemeVersionImpl.class);
				s2 = s1.getNestedService(RelationsImpl.class);
				s3 = s2.getNestedService(AssociationImpl.class);
				s4 = s3.getNestedService(AssociationInstanceImpl.class);
				if (s1 instanceof LgBaseService && s1 instanceof LgBaseService && s3 instanceof LgBaseService && s4 instanceof LgBaseService) {
					LgBaseService cvService = (LgBaseService) s1;
					LgBaseService rcService = (LgBaseService) s2;
					LgBaseService acService = (LgBaseService) s3;
					LgBaseService aiService = (LgBaseService) s4;
	
					// Init search filter ...
					StringBuffer sb = new StringBuffer(256);
					sb.append("(&");
					sb.append("(|(");
					String[] classes = aiService.getResolveClasses();
					for (int i = 0; i < classes.length; i++)
						sb.append("(objectClass=").append(classes[i]).append(')');
					sb.append("))(");
					sb.append(org.LexGrid.persistence.ldap.RelationsSchemaDef.ATTR_sourceConcept);
					sb.append("=").append(code).append("))");
	
					String expr = sb.toString();
	
					Map dn2ac = new HashMap();
	
					cvService.setContextEntryPoint(_versionsService.qualifyRdn(_versionsService.obj2rdn(scheme.getVersions())));
					cvService.setEContext(versions, null, false);
					for (Iterator versionIt = scheme.getVersions().getVersion().iterator(); versionIt.hasNext(); ) {
						CodingSchemeVersion version = (CodingSchemeVersion) versionIt.next();
						rcService.setContextEntryPoint(cvService.qualifyRdn(cvService.obj2rdn(version)));
						rcService.setEContext(version, null, false);
						LdapContext ctx = checkOutLdapContext();
						try {
							List relationContainers = version.getRelations();
							for (Iterator containers = relationContainers.iterator(); containers.hasNext() && (noLimit || remainingLimit > 0); ) {
								Relations container = (Relations) containers.next();
								String searchRdn = rcService.qualifyRdn(rcService.obj2rdn(container));
								acService.setContextEntryPoint(searchRdn);
								acService.setEContext(container, null, false);
								
								NamingEnumeration ne = ctx.search(searchRdn, expr, null, sc);
								while (ne.hasMoreElements() && (noLimit || remainingLimit > 0)) {
									// Extract names for association instance and class ...
									SearchResult sr = (SearchResult) ne.next();
									String srName = unwrapName(sr);
									int i = srName.indexOf(',');
									String aiName = srName.substring(0, i);
									String acName = srName.substring(i+1);
									String acNameQ = acService.qualifyRdn(acName);
	
									// Resolve the names, reusing parent objects when possible ...
									Association ac = (Association) dn2ac.get(acNameQ);
									if (ac == null) {
										acService.setEContext(container, null, false);
										ac = (Association) acService.dcResolve(acName);
										dn2ac.put(acNameQ, ac);
									}
									// Add the target, with resolved ancestors, to the list ...
									aiService.setContextEntryPoint(acNameQ);
									aiService.setEContext(ac, null, false);
									list.add(aiService.dcResolve(aiName));
									remainingLimit--;		
								}
							}
						} finally {
							checkInContext(ctx);
						}
					}
				}
			}
		} catch (NamingException e) {
			throw new QueryException(e);
		}
		return new ManagedObjIteratorWrapper(list.iterator());
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.plugin.base.LgSearchableIF#queryRelationTargets(org.LexGrid.plugin.base.LgModelObj, java.lang.String, java.lang.String, int)
	 */
	public ManagedObjIterator queryRelationTargets(LgModelObj root, String targetContext, String targetCode, int limit) throws QueryException {
		if (!(root instanceof CodingSchemeType))
			throw new IllegalArgumentException("eptRoot");
		if (limit < 0)
			throw new IllegalArgumentException("limit");
		
		List list = new ArrayList();
		CodingSchemeType scheme = (CodingSchemeType) root;
		BaseService s1, s2, s3, s4, s5;
		boolean noLimit = limit == 0;
		int remainingLimit = limit;
		try {
			// Init immediately nested services ...
			_relationsService.setContextEntryPoint(qualifyRdn(obj2rdn(scheme)));
			_relationsService.setEContext(scheme, null, false);
			_versionsService.setContextEntryPoint(qualifyRdn(obj2rdn(scheme)));
			_versionsService.setEContext(scheme, null, false);
			
			// Init search controls ...
			SearchControls sc = new SearchControls();
			sc.setDerefLinkFlag(true);
			sc.setReturningObjFlag(false);
			sc.setSearchScope(SearchControls.SUBTREE_SCOPE);
			sc.setReturningAttributes(null);

			// Search all non-versioned relation containers ...
			s1 = _relationsService.getNestedService(AssociationImpl.class);
			s2 = s1.getNestedService(AssociationInstanceImpl.class);
			s3 = s2.getNestedService(AssociationTargetImpl.class);
			if (s1 instanceof LgBaseService && s1 instanceof LgBaseService && s3 instanceof LgBaseService) {
				LgBaseService acService = (LgBaseService) s1;
				LgBaseService aiService = (LgBaseService) s2;
				LgBaseService atService = (LgBaseService) s3;

				// Init search filter ...
				StringBuffer sb = new StringBuffer(256);
				sb.append("(&");
				sb.append("(|(");
				String[] classes = atService.getResolveClasses();
				for (int i = 0; i < classes.length; i++)
					sb.append("(objectClass=").append(classes[i]).append(')');
				sb.append("))(");
				sb.append(org.LexGrid.persistence.ldap.RelationsSchemaDef.ATTR_targetConceptCode);
				sb.append("=").append(targetCode).append("))");

				String expr = sb.toString();

				Map dn2ac = new HashMap();
				Map dn2ai = new HashMap();

				// Perform the search ...
				LdapContext ctx = checkOutLdapContext();
				try {
					for (Iterator containers = scheme.getRelations().iterator(); containers.hasNext() && (noLimit || remainingLimit > 0); ) {
						Relations container = (Relations) containers.next();
						String searchRdn = _relationsService.qualifyRdn(_relationsService.obj2rdn(container));
						acService.setContextEntryPoint(searchRdn);
						acService.setEContext(container, null, false);

						NamingEnumeration ne = ctx.search(searchRdn, expr, null, sc);
						while (ne.hasMoreElements() && (noLimit || remainingLimit > 0)) {
							// Extract names for association target, instance, and class ...
							SearchResult sr = (SearchResult) ne.next();
							String srName = unwrapName(sr);
							int i = srName.indexOf(',');
							String atName = srName.substring(0, i);
							srName = srName.substring(i+1);
							i = srName.indexOf(',');
							String aiName = srName.substring(0, i);
							String acName = srName.substring(i+1);
							String acDn = acService.qualifyRdn(acName);
							aiService.setContextEntryPoint(acDn);
							String aiNameQ = aiService.qualifyRdn(aiName);

							// Resolve the names, reusing parent objects when possible ...
							Association ac = (Association) dn2ac.get(acDn);
							if (ac == null) {
								acService.setEContext(container, null, false);
								ac = (Association) acService.dcResolve(acName);
								dn2ac.put(acDn, ac);
							}
							AssociationInstance ai = (AssociationInstance) dn2ai.get(aiNameQ);
							if (ai == null) {
								aiService.setEContext(ac, null, false);
								ai = (AssociationInstance) aiService.dcResolve(aiName);
								dn2ai.put(aiNameQ, ai);
							}
							// Add matching targets, with resolved ancestors, to the list ...
							String acContext = RelationsUtil.resolveTargetSchemeName(ac);
							if (targetContext == null || targetContext == acContext || targetContext.equalsIgnoreCase(acContext)) {
								atService.setContextEntryPoint(aiService.qualifyRdn(aiName));
								atService.setEContext(ai, null, false);
								list.add(atService.dcResolve(atName));
								remainingLimit--;
							}
						}
					}
				} finally {
					checkInContext(ctx);
				}
			}

			// Also search all versioned relation containers ...
			Versions versions = scheme.getVersions();
			if (versions != null && (noLimit || remainingLimit > 0)) {
				s1 = _versionsService.getNestedService(CodingSchemeVersionImpl.class);
				s2 = s1.getNestedService(RelationsImpl.class);
				s3 = s2.getNestedService(AssociationImpl.class);
				s4 = s3.getNestedService(AssociationInstanceImpl.class);
				s5 = s4.getNestedService(AssociationTargetImpl.class);
				if (s1 instanceof LgBaseService && s1 instanceof LgBaseService && s3 instanceof LgBaseService && s4 instanceof LgBaseService && s5 instanceof LgBaseService) {
					LgBaseService cvService = (LgBaseService) s1;
					LgBaseService rcService = (LgBaseService) s2;
					LgBaseService acService = (LgBaseService) s3;
					LgBaseService aiService = (LgBaseService) s4;
					LgBaseService atService = (LgBaseService) s5;
	
					// Init search filter ...
					StringBuffer sb = new StringBuffer(256);
					sb.append("(&");
					sb.append("(|(");
					String[] classes = atService.getResolveClasses();
					for (int i = 0; i < classes.length; i++)
						sb.append("(objectClass=").append(classes[i]).append(')');
					sb.append("))(");
					sb.append(org.LexGrid.persistence.ldap.RelationsSchemaDef.ATTR_targetConceptCode);
					sb.append("=").append(targetCode).append("))");
	
					String expr = sb.toString();
	
					Map dn2ac = new HashMap();
					Map dn2ai = new HashMap();
	
					cvService.setContextEntryPoint(_versionsService.qualifyRdn(_versionsService.obj2rdn(scheme.getVersions())));
					cvService.setEContext(versions, null, false);
					for (Iterator versionIt = scheme.getVersions().getVersion().iterator(); versionIt.hasNext(); ) {
						CodingSchemeVersion version = (CodingSchemeVersion) versionIt.next();
						rcService.setContextEntryPoint(cvService.qualifyRdn(cvService.obj2rdn(version)));
						rcService.setEContext(version, null, false);
						LdapContext ctx = checkOutLdapContext();
						try {
							// Q: Should model accomodate multiple relation containers for version??
							List relationContainers = version.getRelations();
							for (Iterator containers = relationContainers.iterator(); containers.hasNext() && (noLimit || remainingLimit > 0); ) {
								Relations container = (Relations) containers.next();
								String searchRdn = rcService.qualifyRdn(rcService.obj2rdn(container));
								acService.setContextEntryPoint(searchRdn);
								acService.setEContext(container, null, false);
	
								NamingEnumeration ne = ctx.search(searchRdn, expr, null, sc);
								while (ne.hasMoreElements() && (noLimit || remainingLimit > 0)) {
									// Extract names for association target, instance, and class ...
									SearchResult sr = (SearchResult) ne.next();
									String srName = unwrapName(sr);
									int i = srName.indexOf(',');
									String atName = srName.substring(0, i);
									srName = srName.substring(i+1);
									i = srName.indexOf(',');
									String aiName = srName.substring(0, i);
									String acName = srName.substring(i+1);
									String acDn = acService.qualifyRdn(acName);
									aiService.setContextEntryPoint(acDn);
									String aiDn = aiService.qualifyRdn(aiName);
	
									// Resolve the names, reusing parent objects when possible ...
									Association ac = (Association) dn2ac.get(acDn);
									if (ac == null) {
										acService.setEContext(container, null, false);
										ac = (Association) acService.dcResolve(acName);
										dn2ac.put(acDn, ac);
									}
									AssociationInstance ai = (AssociationInstance) dn2ai.get(aiDn);
									if (ai == null) {
										aiService.setEContext(ac, null, false);
										ai = (AssociationInstance) aiService.dcResolve(aiName);
										dn2ai.put(aiDn, ai);
									}
									// Add matching targets, with resolved ancestors, to the list ...
									CodingSchemeType acScheme = CodingschemesUtil.resolveCodingScheme(ac, ac.getTargetCodingScheme());
									String acContext = acScheme == null ? null : acScheme.getCodingScheme();
									if (targetContext == null || targetContext == acContext || targetContext.equalsIgnoreCase(acContext)) {
										atService.setContextEntryPoint(aiService.qualifyRdn(aiName));
										atService.setEContext(ai, null, false);
										list.add(atService.dcResolve(atName));
										remainingLimit--;
									}
								}
							}
						} finally {
							checkInContext(ctx);
						}
					}
				}
			}
		} catch (NamingException e) {
			throw new QueryException(e);
		}
		return new ManagedObjIteratorWrapper(list.iterator());
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getEClass()
	 */
	protected EClass getEClass() {
		return CodingschemesPackage.eINSTANCE.getCodingSchemeType();
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getEFactory()
	 */
	protected EFactory getEFactory() {
		return CodingschemesFactory.eINSTANCE;
	}

	protected void ensureContext() {
		DirContext ctx = null;
		try {
			ctx = checkOutDirContext();
			try {
				ctx.list("");
			} catch (NameNotFoundException nnfe) {
				// Extract names for the intended coding schemes and service
				// level entries from the assigned context ...
				String fullname = ctx.getNameInNamespace();
				StringTokenizer st = new StringTokenizer(fullname, ",");
				String schemesRdn = null;
				String serviceRdn = null;
				StringBuffer base = new StringBuffer();
				if (st.hasMoreTokens())
					schemesRdn = st.nextToken();
				if (st.hasMoreTokens()) 
					serviceRdn = st.nextToken();
				if (st.hasMoreTokens())
					base.append(st.nextToken());
				while (st.hasMoreTokens())
					base.append(',').append(st.nextToken());
				
				// If the names fit, attempt to create the parent entries ...
				String url = (String) ctx.getEnvironment().get(Context.PROVIDER_URL);
				LdapContextDescriptor desc = (LdapContextDescriptor) getContextDescriptor().clone();
				DirContext baseContext = null, schemesContext = null;
				
				if (serviceRdn.startsWith("service") && schemesRdn.startsWith("dc")) {
					// Create the service level first ...
					String prefix = url.substring(0, url.lastIndexOf('/') + 1) + base;
					desc.getEnvironment().put(Context.PROVIDER_URL, prefix);
					baseContext = new InitialLdapContext(desc.getEnvironment(), desc.getControls());
					try {
						Attributes attrs = new BasicAttributes();
						attrs.put(org.LexGrid.managedobj.jndi.SchemaDef.ATTR_objectClass, CodingSchemesSchemaDef.CLASS_service);
						attrs.put(CodingSchemesSchemaDef.ATTR_service, (serviceRdn.substring((serviceRdn.lastIndexOf('=') + 1)).trim()));
						baseContext.createSubcontext(serviceRdn, attrs);
					} catch (NameAlreadyBoundException nabe) {
					} finally {
						baseContext.close();
					}

					// Then the codingSchemes level ...
					prefix = url.substring(0, url.lastIndexOf('/') + 1) + serviceRdn + ',' + base;
					desc.getEnvironment().put(Context.PROVIDER_URL, prefix);
					schemesContext = new InitialLdapContext(desc.getEnvironment(), desc.getControls());
					try {
						Attributes attrs = new BasicAttributes();
						attrs.put(org.LexGrid.managedobj.jndi.SchemaDef.ATTR_objectClass, CodingSchemesSchemaDef.CLASS_codingSchemesType);
						attrs.put(CodingSchemesSchemaDef.ATTR_dc, (schemesRdn.substring((schemesRdn.lastIndexOf('=') + 1)).trim()));
						schemesContext.createSubcontext(schemesRdn, attrs);
					} catch (NameAlreadyBoundException nabe) {
					} finally {
						baseContext.close();
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error creating ldap parent context", e);
		} finally {
			checkInContext(ctx);
		}
	}

}