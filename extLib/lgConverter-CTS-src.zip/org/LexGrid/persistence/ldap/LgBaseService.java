/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence.ldap;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.OperationNotSupportedException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.Control;
import javax.naming.ldap.LdapContext;

import org.LexGrid.emf.base.LgConstrainableList;
import org.LexGrid.emf.base.LgConstraint;
import org.LexGrid.emf.base.LgModelObj;
import org.LexGrid.emf.base.LgModelObjWrapper;
import org.LexGrid.emf.base.LgPagedList;
import org.LexGrid.emf.base.LgPagedListService;
import org.LexGrid.emf.base.LgStagedObj;
import org.LexGrid.emf.base.LgStagingService;
import org.LexGrid.emf.base.LgUnsupportedConstraintException;
import org.LexGrid.emf.base.util.LgModelUtil;
import org.LexGrid.emf.commonTypes.CommontypesFactory;
import org.LexGrid.emf.commonTypes.Source;
import org.LexGrid.emf.naming.NamingFactory;
import org.LexGrid.emf.naming.NamingPackage;
import org.LexGrid.emf.naming.SupportedAssociation;
import org.LexGrid.emf.naming.SupportedAssociationQualifier;
import org.LexGrid.emf.naming.SupportedCodingScheme;
import org.LexGrid.emf.naming.SupportedConceptStatus;
import org.LexGrid.emf.naming.SupportedContext;
import org.LexGrid.emf.naming.SupportedDegreeOfFidelity;
import org.LexGrid.emf.naming.SupportedFormat;
import org.LexGrid.emf.naming.SupportedLanguage;
import org.LexGrid.emf.naming.SupportedProperty;
import org.LexGrid.emf.naming.SupportedPropertyLink;
import org.LexGrid.emf.naming.SupportedPropertyQualifier;
import org.LexGrid.emf.naming.URNMap;
import org.LexGrid.managedobj.FindException;
import org.LexGrid.managedobj.HomeServiceBroker;
import org.LexGrid.managedobj.HomeServiceIF;
import org.LexGrid.managedobj.InsertException;
import org.LexGrid.managedobj.ManagedObjException;
import org.LexGrid.managedobj.ManagedObjIF;
import org.LexGrid.managedobj.ObjectAlreadyExistsException;
import org.LexGrid.managedobj.ObjectNotFoundException;
import org.LexGrid.managedobj.ResolveException;
import org.LexGrid.managedobj.ServiceInitException;
import org.LexGrid.managedobj.ServiceUnavailableException;
import org.LexGrid.managedobj.UpdateException;
import org.LexGrid.managedobj.jndi.JndiBaseService;
import org.LexGrid.managedobj.jndi.JndiContextPoolPolicy;
import org.LexGrid.managedobj.jndi.LdapBaseService;
import org.LexGrid.managedobj.jndi.LdapContextDescriptor;
import org.LexGrid.managedobj.jndi.LdapContextPoolPolicy;
import org.LexGrid.managedobj.jndi.SchemaDef;
import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EFactory;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

import com.sun.jndi.ldap.ctl.PagedResultsControl;
import com.sun.jndi.ldap.ctl.PagedResultsResponseControl;

/**
 * Extension point for LexGrid-specific implementation.
 * <p>
 * The intent of these services is to allow decoupling of the LexGrid information
 * model from ldap-specific data representation and the ability to map between
 * the two forms.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public abstract class LgBaseService extends LdapBaseService implements LgStagingService, LgPagedListService {
    protected final static Logger logger = Logger.getLogger("org.LexGrid.persistence.ldap.lgBaseService");

	// Well-known identifiers for LDAP schema extensions ...
	protected static final String OID_PagedResponseControl = "1.2.840.113556.1.4.319";

	// Well-known identifiers for staged retrieval of object features ...
	protected static final Integer STAGE_Initial = new Integer(1); // Typically needed when an item is first displayed
	protected static final Integer STAGE_Extended = new Integer(2); // Typically needed for property sheet 
	protected static final Integer STAGE_Advanced = new Integer(3); // Typically needed for advanced property sheet
	protected static final Integer STAGE_Content = new Integer(4); // Typically needed when an item is expanded

	protected static final Pattern urnMapPattern = Pattern.compile("^([^ ]*)([ ]+)(.*)");

	protected ThreadLocal _eContext = null;

	private String[] _rAttrs = null;
	private boolean _stagingEnabled = false;
	private int _pageSize = -1;

	/**
	 * Encapsulates a filter expression and related arguments.
	 */
	public class LgFilterCriteria {
		public String expr = null;
		public Object[] args = null;
		
		public void and(String expr) {
			this.expr = (this.expr == null) ? expr : "(&("+expr+")("+this.expr+"))";
		}
		public void and(String attr, int type, Object value) {
			and(toExpr(attr, type, value));
		}
		public void or(String expr) {
			this.expr = (this.expr == null) ? expr : "(|("+expr+")("+this.expr+"))";
		}
		public void or(String attr, int constraintType, Object value) {
			or(toExpr(attr, constraintType, value));
		}
		private String toExpr(String attr, int type, Object value) {
			StringBuffer sb = new StringBuffer(attr);
			switch(type) {
				case LgConstraint.RELATION_beginsWith : sb.append('=').append(value).append('*'); break;
				case LgConstraint.RELATION_contains : sb.append("=*").append(value).append('*'); break;
				case LgConstraint.RELATION_endsWith : sb.append("=*").append(value); break;
				case LgConstraint.RELATION_equals : sb.append('=').append(value); break;
				case LgConstraint.RELATION_greaterThanOrEqualTo : sb.append(">=").append(value); break;
				case LgConstraint.RELATION_lessThanOrEqualTo : sb.append("<=").append(value); break;
				default : throw new LgUnsupportedConstraintException();
			}
			return sb.toString();
		}
	}
	
	/**
	 * Encapsulates container information for newly resolved objects;
	 * remembered on a per-thread basis.
	 */
	public class LgContextStruct {
		EObject container = null;
		EStructuralFeature containerFeature = null;
		boolean addToContainer = true;
	}

	/**
	 * @param broker
	 * @param xmlFile
	 * @param ctxDescriptor
	 * @param ctxPoolPolicy
	 * @throws ServiceInitException
	 */
	public LgBaseService(
		HomeServiceBroker broker,
		File xmlFile,
		LdapContextDescriptor ctxDescriptor,
		LdapContextPoolPolicy ctxPoolPolicy)
		throws ServiceInitException {
		this(broker, xmlFile, ctxDescriptor, ctxPoolPolicy, false);
	}

	/**
	 * @param broker
	 * @param xmlFile
	 * @param ctxDescriptor
	 * @param ctxPoolPolicy
	 * @param stagedRetrievalEnabled
	 * @throws ServiceInitException
	 */
	public LgBaseService(
		HomeServiceBroker broker,
		File xmlFile,
		LdapContextDescriptor ctxDescriptor,
		LdapContextPoolPolicy ctxPoolPolicy,
		boolean stagedRetrievalEnabled) throws ServiceInitException
	{
		super();
		setStagingEnabled(stagedRetrievalEnabled);
		setBroker(broker);
		setConfigFile(xmlFile);
		setContextDescriptor(ctxDescriptor);
		setContextPoolPolicy(ctxPoolPolicy);
		init();
	}

	/**
	 * @param anchorService
	 * @throws ServiceInitException
	 */
	protected LgBaseService(LdapBaseService anchorService) throws ServiceInitException {
		super();
		if (anchorService instanceof LgBaseService)
			setStagingEnabled(((LgBaseService) anchorService).isStagingEnabled());
		setBroker(anchorService.getBroker());
		anchorService.internalRegisterNestedService(this);
		setAnchorService(anchorService);
		setContextDescriptor(anchorService.getContextDescriptor());
		setContextPool(anchorService.getContextPool());
		setContextPoolPolicy(anchorService.getContextPoolPolicy());
		init();
	}
	
	/* (non-Javadoc)
	 * @see org.org.LexGrid.commons.managedobj.service.BaseService#closePrim()
	 */
	public void closePrim() {
		try {
			setStagingEnabled(false);
			super.closePrim();
		} finally {
			_eContext = null;
		}
	}

	/**
	 * Allow individual services ability to ensure that the LDAP entries
	 * comprising the base context exist.
	 * <p>
	 * The abstract superclass takes no action; this method should be
	 * overridden by concrete subclasses as desired.
	 */
	protected void ensureContext() {
	}
	
	/**
	 * Primitive method to perform the insert operation.
	 * <p>
	 * By default, this method recurses to include insertion of contents.
	 * @param obj
	 * @throws InsertException
	 * @throws ObjectAlreadyExistsException
	 */
	protected void insertPrim(ManagedObjIF obj) throws InsertException, ObjectAlreadyExistsException {
		insertPrim((LgModelObj) obj, true);
	}
	protected void insertPrim(LgModelObj obj, boolean recurse) throws InsertException, ObjectAlreadyExistsException {
		// Allow individual services ability to ensure that the LDAP entries
		// comprising the base context exist ...
		ensureContext();

		// This method may trigger notifications by manipulating the object or contents;
		// disable notifications while processing.
		boolean notifyOn = LgModelUtil.isNotifyRequired();
		LgModelUtil.setNotifyRequired(false);
		try {
			super.insertPrim(obj);
			if (recurse)
				for (Iterator children = obj.eContents().iterator(); children.hasNext(); ) {
					Object next = children.next();
					if (next instanceof LgModelObj) {
						LgModelObj child = (LgModelObj) next;
						if (!(child instanceof LgModelObjWrapper)) {
							try {
								HomeServiceIF childService = getNestedService(child.getClass());
								if (childService instanceof LgBaseService) {
									((LgBaseService) childService).setEContext(obj, child.eContainingFeature(), true);
									((LgBaseService) childService).setContextEntryPoint(qualifyRdn(obj2rdn(obj)));
									((LgBaseService) childService).insertPrim(child, true);
								}
							// Ignore objects that do not have an available service ...
							} catch (ServiceUnavailableException e) {
							}
						}
					}
				}
		} finally {
			LgModelUtil.setNotifyRequired(notifyOn);
		}
	}
	/**
	 * Primitive method to perform the update operation.
	 * <p>
	 * By default, this method recurses to include update and/or insertion of contents.
	 * @param obj
	 * @throws UpdateException
	 * @throws ObjectNotFoundException
	 */
	protected void updatePrim(ManagedObjIF obj) throws UpdateException, ObjectNotFoundException {
		updatePrim((LgModelObj) obj, true);
	}
	protected void updatePrim(LgModelObj obj, boolean recurse) throws UpdateException, ObjectNotFoundException {
		// This method may trigger notifications by manipulating the object or contents;
		// disable notifications while processing.
		boolean notifyOn = LgModelUtil.isNotifyRequired();
		LgModelUtil.setNotifyRequired(false);
		try {
			super.updatePrim(obj);
			if (recurse) {
				List newContent = obj.eContents();

				// Remove content no longer included ...
				List oldContent = new ArrayList();
				dcResolveContent(obj2rdn(obj), oldContent);
				for (Iterator oldChildren = oldContent.iterator(); oldChildren.hasNext(); ) {
					LgModelObj oldChild = (LgModelObj) oldChildren.next();
					if (!newContent.contains(oldChild))
						try {
							HomeServiceIF childService = getNestedService(oldChild.getClass());
							if (childService instanceof LgBaseService) {
								((LgBaseService) childService).setEContext(obj, oldChild.eContainingFeature(), true);
								((LgBaseService) childService).setContextEntryPoint(qualifyRdn(obj2rdn(obj)));
								try {
									((LgBaseService) childService).remove(oldChild);
								} catch (ObjectNotFoundException e) {
								}
							}
						// Ignore objects that do not have an available service ...
						} catch (ServiceUnavailableException e) {
						}
				}
				
				// Update or insert current content ...
				for (Iterator children = newContent.iterator(); children.hasNext(); ) {
					Object next = children.next();
					if (next instanceof LgModelObj) {
					LgModelObj child = (LgModelObj) next;
						if (!(child instanceof LgModelObjWrapper))
							try {
								HomeServiceIF childService = getNestedService(child.getClass());
								if (childService instanceof LgBaseService) {
									((LgBaseService) childService).setEContext(obj, child.eContainingFeature(), true);
									((LgBaseService) childService).setContextEntryPoint(qualifyRdn(obj2rdn(obj)));
									try {
										((LgBaseService) childService).updatePrim(child, true);
									} catch (ObjectNotFoundException e) {
										((LgBaseService) childService).insertPrim(child, true);
									}
								}
							// Ignore duplicates or objects that do not have an available service ...
							} catch (ObjectAlreadyExistsException e) {
							} catch (ServiceUnavailableException e) {
							}
					}
				}
			}
		} catch (ObjectNotFoundException e) {
			throw e;
		} catch (UpdateException e) {
			throw e;
		} catch (Exception e) {
			throw new UpdateException(e);
		} finally {
			LgModelUtil.setNotifyRequired(notifyOn);
		}
	}
	public void synchronize(LgModelObj obj, boolean recurse) throws ManagedObjException {
		try {
			insertPrim(obj, recurse);
		} catch (ObjectAlreadyExistsException e) {
			updatePrim(obj, recurse);
		}
	}

	/**
	 * Resolves managed objects to the given list, allowing for enhanced
	 * functionality (paging, constraints, etc) offered by lists implementing
	 * the LgEnhancedListIF interface.
	 * @param rdn Relative distinguished name of the parent entry to search.
	 * @param list The list to fill with resolved objects, which may be
	 * constrained or paged.
	 * @throws NamingException
	 */
	public void dcEnhancedResolve(String rdn, List list)
		throws NamingException {

		// Paging or constraint-based? If not, use normal resolve ...
		boolean constrained =
			list instanceof LgConstrainableList
				&& ((LgConstrainableList) list).isConstrained();
		boolean paged =
			list instanceof LgPagedList
				&& !(list.isEmpty() && ((LgPagedList) list).getPageSize() == 0);

		if (!(constrained || paged))
			list.addAll(dcResolveAllToList(rdn, null));
		else {
			// Define the search controls and filter criteria.
			// Note that this may vary based on the contraints assigned to
			// the list, since resolution may require evaluation of
			// subtree nodes, etc ...
			SearchControls sc = dcEnhResSearchControls(rdn, list);
			LgFilterCriteria fc = dcEnhResSearchFilter(rdn, list);

			try {
				// If paging, initialize the paged result controls ...
				Control[] controls = null;
				if (paged) {
					LgPagedList pList = (LgPagedList) list;
					pList.setPagingService(this);
					Object cookie = pList.getPageCookie();
					PagedResultsControl prc =
						cookie instanceof byte[]
							? new PagedResultsControl(pList.getPageSize(), (byte[]) cookie, true)
							: new PagedResultsControl(pList.getPageSize());
					controls = new Control[] {prc};
				}

				// Perform the search ...
				LdapContext ctx = checkOutLdapContext();
				try {
					ctx.setRequestControls(controls);
					NamingEnumeration ne =
						ctx.search(qualifyRdn(rdn), fc.expr, fc.args, sc);
							
					// Process results ...
					while (ne.hasMore()) {
						dcEnhResProcessResult((SearchResult) ne.next(), list, sc, fc);
					}
	
					// Remember the cookie (if paging) for subsequent requests ...
					if (paged) {
						LgPagedList pList = (LgPagedList) list;
						byte[] cookie = null;
						try {
							Control[] response = ctx.getResponseControls();
							if (response != null)
								for (int i = 0; i < response.length; i++) {
									if (response[i] instanceof PagedResultsResponseControl) {
										cookie = ((PagedResultsResponseControl) response[i]).getCookie();
										break;
									}
									else if (OID_PagedResponseControl.equals(response[i].getID())) {
										PagedResultsResponseControl prc = new PagedResultsResponseControl(OID_PagedResponseControl, true, response[i].getEncodedValue());
										cookie = prc.getCookie();
										break;
									}
								}
						} finally {
							pList.setPageCookie(cookie);
						}
					}
					
				} finally {
					checkInContext(ctx);
				}
			} catch (OperationNotSupportedException e) {
				dcEnhResPagingHack(rdn, (LgPagedList) list, sc, fc);
			} catch (Exception e) {
				logger.error("Content resolution error. rdn = "+ qualifyRdn(rdn), e);
				throw (e instanceof NamingException) ? (NamingException) e
					: new NamingException(e.toString());
			}
		}
	}

	/**
	 * Enhanced resolution helper method to provide a
	 * <b><i>!!!!!!!!!!! temporary and highly fragile !!!!!!!!!!!</i></b>
	 * workaround in cases where the ldap server (specifically, OpenLDAP)
	 * does not yet support the simple paged results extension.
	 * It relies on an implied sort order that appears to be presented
	 * by the entryCSN operational attribute <b><i>for current LexGrid datasets</i></b>.
	 * However, this is an unsupported ordering and is likely to
	 * present any number of problems at some point.
	 * @param rdn Relative distinguished name of the parent entry to search.
	 * @param list The list to fill with resolved objects, which may be
	 * constrained or paged.
	 * @param sc SearchControls
	 * @param fc LgFilterCriteria
	 * @throws NamingException
	 */
	protected void dcEnhResPagingHack(
		String rdn,
		LgPagedList list,
		SearchControls sc,
		LgFilterCriteria fc) throws NamingException {

		// Add the 'entryCSN' attribute to those returned ...
		List rAttrs = new ArrayList();
		String[] scAttrs = sc.getReturningAttributes();
		if (scAttrs != null)
			rAttrs.addAll(Arrays.asList(scAttrs));
		rAttrs.add("entryCSN");
		sc.setReturningAttributes(
			(String[]) rAttrs.toArray(new String[rAttrs.size()]));
			
		// Set paging ...
		list.setPagingService(this);
		Object cookie = list.getPageCookie();
		boolean firstPage = !(cookie instanceof String);
		if (firstPage)
			sc.setCountLimit(list.getPageSize());
		else {
			fc.and("entryCSN>=" + cookie);
			sc.setCountLimit(list.getPageSize() + 1); // add 1 to account for >=
		}

		// Perform the search ...
		LdapContext ctx = checkOutLdapContext();
		try {
			NamingEnumeration ne =
				ctx.search(qualifyRdn(rdn), fc.expr, fc.args, sc);

			// Skip the first element (filter was specified as '>='),
			// and process any remaining elements ...
			if (!firstPage && ne.hasMoreElements())
				ne.next();
			int count = 0;
			SearchResult sr = null;
			while (ne.hasMoreElements()) {
				dcEnhResProcessResult(sr = (SearchResult) ne.next(), list, sc, fc);
				count++;
			}
			
			// Remember paging info for subsequent requests ...
			Attribute csn = sr == null ? null : sr.getAttributes().get("entryCSN");
			list.setPageCookie(
				(count >= list.getPageSize() && csn != null)
					? csn.get() : null);
		} finally {
			checkInContext(ctx);
		}
	}

	/**
	 * Enhanced resolution helper method to process a single search result.
	 * <p>
	 * The method is responsible for converting the search result to a
	 * model object and adding the model to the list.
	 * <p>
	 * Note: The superclass handles the result by invoking the standard
	 * <i>result2obj()</i> method with the given search result,
	 * and adds the returned object to the list. Subclasses requiring more
	 * refined handling should override this method.
	 * @param sr The search result to process.
	 * @param list The list to fill.
	 * @param sc Search controls in effect during the search.
	 * @param fc Filter criteria in effect during the search.
	 * @throws NamingException
	 * @see #dcEnhancedResolve(java.lang.String, java.util.List)
	 */
	protected void dcEnhResProcessResult(
		SearchResult sr,
		List list,
		SearchControls sc,
		LgFilterCriteria fc)
		throws NamingException {
			
		list.add(result2obj(sr));
	}

	/**
	 * Returns the search controls to be used during enhanced resolution.
	 * <p>
	 * Note: The superclass defines a search control that returns the
	 * standard resolve attributes for the service (<i>getResolveAttrs()</i>),
	 * and one level scope. Subclasses requiring alternative behavior
	 * should override this method.
	 * @param rdn Relative distinguished name of the parent entry to search.
	 * @param list The list to fill with resolved objects, which may be
	 * constrained or paged.
	 * @return SearchControls
	 * @throws NamingException
	 * @see #dcEnhancedResolve(java.lang.String, java.util.List)
	 */
	protected SearchControls dcEnhResSearchControls(
		String rdn,
		List list)
		throws NamingException {

		List attrs = new ArrayList();
		attrs.addAll(Arrays.asList(getResolveAttrs()));
		attrs.add("objectclass");
		
		SearchControls sc = new SearchControls();
		sc.setDerefLinkFlag(true);
		sc.setReturningObjFlag(false);
		sc.setSearchScope(SearchControls.ONELEVEL_SCOPE);
		sc.setReturningAttributes(
			(String[]) attrs.toArray(new String[attrs.size()]));
		return sc;
	}

	/**
	 * Returns an object containing the LDAP filter string and related
	 * arguments to be used during enhanced resolution.
	 * <p>
	 * Note: The superclass defines criteria to return only those entries
	 * that correspond to typically resolved ldap classes for the service
	 * (<i>getResolveClasses()</i>). Constraints are not handled. 
	 * Subclasses that support constraints or require other unique processing
	 * should override this method.
	 * @param rdn Relative distinguished name of the parent entry to search.
	 * @param list The list to fill with resolved objects, which may be
	 * constrained or paged.
	 * @return LgFilterCriteria
	 * @throws NamingException
	 * @see #dcEnhancedResolve(java.lang.String, java.util.List)
	 */
	protected LgFilterCriteria dcEnhResSearchFilter(
		String rdn,
		List list)
		throws NamingException {

		if (list instanceof LgConstrainableList && ((LgConstrainableList) list).isConstrained())
			throw new LgUnsupportedConstraintException();

		StringBuffer sb = new StringBuffer(256);
		sb.append("(|(");
		String[] classes = getResolveClasses();
		for (int i = 0; i < classes.length; i++)
			sb.append("(objectClass=").append(classes[i]).append(')');
		sb.append("))");

		LgFilterCriteria fc = new LgFilterCriteria();
		fc.expr = sb.toString();
		return fc;		
	}

	/**
	 * Resolve encapsulated content for the given item.
	 * <p>
	 * The default implementation takes no action; subclasses servicing
	 * objects with content should override as appropriate.
	 * @param obj
	 * @throws NamingException
	 */
	public void dcResolveContent(LgModelObj obj) throws NamingException {
	}

	/**
	 * Resolves encapsulated content.
	 * <p>
	 * Note: The default action taken by the superclass is to adjust the
	 * initial page size, based on preference settings, prior to invoking the
	 * <i>dcEnhancedResolve()</i> method to resolve the content.
	 * @param rdn Relative distinguished name of the parent entry to search.
	 * @param list The list to fill with resolved objects, which may be
	 * constrained or paged.
	 * @throws NamingException
	 */
	public void dcResolveContent(String rdn, List list) throws NamingException {
		// If paging is allowed and the list supports it,
		// adjust the page size ...
		if (isPagingEnabled() && list instanceof LgPagedList)
			((LgPagedList) list).setPageSize(resolvePageSize());
					
		// Perform resolution ...
		dcEnhancedResolve(rdn, list);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.jndiJndiDirService#getManagedAttrs()
	 */
	public List getManagedAttrs() {
		List attrs = super.getManagedAttrs();
		Map staging = getStagingLevel2AttrsMap();
		if (staging.containsKey(STAGE_Initial))
			CollectionUtils.addAll(attrs, (Object[])getStagingLevel2AttrsMap().get(STAGE_Initial));
		if (staging.containsKey(STAGE_Extended))
			CollectionUtils.addAll(attrs, (Object[])getStagingLevel2AttrsMap().get(STAGE_Extended));
		if (staging.containsKey(STAGE_Advanced))
			CollectionUtils.addAll(attrs, (Object[])getStagingLevel2AttrsMap().get(STAGE_Advanced));
		return attrs;
	}

	/**
	 * Returns the maximum number of entries to be retrieved in each page
	 * for paged lists that are resolved by the service.
	 * @return The page size; 0 for unpaged content (everything
	 * resolved in single pass); -1 to attempt to resolve the page size
	 * from the plugin preference store (not available outside of the
	 * eclipse runtime).
	 */
	public int getPageSize() {
		return _pageSize;
	}
	
	/**
	 * Returns an indication of whether objects are to
	 * be directly assigned to the container contents when resolved;
	 * true if unspecified.
	 * @return boolean
	 */
	public boolean getAddToEContainer() {
		initContext();
		Object o = _eContext.get();
		if (o instanceof LgContextStruct)
			return ((LgContextStruct) o).addToContainer;
		return true;
	}

	/**
	 * Returns the container to directly include resolved objects;
	 * null if not applicable or available.
	 * @return EObject
	 */
	public EObject getEContainer() {
		initContext();
		Object o = _eContext.get();
		if (o instanceof LgContextStruct)
			return ((LgContextStruct) o).container;
		return null;
	}

	/**
	 * Returns the feature on the container that will be associated with
	 * resolved objects, if applicable.
	 * @return EStructuralFeature
	 */
	public EStructuralFeature getEContainmentFeature() {
		initContext();
		Object o = _eContext.get();
		if (o instanceof LgContextStruct)
			return ((LgContextStruct) o).containerFeature;
		return null;
	}

	/**
	 * Returns the EFactory associated with objects created and managed by
	 * the service.
	 * @return EFactory
	 */
	protected abstract EFactory getEFactory();
	
	/**
	 * Returns the EClass associated with objects created and managed by
	 * the service.
	 * @return getEClass
	 */
	protected abstract EClass getEClass();
	
	/**
	 * Returns a sorted array of attribute names required to initialize managed
	 * instances, with concern for nested services.
	 * <p>
	 * Note: Subclasses intending to provide staged (on-demand) resolution of
	 * object features should override the <i>getUnstagedAttrs()</i> method to provide
	 * the minimal set of attributes required to initialize each instance.
	 * <p>
	 * @return The array of attribute names; null to indicate that all
	 * attributes should be retrieved for purposes of object resolution.
	 */
	public String[] getResolveAttrs() {
		if (_rAttrs == null) {
			// Start with immediately managed attributes...
			Set attrs = new HashSet();
			attrs.addAll(isStagingEnabled() ? getUnstagedAttrs() : getManagedAttrs());

			// Add those required by nested services handling
			// subclass resolution...
			List mClass = getManagedClasses();
			Iterator nested = getNestedServices().iterator();
			LdapBaseService ls;
			while (nested.hasNext()) {
				ls = (LdapBaseService) nested.next();
				if (ls.getManagedClasses().containsAll(mClass)) {
					String[] subAttrs = ls.getResolveAttrs();
					CollectionUtils.addAll(attrs,
						subAttrs != null ? subAttrs
							: ls.getManagedAttrs().toArray());
				}
			}
			if (!attrs.isEmpty())
				Arrays.sort(_rAttrs = (String[]) attrs.toArray(new String[attrs.size()]));
		}
		return _rAttrs;
	}

	/**
	 * Returns a map where each key is a EStructuralFeature that can be requested
	 * on demand and each value identifies an associated information level (eg Integer).
	 * The returned value can be empty (Collections.EMPTY_MAP) if the service
	 * does not support on-demand feature resolution.
	 * <p>
	 * Level granularity and meanings are service-specific. So, for example,
	 * a service might define levels 1, 2, and 3. Level 1 could indicate basic
	 * identifying information for the model object. Level 2 could indicate
	 * detailed information for the object. Finally, Level 3 could indicate
	 * encapsulated children.
	 * <p>
	 * When a staging request is received (<i>stageFeature()</i>), the superclass
	 * will automatically translate the request to one based on level and invoke
	 * the (<i>stageFeaturesByLevel()</i>) method. The superclass version of this
	 * method will then handle retrieval and assignment of attributes associated
	 * with the level, based on the level to attribute mappings.
	 * <p>
	 * The individual service is responsible for overriding the <i>stageFeaturesByLevel</i>
	 * method to handle any levels not based on field-level attributes, such as
	 * those involving encapsulated children or linked values.
	 * <p>
	 * The intent is to allow information for the model objects to be grouped
	 * in order to optimize performance, based on expected use or how the
	 * information is stored. If two attributes A & B are typically referenced
	 * at the same time, or if retrieving attribute B comes at little or no
	 * cost when a request is made for attribute A, then it makes sense to
	 * resolve them together and avoid a subsequent call to fetch B
	 * separately.
	 * 
	 * @return Map
	 */
	protected Map getStagingFeature2LevelMap() {
		return Collections.EMPTY_MAP;
	}

	/**
	 * Returns a service-specific staging level assigned to the given feature,
	 * or -1 if staging of the given feature is not supported.
	 * @return int
	 */
	protected int getStagingLevel(EStructuralFeature feature) {
		return -1;
	}

	/**
	 * Returns a map where each key identifies a staging level (eg Integer),
	 * and each value is an array of Strings defining the LDAP attributes that
	 * correspond to that level (relative to an object's RDN).
	 * The returned value can be empty (Collections.EMPTY_MAP) if the service
	 * does not support on-demand feature resolution, or if no staging levels
	 * are attribute-based. 
	 * <p>
	 * Level granularity and meanings are service-specific. So, for example,
	 * a service might define levels 1, 2, and 3. Level 1 could indicate basic
	 * identifying information for the model object. Level 2 could indicate
	 * detailed information for the object. Finally, Level 3 could indicate
	 * encapsulated children.
	 * <p>
	 * When a staging request is received (<i>stageFeature()</i>), the superclass
	 * will automatically translate the request to one based on level and invoke
	 * the (<i>stageFeaturesByLevel()</i>) method. The superclass version of this
	 * method will then handle retrieval and assignment of attributes associated
	 * with the level, based on the level to attribute mappings.
	 * <p>
	 * The individual service is responsible for overriding the <i>stageFeaturesByLevel</i>
	 * method to handle any levels not based on field-level attributes, such as
	 * those involving encapsulated children or linked values.
	 * <p>
	 * The intent is to allow information for the model objects to be grouped
	 * in order to optimize performance, based on expected use or how the
	 * information is stored. If two attributes A & B are typically referenced
	 * at the same time, or if retrieving attribute B comes at little or no
	 * cost when a request is made for attribute A, then it makes sense to
	 * resolve them together and avoid a subsequent call to fetch B
	 * separately.
	 * 
	 * @return Map
	 */
	protected Map getStagingLevel2AttrsMap() {
		return Collections.EMPTY_MAP;
	}

	/**
	 * Returns an unordered list of JNDI attribute names initially resolved
	 * for each LDAP entry when staged (on-demand) feature resolution is enabled.
	 * At a minimum, the returned value should include all attributes required
	 * to instantiate new instances and provide identification for subsequent
	 * staged retrievals.
	 * <p>
	 * Note: By default all attributes are returned that correspond to the
	 * <b>STAGE_Initial</b> level in the staging level map (<i>getStagingLevel2AttrsMap()</i>).
	 * If this level is not defined, all managed attributes are returned.
	 * <p>
	 * Subclasses with unique staging requirements should override this method
	 * and provide the desired set of attributes to be resolved on first touch.
	 * @return List
	 */
	protected List getUnstagedAttrs() {
		Map level2attrs = getStagingLevel2AttrsMap();
		if (level2attrs.containsKey(STAGE_Initial))
			return Arrays.asList(
				(String[]) level2attrs.get(STAGE_Initial));
		return getManagedAttrs();
	}

	/**
	 * Initializes the service.
	 * @throws ServiceInitException
	 */
	protected void init() throws ServiceInitException {
		super.init();
	}

	/**
	 * Initializes the thread localized context for resolved objects.
	 * <p>
	 * Note: Separated into separate sync method (instead of lazy init in
	 * getter) due to concerns over integrity of approaches using double-checked
	 * locking.
	 */
	protected synchronized void initContext() {
		if (_eContext == null)
			_eContext = new ThreadLocal();
	}

	/**
	 * Indicates whether on-demand resolution of paged content is
	 * currently enabled for the service.
	 * <p>
	 * Note: Superclass implementation returns true if general on-demand
	 * resolution of features is enabled.
	 * @return b
	 */
	protected boolean isPagingEnabled() {
		return isStagingEnabled();
	}

	/*
	 * @see org.LexGrid.plugin.base.LgStagingService#isStagingEnabled()
	 */
	public boolean isStagingEnabled() {
		return _stagingEnabled;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.service.naming.JndiBaseService#newContextPoolPolicy()
	 */
	protected JndiContextPoolPolicy newContextPoolPolicy() {
		JndiContextPoolPolicy pol = super.newContextPoolPolicy();
		pol.testOnBorrow = true;
		return pol;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.HomeServiceIF#newInstance()
	 */
	public ManagedObjIF newInstance() {
		ManagedObjIF obj = newInstance(getEFactory(), getEClass());
		if (this instanceof LgStagingService && obj instanceof LgStagedObj)
			((LgStagedObj) obj).setStagingService(this);
		return obj;
	}
	
	protected ManagedObjIF newInstance(EFactory factory, EClass eclass) {
		EObject o = factory.create(eclass);
		return o instanceof ManagedObjIF ? (ManagedObjIF) o : null;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.jndi.JndiDirService#newMultiValAttr(java.lang.String, java.util.List)
	 */
	protected Attribute newMultiValAttr(String id, List vals) {
		Attribute attr = new BasicAttribute(id);
		if (!vals.isEmpty())
			for (Iterator it = vals.iterator(); it.hasNext(); ) {
				Object o = it.next();
				attr.add(o instanceof Source ? ((Source) o).getValue() : o.toString());
			}
		return attr;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.jndi.JndiDirService#newMultiValAttr(java.lang.String, java.lang.Object[])
	 */
	protected Attribute newMultiValAttr(String id, Object[] vals) {
		Attribute attr = new BasicAttribute(id);
		if (vals.length > 0)
			for (int i = 0; i < vals.length; i++) {
				Object o = vals[i];
				attr.add(o instanceof Source ? ((Source) o).getValue() : o.toString());
			}
		return attr;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.commons.model.emf.base.LgPagedListService#pagedListDisposed(org.LexGrid.plugin.base.LgPagedList)
	 */
	public void pagedListDisposed(LgPagedList pagedList) {
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.jndiJndiDirService#postResolve(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public void postResolve(ManagedObjIF obj) throws NamingException {
		// Assign the parent, if available ...
		if (obj instanceof LgModelObj)
			((LgModelObj) obj).setContainer(getEContainer(), getEContainmentFeature(), getAddToEContainer());		
		super.postResolve(obj);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.commons.model.emf.base.LgPagedListService#resolveNextPage(org.LexGrid.plugin.base.LgPagedList)
	 */
	public void resolveNextPage(LgPagedList pagedList) throws ResolveException {
		// Attempt to initialize context for the service prior to resolution ...
		LgModelObj obj = pagedList.getPagingContext();
		if (obj != null) {
			setEContext(obj, null, false);		
			HomeServiceIF parentService = getAnchorService();
			if (parentService == null)
				parentService = getBroker().getService(obj.getClass());
			if (parentService instanceof LgBaseService) {
				LgBaseService lgService = (LgBaseService) parentService;
				setContextEntryPoint(lgService.qualifyRdn(lgService.obj2rdn(obj)));
			}
		}
		
		// Adjust the page size and resolve the next set of objects ...
		try {
			pagedList.setPageSize(resolvePageSize());
			dcEnhancedResolve("", pagedList);
		} catch (NamingException e) {
			throw new ResolveException(e);
		}
	}

	/**
	 * Returns the maximum number of entries to be retrieved in each page
	 * for paged lists that are resolved by the service, resolving from the
	 * plugin preference store if indicated and available.
	 * @return The page size; 0 for unpaged content (everything
	 * resolved in single pass).
	 */
	protected int resolvePageSize() {
		return (_pageSize < 0) ? 256 : _pageSize;
	}
	
	/**
	 * Assigns the maximum number of entries to be retrieved in each page
	 * for paged lists that are resolved by the service.
	 * @param pageSize The page size; 0 for unpaged content (everything
	 * resolved in single pass); -1 to attempt to resolve the page size
	 * from the plugin preference store (not available outside of the
	 * eclipse runtime).
	 */
	public void setPageSize(int pageSize) {
		_pageSize = pageSize;
	}
	
	/**
	 * Sets the EMF container to be applied to resolved objects, optionally
	 * adding the model to the contents of the container when resolved.
	 * @param container EObject
	 * @param containerFeature EStructuralFeature
	 * @param addToContainer boolean
	 */
	public void setEContext(EObject container, EStructuralFeature containerFeature, boolean addToContainer) {
		initContext();
		LgContextStruct eStruct = new LgContextStruct();
		eStruct.container = container;
		eStruct.containerFeature = containerFeature;
		eStruct.addToContainer = addToContainer;
		
		_eContext.set(eStruct);
	}

	/**
	 * Sets the starting point for resolution of staged features based on ancestry
	 * for the given object.
	 * <p>
	 * Note: This value is maintained in thread-local storage; callers can
	 * assume that the value will not be altered by other threads simultaneously
	 * accessing the service.
	 * <p>
	 * Note: The current implementation is potentially problematic, in that we
	 * assume all ancestors are also staged through a JNDI service.
	 * However, it is convenient to make this assumption for now, in that
	 * object-to-rdn naming conventions for a particular type of object remain
	 * centrally defined by the service used to maintain that type.
	 * @param obj LgModelObj
	 */
	protected void setStagingContext(LgModelObj obj) {
		StringBuffer sb = new StringBuffer();
		EObject container = obj.eContainer();
		while (container instanceof LgStagedObj) {
			LgStagingService service = ((LgStagedObj) container).getStagingService();
			if (service instanceof JndiBaseService && container instanceof LgModelObj) {
				if (sb.length() > 0)
					sb.append(',');
				sb.append(escapeRdn(((JndiBaseService) service).obj2rdn((LgModelObj) container)));
			}
			container = container.eContainer();
		}
		setContextEntryPoint(sb.toString());
	}

	/**
	 * Indicates whether staged (on-demand) feature resolution is
	 * currently enabled for the service.
	 * @param b boolean
	 */
	protected void setStagingEnabled(boolean b) {
		_stagingEnabled = b;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.plugin.base.LgStagingService#stageFeature(org.LexGrid.plugin.base.LgStagedObj, org.eclipse.emf.ecore.EStructuralFeature)
	 */
	public void stageFeature(LgStagedObj obj, EStructuralFeature feature) throws ResolveException {
		Map feature2Level = getStagingFeature2LevelMap();
		Object levelID = feature2Level.get(feature);
		if (levelID != null) {
			stageFeaturesByLevel(obj, levelID);
			obj.stageComplete(feature);
		}
	}

	/**
	 * When a staging request is received (<i>stageFeature()</i>), the superclass
	 * will automatically translate the request to one based on level and invoke
	 * this method. The superclass will then handle retrieval and assignment of
	 * attributes associated with the level, based on level to attribute mappings.
	 * <p>
	 * The individual service is responsible for overriding this
	 * method to handle any levels not based on field-level attributes, such as
	 * those involving encapsulated children or linked values.
	 * <p>
	 * The intent is to allow information for the model objects to be grouped
	 * in order to optimize performance, based on expected use or how the
	 * information is stored. If two attributes A & B are typically referenced
	 * at the same time, or if retrieving attribute B comes at little or no
	 * cost when a request is made for attribute A, then it makes sense to
	 * resolve them together and avoid a subsequent call to fetch B
	 * separately.
	 * 
	 * @param obj LgModelObj
	 * @param levelID Object
	 * @throws ResolveException
	 */
	protected void stageFeaturesByLevel(LgModelObj obj, Object levelID) throws ResolveException {
		try {
			// Check well-known identifier for content requests.
			// For all other cases, attempt attribute-based resolution.
			if (levelID.equals(STAGE_Content)) {
				setStagingContext(obj);
				dcResolveContent(obj);
			} else {
				String[] attrNames = (String[]) getStagingLevel2AttrsMap().get(levelID);
				if (attrNames != null && attrNames.length > 0) {
					setStagingContext(obj);
					attrs2obj(obj, dcGetAttributes(obj2rdn(obj), attrNames));
				}
			}
		} catch (NamingException e) {
			throw new ResolveException(e);
		}
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.service.naming.JndiBaseService#primaryKey2rdn(java.lang.Object)
	 */
	public String primaryKey2rdn(Object key) {
		return null;
	}

	/////////////////////////////////////////////////
	// Caching support
	/////////////////////////////////////////////////
	
	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.service.CachedService#getPrimaryCacheMaxSize()
	 */
	protected int getPrimaryCacheMaxSize() {
		return 256;
	}
	
	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.service.CachedService#addToPrimaryCache(org.LexGrid.managedobj.ManagedObjIF)
	 */
	protected void addToPrimaryCache(ManagedObjIF obj) {
		if (getPrimaryCacheMaxSize() > 0) {
			if (obj instanceof LgModelObj) {
				Object key = getPrimaryCacheKey((LgModelObj) obj);
				if (key != null)
					getPrimaryCache().put(key, obj);
			} else
				super.addToPrimaryCache(obj);
		}
	}
	
	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.HomeServiceIF#findByPrimaryKey(java.lang.Object)
	 */
	public ManagedObjIF findByPrimaryKey(Object key) throws FindException {
		ManagedObjIF obj = null;
		if (getPrimaryCacheMaxSize() > 0) {
			Object cacheKey = qualifyCacheLookupKey(key);
			if (cacheKey != null
					&& (obj = (ManagedObjIF) getPrimaryCache().get(cacheKey)) != null)
				return obj;
		}

		obj = findByPrimaryKeyPrim(key);
		addToPrimaryCache(obj);
		return obj;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.service.CachedService#removeFromPrimaryCache(org.LexGrid.managedobj.ManagedObjIF)
	 */
	protected void removeFromPrimaryCache(ManagedObjIF obj) {
		if (getPrimaryCacheMaxSize() > 0) {
			if (obj instanceof LgModelObj) {
				Object key = getPrimaryCacheKey((LgModelObj) obj);
				if (key != null)
					getPrimaryCache().remove(key);
			} else
				super.removeFromPrimaryCache(obj);
		}
	}
	
	/**
	 * Returns the key corresponding to the object in the primary cache.
	 * @param model
	 * @return Object
	 */
	protected Object getPrimaryCacheKey(LgModelObj model) {
		Object key = null;
		if (model != null) {
			Object modelKey = model.getPrimaryKey();
			EObject container = model.eContainer();
			Object parentKey = (container instanceof LgModelObj)
				? ((LgModelObj) container).getPrimaryKey()
				: "";
			if (modelKey != null && parentKey != null)
				key = new StringBuffer(modelKey.toString())
					.append("::").append(parentKey).toString();
		}
		return key;
	}
	
	/**
	 * Qualifies the given key according to the assigned parent.
	 * @param key
	 * @return Object
	 */
	protected Object qualifyCacheLookupKey(Object key) {
		Object qkey = null;
		if (key != null) {
			Object container = getEContainer();
			if (container instanceof LgModelObj) {
				Object containerKey = ((LgModelObj) container).getPrimaryKey();
				if (containerKey != null)
					qkey = new StringBuffer(key.toString())
						.append("::").append(containerKey).toString();
			}
		}
		return qkey;
	}
	
	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.jndi.JndiDirService#attr2list(javax.naming.directory.Attribute)
	 */
	protected List attr2sourceList(Attribute attr) throws NamingException {
		List l = new ArrayList();
		NamingEnumeration ne = attr.getAll();
		while (ne.hasMore()) {
			Source s = CommontypesFactory.eINSTANCE.createSource();
			s.setValue(ne.next().toString());
			l.add(s);
		}
		return l;
	}

	/**
	 * @see org.LexGrid.managedobj.jndiJndiDirService#attrs2obj(Attributes)
	 */
	public ManagedObjIF attrs2obj(Attributes attrs) throws NamingException {
		Attribute classAttr = attrs.get(SchemaDef.ATTR_objectClass);
		ManagedObjIF obj =
			(classAttr != null)
				? newInstance((String[]) attr2list(classAttr).toArray(new String[0]))
				: newInstance();
		attrs2obj(obj, attrs);
		return obj;
	}

	/**
	 * Converts from a multi-valued LDAP attribute to a list of
	 * URNMap objects of the given class.
	 * @param attr
	 * @param urnMapInstanceClass
	 * @return A list containing URNMap instances corresponding to the
	 * attribute values.
	 * @throws NamingException
	 */
	protected List attr2urnMaps(Attribute attr, Class urnMapInstanceClass) throws NamingException {
		List maps = new ArrayList();
		for (NamingEnumeration ne = attr.getAll(); ne.hasMore(); ) {
			String val = ne.nextElement().toString();
			Matcher m = urnMapPattern.matcher(val);

			// Translate map instance class to eclass...
			EClass urnEClass = null;
			if (SupportedAssociation.class.isAssignableFrom(urnMapInstanceClass))
				urnEClass = NamingPackage.eINSTANCE.getSupportedAssociation();
			else if (SupportedAssociationQualifier.class.isAssignableFrom(urnMapInstanceClass))
				urnEClass = NamingPackage.eINSTANCE.getSupportedAssociationQualifier();
			else if (SupportedCodingScheme.class.isAssignableFrom(urnMapInstanceClass))
				urnEClass = NamingPackage.eINSTANCE.getSupportedCodingScheme();
			else if (SupportedConceptStatus.class.isAssignableFrom(urnMapInstanceClass))
				urnEClass = NamingPackage.eINSTANCE.getSupportedConceptStatus();
			else if (SupportedContext.class.isAssignableFrom(urnMapInstanceClass))
				urnEClass = NamingPackage.eINSTANCE.getSupportedContext();
			else if (SupportedDegreeOfFidelity.class.isAssignableFrom(urnMapInstanceClass))
				urnEClass = NamingPackage.eINSTANCE.getSupportedDegreeOfFidelity();
			else if (SupportedFormat.class.isAssignableFrom(urnMapInstanceClass))
				urnEClass = NamingPackage.eINSTANCE.getSupportedFormat();
			else if (SupportedLanguage.class.isAssignableFrom(urnMapInstanceClass))
				urnEClass = NamingPackage.eINSTANCE.getSupportedLanguage();
			else if (SupportedProperty.class.isAssignableFrom(urnMapInstanceClass))
				urnEClass = NamingPackage.eINSTANCE.getSupportedProperty();
			else if (SupportedPropertyLink.class.isAssignableFrom(urnMapInstanceClass))
				urnEClass = NamingPackage.eINSTANCE.getSupportedPropertyLink();
			else if (SupportedPropertyQualifier.class.isAssignableFrom(urnMapInstanceClass))
				urnEClass = NamingPackage.eINSTANCE.getSupportedPropertyQualifier();

			// Instantiate and return the map ...
			if (urnEClass != null)
				try {
					URNMap map = (URNMap) newInstance(NamingFactory.eINSTANCE, urnEClass);
					if (m.matches()) {
						map.setUrn(m.group(1));
						map.setLocalId(m.group(3));
					} else {
						map.setUrn("");
						map.setLocalId(val);
					}
					maps.add(map);
				} catch (RuntimeException e) {
				}
		}
		return maps;
	}
	
	/**
	 * Converts from a collection of URNMap instances to a
	 * multi-valued LDAP attribute with the given ID.
	 * @param id
	 * @param maps
	 * @return A multi-valued LDAP attribute representing
	 * the list of mapped URNs. 
	 */
	protected Attribute urnMaps2attr(String id, List maps) {
		Attribute attr = new BasicAttribute(id);
		if (!maps.isEmpty())
			for (Iterator it = maps.iterator(); it.hasNext(); ) {
				URNMap map = (URNMap) it.next();
				String urn = map.getUrn();
				String lcl = map.getLocalId();
				attr.add(
					(urn == null || urn.equals(""))
						? lcl
						: new StringBuffer(128)
							.append(urn).append(' ').append(lcl).toString());
			}
		return attr;
	}
}