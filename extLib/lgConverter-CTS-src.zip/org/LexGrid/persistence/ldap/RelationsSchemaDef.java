/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence.ldap;

/**
 * Constants defining the LDAP schema referenced by local services.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public interface RelationsSchemaDef {
	public static final String ATTR_association = "association";
	public static final String ATTR_associationQualifier = "associationQualifier";
	public static final String ATTR_associationQualifierValue = "associationQualifierValue";
	public static final String ATTR_dataType = "dataType";
	public static final String ATTR_dataValue = "dataValue";
	public static final String ATTR_dc = "dc";
	public static final String ATTR_entityDescription = "entityDescription";
	public static final String ATTR_forwardName = "forwardName";
	public static final String ATTR_id = "id";
	public static final String ATTR_isAntiReflexive = "isAntiReflexive";
	public static final String ATTR_isAntiSymmetric = "isAntiSymmetric";
	public static final String ATTR_isAntiTransitive = "isAntiTransitive";
	public static final String ATTR_isFirstVersion = "firstVersion";
	public static final String ATTR_isFunctional = "isFunctional";
	public static final String ATTR_isLastVersion = "lastVersion";
	public static final String ATTR_isNative = "isNative";
	public static final String ATTR_isReflexive = "isReflexive";
	public static final String ATTR_isReverseFunctional = "isReverseFunctional";
	public static final String ATTR_isSymmetric = "isSymmetric";
	public static final String ATTR_isTransitive = "isTransitive";
	public static final String ATTR_isTranslationAssociation = "isTranslationAssociation";
	public static final String ATTR_modVersion = "modVersion";
	public static final String ATTR_registeredName = "registeredName";
	public static final String ATTR_reverseName = "reverseName";
	public static final String ATTR_source = "source";
	public static final String ATTR_sourceCodingScheme = "sourceCodingScheme";
	public static final String ATTR_sourceConcept = "sourceConcept";
	public static final String ATTR_targetCodingScheme = "targetCodingScheme";
	public static final String ATTR_targetConceptCode = "targetConcept";

	public static final String CLASS_associationClass = "associationClass";
	public static final String CLASS_associationData = "associationData";
	public static final String CLASS_associationInstance = "associationInstance";
	public static final String CLASS_associationLink = "associationLink";
	public static final String CLASS_associationQualification = "associationQualification";
	public static final String CLASS_associationTarget = "associationTarget";
	public static final String CLASS_codedEntry = "codedEntry";
	public static final String CLASS_codingSchemeClass = "codingSchemeClass";
	public static final String CLASS_relations = "relations";
	public static final String CLASS_relationChanges = "relations";
	public static final String CLASS_sourceLink = "sourceLink";
	public static final String CLASS_targetLink = "targetLink";

	public static final String LINKNAME_association = "associationLink";
	public static final String LINKNAME_source = "sourceLink";
	public static final String LINKNAME_target = "targetLink";
	public static final String LINKNAME_targetCodingScheme = "codingSchemeLink";
}