/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence.ldap;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;

import org.LexGrid.emf.base.LgModelObj;
import org.LexGrid.emf.commonTypes.CommontypesPackage;
import org.LexGrid.emf.relations.Association;
import org.LexGrid.emf.relations.RelationsFactory;
import org.LexGrid.emf.relations.RelationsPackage;
import org.LexGrid.emf.relations.impl.AssociationImpl;
import org.LexGrid.managedobj.ManagedObjIF;
import org.LexGrid.managedobj.ServiceInitException;
import org.LexGrid.managedobj.jndi.LdapBaseService;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EFactory;

/**
 * Handles LDAP persistence for the corresponding type of managed object.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class AssociationClassService extends LgBaseService {

	static Map _feature2level, _level2attrs;
	static {
		// Information model to stage mappings ...
		_feature2level = new HashMap(16);
		_feature2level.put(CommontypesPackage.eINSTANCE.getDescribable_EntityDescription(), STAGE_Initial);
		_feature2level.put(RelationsPackage.eINSTANCE.getAssociation_Association(), STAGE_Initial);
		_feature2level.put(RelationsPackage.eINSTANCE.getAssociation_ForwardName(), STAGE_Initial);
		_feature2level.put(RelationsPackage.eINSTANCE.getAssociation_IsAntiReflexive(), STAGE_Extended);
		_feature2level.put(RelationsPackage.eINSTANCE.getAssociation_IsAntiSymmetric(), STAGE_Extended);
		_feature2level.put(RelationsPackage.eINSTANCE.getAssociation_IsAntiTransitive(), STAGE_Extended);
		_feature2level.put(RelationsPackage.eINSTANCE.getAssociation_IsFunctional(), STAGE_Extended);
		_feature2level.put(RelationsPackage.eINSTANCE.getAssociation_IsReflexive(), STAGE_Extended);
		_feature2level.put(RelationsPackage.eINSTANCE.getAssociation_IsReverseFunctional(), STAGE_Extended);
		_feature2level.put(RelationsPackage.eINSTANCE.getAssociation_IsSymmetric(), STAGE_Extended);
		_feature2level.put(RelationsPackage.eINSTANCE.getAssociation_IsTransitive(), STAGE_Extended);
		_feature2level.put(RelationsPackage.eINSTANCE.getAssociation_IsTranslationAssociation(), STAGE_Extended);
		_feature2level.put(RelationsPackage.eINSTANCE.getAssociation_ReverseName(), STAGE_Initial);
		_feature2level.put(RelationsPackage.eINSTANCE.getAssociation_SourceConcept(), STAGE_Content);
		_feature2level.put(RelationsPackage.eINSTANCE.getAssociation_TargetCodingScheme(), STAGE_Initial);

		// Stage to LDAP mappings ...
		_level2attrs = new HashMap(2);
		_level2attrs.put( STAGE_Initial, new String[] {
			RelationsSchemaDef.ATTR_association,
			RelationsSchemaDef.ATTR_entityDescription,
			RelationsSchemaDef.ATTR_forwardName,
			RelationsSchemaDef.ATTR_reverseName,
			RelationsSchemaDef.ATTR_targetCodingScheme
			});
		_level2attrs.put(STAGE_Extended, new String[] {
			RelationsSchemaDef.ATTR_isAntiReflexive,
			RelationsSchemaDef.ATTR_isAntiSymmetric,
			RelationsSchemaDef.ATTR_isAntiTransitive,
			RelationsSchemaDef.ATTR_isFunctional,
			RelationsSchemaDef.ATTR_isReflexive,
			RelationsSchemaDef.ATTR_isReverseFunctional,
			RelationsSchemaDef.ATTR_isSymmetric,
			RelationsSchemaDef.ATTR_isTransitive,
			RelationsSchemaDef.ATTR_isTranslationAssociation
			});
	}

	protected AssociationInstanceService _instanceService;

	public AssociationClassService(LdapBaseService anchorService) throws ServiceInitException {
		super(anchorService);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.jndiJndiDirService#attrs2obj(org.LexGrid.managedobj.ManagedObjIF, javax.naming.directory.Attributes)
	 */
	protected void attrs2obj(ManagedObjIF obj, Attributes attrs) throws NamingException {
		AssociationImpl impl = (AssociationImpl) obj;
		Attribute attr;
		if ((attr = attrs.get(RelationsSchemaDef.ATTR_association)) != null)
			impl.eSet(RelationsPackage.eINSTANCE.getAssociation_Association(), attr.get());
		if ((attr = attrs.get(RelationsSchemaDef.ATTR_entityDescription)) != null)
			impl.eSet(CommontypesPackage.eINSTANCE.getDescribable_EntityDescription(), attr.get());
		if ((attr = attrs.get(RelationsSchemaDef.ATTR_forwardName)) != null)
			impl.eSet(RelationsPackage.eINSTANCE.getAssociation_ForwardName(), attr.get());
		if ((attr = attrs.get(RelationsSchemaDef.ATTR_reverseName)) != null)
			impl.eSet(RelationsPackage.eINSTANCE.getAssociation_ReverseName(), attr.get());
		if ((attr = attrs.get(RelationsSchemaDef.ATTR_isFunctional)) != null)
			impl.eSet(RelationsPackage.eINSTANCE.getAssociation_IsFunctional(), str2Bool((String) attr.get()));
		if ((attr = attrs.get(RelationsSchemaDef.ATTR_isReverseFunctional)) != null)
			impl.eSet(RelationsPackage.eINSTANCE.getAssociation_IsReverseFunctional(), str2Bool((String) attr.get()));
		if ((attr = attrs.get(RelationsSchemaDef.ATTR_isAntiReflexive)) != null)
			impl.eSet(RelationsPackage.eINSTANCE.getAssociation_IsAntiReflexive(), str2Bool((String) attr.get()));
		if ((attr = attrs.get(RelationsSchemaDef.ATTR_isAntiSymmetric)) != null)
			impl.eSet(RelationsPackage.eINSTANCE.getAssociation_IsAntiSymmetric(), str2Bool((String) attr.get()));
		if ((attr = attrs.get(RelationsSchemaDef.ATTR_isAntiTransitive)) != null)
			impl.eSet(RelationsPackage.eINSTANCE.getAssociation_IsAntiTransitive(), str2Bool((String) attr.get()));
		if ((attr = attrs.get(RelationsSchemaDef.ATTR_isReflexive)) != null)
			impl.eSet(RelationsPackage.eINSTANCE.getAssociation_IsReflexive(), str2Bool((String) attr.get()));
		if ((attr = attrs.get(RelationsSchemaDef.ATTR_isSymmetric)) != null)
			impl.eSet(RelationsPackage.eINSTANCE.getAssociation_IsSymmetric(), str2Bool((String) attr.get()));
		if ((attr = attrs.get(RelationsSchemaDef.ATTR_isTransitive)) != null)
			impl.eSet(RelationsPackage.eINSTANCE.getAssociation_IsTransitive(), str2Bool((String) attr.get()));
		if ((attr = attrs.get(RelationsSchemaDef.ATTR_isTranslationAssociation)) != null)
			impl.eSet(RelationsPackage.eINSTANCE.getAssociation_IsTranslationAssociation(), str2Bool((String) attr.get()));
		// Pick out the non-ldap scheme name, or default to the encapsulating scheme if no value is specified.
		if ((attr = attrs.get(RelationsSchemaDef.ATTR_targetCodingScheme)) != null) {
			String dn = (String) attr.get();
			String dnLower = dn.toLowerCase();
			String keyLower = org.LexGrid.persistence.ldap.CodingSchemesSchemaDef.ATTR_codingScheme.toLowerCase()+'=';
			int i;
			String scheme = ((i = dnLower.indexOf(keyLower)) >= 0)
				? dn.substring(i+keyLower.length())
				: dn;
			impl.eSet(RelationsPackage.eINSTANCE.getAssociation_TargetCodingScheme(),
				scheme);
// ***  Don't explicitly assign default; value will be inferred dynamically ...
//		} else {
//			Object p = getParent();
//			if (p instanceof LgModelObj) {
//				CodingSchemeType schemeClass = (CodingSchemeType) ((LgModelObj) p).getAncestor(CodingSchemeType.class);
//				if (schemeClass != null)
//					impl.eSet(RelationsPackage.eINSTANCE.getAssociation_TargetCodingScheme(),
//							schemeClass.getCodingScheme());
//			}
		}
	}

	/* (non-Javadoc)
	 * @see org.org.LexGrid.commons.managedobj.service.BaseService#closePrim()
	 */
	public void closePrim() {
		try {
			super.closePrim();
		} finally {
			_instanceService = null;
		}
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#dcResolveContent(org.LexGrid.plugin.base.LgModelObj)
	 */
	public void dcResolveContent(LgModelObj obj) throws NamingException {
		if (obj instanceof Association) {
			_instanceService.setContextEntryPoint(qualifyRdn(obj2rdn(obj)));
			_instanceService.setEContext(obj, null, false);
			_instanceService.dcResolveContent("", ((Association) obj).getSourceConcept());
		}
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getEClass()
	 */
	protected EClass getEClass() {
		return RelationsPackage.eINSTANCE.getAssociation();
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getEFactory()
	 */
	protected EFactory getEFactory() {
		return RelationsFactory.eINSTANCE;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#getInstanceClass()
	 */
	protected Class getInstanceClass() {
		return AssociationImpl.class;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#getManagedClasses()
	 */
	public List getManagedClasses() {
		List clazz = super.getManagedClasses();
		clazz.add(RelationsSchemaDef.CLASS_associationClass);
		return clazz;
	}

	/* (non-Javadoc)
	 * @see org.org.LexGrid.commons.managedobj.service.BaseService#initNestedServices()
	 */
	protected void initNestedServices() throws ServiceInitException {
		_instanceService = new AssociationInstanceService(this);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getStagingFeature2LevelMap()
	 */
	protected Map getStagingFeature2LevelMap() {
		return _feature2level;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getStagingLevel2AttrsMap()
	 */
	protected Map getStagingLevel2AttrsMap() {
		return _level2attrs;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#obj2attrs(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public Attributes obj2attrs(ManagedObjIF obj) {
		// Invoke superclass to pick up generic attributes (objectClass)
		Attributes attrs = super.obj2attrs(obj);

		// Add attributes unique to the given object
		AssociationImpl impl = (AssociationImpl) obj;
		attrs.put(new BasicAttribute(RelationsSchemaDef.ATTR_association, impl.eGet(RelationsPackage.eINSTANCE.getAssociation_Association())));
		attrs.put(new BasicAttribute(RelationsSchemaDef.ATTR_entityDescription, impl.eGet(CommontypesPackage.eINSTANCE.getDescribable_EntityDescription())));
		attrs.put(new BasicAttribute(RelationsSchemaDef.ATTR_forwardName, impl.eGet(RelationsPackage.eINSTANCE.getAssociation_ForwardName())));
		attrs.put(new BasicAttribute(RelationsSchemaDef.ATTR_reverseName, impl.eGet(RelationsPackage.eINSTANCE.getAssociation_ReverseName())));
		attrs.put(new BasicAttribute(RelationsSchemaDef.ATTR_isAntiReflexive, bool2str((Boolean) impl.eGet(RelationsPackage.eINSTANCE.getAssociation_IsAntiReflexive()))));
		attrs.put(new BasicAttribute(RelationsSchemaDef.ATTR_isAntiSymmetric, bool2str((Boolean) impl.eGet(RelationsPackage.eINSTANCE.getAssociation_IsAntiSymmetric()))));
		attrs.put(new BasicAttribute(RelationsSchemaDef.ATTR_isAntiTransitive, bool2str((Boolean) impl.eGet(RelationsPackage.eINSTANCE.getAssociation_IsAntiTransitive()))));
		attrs.put(new BasicAttribute(RelationsSchemaDef.ATTR_isFunctional, bool2str((Boolean) impl.eGet(RelationsPackage.eINSTANCE.getAssociation_IsFunctional()))));
		attrs.put(new BasicAttribute(RelationsSchemaDef.ATTR_isReflexive, bool2str((Boolean) impl.eGet(RelationsPackage.eINSTANCE.getAssociation_IsReflexive()))));
		attrs.put(new BasicAttribute(RelationsSchemaDef.ATTR_isReverseFunctional, bool2str((Boolean) impl.eGet(RelationsPackage.eINSTANCE.getAssociation_IsReverseFunctional()))));
		attrs.put(new BasicAttribute(RelationsSchemaDef.ATTR_isSymmetric, bool2str((Boolean) impl.eGet(RelationsPackage.eINSTANCE.getAssociation_IsSymmetric()))));
		attrs.put(new BasicAttribute(RelationsSchemaDef.ATTR_isTransitive, bool2str((Boolean) impl.eGet(RelationsPackage.eINSTANCE.getAssociation_IsTransitive()))));
		attrs.put(new BasicAttribute(RelationsSchemaDef.ATTR_isTranslationAssociation, bool2str((Boolean) impl.eGet(RelationsPackage.eINSTANCE.getAssociation_IsTranslationAssociation()))));
		// Put the scheme in ldap-specific form ...
		{
			Object schemeO = impl.eGet(RelationsPackage.eINSTANCE.getAssociation_TargetCodingScheme());
			if (schemeO != null) {
				String scheme = schemeO.toString();
                //Dan commented out the following, because it broke things (forge bug 383)...
                //not sure why it was done in the first place?
//				String schemeLower = scheme.toLowerCase();
//				String key = org.LexGrid.persistence.ldap.codingSchemes.CodingSchemesSchemaDef.ATTR_codingScheme+'=';
//				String keyLower = key.toLowerCase();
//				String dn = (schemeLower.indexOf(keyLower) < 0)
//					? key + scheme
//					: scheme;
				attrs.put(new BasicAttribute(RelationsSchemaDef.ATTR_targetCodingScheme,
					scheme));
			}
		}
		return attrs;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#postResolve(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public void postResolve(ManagedObjIF obj) throws NamingException {
		super.postResolve(obj);
		AssociationImpl impl = (AssociationImpl) obj;

		// Resolve association instances (if not staging retrieval) ...
		if (!isStagingEnabled())
			dcResolveContent(impl);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#primaryKey2rdn(java.lang.Object)
	 */
	public String primaryKey2rdn(Object key) {
		return "association=" + (String) key;
	}

}