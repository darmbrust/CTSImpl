/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence.ldap;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.naming.Context;
import javax.naming.NameAlreadyBoundException;
import javax.naming.NameNotFoundException;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.ldap.InitialLdapContext;

import org.LexGrid.emf.base.LgConstraint;
import org.LexGrid.emf.base.LgModelObj;
import org.LexGrid.emf.base.LgSearchable;
import org.LexGrid.emf.codingSchemes.CodingSchemeType;
import org.LexGrid.emf.codingSchemes.CodingSchemesType;
import org.LexGrid.emf.codingSchemes.CodingschemesFactory;
import org.LexGrid.emf.codingSchemes.CodingschemesPackage;
import org.LexGrid.emf.codingSchemes.impl.CodingSchemesTypeImpl;
import org.LexGrid.emf.codingSchemes.persistence.CodingSchemesPersistence;
import org.LexGrid.managedobj.HomeServiceBroker;
import org.LexGrid.managedobj.ManagedObjIF;
import org.LexGrid.managedobj.ManagedObjIterator;
import org.LexGrid.managedobj.ManagedObjIteratorWrapper;
import org.LexGrid.managedobj.QueryException;
import org.LexGrid.managedobj.ServiceInitException;
import org.LexGrid.managedobj.ServiceUnavailableException;
import org.LexGrid.managedobj.jndi.LdapBaseService;
import org.LexGrid.managedobj.jndi.LdapContextDescriptor;
import org.LexGrid.managedobj.jndi.LdapContextPoolPolicy;
import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EFactory;

/**
 * Handles LDAP persistence for the corresponding type of managed object.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class CodingSchemesService
	extends LgBaseService
	implements CodingSchemesPersistence {
	
    protected final static Logger logger = Logger.getLogger("org.LexGrid.persistence.ldap.CodingSchemesService");

	static Map _feature2level, _level2attrs;
	static {
		// Information model to stage mappings ...
		_feature2level = new HashMap(2);
		_feature2level.put(CodingschemesPackage.eINSTANCE.getCodingSchemesType_Dc(), STAGE_Initial);
		_feature2level.put(CodingschemesPackage.eINSTANCE.getCodingSchemesType_CodingScheme(), STAGE_Content);

		// Stage to LDAP mappings ...
		_level2attrs = new HashMap(1);
		_level2attrs.put( STAGE_Initial, new String[] {
			CodingSchemesSchemaDef.ATTR_dc
			});
	}

	protected CodingSchemeService _schemeService;

	/**
	 * @param broker
	 * @param xmlFile
	 * @param ctxDescriptor
	 * @param ctxPoolPolicy
	 * @throws ServiceInitException
	 */
	public CodingSchemesService(
		HomeServiceBroker broker,
		File xmlFile,
		LdapContextDescriptor ctxDescriptor,
		LdapContextPoolPolicy ctxPoolPolicy)
		throws ServiceInitException {
		super(broker, xmlFile, ctxDescriptor, ctxPoolPolicy);
	}

	/**
	 * @param broker
	 * @param xmlFile
	 * @param ctxDescriptor
	 * @param ctxPoolPolicy
	 * @param stagedRetrievalEnabled
	 * @throws ServiceInitException
	 */
	public CodingSchemesService(
		HomeServiceBroker broker,
		File xmlFile,
		LdapContextDescriptor ctxDescriptor,
		LdapContextPoolPolicy ctxPoolPolicy,
		boolean stagedRetrievalEnabled)
		throws ServiceInitException {
		super(
			broker,
			xmlFile,
			ctxDescriptor,
			ctxPoolPolicy,
			stagedRetrievalEnabled);
	}

	/**
	 * @param anchorService
	 * @throws ServiceInitException
	 */
	public CodingSchemesService(LdapBaseService anchorService) throws ServiceInitException {
		super(anchorService);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.jndiJndiDirService#attrs2obj(org.LexGrid.managedobj.ManagedObjIF, javax.naming.directory.Attributes)
	 */
	protected void attrs2obj(ManagedObjIF obj, Attributes attrs) throws NamingException {
		CodingSchemesTypeImpl impl = (CodingSchemesTypeImpl) obj;
		Attribute attr;
		if ((attr = attrs.get(CodingSchemesSchemaDef.ATTR_dc)) != null)
			impl.eSet(CodingschemesPackage.eINSTANCE.getCodingSchemesType_Dc(), attr.get());
	}

	/* (non-Javadoc)
	 * @see org.org.LexGrid.commons.managedobj.service.BaseService#closePrim()
	 */
	public void closePrim() {
		try {
			super.closePrim();
		} finally {
			_schemeService = null;
		}
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#dcResolveContent(org.LexGrid.plugin.base.LgModelObj)
	 */
	public void dcResolveContent(LgModelObj obj) throws NamingException {
		if (obj instanceof CodingSchemesType) {
			_schemeService.setContextEntryPoint(qualifyRdn(obj2rdn(obj)));
			_schemeService.setEContext(obj, null, false);
			_schemeService.dcResolveContent("", ((CodingSchemesType) obj).getCodingScheme());
		}
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getEClass()
	 */
	protected EClass getEClass() {
		return CodingschemesPackage.eINSTANCE.getCodingSchemesType();
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getEFactory()
	 */
	protected EFactory getEFactory() {
		return CodingschemesFactory.eINSTANCE;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#getInstanceClass()
	 */
	protected Class getInstanceClass() {
		return CodingSchemesTypeImpl.class;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#getManagedClasses()
	 */
	public List getManagedClasses() {
		List clazz = super.getManagedClasses();
		clazz.add(CodingSchemesSchemaDef.CLASS_codingSchemesType);
		return clazz;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getStagingFeature2LevelMap()
	 */
	protected Map getStagingFeature2LevelMap() {
		return _feature2level;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getStagingLevel2AttrsMap()
	 */
	protected Map getStagingLevel2AttrsMap() {
		return _level2attrs;
	}

	/* (non-Javadoc)
	 * @see org.org.LexGrid.commons.managedobj.service.BaseService#initNestedServices()
	 */
	protected void initNestedServices() throws ServiceInitException {
		_schemeService = new CodingSchemeService(this);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#obj2attrs(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public Attributes obj2attrs(ManagedObjIF obj) {
		// Invoke superclass to pick up generic attributes (objectClass)
		Attributes attrs = super.obj2attrs(obj);

		// Add attributes unique to the given object
		CodingSchemesTypeImpl impl = (CodingSchemesTypeImpl) obj;
		attrs.put(new BasicAttribute(CodingSchemesSchemaDef.ATTR_dc, impl.eGet(CodingschemesPackage.eINSTANCE.getCodingSchemesType_Dc())));
		return attrs;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#postResolve(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public void postResolve(ManagedObjIF obj) throws NamingException {
		super.postResolve(obj);
		CodingSchemesTypeImpl impl = (CodingSchemesTypeImpl) obj;

		// Resolve the associated coding schemes ...
		if (!isStagingEnabled())
			dcResolveContent(impl);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#primaryKey2rdn(java.lang.Object)
	 */
	public String primaryKey2rdn(Object key) {
		return "dc=" + (String) key;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.plugin.base.LgSearchableIF#queryConcepts(org.LexGrid.plugin.base.LgModelObj, org.LexGrid.plugin.base.LgConstraint[], int)
	 */
	public ManagedObjIterator queryConcepts(LgModelObj root, LgConstraint[] constraints, int limit) throws QueryException {
		if (!(root instanceof CodingSchemesType || root instanceof CodingSchemeType))
			throw new IllegalArgumentException("root");
		if (!(_schemeService instanceof LgSearchable))
			throw new ServiceUnavailableException();

		if (root instanceof CodingSchemeType) {
			_schemeService.setContextEntryPoint(
				qualifyRdn(obj2rdn((LgModelObj) ((CodingSchemeType) root).eContainer())));
			return ((LgSearchable) _schemeService)
				.queryConcepts(root, constraints, limit);
		}
		
		_schemeService.setContextEntryPoint(qualifyRdn(obj2rdn(root)));
		Iterator schemes = root.getContent(CodingSchemeType.class, 0);
		int count = 0;
		boolean noLimit = limit == 0;
		List result = new ArrayList();
		while (schemes.hasNext() && (noLimit || count < limit)) {
			CodingSchemeType scheme = (CodingSchemeType) schemes.next();
			int remainingLimit = noLimit ? 0 : limit - count;
			Iterator found =
				((LgSearchable) _schemeService)
					.queryConcepts(scheme, constraints, remainingLimit);
			while (found.hasNext() && (noLimit || count++ < limit))
				result.add(found.next());
		}
		return new ManagedObjIteratorWrapper(result.iterator());
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.plugin.base.LgSearchableIF#queryRelationSources(org.LexGrid.plugin.base.LgModelObj, java.lang.String, int)
	 */
	public ManagedObjIterator queryRelationSources(LgModelObj root, String code, int limit) throws QueryException {
		if (!(root instanceof CodingSchemesType || root instanceof CodingSchemeType))
			throw new IllegalArgumentException("root");
		if (!(_schemeService instanceof LgSearchable))
			throw new ServiceUnavailableException();

		if (root instanceof CodingSchemeType) {
			_schemeService.setContextEntryPoint(
				qualifyRdn(obj2rdn((LgModelObj) ((CodingSchemeType) root).eContainer())));
			return ((LgSearchable) _schemeService)
				.queryRelationSources(root, code, limit);
		}
		
		_schemeService.setContextEntryPoint(qualifyRdn(obj2rdn(root)));
		Iterator schemes = root.getContent(CodingSchemeType.class, 0);
		int count = 0;
		boolean noLimit = limit == 0;
		List result = new ArrayList();
		while (schemes.hasNext() && (noLimit || count < limit)) {
			CodingSchemeType scheme = (CodingSchemeType) schemes.next();
			Iterator found =
				((LgSearchable) _schemeService)
					.queryRelationSources(scheme, code, limit);
			while (found.hasNext() && (noLimit || count++ < limit))
				result.add(found.next());
		}
		return new ManagedObjIteratorWrapper(result.iterator());
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.plugin.base.LgSearchableIF#queryRelationTargets(org.LexGrid.plugin.base.LgModelObj, java.lang.String, java.lang.String, int)
	 */
	public ManagedObjIterator queryRelationTargets(LgModelObj root, String targetContext, String targetCode, int limit) throws QueryException {
		if (!(root instanceof CodingSchemesType || root instanceof CodingSchemeType))
			throw new IllegalArgumentException("root");
		if (!(_schemeService instanceof LgSearchable))
			throw new ServiceUnavailableException();

		if (root instanceof CodingSchemeType) {
			_schemeService.setContextEntryPoint(
				qualifyRdn(obj2rdn((LgModelObj) ((CodingSchemeType) root).eContainer())));
			return ((LgSearchable) _schemeService)
				.queryRelationTargets(root, targetContext, targetCode, limit);
		}
		
		_schemeService.setContextEntryPoint(qualifyRdn(obj2rdn(root)));
		Iterator schemes = root.getContent(CodingSchemeType.class, 0);
		int count = 0;
		boolean noLimit = limit == 0;
		List result = new ArrayList();
		while (schemes.hasNext() && (noLimit || count < limit)) {
			CodingSchemeType scheme = (CodingSchemeType) schemes.next();
			Iterator found =
				((LgSearchable) _schemeService)
					.queryRelationTargets(scheme, targetContext, targetCode, limit);
			while (found.hasNext() && (noLimit || count++ < limit))
				result.add(found.next());
		}
		return new ManagedObjIteratorWrapper(result.iterator());
	}

	public void dcCreateEntryAbsolute(String dn) throws NamingException {
		try {
			super.dcCreateEntryAbsolute(dn);
		} catch (NameNotFoundException nnfe) {
			logger.error("Unable to create LDAP entry" + dn, nnfe);
		}
	}
	
	protected void ensureContext() {
		DirContext ctx = null;
		try {
			ctx = checkOutDirContext();
			try {
				ctx.list("");
			} catch (NameNotFoundException nnfe) {
				// Extract names for the intended service entry
				// from the assigned context ...
				String fullname = ctx.getNameInNamespace();
				StringTokenizer st = new StringTokenizer(fullname, ",");
				String serviceRdn = null;
				StringBuffer base = new StringBuffer();
				if (st.hasMoreTokens()) 
					serviceRdn = st.nextToken();
				if (st.hasMoreTokens())
					base.append(st.nextToken());
				while (st.hasMoreTokens())
					base.append(',').append(st.nextToken());
				
				// If the names fit, attempt to create the parent entries ...
				String url = (String) ctx.getEnvironment().get(Context.PROVIDER_URL);
				LdapContextDescriptor desc = (LdapContextDescriptor) getContextDescriptor().clone();
				DirContext baseContext = null;
				
				if (serviceRdn.startsWith("service")) {
					// Create the service entry ...
					String prefix = url.substring(0, url.lastIndexOf('/') + 1) + base;
					desc.getEnvironment().put(Context.PROVIDER_URL, prefix);
					baseContext = new InitialLdapContext(desc.getEnvironment(), desc.getControls());
					try {
						Attributes attrs = new BasicAttributes();
						attrs.put(org.LexGrid.managedobj.jndi.SchemaDef.ATTR_objectClass, CodingSchemesSchemaDef.CLASS_service);
						attrs.put(CodingSchemesSchemaDef.ATTR_service, (serviceRdn.substring((serviceRdn.lastIndexOf('=') + 1)).trim()));
						baseContext.createSubcontext(serviceRdn, attrs);
					} catch (NameAlreadyBoundException nabe) {
					} finally {
						baseContext.close();
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error creating ldap parent context", e);
		} finally {
			checkInContext(ctx);
		}
	}

}