/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence.ldap;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;

import org.LexGrid.emf.commonTypes.CommontypesPackage;
import org.LexGrid.emf.commonTypes.Property;
import org.LexGrid.emf.commonTypes.impl.PropertyImpl;
import org.LexGrid.emf.concepts.CodedEntry;
import org.LexGrid.emf.concepts.ConceptsFactory;
import org.LexGrid.emf.concepts.ConceptsPackage;
import org.LexGrid.emf.concepts.util.ConceptsUtil;
import org.LexGrid.managedobj.ManagedObjIF;
import org.LexGrid.managedobj.ServiceInitException;
import org.LexGrid.managedobj.jndi.JndiDirService;
import org.LexGrid.managedobj.jndi.LdapBaseService;
import org.apache.commons.collections.CollectionUtils;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EFactory;
import org.eclipse.emf.ecore.EObject;

/**
 * Handles LDAP persistence for the corresponding type of managed object.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class PropertyService extends LgBaseService {

	static Map _feature2level, _level2attrs;
	static {
		// Information model to stage mappings ...
		_feature2level = new HashMap(16);
		_feature2level.put(CommontypesPackage.eINSTANCE.getProperty_Language(), STAGE_Extended);
		_feature2level.put(CommontypesPackage.eINSTANCE.getProperty_PresentationFormat(), STAGE_Extended);
		_feature2level.put(CommontypesPackage.eINSTANCE.getProperty_Property(), STAGE_Initial);
		_feature2level.put(CommontypesPackage.eINSTANCE.getProperty_PropertyId(), STAGE_Initial);
		_feature2level.put(CommontypesPackage.eINSTANCE.getProperty_Source(), STAGE_Extended);
		_feature2level.put(CommontypesPackage.eINSTANCE.getProperty_Text(), STAGE_Initial);
		_feature2level.put(CommontypesPackage.eINSTANCE.getProperty_UsageContext(), STAGE_Extended);

		// Stage to LDAP mappings ...
		_level2attrs = new HashMap(4);
		_level2attrs.put( STAGE_Initial, new String[] {
			ConceptsSchemaDef.ATTR_dataType,
			ConceptsSchemaDef.ATTR_propertyId,
			ConceptsSchemaDef.ATTR_property,
			ConceptsSchemaDef.ATTR_text
			});
		_level2attrs.put(STAGE_Extended, new String[] {
			ConceptsSchemaDef.ATTR_language,
			ConceptsSchemaDef.ATTR_presentationFormat,
			ConceptsSchemaDef.ATTR_source,
			ConceptsSchemaDef.ATTR_usageContext,
			});
		_level2attrs.put(STAGE_Advanced, new String[] {
			ConceptsSchemaDef.ATTR_blob,
			});
	}

	protected CommentService _commentService;
	protected DefinitionService _defnService;
	protected InstructionService _instrService;
	protected PresentationService _presService;
	private String[] _rAttrs = null;

	public PropertyService(LdapBaseService anchorService) throws ServiceInitException {
		super(anchorService);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.jndiJndiDirService#attrs2obj(org.LexGrid.managedobj.ManagedObjIF, javax.naming.directory.Attributes)
	 */
	protected void attrs2obj(ManagedObjIF obj, Attributes attrs) throws NamingException {
		PropertyImpl impl = (PropertyImpl) obj;
		Attribute attr;
		if ((attr = attrs.get(ConceptsSchemaDef.ATTR_language)) != null)
			impl.eSet(CommontypesPackage.eINSTANCE.getProperty_Language(), attr.get());
		if ((attr = attrs.get(ConceptsSchemaDef.ATTR_presentationFormat)) != null)
			impl.eSet(CommontypesPackage.eINSTANCE.getProperty_PresentationFormat(), attr.get());
		if ((attr = attrs.get(ConceptsSchemaDef.ATTR_property)) != null)
			impl.eSet(CommontypesPackage.eINSTANCE.getProperty_Property(), attr.get());
		if ((attr = attrs.get(ConceptsSchemaDef.ATTR_propertyId)) != null)
			impl.eSet(CommontypesPackage.eINSTANCE.getProperty_PropertyId(), attr.get());
		if ((attr = attrs.get(ConceptsSchemaDef.ATTR_source)) != null)
			impl.eSet(CommontypesPackage.eINSTANCE.getProperty_Source(), attr2sourceList(attr));
		if ((attr = attrs.get(ConceptsSchemaDef.ATTR_text)) != null)
			impl.eSet(CommontypesPackage.eINSTANCE.getProperty_Text(), attr.get());
		if ((attr = attrs.get(ConceptsSchemaDef.ATTR_usageContext)) != null)
			impl.eSet(CommontypesPackage.eINSTANCE.getProperty_UsageContext(), attr2list(attr));
	}

	/* (non-Javadoc)
	 * @see org.org.LexGrid.commons.managedobj.service.BaseService#closePrim()
	 */
	public void closePrim() {
		try {
			super.closePrim();
		} finally {
			_commentService = null;
			_defnService = null;
			_instrService = null;
			_presService = null;
		}
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#dcEnhancedResolve(java.lang.String, java.util.List)
	 */
	public void dcEnhancedResolve(String rdn, List list) throws NamingException {
		// If no list is provided, check if the context item is a coded entry and
		// if so resolve all props (comments, definitions, instructions, presentations,
		// and generic properties) as children.
		if (list != null) {
			super.dcEnhancedResolve(rdn, list);
			return;
		}
		EObject eo = getEContainer();
		if (eo instanceof CodedEntry)
			for (Iterator props = dcResolveAllToList(rdn, null).iterator(); props.hasNext(); )
				ConceptsUtil.addProperty((CodedEntry) eo, (Property) props.next());
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getEClass()
	 */
	protected EClass getEClass() {
		return ConceptsPackage.eINSTANCE.getConceptProperty();
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getEFactory()
	 */
	protected EFactory getEFactory() {
		return ConceptsFactory.eINSTANCE;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#getInstanceClass()
	 */
	protected Class getInstanceClass() {
		return org.LexGrid.emf.concepts.impl.ConceptPropertyImpl.class;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#getManagedClasses()
	 */
	public List getManagedClasses() {
		List clazz = super.getManagedClasses();
		clazz.add(ConceptsSchemaDef.CLASS_propertyClass);
		return clazz;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.service.CachedService#getPrimaryCacheMaxSize()
	 */
	protected int getPrimaryCacheMaxSize() {
		return 0;
	}
	
	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.jndiJndiDirService#getResolveAttrs()
	 */
	public String[] getResolveAttrs() {
		if (_rAttrs == null) {
			// Start with immediately managed attributes...
			Set attrs = new HashSet();
			attrs.addAll(getManagedAttrs());
			
			// Add those required by nested services handling
			// subclass resolution...
			CollectionUtils.addAll(attrs, _commentService.getResolveAttrs());
			CollectionUtils.addAll(attrs, _defnService.getResolveAttrs());
			CollectionUtils.addAll(attrs, _instrService.getResolveAttrs());
			CollectionUtils.addAll(attrs, _presService.getResolveAttrs());

			Arrays.sort(_rAttrs = (String[]) attrs.toArray(new String[attrs.size()]));
		}
		return _rAttrs;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getStagingFeature2LevelMap()
	 */
	protected Map getStagingFeature2LevelMap() {
		return _feature2level;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getStagingLevel2AttrsMap()
	 */
	protected Map getStagingLevel2AttrsMap() {
		return _level2attrs;
	}

	/* (non-Javadoc)
	 * @see org.org.LexGrid.commons.managedobj.service.BaseService#initNestedServices()
	 */
	protected void initNestedServices() throws ServiceInitException {
		// The following are registered to allow for finer-grain
		// resolution when converting attributes to and from objects.
		// For example, a property with class 'Property' and
		// 'comment' will be handled by the nested comment service.
		_commentService = new CommentService(this);
		_defnService = new DefinitionService(this);
		_instrService = new InstructionService(this);
		_presService = new PresentationService(this);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#obj2attrs(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public Attributes obj2attrs(ManagedObjIF obj) {
		// Invoke superclass to pick up generic attributes (objectClass)
		Attributes attrs = super.obj2attrs(obj);

		// Add attributes unique to the given object
		PropertyImpl impl = (PropertyImpl) obj;
		attrs.put(new BasicAttribute(ConceptsSchemaDef.ATTR_language, impl.eGet(CommontypesPackage.eINSTANCE.getProperty_Language())));
		attrs.put(new BasicAttribute(ConceptsSchemaDef.ATTR_presentationFormat,	impl.eGet(CommontypesPackage.eINSTANCE.getProperty_PresentationFormat())));
		attrs.put(new BasicAttribute(ConceptsSchemaDef.ATTR_property, impl.eGet(CommontypesPackage.eINSTANCE.getProperty_Property())));
		attrs.put(new BasicAttribute(ConceptsSchemaDef.ATTR_propertyId, impl.eGet(CommontypesPackage.eINSTANCE.getProperty_PropertyId())));
		attrs.put(newMultiValAttr(ConceptsSchemaDef.ATTR_source, (List) impl.eGet(CommontypesPackage.eINSTANCE.getProperty_Source())));
		attrs.put(new BasicAttribute(ConceptsSchemaDef.ATTR_text, impl.eGet(CommontypesPackage.eINSTANCE.getProperty_Text())));
		attrs.put(newMultiValAttr(ConceptsSchemaDef.ATTR_usageContext, (List) impl.eGet(CommontypesPackage.eINSTANCE.getProperty_UsageContext())));
		return attrs;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#primaryKey2rdn(java.lang.Object)
	 */
	public String primaryKey2rdn(Object key) {
		return "propertyId=" + (String) key;
	}

	protected JndiDirService serviceFor(Attributes attrs) throws NamingException {
		// Use a finer-grain service, if registered & applicable...
		Attribute classAttr =
			attrs.get(org.LexGrid.managedobj.jndi.SchemaDef.ATTR_objectClass);
		if (classAttr != null) {
			List classList = new ArrayList();
			CollectionUtils.addAll(classList, classAttr.getAll());
			if (classList.size() == 1) {
				String clazz = classList.get(0).toString();
				if (ConceptsSchemaDef.CLASS_presentation.equals(clazz)) return _presService;
				if (ConceptsSchemaDef.CLASS_definition.equals(clazz)) return _defnService;
				if (ConceptsSchemaDef.CLASS_comment.equals(clazz)) return _commentService;
				if (ConceptsSchemaDef.CLASS_instruction.equals(clazz)) return _instrService;
				return this;
			}
			return serviceFor((String[]) classList.toArray(new String[classList.size()]));
		}
		return this;
	}

}