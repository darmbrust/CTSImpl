/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence.ldap;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.naming.InvalidNameException;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.LdapContext;

import org.LexGrid.emf.base.LgConstrainableList;
import org.LexGrid.emf.base.LgConstraint;
import org.LexGrid.emf.base.LgModelObj;
import org.LexGrid.emf.base.LgUnsupportedConstraintException;
import org.LexGrid.emf.commonTypes.CommontypesPackage;
import org.LexGrid.emf.concepts.CodedEntry;
import org.LexGrid.emf.concepts.ConceptsFactory;
import org.LexGrid.emf.concepts.ConceptsPackage;
import org.LexGrid.emf.concepts.impl.CodedEntryImpl;
import org.LexGrid.emf.concepts.impl.CommentImpl;
import org.LexGrid.emf.concepts.impl.ConceptPropertyImpl;
import org.LexGrid.emf.concepts.impl.DefinitionImpl;
import org.LexGrid.emf.concepts.impl.InstructionImpl;
import org.LexGrid.emf.concepts.impl.PresentationImpl;
import org.LexGrid.managedobj.FindException;
import org.LexGrid.managedobj.ManagedObjIF;
import org.LexGrid.managedobj.ServiceInitException;
import org.LexGrid.managedobj.jndi.LdapBaseService;
import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EFactory;

/**
 * Handles LDAP persistence for the corresponding type of managed object.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class CodedEntryService extends LgBaseService {
    protected final static Logger logger = Logger.getLogger("org.LexGrid.persistence.ldap.CodedEntryService");

	static Map _feature2level, _level2attrs;
	static {
		// Information model to stage mappings ...
		_feature2level = new HashMap(16);
		_feature2level.put(ConceptsPackage.eINSTANCE.getCodedEntry_ConceptCode(), STAGE_Initial);
		_feature2level.put(ConceptsPackage.eINSTANCE.getCodedEntry_ConceptStatus(), STAGE_Initial);
		_feature2level.put(ConceptsPackage.eINSTANCE.getCodedEntry_IsActive(), STAGE_Initial);
		_feature2level.put(ConceptsPackage.eINSTANCE.getCodedEntry_IsAnonymous(), STAGE_Initial);
		_feature2level.put(ConceptsPackage.eINSTANCE.getCodedEntry_ConceptProperty(), STAGE_Content);
		_feature2level.put(CommontypesPackage.eINSTANCE.getVersionableAndDescribable_EntityDescription(), STAGE_Initial);
		_feature2level.put(CommontypesPackage.eINSTANCE.getVersionable_Deprecated(), STAGE_Extended);
		_feature2level.put(CommontypesPackage.eINSTANCE.getVersionable_FirstRelease(), STAGE_Extended);
		_feature2level.put(CommontypesPackage.eINSTANCE.getVersionable_ModifiedInRelease(), STAGE_Extended);

		// Stage to LDAP mappings ...
		_level2attrs = new HashMap(2);
		_level2attrs.put( STAGE_Initial, new String[] {
			ConceptsSchemaDef.ATTR_conceptCode,
			ConceptsSchemaDef.ATTR_conceptStatus,
			ConceptsSchemaDef.ATTR_entityDescription,
			ConceptsSchemaDef.ATTR_isActive,
			ConceptsSchemaDef.ATTR_isAnonymous
			});
		_level2attrs.put(STAGE_Extended, new String[] {
			ConceptsSchemaDef.ATTR_isFirstVersion,
			ConceptsSchemaDef.ATTR_isLastVersion,
			});
	}

	protected PropertyService _propsService;

	public CodedEntryService(LdapBaseService anchorService) throws ServiceInitException {
		super(anchorService);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#dcEnhancedResolve(java.lang.String, java.util.List)
	 */
	public void dcEnhancedResolve(String rdn, List list) throws NamingException {
		// If not constrained to lookup of a single code, defer to superclass ...
		boolean constrained =
			list instanceof LgConstrainableList
				&& ((LgConstrainableList) list).isConstrained();
		if (constrained) {
			LgConstraint[] constraints = ((LgConstrainableList) list).getConstraints();
			if (constraints.length == 1) {
				LgConstraint constraint = constraints[0];
				if (constraint.getModelFeature().equals(ConceptsPackage.eINSTANCE.getCodedEntry_ConceptCode())
					&& constraint.getRelationType() == LgConstraint.RELATION_equals) {
					// Optimization. Request boils down to lookup of a single code.
					// Just do a resolve by primary key ...
					try {
						list.add(findByPrimaryKey(constraint.getCompareValue()));
					} catch (FindException fe) {
					}
					return;
				}
			}
		}
		super.dcEnhancedResolve(rdn, list);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#dcEnhResProcessResult(javax.naming.directory.SearchResult, java.util.List, javax.naming.directory.SearchControls, org.LexGrid.persistence.ldap.LgBaseService.LgFilterCriteria)
	 */
	protected void dcEnhResProcessResult(SearchResult sr, List list, SearchControls sc, LgFilterCriteria fc)
		throws NamingException {

		if (!(list instanceof LgConstrainableList && ((LgConstrainableList) list).isConstrained())) {
			super.dcEnhResProcessResult(sr, list, sc, fc);
			return;
		}
			
		// Did we get back an entry that corresponds to an imbedded property?
		boolean isProp = false; 
		Attribute oclass = sr.getAttributes().get("objectclass");
		NamingEnumeration oclasses = oclass.getAll();
		while (oclasses.hasMore() && !isProp) {
			String clazz = (String) oclasses.next();
			isProp = 
				clazz.equals(ConceptsSchemaDef.CLASS_propertyClass) ||
				clazz.equals(ConceptsSchemaDef.CLASS_comment) ||
				clazz.equals(ConceptsSchemaDef.CLASS_definition) ||
				clazz.equals(ConceptsSchemaDef.CLASS_instruction) ||
				clazz.equals(ConceptsSchemaDef.CLASS_presentation);
		}
		
		// If so, chop off the first part of the name; we want to
		// resolve and add the encapsulating concept. We also reuse the
		// original filter criteria, since we need to still reject
		// any entries that slipped through the first time on property
		// class matches, but still do not meet constraints set
		// against the coded entry class. 
		if (isProp) {
			String srName = unwrapName(sr);
			String resName = srName.substring(srName.indexOf(',')+1);
			SearchControls resSc = new SearchControls();
			resSc.setDerefLinkFlag(true);
			resSc.setReturningObjFlag(false);
			resSc.setSearchScope(SearchControls.OBJECT_SCOPE);
			resSc.setReturningAttributes(getResolveAttrs());
			LgFilterCriteria resFc = dcEnhResSearchFilter(
				((LgConstrainableList) list).getConstraints(), true);
			LdapContext ctx = checkOutLdapContext();
			try {
				NamingEnumeration ne =
					ctx.search(qualifyRdn(resName), resFc.expr, resFc.args, resSc);
				if (ne.hasMore()) {
					CodedEntry ce1 = (CodedEntry) result2obj((SearchResult) ne.next());
					// Note: We want to prevent duplicates. Normally this is not
					// a problem when entries are retrieved at the coded entry level.
					// However, when dealing with properties we could have multiple
					// properties identified for the same coded entry.
					// Right now we perform a simple iteration through the list
					// to prevent duplicates. This may be limiting, and should be
					// re-examined if performance is not acceptable.
					String trID1 = ce1.getTrackingIDQualified();
					String code1 = ce1.getConceptCode();
					String trID2;
					String code2;
					boolean found = false;
					for (Iterator it = list.iterator(); it.hasNext() && !found; ) {
						CodedEntry ce2 = (CodedEntry) it.next();
						trID2 = ce2.getTrackingIDQualified();
						if (trID1 == null) {
							if (trID2 == null) {
								code2 = ce2.getConceptCode();
								found = code1.equals(code2);
							}
						} else
							found = trID1.equals(trID2);
					}
					if (!found)
						list.add(ce1);
				}
			} catch (InvalidNameException ine) {
				logger.warn("Unable to interpret entry name from search result : "+resName, ine);
			} finally {
				checkInContext(ctx);
			}
		}
		// Otherwise, perform standard conversion ...
		else
			list.add(result2obj(sr));
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#dcEnhResSearchControls(java.lang.String, java.util.List)
	 */
	protected SearchControls dcEnhResSearchControls(String rdn, List list) throws NamingException {
		if (!(list instanceof LgConstrainableList && ((LgConstrainableList) list).isConstrained()))
			return super.dcEnhResSearchControls(rdn, list);

		// Are we constrained by imbedded properties?			
		boolean propConstrained = false;
		LgConstraint[] constraints = ((LgConstrainableList) list).getConstraints();
		for (int i = 0; i < constraints.length && !propConstrained; i++) {
			LgConstraint c = constraints[i];
			if (c.getModelFeature().getEContainingClass() == CommontypesPackage.eINSTANCE.getProperty())
				propConstrained = true;
		}

		List attrs = new ArrayList();
		attrs.addAll(Arrays.asList(getResolveAttrs()));
		attrs.add("objectclass");
		
		SearchControls sc = new SearchControls();
		sc.setDerefLinkFlag(true);
		sc.setReturningObjFlag(false);
		sc.setSearchScope(propConstrained ? SearchControls.SUBTREE_SCOPE : SearchControls.ONELEVEL_SCOPE);
		sc.setReturningAttributes(
			(String[]) attrs.toArray(new String[attrs.size()]));
		return sc;
	}

	/**
	 * Returns a filter criteria object based on the given constraints.
	 * @param constraints LgConstraint[]
	 * @param ignorePropConstraints Whether property-based constraints
	 * should be ignored in producing the returned criteria.
	 * @return LgFilterCriteria
	 */
	protected LgFilterCriteria dcEnhResSearchFilter(LgConstraint[] constraints, boolean ignorePropConstraints) throws NamingException {

		// For now, we keep it simple. Only searches by concept code,
		// entity description, and property text are supported.
		// Multiple constraints are allowed for each.
		LgFilterCriteria conceptFc = new LgFilterCriteria();
		LgFilterCriteria propFc = new LgFilterCriteria();
		for (int i = 0; i < constraints.length; i++) {
			LgConstraint c = constraints[i];
			if (c.getModelFeature() == ConceptsPackage.eINSTANCE.getCodedEntry_ConceptCode()) {
				conceptFc.and(ConceptsSchemaDef.ATTR_conceptCode, c.getRelationType(), c.getCompareValue());
			} else if (c.getModelFeature() == CommontypesPackage.eINSTANCE.getVersionableAndDescribable_EntityDescription()) {
				conceptFc.and(ConceptsSchemaDef.ATTR_entityDescription, c.getRelationType(), c.getCompareValue());
			} else if (c.getModelFeature() == CommontypesPackage.eINSTANCE.getProperty_Text()) {
				if (!ignorePropConstraints)
					propFc.and(ConceptsSchemaDef.ATTR_text, c.getRelationType(), c.getCompareValue());
			} else
				throw new LgUnsupportedConstraintException();
		}
		
		// Now marry class restrictions to each set of filters ...
		if (conceptFc.expr != null) {
			StringBuffer sb = new StringBuffer(256);
			sb.append("(|(");
			String[] classes = getResolveClasses();
			for (int i = 0; i < classes.length; i++)
				sb.append("(objectClass=").append(classes[i]).append(')');
			sb.append("))");
			conceptFc.and(sb.toString());
		}
		if (propFc.expr != null) {
			StringBuffer sb = new StringBuffer(256);
			sb.append("(|(");
			String[] classes = _propsService.getResolveClasses();
			for (int i = 0; i < classes.length; i++)
				sb.append("(objectClass=").append(classes[i]).append(')');
			sb.append("))");
			propFc.and(sb.toString());
		}

		// Finally, combine everything under a single roof ...
		LgFilterCriteria fc = new LgFilterCriteria();
		fc.expr = conceptFc.expr;
		if (!ignorePropConstraints && propFc.expr != null)
			fc.or(propFc.expr);
			
		// If nothing is set, fall back to an unfiltered list of
		// entries for the classes managed by this service ...
		if (fc.expr == null) {
			StringBuffer sb = new StringBuffer(256);
			sb.append("(|(");
			String[] classes = getResolveClasses();
			for (int i = 0; i < classes.length; i++)
				sb.append("(objectClass=").append(classes[i]).append(')');
			sb.append("))");
			fc.expr = sb.toString();
		}
		return fc;		
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#dcEnhResSearchFilter(java.lang.String, java.util.List)
	 */
	protected LgFilterCriteria dcEnhResSearchFilter(String rdn, List list) throws NamingException {
		if (!(list instanceof LgConstrainableList && ((LgConstrainableList) list).isConstrained()))
			return super.dcEnhResSearchFilter(rdn, list);
		return dcEnhResSearchFilter(
			((LgConstrainableList) list).getConstraints(), false);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.jndiJndiDirService#attrs2obj(org.LexGrid.managedobj.ManagedObjIF, javax.naming.directory.Attributes)
	 */
	protected void attrs2obj(ManagedObjIF obj, Attributes attrs) throws NamingException {
		CodedEntryImpl impl = (CodedEntryImpl) obj;
		Attribute attr;
		if ((attr = attrs.get(ConceptsSchemaDef.ATTR_conceptCode)) != null)
			impl.eSet(ConceptsPackage.eINSTANCE.getCodedEntry_ConceptCode(), attr.get());
		if ((attr = attrs.get(ConceptsSchemaDef.ATTR_conceptStatus)) != null)
			impl.eSet(ConceptsPackage.eINSTANCE.getCodedEntry_ConceptStatus(), attr.get());
		if ((attr = attrs.get(ConceptsSchemaDef.ATTR_isActive)) != null)
			impl.eSet(ConceptsPackage.eINSTANCE.getCodedEntry_IsActive(), str2Bool((String) attr.get()));
		if ((attr = attrs.get(ConceptsSchemaDef.ATTR_isAnonymous)) != null)
			impl.eSet(ConceptsPackage.eINSTANCE.getCodedEntry_IsAnonymous(), str2Bool((String) attr.get()));
		if ((attr = attrs.get(ConceptsSchemaDef.ATTR_entityDescription)) != null)
			impl.eSet(CommontypesPackage.eINSTANCE.getVersionableAndDescribable_EntityDescription(), attr.get());
		if ((attr = attrs.get(ConceptsSchemaDef.ATTR_isFirstVersion)) != null)
			impl.eSet(CommontypesPackage.eINSTANCE.getVersionableAndDescribable_EntityDescription(), str2Bool((String) attr.get()));
		if ((attr = attrs.get(ConceptsSchemaDef.ATTR_isLastVersion)) != null)
			impl.eSet(CommontypesPackage.eINSTANCE.getVersionable_FirstRelease(), str2Bool((String) attr.get()));
	}

	/* (non-Javadoc)
	 * @see org.org.LexGrid.commons.managedobj.service.BaseService#closePrim()
	 */
	public void closePrim() {
		try {
			super.closePrim();
		} finally {
			_propsService = null;
		}
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#dcResolveContent(org.LexGrid.plugin.base.LgModelObj)
	 */
	public void dcResolveContent(LgModelObj obj) throws NamingException {
		if (obj instanceof CodedEntry) {
			_propsService.setContextEntryPoint(qualifyRdn(obj2rdn(obj)));
			_propsService.setEContext(obj, null, false);
			_propsService.dcResolveContent("", null);
		}
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getEClass()
	 */
	protected EClass getEClass() {
		return ConceptsPackage.eINSTANCE.getCodedEntry();
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getEFactory()
	 */
	protected EFactory getEFactory() {
		return ConceptsFactory.eINSTANCE;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#getInstanceClass()
	 */
	protected Class getInstanceClass() {
		return CodedEntryImpl.class;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#getManagedClasses()
	 */
	public List getManagedClasses() {
		List clazz = super.getManagedClasses();
		clazz.add(ConceptsSchemaDef.CLASS_codedEntry);
		return clazz;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getStagingFeature2LevelMap()
	 */
	protected Map getStagingFeature2LevelMap() {
		return _feature2level;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getStagingLevel2AttrsMap()
	 */
	protected Map getStagingLevel2AttrsMap() {
		return _level2attrs;
	}

	/* (non-Javadoc)
	 * @see org.org.LexGrid.commons.managedobj.service.BaseService#initNestedServices()
	 */
	protected void initNestedServices() throws ServiceInitException {
		_propsService = new PropertyService(this);
		getNestedServiceMap().put(ConceptPropertyImpl.class, _propsService);
		getNestedServiceMap().put(CommentImpl.class, _propsService._commentService);
		getNestedServiceMap().put(DefinitionImpl.class, _propsService._defnService);
		getNestedServiceMap().put(InstructionImpl.class, _propsService._instrService);
		getNestedServiceMap().put(PresentationImpl.class, _propsService._presService);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#obj2attrs(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public Attributes obj2attrs(ManagedObjIF obj) {
		// Invoke superclass to pick up generic attributes (objectClass)
		Attributes attrs = super.obj2attrs(obj);

		// Add attributes unique to the given object
		CodedEntryImpl impl = (CodedEntryImpl) obj;
		attrs.put(new BasicAttribute(ConceptsSchemaDef.ATTR_conceptCode, impl.eGet(ConceptsPackage.eINSTANCE.getCodedEntry_ConceptCode())));
		attrs.put(new BasicAttribute(ConceptsSchemaDef.ATTR_conceptStatus, impl.eGet(ConceptsPackage.eINSTANCE.getCodedEntry_ConceptStatus())));
		attrs.put(new BasicAttribute(ConceptsSchemaDef.ATTR_entityDescription, impl.eGet(CommontypesPackage.eINSTANCE.getVersionableAndDescribable_EntityDescription())));
		attrs.put(new BasicAttribute(ConceptsSchemaDef.ATTR_isActive, bool2str((Boolean) impl.eGet(ConceptsPackage.eINSTANCE.getCodedEntry_IsActive()))));
		attrs.put(new BasicAttribute(ConceptsSchemaDef.ATTR_isAnonymous, bool2str((Boolean) impl.eGet(ConceptsPackage.eINSTANCE.getCodedEntry_IsAnonymous()))));
		attrs.put(new BasicAttribute(ConceptsSchemaDef.ATTR_isFirstVersion,	bool2str((Boolean) impl.eGet(CommontypesPackage.eINSTANCE.getVersionable_FirstRelease()))));
		attrs.put(new BasicAttribute(ConceptsSchemaDef.ATTR_isLastVersion, bool2str((Boolean) impl.eGet(CommontypesPackage.eINSTANCE.getVersionable_Deprecated()))));
		return attrs;
	}

	protected String[] obj2classes(ManagedObjIF obj) {
		CodedEntryImpl impl = (CodedEntryImpl) obj;
		if (!impl.getConceptCode().equals("@"))
			return super.obj2classes(obj);
		
		List clazz = new ArrayList();
		clazz.addAll(Arrays.asList(super.obj2classes(obj)));
		clazz.add(ConceptsSchemaDef.CLASS_topThing);
		return (String[])
			clazz.toArray(new String[clazz.size()]);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#postResolve(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public void postResolve(ManagedObjIF obj) throws NamingException {
		super.postResolve(obj);
		CodedEntryImpl impl = (CodedEntryImpl) obj;

		// Resolve the associated properties (if not staging retrieval) ...
		if (!isStagingEnabled())
			dcResolveContent(impl);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#primaryKey2rdn(java.lang.Object)
	 */
	public String primaryKey2rdn(Object key) {
		return "conceptCode=" + (String) key;
	}

}