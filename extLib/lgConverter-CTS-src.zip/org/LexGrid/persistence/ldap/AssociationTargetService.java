/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence.ldap;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;

import org.LexGrid.emf.base.LgModelObj;
import org.LexGrid.emf.commonTypes.CommontypesPackage;
import org.LexGrid.emf.relations.AssociationTarget;
import org.LexGrid.emf.relations.RelationsFactory;
import org.LexGrid.emf.relations.RelationsPackage;
import org.LexGrid.emf.relations.impl.AssociationTargetImpl;
import org.LexGrid.managedobj.ManagedObjIF;
import org.LexGrid.managedobj.ServiceInitException;
import org.LexGrid.managedobj.jndi.LdapBaseService;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EFactory;

/**
 * Handles LDAP persistence for the corresponding type of managed object.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class AssociationTargetService extends LgBaseService {

	static Map _feature2level, _level2attrs;
	static {
		// Information model to stage mappings ...
		_feature2level = new HashMap(8);
		_feature2level.put(RelationsPackage.eINSTANCE.getAssociationTarget_TargetCodingScheme(), STAGE_Initial);
		_feature2level.put(RelationsPackage.eINSTANCE.getAssociationTarget_TargetConcept(), STAGE_Initial);
		_feature2level.put(RelationsPackage.eINSTANCE.getAssociatableElement_AssociationQualification(), STAGE_Content);
		_feature2level.put(CommontypesPackage.eINSTANCE.getVersionable_FirstRelease(), STAGE_Extended);
		_feature2level.put(CommontypesPackage.eINSTANCE.getVersionable_Deprecated(), STAGE_Extended);
		_feature2level.put(CommontypesPackage.eINSTANCE.getVersionable_ModifiedInRelease(), STAGE_Extended);

		// Stage to LDAP mappings ...
		_level2attrs = new HashMap(2);
		_level2attrs.put(STAGE_Initial, new String[] {
			RelationsSchemaDef.ATTR_targetCodingScheme,
			RelationsSchemaDef.ATTR_targetConceptCode
			});
		_level2attrs.put(STAGE_Extended, new String[] {
			RelationsSchemaDef.ATTR_isFirstVersion,
			RelationsSchemaDef.ATTR_isLastVersion,
			});
	}

	protected AssociationQualificationService _qualService;

	public AssociationTargetService(LdapBaseService anchorService) throws ServiceInitException {
		super(anchorService);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.jndiJndiDirService#attrs2obj(org.LexGrid.managedobj.ManagedObjIF, javax.naming.directory.Attributes)
	 */
	protected void attrs2obj(ManagedObjIF obj, Attributes attrs) throws NamingException {
		AssociationTargetImpl impl = (AssociationTargetImpl) obj;
		Attribute attr;
		if ((attr = attrs.get(RelationsSchemaDef.ATTR_targetConceptCode)) != null)
			impl.eSet(RelationsPackage.eINSTANCE.getAssociationTarget_TargetConcept(), attr.get());
		if ((attr = attrs.get(RelationsSchemaDef.ATTR_isFirstVersion)) != null)
			impl.eSet(CommontypesPackage.eINSTANCE.getVersionable_FirstRelease(), str2Bool((String) attr.get()));
		if ((attr = attrs.get(RelationsSchemaDef.ATTR_isLastVersion)) != null)
			impl.eSet(CommontypesPackage.eINSTANCE.getVersionable_Deprecated(), str2Bool((String) attr.get()));
		// Pick out the non-ldap scheme name ...
		if ((attr = attrs.get(RelationsSchemaDef.ATTR_targetCodingScheme)) != null) {
			String dn = (String) attr.get();
			String dnLower = dn.toLowerCase();
			String keyLower = org.LexGrid.persistence.ldap.CodingSchemesSchemaDef.ATTR_codingScheme.toLowerCase()+'=';
			int i;
			String scheme = ((i = dnLower.indexOf(keyLower)) >= 0)
				? dn.substring(i+keyLower.length())
				: dn;
			impl.eSet(RelationsPackage.eINSTANCE.getAssociationTarget_TargetCodingScheme(),
				scheme);
		}
	}

	/* (non-Javadoc)
	 * @see org.org.LexGrid.commons.managedobj.service.BaseService#closePrim()
	 */
	public void closePrim() {
		try {
			super.closePrim();
		} finally {
			_qualService = null;
		}
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#dcResolveContent(org.LexGrid.plugin.base.LgModelObj)
	 */
	public void dcResolveContent(LgModelObj obj) throws NamingException {
		if (obj instanceof AssociationTarget) {
			_qualService.setContextEntryPoint(qualifyRdn(obj2rdn(obj)));
			_qualService.setEContext(obj, null, false);
			_qualService.dcResolveContent("", ((AssociationTarget) obj).getAssociationQualification());
		}
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getEClass()
	 */
	protected EClass getEClass() {
		return RelationsPackage.eINSTANCE.getAssociationTarget();
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getEFactory()
	 */
	protected EFactory getEFactory() {
		return RelationsFactory.eINSTANCE;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#getInstanceClass()
	 */
	protected Class getInstanceClass() {
		return AssociationTargetImpl.class;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#getManagedClasses()
	 */
	public List getManagedClasses() {
		List clazz = super.getManagedClasses();
		clazz.add(RelationsSchemaDef.CLASS_associationTarget);
		return clazz;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getStagingFeature2LevelMap()
	 */
	protected Map getStagingFeature2LevelMap() {
		return _feature2level;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LgBaseService#getStagingLevel2AttrsMap()
	 */
	protected Map getStagingLevel2AttrsMap() {
		return _level2attrs;
	}

	/* (non-Javadoc)
	 * @see org.org.LexGrid.commons.managedobj.service.BaseService#initNestedServices()
	 */
	protected void initNestedServices() throws ServiceInitException {
		_qualService = new AssociationQualificationService(this);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#obj2attrs(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public Attributes obj2attrs(ManagedObjIF obj) {
		// Invoke superclass to pick up generic attributes (objectClass)
		Attributes attrs = super.obj2attrs(obj);

		// Add attributes unique to the given object
		AssociationTargetImpl impl = (AssociationTargetImpl) obj;
		attrs.put(new BasicAttribute(RelationsSchemaDef.ATTR_targetConceptCode, impl.eGet(RelationsPackage.eINSTANCE.getAssociationTarget_TargetConcept())));
		attrs.put(new BasicAttribute(RelationsSchemaDef.ATTR_isFirstVersion,	bool2str((Boolean) impl.eGet(CommontypesPackage.eINSTANCE.getVersionable_FirstRelease()))));
		attrs.put(new BasicAttribute(RelationsSchemaDef.ATTR_isLastVersion, bool2str((Boolean) impl.eGet(CommontypesPackage.eINSTANCE.getVersionable_Deprecated()))));
		// Put the scheme in ldap-specific form ...
		{
			Object schemeO = impl.eGet(RelationsPackage.eINSTANCE.getAssociationTarget_TargetCodingScheme());
			if (schemeO != null) {
				String scheme = schemeO.toString();
                //Dan commented out the following, because it broke things (forge bug 383)...
                //not sure why it was done in the first place?
//				String schemeLower = scheme.toLowerCase();
//				String key = org.LexGrid.persistence.ldap.codingSchemes.CodingSchemesSchemaDef.ATTR_codingScheme+'=';
//				String keyLower = key.toLowerCase();
//				String dn = (schemeLower.indexOf(keyLower) < 0)
//					? key + scheme
//					: scheme;
				attrs.put(new BasicAttribute(RelationsSchemaDef.ATTR_targetCodingScheme,
					scheme));
			}
		}
		return attrs;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#postResolve(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public void postResolve(ManagedObjIF obj) throws NamingException {
		super.postResolve(obj);
		AssociationTargetImpl impl = (AssociationTargetImpl) obj;

		// Resolve association qualifiers (if not staging retrieval) ...
		if (!isStagingEnabled())
			dcResolveContent(impl);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.persistence.ldap.LdapBaseService#primaryKey2rdn(java.lang.Object)
	 */
	public String primaryKey2rdn(Object key) {
		return "targetConcept=" + (String) key;
	}

}