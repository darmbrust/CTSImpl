/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.persistence;

import java.util.ArrayList;

import org.LexGrid.emf.base.LgTrackingEntry;
import org.LexGrid.managedobj.HomeServiceBroker;
import org.LexGrid.managedobj.ManagedObjIterator;
import org.LexGrid.managedobj.ManagedObjIteratorWrapper;
import org.LexGrid.managedobj.OIDBasedObjHome;
import org.LexGrid.managedobj.QueryException;
import org.LexGrid.managedobj.RemoveException;
import org.LexGrid.managedobj.ServiceInitException;

/**
 * Provides a home context for the creation and management of objects
 * used to maintain a history of changes to LexGrid model objects.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class LgTrackingEntryHome extends OIDBasedObjHome implements LgTrackingEntryPersistence {

	public LgTrackingEntryHome(HomeServiceBroker broker) {
		super(broker);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntryPersistence#createRepository()
	 */
	public void createRepository() throws ServiceInitException {
		((LgTrackingEntryPersistence) getService()).createRepository();

	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntryPersistence#destroyRepository()
	 */
	public void destroyRepository() throws RemoveException {
		((LgTrackingEntryPersistence) getService()).destroyRepository();
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntryPersistence#getMostRecent(java.lang.String, java.lang.String)
	 */
	public LgTrackingEntry getMostRecent(String context, String id) throws QueryException {
		return ((LgTrackingEntryPersistence) getService()).getMostRecent(context, id);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntryPersistence#query()
	 */
	public ManagedObjIterator query() throws QueryException {
		return ((LgTrackingEntryPersistence) getService()).query();
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntryPersistence#queryByCommitState(boolean)
	 */
	public ManagedObjIterator queryByCommitState(boolean isCommitted) throws QueryException {
		return ((LgTrackingEntryPersistence) getService()).queryByCommitState(isCommitted);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntryPersistence#queryByContext(java.lang.String)
	 */
	public ManagedObjIterator queryByContext(String context) throws QueryException {
		return ((LgTrackingEntryPersistence) getService()).queryByContext(context);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntryPersistence#queryByContext(java.lang.String, java.lang.String)
	 */
	public ManagedObjIterator queryByContext(String context, String type) throws QueryException {
		return ((LgTrackingEntryPersistence) getService()).queryByContext(context, type);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntryPersistence#queryByEventType(int)
	 */
	public ManagedObjIterator queryByEventType(int event) throws QueryException {
		return ((LgTrackingEntryPersistence) getService()).queryByEventType(event);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntryPersistence#queryByItemID(java.lang.String)
	 */
	public ManagedObjIterator queryByItemID(String id) throws QueryException {
		if (id == null)
			return new ManagedObjIteratorWrapper(new ArrayList().iterator());
		return ((LgTrackingEntryPersistence) getService()).queryByItemID(id);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntryPersistence#queryByItemType(java.lang.String)
	 */
	public ManagedObjIterator queryByItemType(String type) throws QueryException {
		return ((LgTrackingEntryPersistence) getService()).queryByItemType(type);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntryPersistence#queryByQualifiedID(java.lang.String, java.lang.String)
	 */
	public ManagedObjIterator queryByQualifiedID(String context, String id) throws QueryException {
		return ((LgTrackingEntryPersistence) getService()).queryByQualifiedID(context, id);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntryPersistence#queryByQualifiedID(java.lang.String, java.lang.String, java.lang.String)
	 */
	public ManagedObjIterator queryByQualifiedID(String context, String id, String type) throws QueryException {
		return ((LgTrackingEntryPersistence) getService()).queryByQualifiedID(context, id, type);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntryPersistence#queryByTimestamp(long, long)
	 */
	public ManagedObjIterator queryByTimestamp(long msStart, long msEnd) throws QueryException {
		return ((LgTrackingEntryPersistence) getService()).queryByTimestamp(msStart, msEnd);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntryPersistence#removeAll()
	 */
	public void removeAll() throws RemoveException {
		((LgTrackingEntryPersistence) getService()).removeAll();
	}

}