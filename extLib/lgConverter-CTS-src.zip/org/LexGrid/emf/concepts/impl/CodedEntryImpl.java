/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.concepts.impl;

import java.util.Iterator;
import java.util.List;

import org.LexGrid.emf.commonTypes.impl.VersionableAndDescribableImpl;
import org.LexGrid.emf.concepts.CodedEntry;
import org.LexGrid.emf.concepts.ConceptsPackage;
import org.LexGrid.emf.concepts.Presentation;
import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Coded Entry</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.LexGrid.emf.concepts.impl.CodedEntryImpl#getPresentation <em>Presentation</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.impl.CodedEntryImpl#getDefinition <em>Definition</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.impl.CodedEntryImpl#getComment <em>Comment</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.impl.CodedEntryImpl#getInstruction <em>Instruction</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.impl.CodedEntryImpl#getConceptProperty <em>Concept Property</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.impl.CodedEntryImpl#getPropertyLink <em>Property Link</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.impl.CodedEntryImpl#getConceptCode <em>Concept Code</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.impl.CodedEntryImpl#getConceptStatus <em>Concept Status</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.impl.CodedEntryImpl#getIsActive <em>Is Active</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.impl.CodedEntryImpl#getIsAnonymous <em>Is Anonymous</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class CodedEntryImpl extends VersionableAndDescribableImpl implements CodedEntry {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CodedEntryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return ConceptsPackage.Literals.CODED_ENTRY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getPresentation() {
		return (List) eGet(ConceptsPackage.Literals.CODED_ENTRY__PRESENTATION, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getDefinition() {
		return (List) eGet(ConceptsPackage.Literals.CODED_ENTRY__DEFINITION, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getComment() {
		return (List) eGet(ConceptsPackage.Literals.CODED_ENTRY__COMMENT, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getInstruction() {
		return (List) eGet(ConceptsPackage.Literals.CODED_ENTRY__INSTRUCTION, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getConceptProperty() {
		return (List) eGet(ConceptsPackage.Literals.CODED_ENTRY__CONCEPT_PROPERTY, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getConceptCode() {
		return (String) eGet(ConceptsPackage.Literals.CODED_ENTRY__CONCEPT_CODE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setConceptCode(String newConceptCode) {
		eSet(ConceptsPackage.Literals.CODED_ENTRY__CONCEPT_CODE, newConceptCode);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetIsActive() {
		eUnset(ConceptsPackage.Literals.CODED_ENTRY__IS_ACTIVE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetIsActive() {
		return eIsSet(ConceptsPackage.Literals.CODED_ENTRY__IS_ACTIVE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean getIsAnonymous() {
		return (Boolean) eGet(ConceptsPackage.Literals.CODED_ENTRY__IS_ANONYMOUS, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsAnonymous(Boolean newIsAnonymous) {
		eSet(ConceptsPackage.Literals.CODED_ENTRY__IS_ANONYMOUS, newIsAnonymous);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getConceptStatus() {
		return (String) eGet(ConceptsPackage.Literals.CODED_ENTRY__CONCEPT_STATUS, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setConceptStatus(String newConceptStatus) {
		eSet(ConceptsPackage.Literals.CODED_ENTRY__CONCEPT_STATUS, newConceptStatus);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean getIsActive() {
		return (Boolean) eGet(ConceptsPackage.Literals.CODED_ENTRY__IS_ACTIVE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsActive(Boolean newIsActive) {
		eSet(ConceptsPackage.Literals.CODED_ENTRY__IS_ACTIVE, newIsActive);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetIsAnonymous() {
		eUnset(ConceptsPackage.Literals.CODED_ENTRY__IS_ANONYMOUS);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetIsAnonymous() {
		return eIsSet(ConceptsPackage.Literals.CODED_ENTRY__IS_ANONYMOUS);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getPropertyLink() {
		return (List) eGet(ConceptsPackage.Literals.CODED_ENTRY__PROPERTY_LINK, true);
	}

	////////////////////////////////////////////////////////////
	// ************** BEGIN NON-GENERATED CODE ************** //
	//                                                        //
	// ****************************************************** //
	////////////////////////////////////////////////////////////

	/**
	 * @see org.LexGrid.emf.base.LgCodedObj#getConcept()
	 * @non-generated
	 */
	public CodedEntry getConcept() {
		return this;
	}

	/**
	 * @see org.LexGrid.emf.base.LgModelObj#getDisplayName()
	 * @non-generated
	 */
	public String getPreferredDisplayName() {
		String base = super.getPreferredDisplayName();
		String text = getPreferredTextDescription();
		if (text != null && !text.equals(base)) {
			StringBuffer sb = new StringBuffer(base);
			sb.append(": ").append(text);
			return sb.toString();
		}
		return base;
	}

	/**
	 * The base text description; pulled from embedded properties if not
	 * present in the entity description.
	 * @non-generated
	 */
	public String getPreferredTextDescription() {
		String s = null;
		String entityDescription = getEntityDescription();
		if (entityDescription != null && entityDescription.length() > 0)
			s = entityDescription;
		else {
			String propText = null;
			for (Iterator props = getContent(Presentation.class, 0); props.hasNext() && propText == null;) {
				Presentation p = (Presentation) props.next();
				if (propText == null || (p.isSetIsPreferred() && p.getIsPreferred().booleanValue()))
					propText = p.getText();
			}
			if (propText != null)
				s = propText;
		}
		return s;
	}
}