/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.concepts.impl;

import java.util.Iterator;

import org.LexGrid.emf.commonTypes.impl.PropertyImpl;
import org.LexGrid.emf.concepts.CodedEntry;
import org.LexGrid.emf.concepts.ConceptsPackage;
import org.LexGrid.emf.concepts.Definition;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Definition</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.LexGrid.emf.concepts.impl.DefinitionImpl#getIsPreferred <em>Is Preferred</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class DefinitionImpl extends PropertyImpl implements Definition {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DefinitionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return ConceptsPackage.Literals.DEFINITION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean getIsPreferred() {
		return (Boolean) eGet(ConceptsPackage.Literals.DEFINITION__IS_PREFERRED, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsPreferred(Boolean newIsPreferred) {
		eSet(ConceptsPackage.Literals.DEFINITION__IS_PREFERRED, newIsPreferred);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetIsPreferred() {
		eUnset(ConceptsPackage.Literals.DEFINITION__IS_PREFERRED);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetIsPreferred() {
		return eIsSet(ConceptsPackage.Literals.DEFINITION__IS_PREFERRED);
	}

	////////////////////////////////////////////////////////////
	// ************** BEGIN NON-GENERATED CODE ************** //
	//                                                        //
	// ****************************************************** //
	////////////////////////////////////////////////////////////
	/* (non-Javadoc)
	 * @see org.eclipse.emf.ecore.EObject#eSet(org.eclipse.emf.ecore.EStructuralFeature, java.lang.Object)
	 * @non-generated
	 */
	public void eSet(EStructuralFeature eFeature, Object newValue) {
		super.eSet(eFeature, newValue);

		switch (eDerivedStructuralFeatureID(eFeature)) {
		// Upon success in setting a definition as preferred, this method
		// also ensures that other definitions for the concept are
		// marked as non-preferred.
		case ConceptsPackage.DEFINITION__IS_PREFERRED:
			if (newValue instanceof Boolean && ((Boolean) newValue).booleanValue()) {
				CodedEntry concept = (CodedEntry) getContainer(CodedEntry.class, 0);
				if (concept != null)
					for (Iterator items = concept.getDefinition().iterator(); items.hasNext();) {
						Definition d = (Definition) items.next();
						if (!d.equals(this))
							d.setIsPreferred(Boolean.FALSE);
					}
			}
		}
	}

} //DefinitionImpl