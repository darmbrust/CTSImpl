/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.concepts.impl;

import java.util.Iterator;
import java.util.List;

import org.LexGrid.emf.base.LgKeyedList;
import org.LexGrid.emf.base.impl.LgEnhancedEListImpl;
import org.LexGrid.emf.base.impl.LgModelObjImpl;
import org.LexGrid.emf.concepts.CodedEntry;
import org.LexGrid.emf.concepts.Concepts;
import org.LexGrid.emf.concepts.ConceptsPackage;
import org.LexGrid.managedobj.ResolveException;
import org.LexGrid.managedobj.UnexpectedException;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Concepts</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.LexGrid.emf.concepts.impl.ConceptsImpl#getConcept <em>Concept</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.impl.ConceptsImpl#getDc <em>Dc</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ConceptsImpl extends LgModelObjImpl implements Concepts {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ConceptsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return ConceptsPackage.Literals.CONCEPTS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDc() {
		return (String) eGet(ConceptsPackage.Literals.CONCEPTS__DC, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDc(String newDc) {
		eSet(ConceptsPackage.Literals.CONCEPTS__DC, newDc);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetDc() {
		eUnset(ConceptsPackage.Literals.CONCEPTS__DC);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetDc() {
		return eIsSet(ConceptsPackage.Literals.CONCEPTS__DC);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getConcept() {
		return (List) eGet(ConceptsPackage.Literals.CONCEPTS__CONCEPT, true);
	}

	////////////////////////////////////////////////////////////
	// ************** BEGIN NON-GENERATED CODE ************** //
	//                                                        //
	// ****************************************************** //
	////////////////////////////////////////////////////////////

	/* (non-Javadoc)
	 * @see org.eclipse.emf.ecore.EObject#eGet(org.eclipse.emf.ecore.EStructuralFeature, boolean)
	 * @non-generated
	 */
	public Object eGet(EStructuralFeature eFeature, boolean resolve) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
		// Control the makeup of the concept list to allow paging, etc
		case ConceptsPackage.CONCEPTS__CONCEPT: {
			if (!eIsSet(eFeature) && internalIsDirty(eFeature)) {
				EList concept = new LgEnhancedEListImpl(CodedEntry.class, this, ConceptsPackage.CONCEPTS__CONCEPT);

				internalMarkClean(eFeature);
				eSettings().dynamicSet(eDynamicFeatureID(eFeature), concept);
				if (resolve)
					try {
						resolveFeature(eFeature);
					} catch (ResolveException e) {
						throw new UnexpectedException(e);
					}
			}
			break;
		}
		}
		return super.eGet(eFeature, resolve);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.concepts.CodedEntryContainer#resolveCodedEntry(java.lang.String)
	 * @non-generated
	 */
	public CodedEntry resolveCodedEntry(String code) {
		CodedEntry match = null;
		CodedEntry candidate;
		if (code != null) {
			List candidates = getConcept();
			if (candidates instanceof LgKeyedList)
				match = (CodedEntry) ((LgKeyedList) candidates).getByPrimaryKey(code);
			else
				for (Iterator items = getConcept().iterator(); items.hasNext() && match == null;)
					if (code.equals((candidate = (CodedEntry) items.next()).getConceptCode()))
						match = candidate;
		}
		return match;
	}

} //ConceptsImpl