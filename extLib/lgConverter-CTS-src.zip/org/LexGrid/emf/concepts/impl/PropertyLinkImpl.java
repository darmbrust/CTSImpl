/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.concepts.impl;

import org.LexGrid.emf.base.impl.LgModelObjImpl;
import org.LexGrid.emf.concepts.ConceptsPackage;
import org.LexGrid.emf.concepts.PropertyLink;
import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Property Link</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.LexGrid.emf.concepts.impl.PropertyLinkImpl#getLink <em>Link</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.impl.PropertyLinkImpl#getSourceProperty <em>Source Property</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.impl.PropertyLinkImpl#getTargetProperty <em>Target Property</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class PropertyLinkImpl extends LgModelObjImpl implements PropertyLink {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PropertyLinkImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return ConceptsPackage.Literals.PROPERTY_LINK;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLink() {
		return (String) eGet(ConceptsPackage.Literals.PROPERTY_LINK__LINK, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLink(String newLink) {
		eSet(ConceptsPackage.Literals.PROPERTY_LINK__LINK, newLink);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSourceProperty() {
		return (String) eGet(ConceptsPackage.Literals.PROPERTY_LINK__SOURCE_PROPERTY, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSourceProperty(String newSourceProperty) {
		eSet(ConceptsPackage.Literals.PROPERTY_LINK__SOURCE_PROPERTY, newSourceProperty);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTargetProperty() {
		return (String) eGet(ConceptsPackage.Literals.PROPERTY_LINK__TARGET_PROPERTY, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTargetProperty(String newTargetProperty) {
		eSet(ConceptsPackage.Literals.PROPERTY_LINK__TARGET_PROPERTY, newTargetProperty);
	}

	////////////////////////////////////////////////////////////
	// ************** BEGIN NON-GENERATED CODE ************** //
	//                                                        //
	// ****************************************************** //
	////////////////////////////////////////////////////////////

	/**
	 * @see org.LexGrid.emf.base.impl.LgModelObjImpl#getDisplayName()
	 * @non-generated
	 */
	public String getPreferredDisplayName() {
		String displayText = null;
		String lnk = getLink();
		String src = getSourceProperty();
		String tgt = getTargetProperty();

		int lnkLen = lnk == null ? 0 : lnk.length();
		int srcLen = src == null ? 0 : src.length();
		int tgtLen = tgt == null ? 0 : tgt.length();

		if (lnkLen > 0 || srcLen > 0 || tgtLen > 0) {
			StringBuffer sb = new StringBuffer(128);
			if (lnkLen > 0)
				sb.append(lnk).append(": ");
			if (srcLen > 0)
				sb.append(src.length() > 32 ? src.substring(0, 33) + "..." : src).append(" -> ");
			if (tgtLen > 0)
				sb.append(tgt.length() > 32 ? tgt.substring(0, 33) + "..." : tgt);
			displayText = sb.toString();
			displayText = displayText.replace('\n', ' ');
			displayText = displayText.replace('\r', ' ');
		}
		return displayText == null ? super.getPreferredDisplayName() : displayText;
	}

} //PropertyLinkImpl