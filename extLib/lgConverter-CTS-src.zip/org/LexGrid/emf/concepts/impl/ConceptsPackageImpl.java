/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.concepts.impl;

import org.LexGrid.emf.base.impl.LgAttributeImpl;
import org.LexGrid.emf.base.impl.LgReferenceImpl;
import org.LexGrid.emf.builtins.BuiltinsPackage;
import org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl;
import org.LexGrid.emf.codingSchemes.CodingschemesPackage;
import org.LexGrid.emf.codingSchemes.impl.CodingschemesPackageImpl;
import org.LexGrid.emf.commonTypes.CommontypesPackage;
import org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl;
import org.LexGrid.emf.concepts.CodedEntry;
import org.LexGrid.emf.concepts.Comment;
import org.LexGrid.emf.concepts.ConceptProperty;
import org.LexGrid.emf.concepts.Concepts;
import org.LexGrid.emf.concepts.ConceptsFactory;
import org.LexGrid.emf.concepts.ConceptsPackage;
import org.LexGrid.emf.concepts.Definition;
import org.LexGrid.emf.concepts.DocumentRoot;
import org.LexGrid.emf.concepts.Instruction;
import org.LexGrid.emf.concepts.Presentation;
import org.LexGrid.emf.concepts.PropertyLink;
import org.LexGrid.emf.history.NCIHistoryPackage;
import org.LexGrid.emf.history.impl.NCIHistoryPackageImpl;
import org.LexGrid.emf.ldap.LdapPackage;
import org.LexGrid.emf.ldap.impl.LdapPackageImpl;
import org.LexGrid.emf.naming.NamingPackage;
import org.LexGrid.emf.naming.impl.NamingPackageImpl;
import org.LexGrid.emf.relations.RelationsPackage;
import org.LexGrid.emf.relations.impl.RelationsPackageImpl;
import org.LexGrid.emf.service.ServiceTypePackage;
import org.LexGrid.emf.service.impl.ServiceTypePackageImpl;
import org.LexGrid.emf.valueDomains.ValuedomainsPackage;
import org.LexGrid.emf.valueDomains.impl.ValuedomainsPackageImpl;
import org.LexGrid.emf.versions.VersionsPackage;
import org.LexGrid.emf.versions.impl.VersionsPackageImpl;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ConceptsPackageImpl extends EPackageImpl implements ConceptsPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass conceptsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass codedEntryEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass presentationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass propertyLinkEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass documentRootEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass definitionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass commentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass conceptPropertyEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass instructionEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see org.LexGrid.emf.concepts.ConceptsPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private ConceptsPackageImpl() {
		super(eNS_URI, ConceptsFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this
	 * model, and for any others upon which it depends.  Simple
	 * dependencies are satisfied by calling this method on all
	 * dependent packages before doing anything else.  This method drives
	 * initialization for interdependent packages directly, in parallel
	 * with this package, itself.
	 * <p>Of this package and its interdependencies, all packages which
	 * have not yet been registered by their URI values are first created
	 * and registered.  The packages are then initialized in two steps:
	 * meta-model objects for all of the packages are created before any
	 * are initialized, since one package's meta-model objects may refer to
	 * those of another.
	 * <p>Invocation of this method will not affect any packages that have
	 * already been initialized.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static ConceptsPackage init() {
		if (isInited)
			return (ConceptsPackage) EPackage.Registry.INSTANCE.getEPackage(ConceptsPackage.eNS_URI);

		// Obtain or create and register package
		ConceptsPackageImpl theConceptsPackage = (ConceptsPackageImpl) (EPackage.Registry.INSTANCE.getEPackage(eNS_URI) instanceof ConceptsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(eNS_URI)
				: new ConceptsPackageImpl());

		isInited = true;

		// Obtain or create and register interdependencies
		RelationsPackageImpl theRelationsPackage = (RelationsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(RelationsPackage.eNS_URI) instanceof RelationsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(RelationsPackage.eNS_URI) : RelationsPackage.eINSTANCE);
		NCIHistoryPackageImpl theNCIHistoryPackage = (NCIHistoryPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(NCIHistoryPackage.eNS_URI) instanceof NCIHistoryPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(NCIHistoryPackage.eNS_URI) : NCIHistoryPackage.eINSTANCE);
		VersionsPackageImpl theVersionsPackage = (VersionsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(VersionsPackage.eNS_URI) instanceof VersionsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(VersionsPackage.eNS_URI) : VersionsPackage.eINSTANCE);
		CodingschemesPackageImpl theCodingschemesPackage = (CodingschemesPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(CodingschemesPackage.eNS_URI) instanceof CodingschemesPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(CodingschemesPackage.eNS_URI)
				: CodingschemesPackage.eINSTANCE);
		LdapPackageImpl theLdapPackage = (LdapPackageImpl) (EPackage.Registry.INSTANCE.getEPackage(LdapPackage.eNS_URI) instanceof LdapPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(LdapPackage.eNS_URI)
				: LdapPackage.eINSTANCE);
		BuiltinsPackageImpl theBuiltinsPackage = (BuiltinsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(BuiltinsPackage.eNS_URI) instanceof BuiltinsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(BuiltinsPackage.eNS_URI) : BuiltinsPackage.eINSTANCE);
		ValuedomainsPackageImpl theValuedomainsPackage = (ValuedomainsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(ValuedomainsPackage.eNS_URI) instanceof ValuedomainsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(ValuedomainsPackage.eNS_URI)
				: ValuedomainsPackage.eINSTANCE);
		CommontypesPackageImpl theCommontypesPackage = (CommontypesPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(CommontypesPackage.eNS_URI) instanceof CommontypesPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(CommontypesPackage.eNS_URI) : CommontypesPackage.eINSTANCE);
		ServiceTypePackageImpl theServiceTypePackage = (ServiceTypePackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(ServiceTypePackage.eNS_URI) instanceof ServiceTypePackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(ServiceTypePackage.eNS_URI) : ServiceTypePackage.eINSTANCE);
		NamingPackageImpl theNamingPackage = (NamingPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(NamingPackage.eNS_URI) instanceof NamingPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(NamingPackage.eNS_URI) : NamingPackage.eINSTANCE);

		// Create package meta-data objects
		theConceptsPackage.createPackageContents();
		theRelationsPackage.createPackageContents();
		theNCIHistoryPackage.createPackageContents();
		theVersionsPackage.createPackageContents();
		theCodingschemesPackage.createPackageContents();
		theLdapPackage.createPackageContents();
		theBuiltinsPackage.createPackageContents();
		theValuedomainsPackage.createPackageContents();
		theCommontypesPackage.createPackageContents();
		theServiceTypePackage.createPackageContents();
		theNamingPackage.createPackageContents();

		// Initialize created meta-data
		theConceptsPackage.initializePackageContents();
		theRelationsPackage.initializePackageContents();
		theNCIHistoryPackage.initializePackageContents();
		theVersionsPackage.initializePackageContents();
		theCodingschemesPackage.initializePackageContents();
		theLdapPackage.initializePackageContents();
		theBuiltinsPackage.initializePackageContents();
		theValuedomainsPackage.initializePackageContents();
		theCommontypesPackage.initializePackageContents();
		theServiceTypePackage.initializePackageContents();
		theNamingPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theConceptsPackage.freeze();

		return theConceptsPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getConcepts() {
		return conceptsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getConcepts_Dc() {
		return (EAttribute) conceptsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getConcepts_Concept() {
		return (EReference) conceptsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCodedEntry() {
		return codedEntryEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCodedEntry_Presentation() {
		return (EReference) codedEntryEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCodedEntry_Definition() {
		return (EReference) codedEntryEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCodedEntry_Comment() {
		return (EReference) codedEntryEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCodedEntry_Instruction() {
		return (EReference) codedEntryEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCodedEntry_ConceptProperty() {
		return (EReference) codedEntryEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCodedEntry_ConceptCode() {
		return (EAttribute) codedEntryEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCodedEntry_IsActive() {
		return (EAttribute) codedEntryEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCodedEntry_ConceptStatus() {
		return (EAttribute) codedEntryEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCodedEntry_IsAnonymous() {
		return (EAttribute) codedEntryEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCodedEntry_PropertyLink() {
		return (EReference) codedEntryEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPresentation() {
		return presentationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPresentation_IsPreferred() {
		return (EAttribute) presentationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPresentation_DegreeOfFidelity() {
		return (EAttribute) presentationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPresentation_MatchIfNoContext() {
		return (EAttribute) presentationEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPresentation_RepresentationalForm() {
		return (EAttribute) presentationEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPropertyLink() {
		return propertyLinkEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPropertyLink_Link() {
		return (EAttribute) propertyLinkEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPropertyLink_SourceProperty() {
		return (EAttribute) propertyLinkEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPropertyLink_TargetProperty() {
		return (EAttribute) propertyLinkEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDocumentRoot() {
		return documentRootEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDocumentRoot_Mixed() {
		return (EAttribute) documentRootEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_XMLNSPrefixMap() {
		return (EReference) documentRootEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_XSISchemaLocation() {
		return (EReference) documentRootEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_Concepts() {
		return (EReference) documentRootEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDefinition() {
		return definitionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDefinition_IsPreferred() {
		return (EAttribute) definitionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getComment() {
		return commentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getConceptProperty() {
		return conceptPropertyEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getInstruction() {
		return instructionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConceptsFactory getConceptsFactory() {
		return (ConceptsFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		codedEntryEClass = createEClass(CODED_ENTRY);
		createEReference(codedEntryEClass, CODED_ENTRY__PRESENTATION);
		createEReference(codedEntryEClass, CODED_ENTRY__DEFINITION);
		createEReference(codedEntryEClass, CODED_ENTRY__COMMENT);
		createEReference(codedEntryEClass, CODED_ENTRY__INSTRUCTION);
		createEReference(codedEntryEClass, CODED_ENTRY__CONCEPT_PROPERTY);
		createEReference(codedEntryEClass, CODED_ENTRY__PROPERTY_LINK);
		createEAttribute(codedEntryEClass, CODED_ENTRY__CONCEPT_CODE);
		createEAttribute(codedEntryEClass, CODED_ENTRY__CONCEPT_STATUS);
		createEAttribute(codedEntryEClass, CODED_ENTRY__IS_ACTIVE);
		createEAttribute(codedEntryEClass, CODED_ENTRY__IS_ANONYMOUS);

		commentEClass = createEClass(COMMENT);

		conceptPropertyEClass = createEClass(CONCEPT_PROPERTY);

		conceptsEClass = createEClass(CONCEPTS);
		createEReference(conceptsEClass, CONCEPTS__CONCEPT);
		createEAttribute(conceptsEClass, CONCEPTS__DC);

		definitionEClass = createEClass(DEFINITION);
		createEAttribute(definitionEClass, DEFINITION__IS_PREFERRED);

		instructionEClass = createEClass(INSTRUCTION);

		presentationEClass = createEClass(PRESENTATION);
		createEAttribute(presentationEClass, PRESENTATION__DEGREE_OF_FIDELITY);
		createEAttribute(presentationEClass, PRESENTATION__IS_PREFERRED);
		createEAttribute(presentationEClass, PRESENTATION__MATCH_IF_NO_CONTEXT);
		createEAttribute(presentationEClass, PRESENTATION__REPRESENTATIONAL_FORM);

		propertyLinkEClass = createEClass(PROPERTY_LINK);
		createEAttribute(propertyLinkEClass, PROPERTY_LINK__LINK);
		createEAttribute(propertyLinkEClass, PROPERTY_LINK__SOURCE_PROPERTY);
		createEAttribute(propertyLinkEClass, PROPERTY_LINK__TARGET_PROPERTY);

		documentRootEClass = createEClass(DOCUMENT_ROOT);
		createEAttribute(documentRootEClass, DOCUMENT_ROOT__MIXED);
		createEReference(documentRootEClass, DOCUMENT_ROOT__XMLNS_PREFIX_MAP);
		createEReference(documentRootEClass, DOCUMENT_ROOT__XSI_SCHEMA_LOCATION);
		createEReference(documentRootEClass, DOCUMENT_ROOT__CONCEPTS);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContentsGen() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		CommontypesPackage theCommontypesPackage = (CommontypesPackage) EPackage.Registry.INSTANCE
				.getEPackage(CommontypesPackage.eNS_URI);
		BuiltinsPackage theBuiltinsPackage = (BuiltinsPackage) EPackage.Registry.INSTANCE
				.getEPackage(BuiltinsPackage.eNS_URI);

		// Add supertypes to classes
		codedEntryEClass.getESuperTypes().add(theCommontypesPackage.getVersionableAndDescribable());
		commentEClass.getESuperTypes().add(theCommontypesPackage.getProperty());
		conceptPropertyEClass.getESuperTypes().add(theCommontypesPackage.getProperty());
		definitionEClass.getESuperTypes().add(theCommontypesPackage.getProperty());
		instructionEClass.getESuperTypes().add(theCommontypesPackage.getProperty());
		presentationEClass.getESuperTypes().add(theCommontypesPackage.getProperty());

		// Initialize classes and features; add operations and parameters
		initEClass(codedEntryEClass, CodedEntry.class, "CodedEntry", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCodedEntry_Presentation(), this.getPresentation(), null, "presentation", null, 1, -1,
				CodedEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCodedEntry_Definition(), this.getDefinition(), null, "definition", null, 0, -1,
				CodedEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCodedEntry_Comment(), this.getComment(), null, "comment", null, 0, -1, CodedEntry.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCodedEntry_Instruction(), this.getInstruction(), null, "instruction", null, 0, -1,
				CodedEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCodedEntry_ConceptProperty(), this.getConceptProperty(), null, "conceptProperty", null, 0,
				-1, CodedEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCodedEntry_PropertyLink(), this.getPropertyLink(), null, "propertyLink", null, 0, -1,
				CodedEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCodedEntry_ConceptCode(), theCommontypesPackage.getConceptCode(), "conceptCode", null, 1, 1,
				CodedEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getCodedEntry_ConceptStatus(), theBuiltinsPackage.getLocalId(), "conceptStatus", null, 0, 1,
				CodedEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getCodedEntry_IsActive(), theBuiltinsPackage.getTsBooleanObject(), "isActive", null, 0, 1,
				CodedEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getCodedEntry_IsAnonymous(), theBuiltinsPackage.getTsBooleanObject(), "isAnonymous", null, 0, 1,
				CodedEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(commentEClass, Comment.class, "Comment", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(conceptPropertyEClass, ConceptProperty.class, "ConceptProperty", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(conceptsEClass, Concepts.class, "Concepts", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getConcepts_Concept(), this.getCodedEntry(), null, "concept", null, 1, -1, Concepts.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getConcepts_Dc(), theCommontypesPackage.getDc(), "dc", "concepts", 1, 1, Concepts.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(definitionEClass, Definition.class, "Definition", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDefinition_IsPreferred(), theBuiltinsPackage.getTsBooleanObject(), "isPreferred", null, 0, 1,
				Definition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(instructionEClass, Instruction.class, "Instruction", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(presentationEClass, Presentation.class, "Presentation", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPresentation_DegreeOfFidelity(), theBuiltinsPackage.getLocalId(), "degreeOfFidelity", null,
				0, 1, Presentation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				!IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPresentation_IsPreferred(), theBuiltinsPackage.getTsBooleanObject(), "isPreferred", null, 0,
				1, Presentation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getPresentation_MatchIfNoContext(), theBuiltinsPackage.getTsBooleanObject(), "matchIfNoContext",
				null, 0, 1, Presentation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID,
				!IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPresentation_RepresentationalForm(), theBuiltinsPackage.getLocalId(), "representationalForm",
				null, 0, 1, Presentation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				!IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(propertyLinkEClass, PropertyLink.class, "PropertyLink", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPropertyLink_Link(), theBuiltinsPackage.getLocalId(), "link", null, 1, 1, PropertyLink.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPropertyLink_SourceProperty(), theCommontypesPackage.getPropertyId(), "sourceProperty", null,
				1, 1, PropertyLink.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				!IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPropertyLink_TargetProperty(), theCommontypesPackage.getPropertyId(), "targetProperty", null,
				1, 1, PropertyLink.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				!IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(documentRootEClass, DocumentRoot.class, "DocumentRoot", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDocumentRoot_Mixed(), ecorePackage.getEFeatureMapEntry(), "mixed", null, 0, -1, null,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_XMLNSPrefixMap(), ecorePackage.getEStringToStringMapEntry(), null,
				"xMLNSPrefixMap", null, 0, -1, null, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_XSISchemaLocation(), ecorePackage.getEStringToStringMapEntry(), null,
				"xSISchemaLocation", null, 0, -1, null, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_Concepts(), this.getConcepts(), null, "concepts", null, 0, -2, null,
				IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE,
				IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// null
		createNullAnnotations();
		// http:///org/eclipse/emf/ecore/util/ExtendedMetaData
		createExtendedMetaDataAnnotations();
	}

	/**
	 * Initializes the annotations for <b>null</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createNullAnnotations() {
		String source = null;
		addAnnotation(
				codedEntryEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.5.1.4.1.2114.108.1.7.13</ldap:oid>\r\n\t\t\t\t<ldap:rdn xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">conceptCode</ldap:rdn>\r\n\t\t\t" });
		addAnnotation(
				commentEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.7.5</ldap:oid>\r\n\t\t\t\t<ldap:rdn xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">propertyId</ldap:rdn>\r\n\t\t\t" });
		addAnnotation(
				conceptsEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.7.86</ldap:oid>\r\n\t\t\t\t<ldap:rdn xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">dc</ldap:rdn>\r\n\t\t\t" });
		addAnnotation(
				definitionEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.7.4</ldap:oid>\r\n\t\t\t\t<ldap:rdn xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">propertyId</ldap:rdn>\r\n\t\t\t" });
		addAnnotation(
				instructionEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.7.6</ldap:oid>\r\n\t\t\t\t<ldap:rdn xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">propertyId</ldap:rdn>\r\n\t\t\t" });
		addAnnotation(
				presentationEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.7.7</ldap:oid>\r\n\t\t\t\t<ldap:rdn xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">propertyId</ldap:rdn>\r\n\t\t\t" });
	}

	/**
	 * Initializes the annotations for <b>http:///org/eclipse/emf/ecore/util/ExtendedMetaData</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createExtendedMetaDataAnnotations() {
		String source = "http:///org/eclipse/emf/ecore/util/ExtendedMetaData";
		addAnnotation(codedEntryEClass, source, new String[] { "name", "codedEntry", "kind", "elementOnly" });
		addAnnotation(getCodedEntry_Presentation(), source, new String[] { "kind", "element", "name", "presentation",
				"namespace", "##targetNamespace" });
		addAnnotation(getCodedEntry_Definition(), source, new String[] { "kind", "element", "name", "definition",
				"namespace", "##targetNamespace" });
		addAnnotation(getCodedEntry_Comment(), source, new String[] { "kind", "element", "name", "comment",
				"namespace", "##targetNamespace" });
		addAnnotation(getCodedEntry_Instruction(), source, new String[] { "kind", "element", "name", "instruction",
				"namespace", "##targetNamespace" });
		addAnnotation(getCodedEntry_ConceptProperty(), source, new String[] { "kind", "element", "name",
				"conceptProperty", "namespace", "##targetNamespace" });
		addAnnotation(getCodedEntry_PropertyLink(), source, new String[] { "kind", "element", "name", "propertyLink",
				"namespace", "##targetNamespace" });
		addAnnotation(getCodedEntry_ConceptCode(), source, new String[] { "kind", "attribute", "name", "conceptCode" });
		addAnnotation(getCodedEntry_ConceptStatus(), source, new String[] { "kind", "attribute", "name",
				"conceptStatus" });
		addAnnotation(getCodedEntry_IsActive(), source, new String[] { "kind", "attribute", "name", "isActive" });
		addAnnotation(getCodedEntry_IsAnonymous(), source, new String[] { "kind", "attribute", "name", "isAnonymous" });
		addAnnotation(commentEClass, source, new String[] { "name", "comment", "kind", "elementOnly" });
		addAnnotation(conceptPropertyEClass, source, new String[] { "name", "conceptProperty", "kind", "elementOnly" });
		addAnnotation(conceptsEClass, source, new String[] { "name", "concepts", "kind", "elementOnly" });
		addAnnotation(getConcepts_Concept(), source, new String[] { "kind", "element", "name", "concept", "namespace",
				"##targetNamespace" });
		addAnnotation(getConcepts_Dc(), source, new String[] { "kind", "attribute", "name", "dc" });
		addAnnotation(definitionEClass, source, new String[] { "name", "definition", "kind", "elementOnly" });
		addAnnotation(getDefinition_IsPreferred(), source, new String[] { "kind", "attribute", "name", "isPreferred" });
		addAnnotation(instructionEClass, source, new String[] { "name", "instruction", "kind", "elementOnly" });
		addAnnotation(presentationEClass, source, new String[] { "name", "presentation", "kind", "elementOnly" });
		addAnnotation(getPresentation_DegreeOfFidelity(), source, new String[] { "kind", "attribute", "name",
				"degreeOfFidelity" });
		addAnnotation(getPresentation_IsPreferred(), source,
				new String[] { "kind", "attribute", "name", "isPreferred" });
		addAnnotation(getPresentation_MatchIfNoContext(), source, new String[] { "kind", "attribute", "name",
				"matchIfNoContext" });
		addAnnotation(getPresentation_RepresentationalForm(), source, new String[] { "kind", "attribute", "name",
				"representationalForm" });
		addAnnotation(propertyLinkEClass, source, new String[] { "name", "propertyLink", "kind", "empty" });
		addAnnotation(getPropertyLink_Link(), source, new String[] { "kind", "attribute", "name", "link" });
		addAnnotation(getPropertyLink_SourceProperty(), source, new String[] { "kind", "attribute", "name",
				"sourceProperty" });
		addAnnotation(getPropertyLink_TargetProperty(), source, new String[] { "kind", "attribute", "name",
				"targetProperty" });
		addAnnotation(documentRootEClass, source, new String[] { "name", "", "kind", "mixed" });
		addAnnotation(getDocumentRoot_Mixed(), source, new String[] { "kind", "elementWildcard", "name", ":mixed" });
		addAnnotation(getDocumentRoot_XMLNSPrefixMap(), source, new String[] { "kind", "attribute", "name",
				"xmlns:prefix" });
		addAnnotation(getDocumentRoot_XSISchemaLocation(), source, new String[] { "kind", "attribute", "name",
				"xsi:schemaLocation" });
		addAnnotation(getDocumentRoot_Concepts(), source, new String[] { "kind", "element", "name", "concepts",
				"namespace", "##targetNamespace" });
	}

	////////////////////////////////////////////////////////////
	// ************** BEGIN NON-GENERATED CODE ************** //
	//                                                        //
	// ****************************************************** //
	////////////////////////////////////////////////////////////
	/**
	 * Override superclass to create a LexGrid-aware attribute.
	 * @non-generated
	 */
	protected void createEAttribute(EClass owner, int id) {
		LgAttributeImpl eAttribute = new LgAttributeImpl();
		eAttribute.setFeatureID(id);
		owner.getEStructuralFeatures().add(eAttribute);
	}

	/**
	 * Override superclass to create a LexGrid-aware reference.
	 * @non-generated
	 */
	protected void createEReference(EClass owner, int id) {
		LgReferenceImpl eReference = new LgReferenceImpl();
		eReference.setFeatureID(id);
		owner.getEStructuralFeatures().add(eReference);
	}

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * @non-generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		initializePackageContentsGen();

		((LgAttributeImpl) getCodedEntry_ConceptCode()).setID(true);
		((LgAttributeImpl) getConcepts_Dc()).setID(true);
		((LgAttributeImpl) getConcepts_Dc()).setDefaultValueLiteral("concepts");
		((LgAttributeImpl) getPropertyLink_Link()).setID(true);

		((LgAttributeImpl) getCodedEntry_IsActive()).setDefaultValueLiteral("true");
		((LgAttributeImpl) getDefinition_IsPreferred()).setDefaultValueLiteral("false");
		((LgAttributeImpl) getPresentation_IsPreferred()).setDefaultValueLiteral("false");

		// Ensures order of output in XML ...
		String source = "http:///org/eclipse/emf/mapping/xsd2ecore/XSD2Ecore";
		addAnnotation(codedEntryEClass, source, new String[] { "feature-order",
				"presentation definition comment instruction conceptProperty propertyLink" });
	}
	////////////////////////////////////////////////////////////
	// *************** END NON-GENERATED CODE *************** //
	////////////////////////////////////////////////////////////

} //ConceptsPackageImpl