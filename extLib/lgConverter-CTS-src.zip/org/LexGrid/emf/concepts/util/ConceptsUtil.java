/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.concepts.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.LexGrid.emf.base.LgConstraint;
import org.LexGrid.emf.base.LgModelObj;
import org.LexGrid.emf.base.LgSearchable;
import org.LexGrid.emf.base.impl.LgConstraintImpl;
import org.LexGrid.emf.codingSchemes.CodingSchemeType;
import org.LexGrid.emf.codingSchemes.CodingSchemeVersion;
import org.LexGrid.emf.codingSchemes.CodingSchemesType;
import org.LexGrid.emf.codingSchemes.Versions;
import org.LexGrid.emf.codingSchemes.util.CodingschemesUtil;
import org.LexGrid.emf.concepts.CodedEntry;
import org.LexGrid.emf.concepts.Comment;
import org.LexGrid.emf.concepts.ConceptProperty;
import org.LexGrid.emf.concepts.Concepts;
import org.LexGrid.emf.concepts.ConceptsFactory;
import org.LexGrid.emf.concepts.ConceptsPackage;
import org.LexGrid.emf.concepts.Definition;
import org.LexGrid.emf.concepts.Instruction;
import org.LexGrid.emf.concepts.Presentation;
import org.LexGrid.emf.relations.AssociationInstance;
import org.LexGrid.emf.relations.AssociationTarget;
import org.LexGrid.managedobj.QueryException;
import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.resource.Resource;

/**
 * Common utility class to support concepts and related model objects.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 * @non-generated
 */
public class ConceptsUtil {
    protected final static Logger logger = Logger.getLogger("org.LexGrid.emf.concepts.util.ConceptsUtil");

    private ConceptsUtil() {
		super();
	}
	
    /**
     * Assigns a given property to its matching feature on a CodedEntry.
     * Each property type (comment, definition, intruction, presentation, and
     * generic property) for the coded entry inherits from the Property
     * common type but is contained by a separate feature.  This is a
     * convenience method for simplified assignment of any concept property.
     * 
     * @param concept The coded entry.
     * @param prop The Comment, Definition, Instruction, 
     * @return The coded entry, with the property assigned.
     */
    public static CodedEntry addProperty(CodedEntry concept, org.LexGrid.emf.commonTypes.Property prop) {
    	if (prop instanceof Comment)
    		concept.getComment().add(prop);
    	else if (prop instanceof Definition)
    		concept.getDefinition().add(prop);
    	else if (prop instanceof Instruction)
    		concept.getInstruction().add(prop);
    	else if (prop instanceof Presentation)
    		concept.getPresentation().add(prop);
    	else if (prop instanceof ConceptProperty)
    		concept.getConceptProperty().add(prop);
    	else {
    		ConceptProperty conceptProp = ConceptsFactory.eINSTANCE.createConceptProperty();
    		conceptProp.setLanguage(prop.getLanguage());
    		conceptProp.setPresentationFormat(prop.getPresentationFormat());
    		conceptProp.setProperty(prop.getProperty());
    		conceptProp.setPropertyId(prop.getPropertyId());
    		conceptProp.setText(prop.getText());
    		concept.getConceptProperty().add(prop);
    	}
    	return concept;
    }
    
	/**
	 * Returns the first CodedEntry object matching the given concept code; null if not found.
	 * <p>
	 * The entry is resolved from concepts and versions of the CodingSchemeType implied by the model.
	 * For concepts, this is the containing scheme.  For relation sources and targets, the
	 * assigned source or target code scheme is searched (if specified).
	 * <p>
	 * Versioned entries are considered first, followed by
	 * entries found in the coding scheme primary concept container.
	 * @param model
	 * @param code
	 * @return CodedEntry
	 */
	public static CodedEntry resolveCodedEntry(LgModelObj model, String code) {
		CodingSchemeType scheme = null;
		if (model instanceof CodingSchemeType) {
			scheme = (CodingSchemeType) model;
		} else if (model instanceof AssociationInstance) {
			String schemeName = ((AssociationInstance) model).getSourceCodingScheme();
			if (schemeName != null)
				scheme = CodingschemesUtil.resolveCodingScheme(model, schemeName);
		} else if (model instanceof AssociationTarget) {
			String schemeName = ((AssociationTarget) model).getTargetCodingScheme();
			if (schemeName != null)
				scheme = CodingschemesUtil.resolveCodingScheme(model, schemeName);
		}
		if (scheme == null)
			scheme = (CodingSchemeType) model.getContainer(CodingSchemeType.class, 0);
		return resolveCodedEntryFromScheme(scheme, code);
	}

	/**
	 * Returns the first CodedEntry object matching the given concept code; null if not found.
	 * <p>
	 * Entries are resolved from concepts and versions of the given CodingSchemeType.
	 * Versioned entries are considered first, followed by
	 * entries found in the coding scheme primary concept container.
	 * @param scheme
	 * @param code
	 * @return CodedEntry
	 */
	public static CodedEntry resolveCodedEntryFromScheme(CodingSchemeType scheme, String code) {
		CodedEntry match = null;
		
		// Enough info to continue?
		if (scheme != null && code != null) {
			// Is the scheme accessed as part of a networkable resource?
			// If so, delegate the request ...
			Resource eResource = scheme.eResource();
			if (eResource instanceof LgSearchable) {
				LgConstraintImpl[] constraints = new LgConstraintImpl[] {
					new LgConstraintImpl(ConceptsPackage.eINSTANCE.getCodedEntry_ConceptCode(),
						LgConstraint.RELATION_equals,
						code)
				};
				try {
					Iterator entries = ((LgSearchable) eResource).queryConcepts(scheme, constraints, 1);
					if (entries.hasNext())
						match = (CodedEntry) entries.next();
				} catch (QueryException e) {
					logger.error("Error resolving scheme concept", e);
				}
			}
			else {
				// Scheme is referenced as part of locally maintained content.
				// Check all imbedded concepts for matches.
				// Check primary container first.
				Concepts concepts = scheme.getConcepts();
				if (concepts != null) {
					match = concepts.resolveCodedEntry(code);
					if (match == null) {
						// Check additional containers
						List containers = resolveConcepts(scheme);
						containers.remove(concepts);
						for (Iterator it = containers.iterator(); it.hasNext() && match == null; )
							match = ((Concepts) it.next()).resolveCodedEntry(code);
					}
				}
			}
		}
		return match;
	}
	
	/**
	 * Returns the list of CodedEntry objects matching the given concept code.
	 * <p>
	 * Entries are resolved from concepts and versions of the given CodingSchemeType.
	 * Versioned entries are returned first, followed by
	 * any entries found in the coding scheme primary concept container.
	 * @param scheme
	 * @param code
	 * @return List
	 */
	public static List resolveCodedEntriesFromScheme(CodingSchemeType scheme, String code) {
		List matches = new ArrayList();
		
		// Enough info to continue?
		if (scheme != null && code != null) {
			// Is the scheme accessed as part of a networkable resource?
			// If so, resolve from the network ...
			Resource eResource = scheme.eResource();
			if (eResource instanceof LgSearchable) {
				LgConstraintImpl[] constraints = new LgConstraintImpl[] {
					new LgConstraintImpl(ConceptsPackage.eINSTANCE.getCodedEntry_ConceptCode(),
						LgConstraint.RELATION_equals,
						code)
				};
				try {
					CollectionUtils.addAll(matches, ((LgSearchable) eResource).queryConcepts(scheme, constraints, 0));
				} catch (QueryException e) {
					logger.error("Error resolving scheme concepts", e);
				}
			}
			else {		
				// Check all imbedded concepts for matches.
				// Check more recent versions first.
				CodedEntry match;
				for (Iterator containers = resolveConcepts(scheme).iterator(); containers.hasNext(); )
					if ((match = ((Concepts) containers.next()).resolveCodedEntry(code)) != null)
						matches.add(match);
			}
		}
		return matches;
	}

	/**
	 * Resolve the CodingScheme container for the given concept.
	 * @param concept
	 * @return CodingSchemesType
	 */
	public static CodingSchemeType resolveCodingScheme(CodedEntry concept) {
		return (CodingSchemeType) concept.getContainer(CodingSchemeType.class, 1);
	}

	/**
	 * Resolve the CodingSchemes container for the given concept.
	 * @param concept
	 * @return CodingSchemesType
	 */
	public static CodingSchemesType resolveCodingSchemes(CodedEntry concept) {
		return (CodingSchemesType) concept.getContainer(CodingSchemesType.class, 2);
	}

	/**
	 * Returns the list of Concept containers within the given coding scheme.
	 * <p>
	 * Versioned containers are returned first, followed by
	 * the primary concept container.
	 * @param scheme
	 * @return List
	 */
	public static List resolveConcepts(CodingSchemeType scheme) {
		List items = new ArrayList();
		
		if (scheme != null) {
			Concepts container;
			Versions versions = scheme.getVersions();
			if (versions != null)
				for (Iterator versionEntries = versions.getVersion().iterator(); versionEntries.hasNext(); )
					if ((container = ((CodingSchemeVersion) versionEntries.next()).getConcepts()) != null)
						items.add(container);
					
			if ((container = scheme.getConcepts()) != null)
				items.add(container);
		}
		return items;
	}

	/**
	 * Incorporates a concept within the scheme.
	 * <p>
	 * If an item already exists to match the one provided, nothing is added and the
	 * existing item remains unchanged. If not present, the given item is added
	 * to the scheme's primary concept container.
	 * <p>
	 * Note: The primary concepts container is automatically added to the scheme
	 * if not already present.
	 * @param scheme
	 * @param concept
	 * @return The item as maintained by the container.
	 */
	public static CodedEntry subsume(CodingSchemeType scheme, CodedEntry concept) {
		CodedEntry maintainedItem =
			resolveCodedEntryFromScheme(scheme, concept.getConceptCode());
		if (maintainedItem == null) {
			Concepts container = scheme.getConcepts();
			if (container == null) {
				container = ((ConceptsFactory) ConceptsPackage.eINSTANCE.getEFactoryInstance()).createConcepts();
				container.setDc("concepts");
				scheme.setConcepts(container);
			}
			container.eContents().add(maintainedItem = concept);
		}
		return maintainedItem;
	}
	
	
	/**
	 * Returns the  first matching property object for a concept that matches the given propertyName. Returns null if there is no match.
	 * @param CodedEntry, propertyName
	 * @return property
	 */
	public static ConceptProperty resolveProperty(CodedEntry concept, String propertyName) {
		for (Iterator items= concept.getConceptProperty().iterator(); items.hasNext();) {
			ConceptProperty property= (ConceptProperty) items.next();
			if (property.getProperty().equals(propertyName)) {
				return property;
			}
		}
		return null;
	}		
	
	/**
	 * Returns the  list of property object for a Concept that matches the given propertyName. 
	 * @param CodedEntry, propertyName
	 * @return List of properties
	 */
	public static List resolveProperties(CodedEntry concept, String propertyName) {
		List list = new ArrayList();
		for (Iterator items= concept.getConceptProperty().iterator(); items.hasNext();) {
			ConceptProperty property= (ConceptProperty) items.next();
			if (property.getProperty().equals(propertyName)) {
				list.add(property);
			}
		}
		return list;
	}	
	
	/**
	 * Returns the  synonym presentation object for a concept 
	 * @param CodedEntry
	 * @return List of presentation
	 */
	public static List getNonPreferredPresentation(CodedEntry concept) {
		List list = new ArrayList();
		for (Iterator items= concept.getConceptProperty().iterator(); items.hasNext();) {
			ConceptProperty property= (ConceptProperty) items.next();
			if (property instanceof Presentation) {
				Presentation presentation= (Presentation)property;
				if (!presentation.getIsPreferred().booleanValue()) {
					list.add(presentation);
				}
			}
		}
		return list;
	}	
}