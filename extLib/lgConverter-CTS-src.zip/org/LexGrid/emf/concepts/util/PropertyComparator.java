/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.concepts.util;

import java.util.Comparator;

import org.LexGrid.emf.concepts.Comment;
import org.LexGrid.emf.concepts.Definition;
import org.LexGrid.emf.concepts.Instruction;
import org.LexGrid.emf.concepts.Presentation;

/**
 * Compares property instances to enforce a standard sort order.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 * @non-generated
 */
public class PropertyComparator implements Comparator {
	public static PropertyComparator INSTANCE = new PropertyComparator();

	protected PropertyComparator() {
		super();
	}
	public int compare(Object o1, Object o2) {
		int i = rank(o1) - rank(o2);
		if (i != 0)
			return i;
		i = subrank(o1) - subrank(o2);
		return i != 0 ? i
			: o1.hashCode() - o2.hashCode();
	}
	/**
	 * Order properties according to schema.
	 * @param o
	 * @return int
	 */
	private int rank(Object o) {
		if (o instanceof Presentation) return 0;
		if (o instanceof Definition) return 1;
		if (o instanceof Comment) return 2;
		if (o instanceof Instruction) return 3;
		return 4;
	}
	/**
	 * Bubble preferred representations to the top.
	 * @param o
	 * @return int
	 */
	private int subrank(Object o) {
		if ((o instanceof Presentation
				&& ((Presentation)o).isSetIsPreferred()
				&& ((Presentation)o).getIsPreferred().booleanValue())
		|| (o instanceof Definition
				&& ((Definition)o).isSetIsPreferred()
				&& ((Definition)o).getIsPreferred().booleanValue()))
			return 0;
		return 1;
	}
}