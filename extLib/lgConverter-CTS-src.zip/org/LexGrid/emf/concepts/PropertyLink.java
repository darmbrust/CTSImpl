/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.concepts;

import org.LexGrid.emf.base.LgModelObj;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Property Link</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A link between two properties for a concept.. Examples include acronymFor, abbreviationOf, spellingVariantOf, etc. Must be in
 * 				supportedPropertyLink.
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.LexGrid.emf.concepts.PropertyLink#getLink <em>Link</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.PropertyLink#getSourceProperty <em>Source Property</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.PropertyLink#getTargetProperty <em>Target Property</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.LexGrid.emf.concepts.ConceptsPackage#getPropertyLink()
 * @model extendedMetaData="name='propertyLink' kind='empty'"
 * @extends LgModelObj
 * @generated
 */
public interface PropertyLink extends LgModelObj {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Returns the value of the '<em><b>Link</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The link code.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Link</em>' attribute.
	 * @see #setLink(String)
	 * @see org.LexGrid.emf.concepts.ConceptsPackage#getPropertyLink_Link()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.LocalId" required="true"
	 *        extendedMetaData="kind='attribute' name='link'"
	 * @generated
	 */
	String getLink();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.concepts.PropertyLink#getLink <em>Link</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Link</em>' attribute.
	 * @see #getLink()
	 * @generated
	 */
	void setLink(String value);

	/**
	 * Returns the value of the '<em><b>Source Property</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The first property in the link.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Source Property</em>' attribute.
	 * @see #setSourceProperty(String)
	 * @see org.LexGrid.emf.concepts.ConceptsPackage#getPropertyLink_SourceProperty()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.PropertyId" required="true"
	 *        extendedMetaData="kind='attribute' name='sourceProperty'"
	 * @generated
	 */
	String getSourceProperty();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.concepts.PropertyLink#getSourceProperty <em>Source Property</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source Property</em>' attribute.
	 * @see #getSourceProperty()
	 * @generated
	 */
	void setSourceProperty(String value);

	/**
	 * Returns the value of the '<em><b>Target Property</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The second property in the link.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Target Property</em>' attribute.
	 * @see #setTargetProperty(String)
	 * @see org.LexGrid.emf.concepts.ConceptsPackage#getPropertyLink_TargetProperty()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.PropertyId" required="true"
	 *        extendedMetaData="kind='attribute' name='targetProperty'"
	 * @generated
	 */
	String getTargetProperty();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.concepts.PropertyLink#getTargetProperty <em>Target Property</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target Property</em>' attribute.
	 * @see #getTargetProperty()
	 * @generated
	 */
	void setTargetProperty(String value);

} // PropertyLink