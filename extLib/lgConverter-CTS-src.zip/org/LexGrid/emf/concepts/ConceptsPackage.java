/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.concepts;

import org.LexGrid.emf.commonTypes.CommontypesPackage;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * <!-- begin-model-doc -->
 * 
 * 			<h2 xmlns="http://LexGrid.org/schema/2006/01/LexGrid/builtins">Core data types for the lexical grid.</h2>
 * 		
 * These types need to be mapped to the appropriate implementation specific data types. The mapping in this package represents the XML
 * 			Schema data types mapping
 * LDAP specific types for appinfo annotation
 * Basic builtin types
 * <!-- end-model-doc -->
 * @see org.LexGrid.emf.concepts.ConceptsFactory
 * @model kind="package"
 * @generated
 */
public interface ConceptsPackage extends EPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "concepts";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://LexGrid.org/schema/2006/01/LexGrid/concepts";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "lgCon";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ConceptsPackage eINSTANCE = org.LexGrid.emf.concepts.impl.ConceptsPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.concepts.impl.ConceptsImpl <em>Concepts</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.concepts.impl.ConceptsImpl
	 * @see org.LexGrid.emf.concepts.impl.ConceptsPackageImpl#getConcepts()
	 * @generated
	 */
	int CONCEPTS = 3;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.concepts.impl.CodedEntryImpl <em>Coded Entry</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.concepts.impl.CodedEntryImpl
	 * @see org.LexGrid.emf.concepts.impl.ConceptsPackageImpl#getCodedEntry()
	 * @generated
	 */
	int CODED_ENTRY = 0;

	/**
	 * The feature id for the '<em><b>Deprecated</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODED_ENTRY__DEPRECATED = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE__DEPRECATED;

	/**
	 * The feature id for the '<em><b>First Release</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODED_ENTRY__FIRST_RELEASE = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE__FIRST_RELEASE;

	/**
	 * The feature id for the '<em><b>Modified In Release</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODED_ENTRY__MODIFIED_IN_RELEASE = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE__MODIFIED_IN_RELEASE;

	/**
	 * The feature id for the '<em><b>Entity Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODED_ENTRY__ENTITY_DESCRIPTION = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE__ENTITY_DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Presentation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODED_ENTRY__PRESENTATION = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Definition</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODED_ENTRY__DEFINITION = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Comment</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODED_ENTRY__COMMENT = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Instruction</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODED_ENTRY__INSTRUCTION = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Concept Property</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODED_ENTRY__CONCEPT_PROPERTY = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Property Link</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODED_ENTRY__PROPERTY_LINK = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Concept Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODED_ENTRY__CONCEPT_CODE = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Concept Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODED_ENTRY__CONCEPT_STATUS = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 7;

	/**
	 * The feature id for the '<em><b>Is Active</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODED_ENTRY__IS_ACTIVE = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 8;

	/**
	 * The feature id for the '<em><b>Is Anonymous</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODED_ENTRY__IS_ANONYMOUS = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 9;

	/**
	 * The number of structural features of the '<em>Coded Entry</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODED_ENTRY_FEATURE_COUNT = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 10;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.concepts.impl.PresentationImpl <em>Presentation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.concepts.impl.PresentationImpl
	 * @see org.LexGrid.emf.concepts.impl.ConceptsPackageImpl#getPresentation()
	 * @generated
	 */
	int PRESENTATION = 6;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.concepts.impl.PropertyLinkImpl <em>Property Link</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.concepts.impl.PropertyLinkImpl
	 * @see org.LexGrid.emf.concepts.impl.ConceptsPackageImpl#getPropertyLink()
	 * @generated
	 */
	int PROPERTY_LINK = 7;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.concepts.impl.DefinitionImpl <em>Definition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.concepts.impl.DefinitionImpl
	 * @see org.LexGrid.emf.concepts.impl.ConceptsPackageImpl#getDefinition()
	 * @generated
	 */
	int DEFINITION = 4;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.concepts.impl.CommentImpl <em>Comment</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.concepts.impl.CommentImpl
	 * @see org.LexGrid.emf.concepts.impl.ConceptsPackageImpl#getComment()
	 * @generated
	 */
	int COMMENT = 1;

	/**
	 * The feature id for the '<em><b>Source</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMENT__SOURCE = CommontypesPackage.PROPERTY__SOURCE;

	/**
	 * The feature id for the '<em><b>Usage Context</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMENT__USAGE_CONTEXT = CommontypesPackage.PROPERTY__USAGE_CONTEXT;

	/**
	 * The feature id for the '<em><b>Property Qualifier</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMENT__PROPERTY_QUALIFIER = CommontypesPackage.PROPERTY__PROPERTY_QUALIFIER;

	/**
	 * The feature id for the '<em><b>Text</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMENT__TEXT = CommontypesPackage.PROPERTY__TEXT;

	/**
	 * The feature id for the '<em><b>Language</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMENT__LANGUAGE = CommontypesPackage.PROPERTY__LANGUAGE;

	/**
	 * The feature id for the '<em><b>Presentation Format</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMENT__PRESENTATION_FORMAT = CommontypesPackage.PROPERTY__PRESENTATION_FORMAT;

	/**
	 * The feature id for the '<em><b>Property</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMENT__PROPERTY = CommontypesPackage.PROPERTY__PROPERTY;

	/**
	 * The feature id for the '<em><b>Property Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMENT__PROPERTY_ID = CommontypesPackage.PROPERTY__PROPERTY_ID;

	/**
	 * The number of structural features of the '<em>Comment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMENT_FEATURE_COUNT = CommontypesPackage.PROPERTY_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.concepts.impl.ConceptPropertyImpl <em>Concept Property</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.concepts.impl.ConceptPropertyImpl
	 * @see org.LexGrid.emf.concepts.impl.ConceptsPackageImpl#getConceptProperty()
	 * @generated
	 */
	int CONCEPT_PROPERTY = 2;

	/**
	 * The feature id for the '<em><b>Source</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCEPT_PROPERTY__SOURCE = CommontypesPackage.PROPERTY__SOURCE;

	/**
	 * The feature id for the '<em><b>Usage Context</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCEPT_PROPERTY__USAGE_CONTEXT = CommontypesPackage.PROPERTY__USAGE_CONTEXT;

	/**
	 * The feature id for the '<em><b>Property Qualifier</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCEPT_PROPERTY__PROPERTY_QUALIFIER = CommontypesPackage.PROPERTY__PROPERTY_QUALIFIER;

	/**
	 * The feature id for the '<em><b>Text</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCEPT_PROPERTY__TEXT = CommontypesPackage.PROPERTY__TEXT;

	/**
	 * The feature id for the '<em><b>Language</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCEPT_PROPERTY__LANGUAGE = CommontypesPackage.PROPERTY__LANGUAGE;

	/**
	 * The feature id for the '<em><b>Presentation Format</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCEPT_PROPERTY__PRESENTATION_FORMAT = CommontypesPackage.PROPERTY__PRESENTATION_FORMAT;

	/**
	 * The feature id for the '<em><b>Property</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCEPT_PROPERTY__PROPERTY = CommontypesPackage.PROPERTY__PROPERTY;

	/**
	 * The feature id for the '<em><b>Property Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCEPT_PROPERTY__PROPERTY_ID = CommontypesPackage.PROPERTY__PROPERTY_ID;

	/**
	 * The number of structural features of the '<em>Concept Property</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCEPT_PROPERTY_FEATURE_COUNT = CommontypesPackage.PROPERTY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Concept</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCEPTS__CONCEPT = 0;

	/**
	 * The feature id for the '<em><b>Dc</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCEPTS__DC = 1;

	/**
	 * The number of structural features of the '<em>Concepts</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCEPTS_FEATURE_COUNT = 2;

	/**
	 * The feature id for the '<em><b>Source</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEFINITION__SOURCE = CommontypesPackage.PROPERTY__SOURCE;

	/**
	 * The feature id for the '<em><b>Usage Context</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEFINITION__USAGE_CONTEXT = CommontypesPackage.PROPERTY__USAGE_CONTEXT;

	/**
	 * The feature id for the '<em><b>Property Qualifier</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEFINITION__PROPERTY_QUALIFIER = CommontypesPackage.PROPERTY__PROPERTY_QUALIFIER;

	/**
	 * The feature id for the '<em><b>Text</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEFINITION__TEXT = CommontypesPackage.PROPERTY__TEXT;

	/**
	 * The feature id for the '<em><b>Language</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEFINITION__LANGUAGE = CommontypesPackage.PROPERTY__LANGUAGE;

	/**
	 * The feature id for the '<em><b>Presentation Format</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEFINITION__PRESENTATION_FORMAT = CommontypesPackage.PROPERTY__PRESENTATION_FORMAT;

	/**
	 * The feature id for the '<em><b>Property</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEFINITION__PROPERTY = CommontypesPackage.PROPERTY__PROPERTY;

	/**
	 * The feature id for the '<em><b>Property Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEFINITION__PROPERTY_ID = CommontypesPackage.PROPERTY__PROPERTY_ID;

	/**
	 * The feature id for the '<em><b>Is Preferred</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEFINITION__IS_PREFERRED = CommontypesPackage.PROPERTY_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Definition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEFINITION_FEATURE_COUNT = CommontypesPackage.PROPERTY_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.concepts.impl.InstructionImpl <em>Instruction</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.concepts.impl.InstructionImpl
	 * @see org.LexGrid.emf.concepts.impl.ConceptsPackageImpl#getInstruction()
	 * @generated
	 */
	int INSTRUCTION = 5;

	/**
	 * The feature id for the '<em><b>Source</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTRUCTION__SOURCE = CommontypesPackage.PROPERTY__SOURCE;

	/**
	 * The feature id for the '<em><b>Usage Context</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTRUCTION__USAGE_CONTEXT = CommontypesPackage.PROPERTY__USAGE_CONTEXT;

	/**
	 * The feature id for the '<em><b>Property Qualifier</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTRUCTION__PROPERTY_QUALIFIER = CommontypesPackage.PROPERTY__PROPERTY_QUALIFIER;

	/**
	 * The feature id for the '<em><b>Text</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTRUCTION__TEXT = CommontypesPackage.PROPERTY__TEXT;

	/**
	 * The feature id for the '<em><b>Language</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTRUCTION__LANGUAGE = CommontypesPackage.PROPERTY__LANGUAGE;

	/**
	 * The feature id for the '<em><b>Presentation Format</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTRUCTION__PRESENTATION_FORMAT = CommontypesPackage.PROPERTY__PRESENTATION_FORMAT;

	/**
	 * The feature id for the '<em><b>Property</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTRUCTION__PROPERTY = CommontypesPackage.PROPERTY__PROPERTY;

	/**
	 * The feature id for the '<em><b>Property Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTRUCTION__PROPERTY_ID = CommontypesPackage.PROPERTY__PROPERTY_ID;

	/**
	 * The number of structural features of the '<em>Instruction</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTRUCTION_FEATURE_COUNT = CommontypesPackage.PROPERTY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Source</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRESENTATION__SOURCE = CommontypesPackage.PROPERTY__SOURCE;

	/**
	 * The feature id for the '<em><b>Usage Context</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRESENTATION__USAGE_CONTEXT = CommontypesPackage.PROPERTY__USAGE_CONTEXT;

	/**
	 * The feature id for the '<em><b>Property Qualifier</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRESENTATION__PROPERTY_QUALIFIER = CommontypesPackage.PROPERTY__PROPERTY_QUALIFIER;

	/**
	 * The feature id for the '<em><b>Text</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRESENTATION__TEXT = CommontypesPackage.PROPERTY__TEXT;

	/**
	 * The feature id for the '<em><b>Language</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRESENTATION__LANGUAGE = CommontypesPackage.PROPERTY__LANGUAGE;

	/**
	 * The feature id for the '<em><b>Presentation Format</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRESENTATION__PRESENTATION_FORMAT = CommontypesPackage.PROPERTY__PRESENTATION_FORMAT;

	/**
	 * The feature id for the '<em><b>Property</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRESENTATION__PROPERTY = CommontypesPackage.PROPERTY__PROPERTY;

	/**
	 * The feature id for the '<em><b>Property Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRESENTATION__PROPERTY_ID = CommontypesPackage.PROPERTY__PROPERTY_ID;

	/**
	 * The feature id for the '<em><b>Degree Of Fidelity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRESENTATION__DEGREE_OF_FIDELITY = CommontypesPackage.PROPERTY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Is Preferred</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRESENTATION__IS_PREFERRED = CommontypesPackage.PROPERTY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Match If No Context</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRESENTATION__MATCH_IF_NO_CONTEXT = CommontypesPackage.PROPERTY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Representational Form</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRESENTATION__REPRESENTATIONAL_FORM = CommontypesPackage.PROPERTY_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Presentation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRESENTATION_FEATURE_COUNT = CommontypesPackage.PROPERTY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Link</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY_LINK__LINK = 0;

	/**
	 * The feature id for the '<em><b>Source Property</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY_LINK__SOURCE_PROPERTY = 1;

	/**
	 * The feature id for the '<em><b>Target Property</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY_LINK__TARGET_PROPERTY = 2;

	/**
	 * The number of structural features of the '<em>Property Link</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY_LINK_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.concepts.impl.DocumentRootImpl <em>Document Root</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.concepts.impl.DocumentRootImpl
	 * @see org.LexGrid.emf.concepts.impl.ConceptsPackageImpl#getDocumentRoot()
	 * @generated
	 */
	int DOCUMENT_ROOT = 8;

	/**
	 * The feature id for the '<em><b>Mixed</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__MIXED = 0;

	/**
	 * The feature id for the '<em><b>XMLNS Prefix Map</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__XMLNS_PREFIX_MAP = 1;

	/**
	 * The feature id for the '<em><b>XSI Schema Location</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = 2;

	/**
	 * The feature id for the '<em><b>Concepts</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__CONCEPTS = 3;

	/**
	 * The number of structural features of the '<em>Document Root</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT_FEATURE_COUNT = 4;

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.concepts.Concepts <em>Concepts</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Concepts</em>'.
	 * @see org.LexGrid.emf.concepts.Concepts
	 * @generated
	 */
	EClass getConcepts();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.concepts.Concepts#getDc <em>Dc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Dc</em>'.
	 * @see org.LexGrid.emf.concepts.Concepts#getDc()
	 * @see #getConcepts()
	 * @generated
	 */
	EAttribute getConcepts_Dc();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.concepts.Concepts#getConcept <em>Concept</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Concept</em>'.
	 * @see org.LexGrid.emf.concepts.Concepts#getConcept()
	 * @see #getConcepts()
	 * @generated
	 */
	EReference getConcepts_Concept();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.concepts.CodedEntry <em>Coded Entry</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Coded Entry</em>'.
	 * @see org.LexGrid.emf.concepts.CodedEntry
	 * @generated
	 */
	EClass getCodedEntry();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.concepts.CodedEntry#getPresentation <em>Presentation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Presentation</em>'.
	 * @see org.LexGrid.emf.concepts.CodedEntry#getPresentation()
	 * @see #getCodedEntry()
	 * @generated
	 */
	EReference getCodedEntry_Presentation();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.concepts.CodedEntry#getDefinition <em>Definition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Definition</em>'.
	 * @see org.LexGrid.emf.concepts.CodedEntry#getDefinition()
	 * @see #getCodedEntry()
	 * @generated
	 */
	EReference getCodedEntry_Definition();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.concepts.CodedEntry#getComment <em>Comment</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Comment</em>'.
	 * @see org.LexGrid.emf.concepts.CodedEntry#getComment()
	 * @see #getCodedEntry()
	 * @generated
	 */
	EReference getCodedEntry_Comment();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.concepts.CodedEntry#getInstruction <em>Instruction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Instruction</em>'.
	 * @see org.LexGrid.emf.concepts.CodedEntry#getInstruction()
	 * @see #getCodedEntry()
	 * @generated
	 */
	EReference getCodedEntry_Instruction();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.concepts.CodedEntry#getConceptProperty <em>Concept Property</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Concept Property</em>'.
	 * @see org.LexGrid.emf.concepts.CodedEntry#getConceptProperty()
	 * @see #getCodedEntry()
	 * @generated
	 */
	EReference getCodedEntry_ConceptProperty();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.concepts.CodedEntry#getConceptCode <em>Concept Code</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Concept Code</em>'.
	 * @see org.LexGrid.emf.concepts.CodedEntry#getConceptCode()
	 * @see #getCodedEntry()
	 * @generated
	 */
	EAttribute getCodedEntry_ConceptCode();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.concepts.CodedEntry#getIsActive <em>Is Active</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Active</em>'.
	 * @see org.LexGrid.emf.concepts.CodedEntry#getIsActive()
	 * @see #getCodedEntry()
	 * @generated
	 */
	EAttribute getCodedEntry_IsActive();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.concepts.CodedEntry#getConceptStatus <em>Concept Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Concept Status</em>'.
	 * @see org.LexGrid.emf.concepts.CodedEntry#getConceptStatus()
	 * @see #getCodedEntry()
	 * @generated
	 */
	EAttribute getCodedEntry_ConceptStatus();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.concepts.CodedEntry#getIsAnonymous <em>Is Anonymous</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Anonymous</em>'.
	 * @see org.LexGrid.emf.concepts.CodedEntry#getIsAnonymous()
	 * @see #getCodedEntry()
	 * @generated
	 */
	EAttribute getCodedEntry_IsAnonymous();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.concepts.CodedEntry#getPropertyLink <em>Property Link</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Property Link</em>'.
	 * @see org.LexGrid.emf.concepts.CodedEntry#getPropertyLink()
	 * @see #getCodedEntry()
	 * @generated
	 */
	EReference getCodedEntry_PropertyLink();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.concepts.Presentation <em>Presentation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Presentation</em>'.
	 * @see org.LexGrid.emf.concepts.Presentation
	 * @generated
	 */
	EClass getPresentation();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.concepts.Presentation#getIsPreferred <em>Is Preferred</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Preferred</em>'.
	 * @see org.LexGrid.emf.concepts.Presentation#getIsPreferred()
	 * @see #getPresentation()
	 * @generated
	 */
	EAttribute getPresentation_IsPreferred();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.concepts.Presentation#getDegreeOfFidelity <em>Degree Of Fidelity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Degree Of Fidelity</em>'.
	 * @see org.LexGrid.emf.concepts.Presentation#getDegreeOfFidelity()
	 * @see #getPresentation()
	 * @generated
	 */
	EAttribute getPresentation_DegreeOfFidelity();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.concepts.Presentation#getMatchIfNoContext <em>Match If No Context</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Match If No Context</em>'.
	 * @see org.LexGrid.emf.concepts.Presentation#getMatchIfNoContext()
	 * @see #getPresentation()
	 * @generated
	 */
	EAttribute getPresentation_MatchIfNoContext();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.concepts.Presentation#getRepresentationalForm <em>Representational Form</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Representational Form</em>'.
	 * @see org.LexGrid.emf.concepts.Presentation#getRepresentationalForm()
	 * @see #getPresentation()
	 * @generated
	 */
	EAttribute getPresentation_RepresentationalForm();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.concepts.PropertyLink <em>Property Link</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Property Link</em>'.
	 * @see org.LexGrid.emf.concepts.PropertyLink
	 * @generated
	 */
	EClass getPropertyLink();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.concepts.PropertyLink#getLink <em>Link</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Link</em>'.
	 * @see org.LexGrid.emf.concepts.PropertyLink#getLink()
	 * @see #getPropertyLink()
	 * @generated
	 */
	EAttribute getPropertyLink_Link();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.concepts.PropertyLink#getSourceProperty <em>Source Property</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Source Property</em>'.
	 * @see org.LexGrid.emf.concepts.PropertyLink#getSourceProperty()
	 * @see #getPropertyLink()
	 * @generated
	 */
	EAttribute getPropertyLink_SourceProperty();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.concepts.PropertyLink#getTargetProperty <em>Target Property</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Target Property</em>'.
	 * @see org.LexGrid.emf.concepts.PropertyLink#getTargetProperty()
	 * @see #getPropertyLink()
	 * @generated
	 */
	EAttribute getPropertyLink_TargetProperty();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.concepts.DocumentRoot <em>Document Root</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Document Root</em>'.
	 * @see org.LexGrid.emf.concepts.DocumentRoot
	 * @generated
	 */
	EClass getDocumentRoot();

	/**
	 * Returns the meta object for the attribute list '{@link org.LexGrid.emf.concepts.DocumentRoot#getMixed <em>Mixed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Mixed</em>'.
	 * @see org.LexGrid.emf.concepts.DocumentRoot#getMixed()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EAttribute getDocumentRoot_Mixed();

	/**
	 * Returns the meta object for the map '{@link org.LexGrid.emf.concepts.DocumentRoot#getXMLNSPrefixMap <em>XMLNS Prefix Map</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>XMLNS Prefix Map</em>'.
	 * @see org.LexGrid.emf.concepts.DocumentRoot#getXMLNSPrefixMap()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_XMLNSPrefixMap();

	/**
	 * Returns the meta object for the map '{@link org.LexGrid.emf.concepts.DocumentRoot#getXSISchemaLocation <em>XSI Schema Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>XSI Schema Location</em>'.
	 * @see org.LexGrid.emf.concepts.DocumentRoot#getXSISchemaLocation()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_XSISchemaLocation();

	/**
	 * Returns the meta object for the containment reference '{@link org.LexGrid.emf.concepts.DocumentRoot#getConcepts <em>Concepts</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Concepts</em>'.
	 * @see org.LexGrid.emf.concepts.DocumentRoot#getConcepts()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_Concepts();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.concepts.Definition <em>Definition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Definition</em>'.
	 * @see org.LexGrid.emf.concepts.Definition
	 * @generated
	 */
	EClass getDefinition();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.concepts.Definition#getIsPreferred <em>Is Preferred</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Preferred</em>'.
	 * @see org.LexGrid.emf.concepts.Definition#getIsPreferred()
	 * @see #getDefinition()
	 * @generated
	 */
	EAttribute getDefinition_IsPreferred();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.concepts.Comment <em>Comment</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Comment</em>'.
	 * @see org.LexGrid.emf.concepts.Comment
	 * @generated
	 */
	EClass getComment();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.concepts.ConceptProperty <em>Concept Property</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Concept Property</em>'.
	 * @see org.LexGrid.emf.concepts.ConceptProperty
	 * @generated
	 */
	EClass getConceptProperty();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.concepts.Instruction <em>Instruction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Instruction</em>'.
	 * @see org.LexGrid.emf.concepts.Instruction
	 * @generated
	 */
	EClass getInstruction();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	ConceptsFactory getConceptsFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.concepts.impl.CodedEntryImpl <em>Coded Entry</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.concepts.impl.CodedEntryImpl
		 * @see org.LexGrid.emf.concepts.impl.ConceptsPackageImpl#getCodedEntry()
		 * @generated
		 */
		EClass CODED_ENTRY = eINSTANCE.getCodedEntry();

		/**
		 * The meta object literal for the '<em><b>Presentation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CODED_ENTRY__PRESENTATION = eINSTANCE.getCodedEntry_Presentation();

		/**
		 * The meta object literal for the '<em><b>Definition</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CODED_ENTRY__DEFINITION = eINSTANCE.getCodedEntry_Definition();

		/**
		 * The meta object literal for the '<em><b>Comment</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CODED_ENTRY__COMMENT = eINSTANCE.getCodedEntry_Comment();

		/**
		 * The meta object literal for the '<em><b>Instruction</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CODED_ENTRY__INSTRUCTION = eINSTANCE.getCodedEntry_Instruction();

		/**
		 * The meta object literal for the '<em><b>Concept Property</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CODED_ENTRY__CONCEPT_PROPERTY = eINSTANCE.getCodedEntry_ConceptProperty();

		/**
		 * The meta object literal for the '<em><b>Property Link</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CODED_ENTRY__PROPERTY_LINK = eINSTANCE.getCodedEntry_PropertyLink();

		/**
		 * The meta object literal for the '<em><b>Concept Code</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CODED_ENTRY__CONCEPT_CODE = eINSTANCE.getCodedEntry_ConceptCode();

		/**
		 * The meta object literal for the '<em><b>Concept Status</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CODED_ENTRY__CONCEPT_STATUS = eINSTANCE.getCodedEntry_ConceptStatus();

		/**
		 * The meta object literal for the '<em><b>Is Active</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CODED_ENTRY__IS_ACTIVE = eINSTANCE.getCodedEntry_IsActive();

		/**
		 * The meta object literal for the '<em><b>Is Anonymous</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CODED_ENTRY__IS_ANONYMOUS = eINSTANCE.getCodedEntry_IsAnonymous();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.concepts.impl.CommentImpl <em>Comment</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.concepts.impl.CommentImpl
		 * @see org.LexGrid.emf.concepts.impl.ConceptsPackageImpl#getComment()
		 * @generated
		 */
		EClass COMMENT = eINSTANCE.getComment();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.concepts.impl.ConceptPropertyImpl <em>Concept Property</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.concepts.impl.ConceptPropertyImpl
		 * @see org.LexGrid.emf.concepts.impl.ConceptsPackageImpl#getConceptProperty()
		 * @generated
		 */
		EClass CONCEPT_PROPERTY = eINSTANCE.getConceptProperty();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.concepts.impl.ConceptsImpl <em>Concepts</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.concepts.impl.ConceptsImpl
		 * @see org.LexGrid.emf.concepts.impl.ConceptsPackageImpl#getConcepts()
		 * @generated
		 */
		EClass CONCEPTS = eINSTANCE.getConcepts();

		/**
		 * The meta object literal for the '<em><b>Concept</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONCEPTS__CONCEPT = eINSTANCE.getConcepts_Concept();

		/**
		 * The meta object literal for the '<em><b>Dc</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONCEPTS__DC = eINSTANCE.getConcepts_Dc();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.concepts.impl.DefinitionImpl <em>Definition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.concepts.impl.DefinitionImpl
		 * @see org.LexGrid.emf.concepts.impl.ConceptsPackageImpl#getDefinition()
		 * @generated
		 */
		EClass DEFINITION = eINSTANCE.getDefinition();

		/**
		 * The meta object literal for the '<em><b>Is Preferred</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DEFINITION__IS_PREFERRED = eINSTANCE.getDefinition_IsPreferred();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.concepts.impl.InstructionImpl <em>Instruction</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.concepts.impl.InstructionImpl
		 * @see org.LexGrid.emf.concepts.impl.ConceptsPackageImpl#getInstruction()
		 * @generated
		 */
		EClass INSTRUCTION = eINSTANCE.getInstruction();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.concepts.impl.PresentationImpl <em>Presentation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.concepts.impl.PresentationImpl
		 * @see org.LexGrid.emf.concepts.impl.ConceptsPackageImpl#getPresentation()
		 * @generated
		 */
		EClass PRESENTATION = eINSTANCE.getPresentation();

		/**
		 * The meta object literal for the '<em><b>Degree Of Fidelity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRESENTATION__DEGREE_OF_FIDELITY = eINSTANCE.getPresentation_DegreeOfFidelity();

		/**
		 * The meta object literal for the '<em><b>Is Preferred</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRESENTATION__IS_PREFERRED = eINSTANCE.getPresentation_IsPreferred();

		/**
		 * The meta object literal for the '<em><b>Match If No Context</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRESENTATION__MATCH_IF_NO_CONTEXT = eINSTANCE.getPresentation_MatchIfNoContext();

		/**
		 * The meta object literal for the '<em><b>Representational Form</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRESENTATION__REPRESENTATIONAL_FORM = eINSTANCE.getPresentation_RepresentationalForm();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.concepts.impl.PropertyLinkImpl <em>Property Link</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.concepts.impl.PropertyLinkImpl
		 * @see org.LexGrid.emf.concepts.impl.ConceptsPackageImpl#getPropertyLink()
		 * @generated
		 */
		EClass PROPERTY_LINK = eINSTANCE.getPropertyLink();

		/**
		 * The meta object literal for the '<em><b>Link</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROPERTY_LINK__LINK = eINSTANCE.getPropertyLink_Link();

		/**
		 * The meta object literal for the '<em><b>Source Property</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROPERTY_LINK__SOURCE_PROPERTY = eINSTANCE.getPropertyLink_SourceProperty();

		/**
		 * The meta object literal for the '<em><b>Target Property</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROPERTY_LINK__TARGET_PROPERTY = eINSTANCE.getPropertyLink_TargetProperty();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.concepts.impl.DocumentRootImpl <em>Document Root</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.concepts.impl.DocumentRootImpl
		 * @see org.LexGrid.emf.concepts.impl.ConceptsPackageImpl#getDocumentRoot()
		 * @generated
		 */
		EClass DOCUMENT_ROOT = eINSTANCE.getDocumentRoot();

		/**
		 * The meta object literal for the '<em><b>Mixed</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCUMENT_ROOT__MIXED = eINSTANCE.getDocumentRoot_Mixed();

		/**
		 * The meta object literal for the '<em><b>XMLNS Prefix Map</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__XMLNS_PREFIX_MAP = eINSTANCE.getDocumentRoot_XMLNSPrefixMap();

		/**
		 * The meta object literal for the '<em><b>XSI Schema Location</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = eINSTANCE.getDocumentRoot_XSISchemaLocation();

		/**
		 * The meta object literal for the '<em><b>Concepts</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__CONCEPTS = eINSTANCE.getDocumentRoot_Concepts();

	}

} //ConceptsPackage