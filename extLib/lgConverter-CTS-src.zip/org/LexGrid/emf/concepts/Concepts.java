/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.concepts;

import java.util.List;

import org.LexGrid.emf.base.LgModelObj;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Concepts</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A directory of coded entries in a coding scheme.
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.LexGrid.emf.concepts.Concepts#getConcept <em>Concept</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.Concepts#getDc <em>Dc</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.LexGrid.emf.concepts.ConceptsPackage#getConcepts()
 * @model extendedMetaData="name='concepts' kind='elementOnly'"
 * @extends LgModelObj
 * @generated
 */
public interface Concepts extends LgModelObj {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Returns the value of the '<em><b>Dc</b></em>' attribute.
	 * The default value is <code>"concepts"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Dc</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The context identifier for this directory.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Dc</em>' attribute.
	 * @see #isSetDc()
	 * @see #unsetDc()
	 * @see #setDc(String)
	 * @see org.LexGrid.emf.concepts.ConceptsPackage#getConcepts_Dc()
	 * @model default="concepts" unique="false" unsettable="true" dataType="org.LexGrid.emf.commonTypes.Dc" required="true"
	 *        extendedMetaData="kind='attribute' name='dc'"
	 * @generated
	 */
	String getDc();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.concepts.Concepts#getDc <em>Dc</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Dc</em>' attribute.
	 * @see #isSetDc()
	 * @see #unsetDc()
	 * @see #getDc()
	 * @generated
	 */
	void setDc(String value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.concepts.Concepts#getDc <em>Dc</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetDc()
	 * @see #getDc()
	 * @see #setDc(String)
	 * @generated
	 */
	void unsetDc();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.concepts.Concepts#getDc <em>Dc</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Dc</em>' attribute is set.
	 * @see #unsetDc()
	 * @see #getDc()
	 * @see #setDc(String)
	 * @generated
	 */
	boolean isSetDc();

	/**
	 * Returns the value of the '<em><b>Concept</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.concepts.CodedEntry}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The list of contained concepts.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Concept</em>' containment reference list.
	 * @see org.LexGrid.emf.concepts.ConceptsPackage#getConcepts_Concept()
	 * @model type="org.LexGrid.emf.concepts.CodedEntry" containment="true" required="true"
	 *        extendedMetaData="kind='element' name='concept' namespace='##targetNamespace'"
	 * @generated
	 */
	List getConcept();

	////////////////////////////////////////////////////////////
	// ************** BEGIN NON-GENERATED CODE ************** //
	//                                                        //
	// ****************************************************** //
	////////////////////////////////////////////////////////////

	/**
	 * Returns a contained CodedEntry matching the given concept code;
	 * null if not available.
	 * <p>
	 * Note: If more than one concept exists for the given criteria,
	 * the one selected and returned is implementation-specific.
	 * @param code The concept code to match; not null.
	 * @return CodedEntry
	 * @non-generated
	 */
	CodedEntry resolveCodedEntry(String code);

} // Concepts