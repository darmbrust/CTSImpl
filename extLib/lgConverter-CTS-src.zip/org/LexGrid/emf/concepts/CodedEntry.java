/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.concepts;

import java.util.List;

import org.LexGrid.emf.base.LgCodedObj;
import org.LexGrid.emf.commonTypes.VersionableAndDescribable;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Coded Entry</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A concept code within a coding scheme or a coding scheme version.
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.LexGrid.emf.concepts.CodedEntry#getPresentation <em>Presentation</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.CodedEntry#getDefinition <em>Definition</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.CodedEntry#getComment <em>Comment</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.CodedEntry#getInstruction <em>Instruction</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.CodedEntry#getConceptProperty <em>Concept Property</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.CodedEntry#getPropertyLink <em>Property Link</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.CodedEntry#getConceptCode <em>Concept Code</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.CodedEntry#getConceptStatus <em>Concept Status</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.CodedEntry#getIsActive <em>Is Active</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.CodedEntry#getIsAnonymous <em>Is Anonymous</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.LexGrid.emf.concepts.ConceptsPackage#getCodedEntry()
 * @model extendedMetaData="name='codedEntry' kind='elementOnly'"
 * @generated
 */
public interface CodedEntry extends VersionableAndDescribable, LgCodedObj {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Returns the value of the '<em><b>Presentation</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.concepts.Presentation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Representation of designation of the concept code.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Presentation</em>' containment reference list.
	 * @see org.LexGrid.emf.concepts.ConceptsPackage#getCodedEntry_Presentation()
	 * @model type="org.LexGrid.emf.concepts.Presentation" containment="true" required="true"
	 *        extendedMetaData="kind='element' name='presentation' namespace='##targetNamespace'"
	 * @generated
	 */
	List getPresentation();

	/**
	 * Returns the value of the '<em><b>Definition</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.concepts.Definition}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Definition or description of the intent of the concept code.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Definition</em>' containment reference list.
	 * @see org.LexGrid.emf.concepts.ConceptsPackage#getCodedEntry_Definition()
	 * @model type="org.LexGrid.emf.concepts.Definition" containment="true"
	 *        extendedMetaData="kind='element' name='definition' namespace='##targetNamespace'"
	 * @generated
	 */
	List getDefinition();

	/**
	 * Returns the value of the '<em><b>Comment</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.concepts.Comment}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Annotation or other note about the state or usage of the concept code.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Comment</em>' containment reference list.
	 * @see org.LexGrid.emf.concepts.ConceptsPackage#getCodedEntry_Comment()
	 * @model type="org.LexGrid.emf.concepts.Comment" containment="true"
	 *        extendedMetaData="kind='element' name='comment' namespace='##targetNamespace'"
	 * @generated
	 */
	List getComment();

	/**
	 * Returns the value of the '<em><b>Instruction</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.concepts.Instruction}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Formal or semi-formal notes about when or how to use the concept code.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Instruction</em>' containment reference list.
	 * @see org.LexGrid.emf.concepts.ConceptsPackage#getCodedEntry_Instruction()
	 * @model type="org.LexGrid.emf.concepts.Instruction" containment="true"
	 *        extendedMetaData="kind='element' name='instruction' namespace='##targetNamespace'"
	 * @generated
	 */
	List getInstruction();

	/**
	 * Returns the value of the '<em><b>Concept Property</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.concepts.ConceptProperty}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Uncategorized properties that further identify or describe the concept code.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Concept Property</em>' containment reference list.
	 * @see org.LexGrid.emf.concepts.ConceptsPackage#getCodedEntry_ConceptProperty()
	 * @model type="org.LexGrid.emf.concepts.ConceptProperty" containment="true"
	 *        extendedMetaData="kind='element' name='conceptProperty' namespace='##targetNamespace'"
	 * @generated
	 */
	List getConceptProperty();

	/**
	 * Returns the value of the '<em><b>Concept Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Unique concept code within coding system.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Concept Code</em>' attribute.
	 * @see #setConceptCode(String)
	 * @see org.LexGrid.emf.concepts.ConceptsPackage#getCodedEntry_ConceptCode()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.ConceptCode" required="true"
	 *        extendedMetaData="kind='attribute' name='conceptCode'"
	 * @generated
	 */
	String getConceptCode();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.concepts.CodedEntry#getConceptCode <em>Concept Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Concept Code</em>' attribute.
	 * @see #getConceptCode()
	 * @generated
	 */
	void setConceptCode(String value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.concepts.CodedEntry#getIsActive <em>Is Active</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsActive()
	 * @see #getIsActive()
	 * @see #setIsActive(Boolean)
	 * @generated
	 */
	void unsetIsActive();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.concepts.CodedEntry#getIsActive <em>Is Active</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Active</em>' attribute is set.
	 * @see #unsetIsActive()
	 * @see #getIsActive()
	 * @see #setIsActive(Boolean)
	 * @generated
	 */
	boolean isSetIsActive();

	/**
	 * Returns the value of the '<em><b>Is Anonymous</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * TRUE means that this node doesn't have an actual code in the code system.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Is Anonymous</em>' attribute.
	 * @see #isSetIsAnonymous()
	 * @see #unsetIsAnonymous()
	 * @see #setIsAnonymous(Boolean)
	 * @see org.LexGrid.emf.concepts.ConceptsPackage#getCodedEntry_IsAnonymous()
	 * @model unique="false" unsettable="true" dataType="org.LexGrid.emf.builtins.TsBooleanObject"
	 *        extendedMetaData="kind='attribute' name='isAnonymous'"
	 * @generated
	 */
	Boolean getIsAnonymous();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.concepts.CodedEntry#getIsAnonymous <em>Is Anonymous</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Anonymous</em>' attribute.
	 * @see #isSetIsAnonymous()
	 * @see #unsetIsAnonymous()
	 * @see #getIsAnonymous()
	 * @generated
	 */
	void setIsAnonymous(Boolean value);

	/**
	 * Returns the value of the '<em><b>Concept Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Current status of the concept. Must be in supportedConceptStatus.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Concept Status</em>' attribute.
	 * @see #setConceptStatus(String)
	 * @see org.LexGrid.emf.concepts.ConceptsPackage#getCodedEntry_ConceptStatus()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.LocalId"
	 *        extendedMetaData="kind='attribute' name='conceptStatus'"
	 * @generated
	 */
	String getConceptStatus();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.concepts.CodedEntry#getConceptStatus <em>Concept Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Concept Status</em>' attribute.
	 * @see #getConceptStatus()
	 * @generated
	 */
	void setConceptStatus(String value);

	/**
	 * Returns the value of the '<em><b>Is Active</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * TRUE means that the code is currently active within the coding scheme. Default: TRUE.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Is Active</em>' attribute.
	 * @see #isSetIsActive()
	 * @see #unsetIsActive()
	 * @see #setIsActive(Boolean)
	 * @see org.LexGrid.emf.concepts.ConceptsPackage#getCodedEntry_IsActive()
	 * @model unique="false" unsettable="true" dataType="org.LexGrid.emf.builtins.TsBooleanObject"
	 *        extendedMetaData="kind='attribute' name='isActive'"
	 * @generated
	 */
	Boolean getIsActive();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.concepts.CodedEntry#getIsActive <em>Is Active</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Active</em>' attribute.
	 * @see #isSetIsActive()
	 * @see #unsetIsActive()
	 * @see #getIsActive()
	 * @generated
	 */
	void setIsActive(Boolean value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.concepts.CodedEntry#getIsAnonymous <em>Is Anonymous</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsAnonymous()
	 * @see #getIsAnonymous()
	 * @see #setIsAnonymous(Boolean)
	 * @generated
	 */
	void unsetIsAnonymous();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.concepts.CodedEntry#getIsAnonymous <em>Is Anonymous</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Anonymous</em>' attribute is set.
	 * @see #unsetIsAnonymous()
	 * @see #getIsAnonymous()
	 * @see #setIsAnonymous(Boolean)
	 * @generated
	 */
	boolean isSetIsAnonymous();

	/**
	 * Returns the value of the '<em><b>Property Link</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.concepts.PropertyLink}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Property Link</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Property Link</em>' containment reference list.
	 * @see org.LexGrid.emf.concepts.ConceptsPackage#getCodedEntry_PropertyLink()
	 * @model type="org.LexGrid.emf.concepts.PropertyLink" containment="true"
	 *        extendedMetaData="kind='element' name='propertyLink' namespace='##targetNamespace'"
	 * @generated
	 */
	List getPropertyLink();

} // CodedEntry