/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.concepts;

import org.LexGrid.emf.commonTypes.Property;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Presentation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 *  A designation of a given concept. The presentation identifier must, at bare minimum, uniquely map to a given text string, bitmap,
 * 				etc. within the context of the containing concept. In some terminologies, every unique text string will have exactly one presentation
 * 				identifier, which means that the same presentation identifier may occur under more than one concept. In other terminologies, there may be more
 * 				than one identifier for a given text string, meaning that the presentation identifier uniquely determines the concept. Service software must not
 * 				assume *either* model. (See: property for additional elements)
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.LexGrid.emf.concepts.Presentation#getDegreeOfFidelity <em>Degree Of Fidelity</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.Presentation#getIsPreferred <em>Is Preferred</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.Presentation#getMatchIfNoContext <em>Match If No Context</em>}</li>
 *   <li>{@link org.LexGrid.emf.concepts.Presentation#getRepresentationalForm <em>Representational Form</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.LexGrid.emf.concepts.ConceptsPackage#getPresentation()
 * @model extendedMetaData="name='presentation' kind='elementOnly'"
 * @generated
 */
public interface Presentation extends Property {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.concepts.Presentation#getIsPreferred <em>Is Preferred</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsPreferred()
	 * @see #getIsPreferred()
	 * @see #setIsPreferred(Boolean)
	 * @generated
	 */
	void unsetIsPreferred();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.concepts.Presentation#getIsPreferred <em>Is Preferred</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Preferred</em>' attribute is set.
	 * @see #unsetIsPreferred()
	 * @see #getIsPreferred()
	 * @see #setIsPreferred(Boolean)
	 * @generated
	 */
	boolean isSetIsPreferred();

	/**
	 * Returns the value of the '<em><b>Match If No Context</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * TRUE if the list entry matches if no context is supplied.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Match If No Context</em>' attribute.
	 * @see #isSetMatchIfNoContext()
	 * @see #unsetMatchIfNoContext()
	 * @see #setMatchIfNoContext(Boolean)
	 * @see org.LexGrid.emf.concepts.ConceptsPackage#getPresentation_MatchIfNoContext()
	 * @model unique="false" unsettable="true" dataType="org.LexGrid.emf.builtins.TsBooleanObject"
	 *        extendedMetaData="kind='attribute' name='matchIfNoContext'"
	 * @generated
	 */
	Boolean getMatchIfNoContext();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.concepts.Presentation#getMatchIfNoContext <em>Match If No Context</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Match If No Context</em>' attribute.
	 * @see #isSetMatchIfNoContext()
	 * @see #unsetMatchIfNoContext()
	 * @see #getMatchIfNoContext()
	 * @generated
	 */
	void setMatchIfNoContext(Boolean value);

	/**
	 * Returns the value of the '<em><b>Degree Of Fidelity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * How closely a term approximates the meaning of a concept.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Degree Of Fidelity</em>' attribute.
	 * @see #setDegreeOfFidelity(String)
	 * @see org.LexGrid.emf.concepts.ConceptsPackage#getPresentation_DegreeOfFidelity()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.LocalId"
	 *        extendedMetaData="kind='attribute' name='degreeOfFidelity'"
	 * @generated
	 */
	String getDegreeOfFidelity();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.concepts.Presentation#getDegreeOfFidelity <em>Degree Of Fidelity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Degree Of Fidelity</em>' attribute.
	 * @see #getDegreeOfFidelity()
	 * @generated
	 */
	void setDegreeOfFidelity(String value);

	/**
	 * Returns the value of the '<em><b>Is Preferred</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * TRUE means that, *if* the text meets the selection criteria, it should be the preferred form.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Is Preferred</em>' attribute.
	 * @see #isSetIsPreferred()
	 * @see #unsetIsPreferred()
	 * @see #setIsPreferred(Boolean)
	 * @see org.LexGrid.emf.concepts.ConceptsPackage#getPresentation_IsPreferred()
	 * @model unique="false" unsettable="true" dataType="org.LexGrid.emf.builtins.TsBooleanObject"
	 *        extendedMetaData="kind='attribute' name='isPreferred'"
	 * @generated
	 */
	Boolean getIsPreferred();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.concepts.Presentation#getIsPreferred <em>Is Preferred</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Preferred</em>' attribute.
	 * @see #isSetIsPreferred()
	 * @see #unsetIsPreferred()
	 * @see #getIsPreferred()
	 * @generated
	 */
	void setIsPreferred(Boolean value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.concepts.Presentation#getMatchIfNoContext <em>Match If No Context</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetMatchIfNoContext()
	 * @see #getMatchIfNoContext()
	 * @see #setMatchIfNoContext(Boolean)
	 * @generated
	 */
	void unsetMatchIfNoContext();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.concepts.Presentation#getMatchIfNoContext <em>Match If No Context</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Match If No Context</em>' attribute is set.
	 * @see #unsetMatchIfNoContext()
	 * @see #getMatchIfNoContext()
	 * @see #setMatchIfNoContext(Boolean)
	 * @generated
	 */
	boolean isSetMatchIfNoContext();

	/**
	 * Returns the value of the '<em><b>Representational Form</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * How the term represents the concept (abbrev, acronym, etc.) - Must be in
	 * 						supportedRepresentationalForm.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Representational Form</em>' attribute.
	 * @see #setRepresentationalForm(String)
	 * @see org.LexGrid.emf.concepts.ConceptsPackage#getPresentation_RepresentationalForm()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.LocalId"
	 *        extendedMetaData="kind='attribute' name='representationalForm'"
	 * @generated
	 */
	String getRepresentationalForm();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.concepts.Presentation#getRepresentationalForm <em>Representational Form</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Representational Form</em>' attribute.
	 * @see #getRepresentationalForm()
	 * @generated
	 */
	void setRepresentationalForm(String value);

} // Presentation