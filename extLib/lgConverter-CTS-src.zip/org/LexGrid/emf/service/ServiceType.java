/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.service;

import org.LexGrid.emf.codingSchemes.CodingSchemesType;
import org.LexGrid.emf.commonTypes.Describable;
import org.LexGrid.emf.valueDomains.ValueDomains;
import org.LexGrid.emf.versions.History;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>ServiceType</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.LexGrid.emf.service.ServiceType#getCodingSchemes <em>Coding Schemes</em>}</li>
 *   <li>{@link org.LexGrid.emf.service.ServiceType#getHistory <em>History</em>}</li>
 *   <li>{@link org.LexGrid.emf.service.ServiceType#getValueDomains <em>Value Domains</em>}</li>
 *   <li>{@link org.LexGrid.emf.service.ServiceType#getService <em>Service</em>}</li>
 *   <li>{@link org.LexGrid.emf.service.ServiceType#getVersion <em>Version</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.LexGrid.emf.service.ServiceTypePackage#getServiceType()
 * @model extendedMetaData="name='service_._type' kind='elementOnly'"
 * @generated
 */
public interface ServiceType extends Describable {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Returns the value of the '<em><b>Service</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The name that is used to reference the service extenally
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Service</em>' attribute.
	 * @see #setService(String)
	 * @see org.LexGrid.emf.service.ServiceTypePackage#getServiceType_Service()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.TsCaseIgnoreIA5String" required="true"
	 *        extendedMetaData="kind='attribute' name='service'"
	 * @generated
	 */
	String getService();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.service.ServiceType#getService <em>Service</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Service</em>' attribute.
	 * @see #getService()
	 * @generated
	 */
	void setService(String value);

	/**
	 * Returns the value of the '<em><b>Version</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The ersion of the service implementation represented by this node
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Version</em>' attribute.
	 * @see #setVersion(String)
	 * @see org.LexGrid.emf.service.ServiceTypePackage#getServiceType_Version()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.Version"
	 *        extendedMetaData="kind='attribute' name='version'"
	 * @generated
	 */
	String getVersion();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.service.ServiceType#getVersion <em>Version</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Version</em>' attribute.
	 * @see #getVersion()
	 * @generated
	 */
	void setVersion(String value);

	/**
	 * Returns the value of the '<em><b>Coding Schemes</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The set of coding schemes represented by tthis service
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Coding Schemes</em>' containment reference.
	 * @see #setCodingSchemes(CodingSchemesType)
	 * @see org.LexGrid.emf.service.ServiceTypePackage#getServiceType_CodingSchemes()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='codingSchemes' namespace='http://LexGrid.org/schema/2006/01/LexGrid/codingSchemes'"
	 * @generated
	 */
	CodingSchemesType getCodingSchemes();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.service.ServiceType#getCodingSchemes <em>Coding Schemes</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Coding Schemes</em>' containment reference.
	 * @see #getCodingSchemes()
	 * @generated
	 */
	void setCodingSchemes(CodingSchemesType value);

	/**
	 * Returns the value of the '<em><b>History</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The history of edits on the coding scheme and/or value domain
	 *                                                                 content.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>History</em>' containment reference.
	 * @see #setHistory(History)
	 * @see org.LexGrid.emf.service.ServiceTypePackage#getServiceType_History()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='history' namespace='##targetNamespace'"
	 * @generated
	 */
	History getHistory();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.service.ServiceType#getHistory <em>History</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>History</em>' containment reference.
	 * @see #getHistory()
	 * @generated
	 */
	void setHistory(History value);

	/**
	 * Returns the value of the '<em><b>Value Domains</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The set of value domains (ordered collections of concept codes) represented by
	 *                                                                         this service
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Value Domains</em>' containment reference.
	 * @see #setValueDomains(ValueDomains)
	 * @see org.LexGrid.emf.service.ServiceTypePackage#getServiceType_ValueDomains()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='valueDomains' namespace='##targetNamespace'"
	 * @generated
	 */
	ValueDomains getValueDomains();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.service.ServiceType#getValueDomains <em>Value Domains</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Value Domains</em>' containment reference.
	 * @see #getValueDomains()
	 * @generated
	 */
	void setValueDomains(ValueDomains value);

} // ServiceType