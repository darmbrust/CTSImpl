/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.service.impl;

import org.LexGrid.emf.base.impl.LgAttributeImpl;
import org.LexGrid.emf.base.impl.LgReferenceImpl;
import org.LexGrid.emf.builtins.BuiltinsPackage;
import org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl;
import org.LexGrid.emf.codingSchemes.CodingschemesPackage;
import org.LexGrid.emf.codingSchemes.impl.CodingschemesPackageImpl;
import org.LexGrid.emf.commonTypes.CommontypesPackage;
import org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl;
import org.LexGrid.emf.concepts.ConceptsPackage;
import org.LexGrid.emf.concepts.impl.ConceptsPackageImpl;
import org.LexGrid.emf.history.NCIHistoryPackage;
import org.LexGrid.emf.history.impl.NCIHistoryPackageImpl;
import org.LexGrid.emf.ldap.LdapPackage;
import org.LexGrid.emf.ldap.impl.LdapPackageImpl;
import org.LexGrid.emf.naming.NamingPackage;
import org.LexGrid.emf.naming.impl.NamingPackageImpl;
import org.LexGrid.emf.relations.RelationsPackage;
import org.LexGrid.emf.relations.impl.RelationsPackageImpl;
import org.LexGrid.emf.service.DocumentRoot;
import org.LexGrid.emf.service.ServiceType;
import org.LexGrid.emf.service.ServiceTypeFactory;
import org.LexGrid.emf.service.ServiceTypePackage;
import org.LexGrid.emf.valueDomains.ValuedomainsPackage;
import org.LexGrid.emf.valueDomains.impl.ValuedomainsPackageImpl;
import org.LexGrid.emf.versions.VersionsPackage;
import org.LexGrid.emf.versions.impl.VersionsPackageImpl;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ServiceTypePackageImpl extends EPackageImpl implements ServiceTypePackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass documentRootEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass serviceTypeEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see org.LexGrid.emf.service.ServiceTypePackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private ServiceTypePackageImpl() {
		super(eNS_URI, ServiceTypeFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this
	 * model, and for any others upon which it depends.  Simple
	 * dependencies are satisfied by calling this method on all
	 * dependent packages before doing anything else.  This method drives
	 * initialization for interdependent packages directly, in parallel
	 * with this package, itself.
	 * <p>Of this package and its interdependencies, all packages which
	 * have not yet been registered by their URI values are first created
	 * and registered.  The packages are then initialized in two steps:
	 * meta-model objects for all of the packages are created before any
	 * are initialized, since one package's meta-model objects may refer to
	 * those of another.
	 * <p>Invocation of this method will not affect any packages that have
	 * already been initialized.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static ServiceTypePackage init() {
		if (isInited)
			return (ServiceTypePackage) EPackage.Registry.INSTANCE.getEPackage(ServiceTypePackage.eNS_URI);

		// Obtain or create and register package
		ServiceTypePackageImpl theServiceTypePackage = (ServiceTypePackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(eNS_URI) instanceof ServiceTypePackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(eNS_URI) : new ServiceTypePackageImpl());

		isInited = true;

		// Obtain or create and register interdependencies
		ConceptsPackageImpl theConceptsPackage = (ConceptsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(ConceptsPackage.eNS_URI) instanceof ConceptsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(ConceptsPackage.eNS_URI) : ConceptsPackage.eINSTANCE);
		RelationsPackageImpl theRelationsPackage = (RelationsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(RelationsPackage.eNS_URI) instanceof RelationsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(RelationsPackage.eNS_URI) : RelationsPackage.eINSTANCE);
		NCIHistoryPackageImpl theNCIHistoryPackage = (NCIHistoryPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(NCIHistoryPackage.eNS_URI) instanceof NCIHistoryPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(NCIHistoryPackage.eNS_URI) : NCIHistoryPackage.eINSTANCE);
		VersionsPackageImpl theVersionsPackage = (VersionsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(VersionsPackage.eNS_URI) instanceof VersionsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(VersionsPackage.eNS_URI) : VersionsPackage.eINSTANCE);
		CodingschemesPackageImpl theCodingschemesPackage = (CodingschemesPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(CodingschemesPackage.eNS_URI) instanceof CodingschemesPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(CodingschemesPackage.eNS_URI)
				: CodingschemesPackage.eINSTANCE);
		LdapPackageImpl theLdapPackage = (LdapPackageImpl) (EPackage.Registry.INSTANCE.getEPackage(LdapPackage.eNS_URI) instanceof LdapPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(LdapPackage.eNS_URI)
				: LdapPackage.eINSTANCE);
		BuiltinsPackageImpl theBuiltinsPackage = (BuiltinsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(BuiltinsPackage.eNS_URI) instanceof BuiltinsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(BuiltinsPackage.eNS_URI) : BuiltinsPackage.eINSTANCE);
		ValuedomainsPackageImpl theValuedomainsPackage = (ValuedomainsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(ValuedomainsPackage.eNS_URI) instanceof ValuedomainsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(ValuedomainsPackage.eNS_URI)
				: ValuedomainsPackage.eINSTANCE);
		CommontypesPackageImpl theCommontypesPackage = (CommontypesPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(CommontypesPackage.eNS_URI) instanceof CommontypesPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(CommontypesPackage.eNS_URI) : CommontypesPackage.eINSTANCE);
		NamingPackageImpl theNamingPackage = (NamingPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(NamingPackage.eNS_URI) instanceof NamingPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(NamingPackage.eNS_URI) : NamingPackage.eINSTANCE);

		// Create package meta-data objects
		theServiceTypePackage.createPackageContents();
		theConceptsPackage.createPackageContents();
		theRelationsPackage.createPackageContents();
		theNCIHistoryPackage.createPackageContents();
		theVersionsPackage.createPackageContents();
		theCodingschemesPackage.createPackageContents();
		theLdapPackage.createPackageContents();
		theBuiltinsPackage.createPackageContents();
		theValuedomainsPackage.createPackageContents();
		theCommontypesPackage.createPackageContents();
		theNamingPackage.createPackageContents();

		// Initialize created meta-data
		theServiceTypePackage.initializePackageContents();
		theConceptsPackage.initializePackageContents();
		theRelationsPackage.initializePackageContents();
		theNCIHistoryPackage.initializePackageContents();
		theVersionsPackage.initializePackageContents();
		theCodingschemesPackage.initializePackageContents();
		theLdapPackage.initializePackageContents();
		theBuiltinsPackage.initializePackageContents();
		theValuedomainsPackage.initializePackageContents();
		theCommontypesPackage.initializePackageContents();
		theNamingPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theServiceTypePackage.freeze();

		return theServiceTypePackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDocumentRoot() {
		return documentRootEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDocumentRoot_Mixed() {
		return (EAttribute) documentRootEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_XMLNSPrefixMap() {
		return (EReference) documentRootEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_XSISchemaLocation() {
		return (EReference) documentRootEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_Service() {
		return (EReference) documentRootEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getServiceType() {
		return serviceTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getServiceType_CodingSchemes() {
		return (EReference) serviceTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getServiceType_History() {
		return (EReference) serviceTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getServiceType_ValueDomains() {
		return (EReference) serviceTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getServiceType_Service() {
		return (EAttribute) serviceTypeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getServiceType_Version() {
		return (EAttribute) serviceTypeEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ServiceTypeFactory getServiceTypeFactory() {
		return (ServiceTypeFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		documentRootEClass = createEClass(DOCUMENT_ROOT);
		createEAttribute(documentRootEClass, DOCUMENT_ROOT__MIXED);
		createEReference(documentRootEClass, DOCUMENT_ROOT__XMLNS_PREFIX_MAP);
		createEReference(documentRootEClass, DOCUMENT_ROOT__XSI_SCHEMA_LOCATION);
		createEReference(documentRootEClass, DOCUMENT_ROOT__SERVICE);

		serviceTypeEClass = createEClass(SERVICE_TYPE);
		createEReference(serviceTypeEClass, SERVICE_TYPE__CODING_SCHEMES);
		createEReference(serviceTypeEClass, SERVICE_TYPE__HISTORY);
		createEReference(serviceTypeEClass, SERVICE_TYPE__VALUE_DOMAINS);
		createEAttribute(serviceTypeEClass, SERVICE_TYPE__SERVICE);
		createEAttribute(serviceTypeEClass, SERVICE_TYPE__VERSION);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContentsGen() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		CommontypesPackage theCommontypesPackage = (CommontypesPackage) EPackage.Registry.INSTANCE
				.getEPackage(CommontypesPackage.eNS_URI);
		CodingschemesPackage theCodingschemesPackage = (CodingschemesPackage) EPackage.Registry.INSTANCE
				.getEPackage(CodingschemesPackage.eNS_URI);
		VersionsPackage theVersionsPackage = (VersionsPackage) EPackage.Registry.INSTANCE
				.getEPackage(VersionsPackage.eNS_URI);
		ValuedomainsPackage theValuedomainsPackage = (ValuedomainsPackage) EPackage.Registry.INSTANCE
				.getEPackage(ValuedomainsPackage.eNS_URI);
		BuiltinsPackage theBuiltinsPackage = (BuiltinsPackage) EPackage.Registry.INSTANCE
				.getEPackage(BuiltinsPackage.eNS_URI);

		// Add supertypes to classes
		serviceTypeEClass.getESuperTypes().add(theCommontypesPackage.getDescribable());

		// Initialize classes and features; add operations and parameters
		initEClass(documentRootEClass, DocumentRoot.class, "DocumentRoot", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDocumentRoot_Mixed(), ecorePackage.getEFeatureMapEntry(), "mixed", null, 0, -1, null,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_XMLNSPrefixMap(), ecorePackage.getEStringToStringMapEntry(), null,
				"xMLNSPrefixMap", null, 0, -1, null, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_XSISchemaLocation(), ecorePackage.getEStringToStringMapEntry(), null,
				"xSISchemaLocation", null, 0, -1, null, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_Service(), this.getServiceType(), null, "service", null, 0, -2, null,
				IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE,
				IS_DERIVED, IS_ORDERED);

		initEClass(serviceTypeEClass, ServiceType.class, "ServiceType", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getServiceType_CodingSchemes(), theCodingschemesPackage.getCodingSchemesType(), null,
				"codingSchemes", null, 0, 1, ServiceType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getServiceType_History(), theVersionsPackage.getHistory(), null, "history", null, 0, 1,
				ServiceType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getServiceType_ValueDomains(), theValuedomainsPackage.getValueDomains(), null, "valueDomains",
				null, 0, 1, ServiceType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getServiceType_Service(), theBuiltinsPackage.getTsCaseIgnoreIA5String(), "service", null, 1, 1,
				ServiceType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getServiceType_Version(), theCommontypesPackage.getVersion(), "version", null, 0, 1,
				ServiceType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http:///org/eclipse/emf/ecore/util/ExtendedMetaData
		createExtendedMetaDataAnnotations();
		// null
		createNullAnnotations();
	}

	/**
	 * Initializes the annotations for <b>http:///org/eclipse/emf/ecore/util/ExtendedMetaData</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createExtendedMetaDataAnnotations() {
		String source = "http:///org/eclipse/emf/ecore/util/ExtendedMetaData";
		addAnnotation(documentRootEClass, source, new String[] { "name", "", "kind", "mixed" });
		addAnnotation(getDocumentRoot_Mixed(), source, new String[] { "kind", "elementWildcard", "name", ":mixed" });
		addAnnotation(getDocumentRoot_XMLNSPrefixMap(), source, new String[] { "kind", "attribute", "name",
				"xmlns:prefix" });
		addAnnotation(getDocumentRoot_XSISchemaLocation(), source, new String[] { "kind", "attribute", "name",
				"xsi:schemaLocation" });
		addAnnotation(getDocumentRoot_Service(), source, new String[] { "kind", "element", "name", "service",
				"namespace", "##targetNamespace" });
		addAnnotation(serviceTypeEClass, source, new String[] { "name", "service_._type", "kind", "elementOnly" });
		addAnnotation(getServiceType_CodingSchemes(), source, new String[] { "kind", "element", "name",
				"codingSchemes", "namespace", "http://LexGrid.org/schema/2006/01/LexGrid/codingSchemes" });
		addAnnotation(getServiceType_History(), source, new String[] { "kind", "element", "name", "history",
				"namespace", "##targetNamespace" });
		addAnnotation(getServiceType_ValueDomains(), source, new String[] { "kind", "element", "name", "valueDomains",
				"namespace", "##targetNamespace" });
		addAnnotation(getServiceType_Service(), source, new String[] { "kind", "attribute", "name", "service" });
		addAnnotation(getServiceType_Version(), source, new String[] { "kind", "attribute", "name", "version" });
	}

	/**
	 * Initializes the annotations for <b>null</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createNullAnnotations() {
		String source = null;
		addAnnotation(
				getDocumentRoot_Service(),
				source,
				new String[] {
						"appinfo",
						"\r\n                                <ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.7.1</ldap:oid>\r\n                                <ldap:rdn xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">service</ldap:rdn>\r\n                                <ldap:objectClass xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">serviceClass</ldap:objectClass>\r\n                        " });
		addAnnotation(
				getServiceType_CodingSchemes(),
				source,
				new String[] {
						"appinfo",
						"\r\n                                <ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.7.81</ldap:oid>\r\n                                <ldap:rdn xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">dc</ldap:rdn>\r\n                        " });
	}

	////////////////////////////////////////////////////////////
	// ************** BEGIN NON-GENERATED CODE ************** //
	//                                                        //
	// ****************************************************** //
	////////////////////////////////////////////////////////////
	/**
	 * Override superclass to create a LexGrid-aware attribute.
	 * @non-generated
	 */
	protected void createEAttribute(EClass owner, int id) {
		LgAttributeImpl eAttribute = new LgAttributeImpl();
		eAttribute.setFeatureID(id);
		owner.getEStructuralFeatures().add(eAttribute);
	}

	/**
	 * Override superclass to create a LexGrid-aware reference.
	 * @non-generated
	 */
	protected void createEReference(EClass owner, int id) {
		LgReferenceImpl eReference = new LgReferenceImpl();
		eReference.setFeatureID(id);
		owner.getEStructuralFeatures().add(eReference);
	}

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * @non-generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		initializePackageContentsGen();

		((LgAttributeImpl) getServiceType_Service()).setID(true);

		// Ensures order of output in XML ...
		String source = "http:///org/eclipse/emf/mapping/xsd2ecore/XSD2Ecore";
		addAnnotation(serviceTypeEClass, source, new String[] { "feature-order",
				"codingSchemes history valueDomains" });
	}
	////////////////////////////////////////////////////////////
	// *************** END NON-GENERATED CODE *************** //
	////////////////////////////////////////////////////////////

} //ServiceTypePackageImpl