/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.relations;

import java.util.List;

import org.LexGrid.emf.commonTypes.Describable;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Relations</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A directory of relations across a set of concept codes drawn from one or more coding schemes.
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.LexGrid.emf.relations.Relations#getSource <em>Source</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.Relations#getAssociation <em>Association</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.Relations#getDc <em>Dc</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.Relations#getIsNative <em>Is Native</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.LexGrid.emf.relations.RelationsPackage#getRelations()
 * @model extendedMetaData="name='relations' kind='elementOnly'"
 * @generated
 */
public interface Relations extends Describable {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Returns the value of the '<em><b>Dc</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The context identifier for this directory.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Dc</em>' attribute.
	 * @see #setDc(String)
	 * @see org.LexGrid.emf.relations.RelationsPackage#getRelations_Dc()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.Dc" required="true"
	 *        extendedMetaData="kind='attribute' name='dc'"
	 * @generated
	 */
	String getDc();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.relations.Relations#getDc <em>Dc</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Dc</em>' attribute.
	 * @see #getDc()
	 * @generated
	 */
	void setDc(String value);

	/**
	 * Returns the value of the '<em><b>Is Native</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * TRUE means that this set of associations were created by the codingScheme
	 *                                                 curators.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Is Native</em>' attribute.
	 * @see #isSetIsNative()
	 * @see #unsetIsNative()
	 * @see #setIsNative(Boolean)
	 * @see org.LexGrid.emf.relations.RelationsPackage#getRelations_IsNative()
	 * @model unique="false" unsettable="true" dataType="org.LexGrid.emf.builtins.TsBooleanObject"
	 *        extendedMetaData="kind='attribute' name='isNative'"
	 * @generated
	 */
	Boolean getIsNative();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.relations.Relations#getIsNative <em>Is Native</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Native</em>' attribute.
	 * @see #isSetIsNative()
	 * @see #unsetIsNative()
	 * @see #getIsNative()
	 * @generated
	 */
	void setIsNative(Boolean value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.relations.Relations#getIsNative <em>Is Native</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsNative()
	 * @see #getIsNative()
	 * @see #setIsNative(Boolean)
	 * @generated
	 */
	void unsetIsNative();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.relations.Relations#getIsNative <em>Is Native</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Native</em>' attribute is set.
	 * @see #unsetIsNative()
	 * @see #getIsNative()
	 * @see #setIsNative(Boolean)
	 * @generated
	 */
	boolean isSetIsNative();

	/**
	 * Returns the value of the '<em><b>Source</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.commonTypes.Source}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The source(s) of this collection of associations. Must be in
	 *                                                         supportedSource.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Source</em>' containment reference list.
	 * @see org.LexGrid.emf.relations.RelationsPackage#getRelations_Source()
	 * @model type="org.LexGrid.emf.commonTypes.Source" containment="true"
	 *        extendedMetaData="kind='element' name='source' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSource();

	/**
	 * Returns the value of the '<em><b>Association</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.relations.Association}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The list of associations supported in this collection.
	 * NOTE: the default for dc should be "Relations", but that forces the element to be
	 *                                                                 optional which, in turn may leave us with only an implied dc value.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Association</em>' containment reference list.
	 * @see org.LexGrid.emf.relations.RelationsPackage#getRelations_Association()
	 * @model type="org.LexGrid.emf.relations.Association" containment="true" required="true"
	 *        extendedMetaData="kind='element' name='association' namespace='##targetNamespace'"
	 * @generated
	 */
	List getAssociation();

} // Relations