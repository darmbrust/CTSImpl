/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.relations;

import java.util.List;

import org.LexGrid.emf.base.LgCodedObj;
import org.LexGrid.emf.commonTypes.Describable;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Association</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A binary relation between concept codes or concept codes and data.
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.LexGrid.emf.relations.Association#getSourceConcept <em>Source Concept</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.Association#getAssociation <em>Association</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.Association#getForwardName <em>Forward Name</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.Association#getInverse <em>Inverse</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.Association#getIsAntiReflexive <em>Is Anti Reflexive</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.Association#getIsAntiSymmetric <em>Is Anti Symmetric</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.Association#getIsAntiTransitive <em>Is Anti Transitive</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.Association#getIsFunctional <em>Is Functional</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.Association#getIsNavigable <em>Is Navigable</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.Association#getIsReflexive <em>Is Reflexive</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.Association#getIsReverseFunctional <em>Is Reverse Functional</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.Association#getIsSymmetric <em>Is Symmetric</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.Association#getIsTransitive <em>Is Transitive</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.Association#getIsTranslationAssociation <em>Is Translation Association</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.Association#getReverseName <em>Reverse Name</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.Association#getTargetCodingScheme <em>Target Coding Scheme</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.LexGrid.emf.relations.RelationsPackage#getAssociation()
 * @model extendedMetaData="name='association' kind='elementOnly'"
 * @generated
 */
public interface Association extends Describable, LgCodedObj {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Returns the value of the '<em><b>Association</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The local name of the association. Must be in supportedAssociation.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Association</em>' attribute.
	 * @see #setAssociation(String)
	 * @see org.LexGrid.emf.relations.RelationsPackage#getAssociation_Association()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.LocalId" required="true"
	 *        extendedMetaData="kind='attribute' name='association'"
	 * @generated
	 */
	String getAssociation();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.relations.Association#getAssociation <em>Association</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Association</em>' attribute.
	 * @see #getAssociation()
	 * @generated
	 */
	void setAssociation(String value);

	/**
	 * Returns the value of the '<em><b>Forward Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * How the association should be represented when reading from source to
	 *                                                 target.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Forward Name</em>' attribute.
	 * @see #setForwardName(String)
	 * @see org.LexGrid.emf.relations.RelationsPackage#getAssociation_ForwardName()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.TsCaseIgnoreIA5String" required="true"
	 *        extendedMetaData="kind='attribute' name='forwardName'"
	 * @generated
	 */
	String getForwardName();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.relations.Association#getForwardName <em>Forward Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Forward Name</em>' attribute.
	 * @see #getForwardName()
	 * @generated
	 */
	void setForwardName(String value);

	/**
	 * Returns the value of the '<em><b>Inverse</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The local identifier of the inverse association.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Inverse</em>' attribute.
	 * @see #setInverse(String)
	 * @see org.LexGrid.emf.relations.RelationsPackage#getAssociation_Inverse()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.LocalId"
	 *        extendedMetaData="kind='attribute' name='inverse'"
	 * @generated
	 */
	String getInverse();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.relations.Association#getInverse <em>Inverse</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Inverse</em>' attribute.
	 * @see #getInverse()
	 * @generated
	 */
	void setInverse(String value);

	/**
	 * Returns the value of the '<em><b>Is Anti Reflexive</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * TRUE means that the association is antiReflexive ( for all a in domain, not r(a,a), false
	 *                                                         means not antiReflexive. If absent, reflexivity is unknown or not applicable.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Is Anti Reflexive</em>' attribute.
	 * @see #isSetIsAntiReflexive()
	 * @see #unsetIsAntiReflexive()
	 * @see #setIsAntiReflexive(Boolean)
	 * @see org.LexGrid.emf.relations.RelationsPackage#getAssociation_IsAntiReflexive()
	 * @model unique="false" unsettable="true" dataType="org.LexGrid.emf.builtins.TsBooleanObject"
	 *        extendedMetaData="kind='attribute' name='isAntiReflexive'"
	 * @generated
	 */
	Boolean getIsAntiReflexive();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.relations.Association#getIsAntiReflexive <em>Is Anti Reflexive</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Anti Reflexive</em>' attribute.
	 * @see #isSetIsAntiReflexive()
	 * @see #unsetIsAntiReflexive()
	 * @see #getIsAntiReflexive()
	 * @generated
	 */
	void setIsAntiReflexive(Boolean value);

	/**
	 * Returns the value of the '<em><b>Reverse Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * How the association should be represented when reading from target to
	 *                                                 source.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Reverse Name</em>' attribute.
	 * @see #setReverseName(String)
	 * @see org.LexGrid.emf.relations.RelationsPackage#getAssociation_ReverseName()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.TsCaseIgnoreIA5String"
	 *        extendedMetaData="kind='attribute' name='reverseName'"
	 * @generated
	 */
	String getReverseName();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.relations.Association#getReverseName <em>Reverse Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Reverse Name</em>' attribute.
	 * @see #getReverseName()
	 * @generated
	 */
	void setReverseName(String value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.relations.Association#getIsTransitive <em>Is Transitive</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsTransitive()
	 * @see #getIsTransitive()
	 * @see #setIsTransitive(Boolean)
	 * @generated
	 */
	void unsetIsTransitive();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.relations.Association#getIsTransitive <em>Is Transitive</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Transitive</em>' attribute is set.
	 * @see #unsetIsTransitive()
	 * @see #getIsTransitive()
	 * @see #setIsTransitive(Boolean)
	 * @generated
	 */
	boolean isSetIsTransitive();

	/**
	 * Returns the value of the '<em><b>Is Translation Association</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * TRUE means that this association represents a "translation" or "mapping" between the
	 *                                                         containing code system and the target code system.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Is Translation Association</em>' attribute.
	 * @see #isSetIsTranslationAssociation()
	 * @see #unsetIsTranslationAssociation()
	 * @see #setIsTranslationAssociation(Boolean)
	 * @see org.LexGrid.emf.relations.RelationsPackage#getAssociation_IsTranslationAssociation()
	 * @model unique="false" unsettable="true" dataType="org.LexGrid.emf.builtins.TsBooleanObject"
	 *        extendedMetaData="kind='attribute' name='isTranslationAssociation'"
	 * @generated
	 */
	Boolean getIsTranslationAssociation();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.relations.Association#getIsTranslationAssociation <em>Is Translation Association</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Translation Association</em>' attribute.
	 * @see #isSetIsTranslationAssociation()
	 * @see #unsetIsTranslationAssociation()
	 * @see #getIsTranslationAssociation()
	 * @generated
	 */
	void setIsTranslationAssociation(Boolean value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.relations.Association#getIsAntiTransitive <em>Is Anti Transitive</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsAntiTransitive()
	 * @see #getIsAntiTransitive()
	 * @see #setIsAntiTransitive(Boolean)
	 * @generated
	 */
	void unsetIsAntiTransitive();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.relations.Association#getIsAntiTransitive <em>Is Anti Transitive</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Anti Transitive</em>' attribute is set.
	 * @see #unsetIsAntiTransitive()
	 * @see #getIsAntiTransitive()
	 * @see #setIsAntiTransitive(Boolean)
	 * @generated
	 */
	boolean isSetIsAntiTransitive();

	/**
	 * Returns the value of the '<em><b>Is Functional</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * TRUE means that the association is injective(for all a in domain, there exists exactly one b
	 *                                                         in the range such that r(a,b).
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Is Functional</em>' attribute.
	 * @see #isSetIsFunctional()
	 * @see #unsetIsFunctional()
	 * @see #setIsFunctional(Boolean)
	 * @see org.LexGrid.emf.relations.RelationsPackage#getAssociation_IsFunctional()
	 * @model unique="false" unsettable="true" dataType="org.LexGrid.emf.builtins.TsBooleanObject"
	 *        extendedMetaData="kind='attribute' name='isFunctional'"
	 * @generated
	 */
	Boolean getIsFunctional();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.relations.Association#getIsFunctional <em>Is Functional</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Functional</em>' attribute.
	 * @see #isSetIsFunctional()
	 * @see #unsetIsFunctional()
	 * @see #getIsFunctional()
	 * @generated
	 */
	void setIsFunctional(Boolean value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.relations.Association#getIsSymmetric <em>Is Symmetric</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsSymmetric()
	 * @see #getIsSymmetric()
	 * @see #setIsSymmetric(Boolean)
	 * @generated
	 */
	void unsetIsSymmetric();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.relations.Association#getIsSymmetric <em>Is Symmetric</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Symmetric</em>' attribute is set.
	 * @see #unsetIsSymmetric()
	 * @see #getIsSymmetric()
	 * @see #setIsSymmetric(Boolean)
	 * @generated
	 */
	boolean isSetIsSymmetric();

	/**
	 * Returns the value of the '<em><b>Is Transitive</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * True means that association is transitive ( r(a,b), r(b,c) -&gt; r(a,c)). False means not
	 *                                                         transitive. If absent, transitivity is unknown or not applicable.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Is Transitive</em>' attribute.
	 * @see #isSetIsTransitive()
	 * @see #unsetIsTransitive()
	 * @see #setIsTransitive(Boolean)
	 * @see org.LexGrid.emf.relations.RelationsPackage#getAssociation_IsTransitive()
	 * @model unique="false" unsettable="true" dataType="org.LexGrid.emf.builtins.TsBooleanObject"
	 *        extendedMetaData="kind='attribute' name='isTransitive'"
	 * @generated
	 */
	Boolean getIsTransitive();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.relations.Association#getIsTransitive <em>Is Transitive</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Transitive</em>' attribute.
	 * @see #isSetIsTransitive()
	 * @see #unsetIsTransitive()
	 * @see #getIsTransitive()
	 * @generated
	 */
	void setIsTransitive(Boolean value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.relations.Association#getIsAntiSymmetric <em>Is Anti Symmetric</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsAntiSymmetric()
	 * @see #getIsAntiSymmetric()
	 * @see #setIsAntiSymmetric(Boolean)
	 * @generated
	 */
	void unsetIsAntiSymmetric();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.relations.Association#getIsAntiSymmetric <em>Is Anti Symmetric</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Anti Symmetric</em>' attribute is set.
	 * @see #unsetIsAntiSymmetric()
	 * @see #getIsAntiSymmetric()
	 * @see #setIsAntiSymmetric(Boolean)
	 * @generated
	 */
	boolean isSetIsAntiSymmetric();

	/**
	 * Returns the value of the '<em><b>Is Anti Transitive</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * True means that the association is antiTransitive ( r(a,b),r(b,c) -&gt; not r(a,c)). False
	 *                                                         means not antitransitive. If absent, transitivity is unknown or not applicable.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Is Anti Transitive</em>' attribute.
	 * @see #isSetIsAntiTransitive()
	 * @see #unsetIsAntiTransitive()
	 * @see #setIsAntiTransitive(Boolean)
	 * @see org.LexGrid.emf.relations.RelationsPackage#getAssociation_IsAntiTransitive()
	 * @model unique="false" unsettable="true" dataType="org.LexGrid.emf.builtins.TsBooleanObject"
	 *        extendedMetaData="kind='attribute' name='isAntiTransitive'"
	 * @generated
	 */
	Boolean getIsAntiTransitive();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.relations.Association#getIsAntiTransitive <em>Is Anti Transitive</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Anti Transitive</em>' attribute.
	 * @see #isSetIsAntiTransitive()
	 * @see #unsetIsAntiTransitive()
	 * @see #getIsAntiTransitive()
	 * @generated
	 */
	void setIsAntiTransitive(Boolean value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.relations.Association#getIsReflexive <em>Is Reflexive</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsReflexive()
	 * @see #getIsReflexive()
	 * @see #setIsReflexive(Boolean)
	 * @generated
	 */
	void unsetIsReflexive();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.relations.Association#getIsReflexive <em>Is Reflexive</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Reflexive</em>' attribute is set.
	 * @see #unsetIsReflexive()
	 * @see #getIsReflexive()
	 * @see #setIsReflexive(Boolean)
	 * @generated
	 */
	boolean isSetIsReflexive();

	/**
	 * Returns the value of the '<em><b>Is Reverse Functional</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * TRUE means that the association is surjective (for all b in range, there exists exactly one a
	 *                                                         in range such that r(a,b).
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Is Reverse Functional</em>' attribute.
	 * @see #isSetIsReverseFunctional()
	 * @see #unsetIsReverseFunctional()
	 * @see #setIsReverseFunctional(Boolean)
	 * @see org.LexGrid.emf.relations.RelationsPackage#getAssociation_IsReverseFunctional()
	 * @model unique="false" unsettable="true" dataType="org.LexGrid.emf.builtins.TsBooleanObject"
	 *        extendedMetaData="kind='attribute' name='isReverseFunctional'"
	 * @generated
	 */
	Boolean getIsReverseFunctional();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.relations.Association#getIsReverseFunctional <em>Is Reverse Functional</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Reverse Functional</em>' attribute.
	 * @see #isSetIsReverseFunctional()
	 * @see #unsetIsReverseFunctional()
	 * @see #getIsReverseFunctional()
	 * @generated
	 */
	void setIsReverseFunctional(Boolean value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.relations.Association#getIsAntiReflexive <em>Is Anti Reflexive</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsAntiReflexive()
	 * @see #getIsAntiReflexive()
	 * @see #setIsAntiReflexive(Boolean)
	 * @generated
	 */
	void unsetIsAntiReflexive();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.relations.Association#getIsAntiReflexive <em>Is Anti Reflexive</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Anti Reflexive</em>' attribute is set.
	 * @see #unsetIsAntiReflexive()
	 * @see #getIsAntiReflexive()
	 * @see #setIsAntiReflexive(Boolean)
	 * @generated
	 */
	boolean isSetIsAntiReflexive();

	/**
	 * Returns the value of the '<em><b>Is Anti Symmetric</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * True means that the association is antiSymmetric ( r(a,b) -&gt; not r(b,a)), false means
	 *                                                         not antitransitive. If absent, symmetricity is unknown or not applicable.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Is Anti Symmetric</em>' attribute.
	 * @see #isSetIsAntiSymmetric()
	 * @see #unsetIsAntiSymmetric()
	 * @see #setIsAntiSymmetric(Boolean)
	 * @see org.LexGrid.emf.relations.RelationsPackage#getAssociation_IsAntiSymmetric()
	 * @model unique="false" unsettable="true" dataType="org.LexGrid.emf.builtins.TsBooleanObject"
	 *        extendedMetaData="kind='attribute' name='isAntiSymmetric'"
	 * @generated
	 */
	Boolean getIsAntiSymmetric();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.relations.Association#getIsAntiSymmetric <em>Is Anti Symmetric</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Anti Symmetric</em>' attribute.
	 * @see #isSetIsAntiSymmetric()
	 * @see #unsetIsAntiSymmetric()
	 * @see #getIsAntiSymmetric()
	 * @generated
	 */
	void setIsAntiSymmetric(Boolean value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.relations.Association#getIsFunctional <em>Is Functional</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsFunctional()
	 * @see #getIsFunctional()
	 * @see #setIsFunctional(Boolean)
	 * @generated
	 */
	void unsetIsFunctional();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.relations.Association#getIsFunctional <em>Is Functional</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Functional</em>' attribute is set.
	 * @see #unsetIsFunctional()
	 * @see #getIsFunctional()
	 * @see #setIsFunctional(Boolean)
	 * @generated
	 */
	boolean isSetIsFunctional();

	/**
	 * Returns the value of the '<em><b>Is Navigable</b></em>' attribute.
	 * The default value is <code>"true"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * True means that the reverse direction of the associaton is "navigable", meaning that it is
	 *                                                         makes sense to represent the target to source side of the association.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Is Navigable</em>' attribute.
	 * @see #isSetIsNavigable()
	 * @see #unsetIsNavigable()
	 * @see #setIsNavigable(Boolean)
	 * @see org.LexGrid.emf.relations.RelationsPackage#getAssociation_IsNavigable()
	 * @model default="true" unique="false" unsettable="true" dataType="org.LexGrid.emf.builtins.TsBooleanObject"
	 *        extendedMetaData="kind='attribute' name='isNavigable'"
	 * @generated
	 */
	Boolean getIsNavigable();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.relations.Association#getIsNavigable <em>Is Navigable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Navigable</em>' attribute.
	 * @see #isSetIsNavigable()
	 * @see #unsetIsNavigable()
	 * @see #getIsNavigable()
	 * @generated
	 */
	void setIsNavigable(Boolean value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.relations.Association#getIsNavigable <em>Is Navigable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsNavigable()
	 * @see #getIsNavigable()
	 * @see #setIsNavigable(Boolean)
	 * @generated
	 */
	void unsetIsNavigable();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.relations.Association#getIsNavigable <em>Is Navigable</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Navigable</em>' attribute is set.
	 * @see #unsetIsNavigable()
	 * @see #getIsNavigable()
	 * @see #setIsNavigable(Boolean)
	 * @generated
	 */
	boolean isSetIsNavigable();

	/**
	 * Returns the value of the '<em><b>Is Reflexive</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * True means that association is reflexive (for all a in domain, r(a,a). False means not
	 *                                                         reflexive. If absent, reflexivity is unknown or not applicable.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Is Reflexive</em>' attribute.
	 * @see #isSetIsReflexive()
	 * @see #unsetIsReflexive()
	 * @see #setIsReflexive(Boolean)
	 * @see org.LexGrid.emf.relations.RelationsPackage#getAssociation_IsReflexive()
	 * @model unique="false" unsettable="true" dataType="org.LexGrid.emf.builtins.TsBooleanObject"
	 *        extendedMetaData="kind='attribute' name='isReflexive'"
	 * @generated
	 */
	Boolean getIsReflexive();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.relations.Association#getIsReflexive <em>Is Reflexive</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Reflexive</em>' attribute.
	 * @see #isSetIsReflexive()
	 * @see #unsetIsReflexive()
	 * @see #getIsReflexive()
	 * @generated
	 */
	void setIsReflexive(Boolean value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.relations.Association#getIsReverseFunctional <em>Is Reverse Functional</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsReverseFunctional()
	 * @see #getIsReverseFunctional()
	 * @see #setIsReverseFunctional(Boolean)
	 * @generated
	 */
	void unsetIsReverseFunctional();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.relations.Association#getIsReverseFunctional <em>Is Reverse Functional</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Reverse Functional</em>' attribute is set.
	 * @see #unsetIsReverseFunctional()
	 * @see #getIsReverseFunctional()
	 * @see #setIsReverseFunctional(Boolean)
	 * @generated
	 */
	boolean isSetIsReverseFunctional();

	/**
	 * Returns the value of the '<em><b>Is Symmetric</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * True means that association is symmetric ( r(a,b) -&gt; r(b, a)). False means not
	 *                                                         symmetric. If absent, symmetricity is unknown or not applicable.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Is Symmetric</em>' attribute.
	 * @see #isSetIsSymmetric()
	 * @see #unsetIsSymmetric()
	 * @see #setIsSymmetric(Boolean)
	 * @see org.LexGrid.emf.relations.RelationsPackage#getAssociation_IsSymmetric()
	 * @model unique="false" unsettable="true" dataType="org.LexGrid.emf.builtins.TsBooleanObject"
	 *        extendedMetaData="kind='attribute' name='isSymmetric'"
	 * @generated
	 */
	Boolean getIsSymmetric();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.relations.Association#getIsSymmetric <em>Is Symmetric</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Symmetric</em>' attribute.
	 * @see #isSetIsSymmetric()
	 * @see #unsetIsSymmetric()
	 * @see #getIsSymmetric()
	 * @generated
	 */
	void setIsSymmetric(Boolean value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.relations.Association#getIsTranslationAssociation <em>Is Translation Association</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsTranslationAssociation()
	 * @see #getIsTranslationAssociation()
	 * @see #setIsTranslationAssociation(Boolean)
	 * @generated
	 */
	void unsetIsTranslationAssociation();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.relations.Association#getIsTranslationAssociation <em>Is Translation Association</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Translation Association</em>' attribute is set.
	 * @see #unsetIsTranslationAssociation()
	 * @see #getIsTranslationAssociation()
	 * @see #setIsTranslationAssociation(Boolean)
	 * @generated
	 */
	boolean isSetIsTranslationAssociation();

	/**
	 * Returns the value of the '<em><b>Target Coding Scheme</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The default coding scheme for the target concepts if not otherwise specified. If omitted, the
	 *                                                         default target is the containing coding scheme. local name - must be in supportedCodeScheme.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Target Coding Scheme</em>' attribute.
	 * @see #setTargetCodingScheme(String)
	 * @see org.LexGrid.emf.relations.RelationsPackage#getAssociation_TargetCodingScheme()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.LocalId"
	 *        extendedMetaData="kind='attribute' name='targetCodingScheme'"
	 * @generated
	 */
	String getTargetCodingScheme();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.relations.Association#getTargetCodingScheme <em>Target Coding Scheme</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target Coding Scheme</em>' attribute.
	 * @see #getTargetCodingScheme()
	 * @generated
	 */
	void setTargetCodingScheme(String value);

	/**
	 * Returns the value of the '<em><b>Source Concept</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.relations.AssociationInstance}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * A list of association instances, each identified by the "source" or "domain"
	 *                                                         concept.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Source Concept</em>' containment reference list.
	 * @see org.LexGrid.emf.relations.RelationsPackage#getAssociation_SourceConcept()
	 * @model type="org.LexGrid.emf.relations.AssociationInstance" containment="true"
	 *        extendedMetaData="kind='element' name='sourceConcept' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSourceConcept();

} // Association