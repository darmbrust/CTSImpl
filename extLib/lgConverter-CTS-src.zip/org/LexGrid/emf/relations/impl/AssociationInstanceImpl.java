/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.relations.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.LexGrid.emf.base.impl.LgModelObjImpl;
import org.LexGrid.emf.codingSchemes.CodingSchemeType;
import org.LexGrid.emf.codingSchemes.util.CodingschemesUtil;
import org.LexGrid.emf.concepts.CodedEntry;
import org.LexGrid.emf.concepts.util.ConceptsUtil;
import org.LexGrid.emf.relations.Association;
import org.LexGrid.emf.relations.AssociationInstance;
import org.LexGrid.emf.relations.AssociationTarget;
import org.LexGrid.emf.relations.RelationsPackage;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Association Instance</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.LexGrid.emf.relations.impl.AssociationInstanceImpl#getTargetConcept <em>Target Concept</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.impl.AssociationInstanceImpl#getTargetDataValue <em>Target Data Value</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.impl.AssociationInstanceImpl#getSourceCodingScheme <em>Source Coding Scheme</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.impl.AssociationInstanceImpl#getSourceConcept <em>Source Concept</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class AssociationInstanceImpl extends LgModelObjImpl implements AssociationInstance {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AssociationInstanceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return RelationsPackage.Literals.ASSOCIATION_INSTANCE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSourceCodingScheme() {
		return (String) eGet(RelationsPackage.Literals.ASSOCIATION_INSTANCE__SOURCE_CODING_SCHEME, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSourceCodingScheme(String newSourceCodingScheme) {
		eSet(RelationsPackage.Literals.ASSOCIATION_INSTANCE__SOURCE_CODING_SCHEME, newSourceCodingScheme);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSourceConcept() {
		return (String) eGet(RelationsPackage.Literals.ASSOCIATION_INSTANCE__SOURCE_CONCEPT, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSourceConcept(String newSourceConcept) {
		eSet(RelationsPackage.Literals.ASSOCIATION_INSTANCE__SOURCE_CONCEPT, newSourceConcept);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getTargetConcept() {
		return (List) eGet(RelationsPackage.Literals.ASSOCIATION_INSTANCE__TARGET_CONCEPT, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getTargetDataValue() {
		return (List) eGet(RelationsPackage.Literals.ASSOCIATION_INSTANCE__TARGET_DATA_VALUE, true);
	}

	////////////////////////////////////////////////////////////
	// ************** BEGIN NON-GENERATED CODE ************** //
	//                                                        //
	// ****************************************************** //
	////////////////////////////////////////////////////////////
	String textDesc = null;

	/* (non-Javadoc)
	 * @see org.eclipse.emf.ecore.EObject#eSet(org.eclipse.emf.ecore.EStructuralFeature, java.lang.Object)
	 * @non-generated
	 */
	public void eSet(EStructuralFeature eFeature, Object newValue) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
		// Clear the cached text description if affected ... 
		case RelationsPackage.ASSOCIATION_INSTANCE__SOURCE_CODING_SCHEME:
		case RelationsPackage.ASSOCIATION_INSTANCE__SOURCE_CONCEPT:
			textDesc = null;
		}
		super.eSet(eFeature, newValue);
	}

	/**
	 * @see org.LexGrid.emf.base.LgCodedObj#getConceptCode()
	 * @non-generated
	 */
	public String getConceptCode() {
		return getSourceConcept();
	}

	/**
	 * Return an iterator over all association targets of the same class
	 * that have a matching concept code or link.
	 * @return
	 * @non-generated
	 */
	protected Iterator getMatchingTargets() {
		List matches = new ArrayList();
		Object parent = getContainer(Association.class, 0);
		if (parent != null && parent instanceof Association)
			for (Iterator sources = ((Association) parent).getSourceConcept().iterator(); sources.hasNext();) {
				AssociationInstance source = (AssociationInstance) sources.next();
				if (!source.equals(this)) {
					for (Iterator targets = source.getTargetConcept().iterator(); targets.hasNext();) {
						AssociationTarget target = (AssociationTarget) targets.next();
						String code = target.getTargetConcept();
						if (code != null && code.equals(this.getSourceConcept()))
							matches.add(target);
					}
				}
			}
		return matches.iterator();
	}

	/**
	 * @see org.LexGrid.emf.base.LgModelObj#getPreferredTextDescription()
	 * @non-generated
	 */
	public String getPreferredTextDescription() {
		String sourceConcept = (String) eGet(RelationsPackage.eINSTANCE.getAssociation_SourceConcept(), false);
		if (textDesc == null && sourceConcept != null) {
			String schemeName = getSourceCodingScheme();
			CodedEntry ce = null;
			if (schemeName == null || schemeName.length() == 0)
				ce = ConceptsUtil.resolveCodedEntry(this, sourceConcept);
			else {
				CodingSchemeType scheme = CodingschemesUtil.resolveCodingScheme(this, schemeName);
				if (scheme != null)
					ce = ConceptsUtil.resolveCodedEntry(scheme, sourceConcept);
			}
			if (ce != null)
				textDesc = ce.getPreferredTextDescription();
		}
		return textDesc;
	}

} //AssociationInstanceImpl