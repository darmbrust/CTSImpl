/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.relations.impl;

import java.util.Iterator;
import java.util.List;

import org.LexGrid.emf.base.impl.LgEnhancedEListImpl;
import org.LexGrid.emf.commonTypes.impl.DescribableImpl;
import org.LexGrid.emf.relations.Association;
import org.LexGrid.emf.relations.AssociationInstance;
import org.LexGrid.emf.relations.RelationsPackage;
import org.LexGrid.managedobj.ResolveException;
import org.LexGrid.managedobj.UnexpectedException;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Association</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.LexGrid.emf.relations.impl.AssociationImpl#getSourceConcept <em>Source Concept</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.impl.AssociationImpl#getAssociation <em>Association</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.impl.AssociationImpl#getForwardName <em>Forward Name</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.impl.AssociationImpl#getInverse <em>Inverse</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.impl.AssociationImpl#getIsAntiReflexive <em>Is Anti Reflexive</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.impl.AssociationImpl#getIsAntiSymmetric <em>Is Anti Symmetric</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.impl.AssociationImpl#getIsAntiTransitive <em>Is Anti Transitive</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.impl.AssociationImpl#getIsFunctional <em>Is Functional</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.impl.AssociationImpl#getIsNavigable <em>Is Navigable</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.impl.AssociationImpl#getIsReflexive <em>Is Reflexive</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.impl.AssociationImpl#getIsReverseFunctional <em>Is Reverse Functional</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.impl.AssociationImpl#getIsSymmetric <em>Is Symmetric</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.impl.AssociationImpl#getIsTransitive <em>Is Transitive</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.impl.AssociationImpl#getIsTranslationAssociation <em>Is Translation Association</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.impl.AssociationImpl#getReverseName <em>Reverse Name</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.impl.AssociationImpl#getTargetCodingScheme <em>Target Coding Scheme</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class AssociationImpl extends DescribableImpl implements Association {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AssociationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return RelationsPackage.Literals.ASSOCIATION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getAssociation() {
		return (String) eGet(RelationsPackage.Literals.ASSOCIATION__ASSOCIATION, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAssociation(String newAssociation) {
		eSet(RelationsPackage.Literals.ASSOCIATION__ASSOCIATION, newAssociation);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getForwardName() {
		return (String) eGet(RelationsPackage.Literals.ASSOCIATION__FORWARD_NAME, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setForwardName(String newForwardName) {
		eSet(RelationsPackage.Literals.ASSOCIATION__FORWARD_NAME, newForwardName);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getInverse() {
		return (String) eGet(RelationsPackage.Literals.ASSOCIATION__INVERSE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setInverse(String newInverse) {
		eSet(RelationsPackage.Literals.ASSOCIATION__INVERSE, newInverse);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean getIsAntiReflexive() {
		return (Boolean) eGet(RelationsPackage.Literals.ASSOCIATION__IS_ANTI_REFLEXIVE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsAntiReflexive(Boolean newIsAntiReflexive) {
		eSet(RelationsPackage.Literals.ASSOCIATION__IS_ANTI_REFLEXIVE, newIsAntiReflexive);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getReverseName() {
		return (String) eGet(RelationsPackage.Literals.ASSOCIATION__REVERSE_NAME, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReverseName(String newReverseName) {
		eSet(RelationsPackage.Literals.ASSOCIATION__REVERSE_NAME, newReverseName);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetIsTransitive() {
		eUnset(RelationsPackage.Literals.ASSOCIATION__IS_TRANSITIVE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetIsTransitive() {
		return eIsSet(RelationsPackage.Literals.ASSOCIATION__IS_TRANSITIVE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean getIsTranslationAssociation() {
		return (Boolean) eGet(RelationsPackage.Literals.ASSOCIATION__IS_TRANSLATION_ASSOCIATION, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsTranslationAssociation(Boolean newIsTranslationAssociation) {
		eSet(RelationsPackage.Literals.ASSOCIATION__IS_TRANSLATION_ASSOCIATION, newIsTranslationAssociation);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetIsAntiTransitive() {
		eUnset(RelationsPackage.Literals.ASSOCIATION__IS_ANTI_TRANSITIVE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetIsAntiTransitive() {
		return eIsSet(RelationsPackage.Literals.ASSOCIATION__IS_ANTI_TRANSITIVE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean getIsFunctional() {
		return (Boolean) eGet(RelationsPackage.Literals.ASSOCIATION__IS_FUNCTIONAL, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsFunctional(Boolean newIsFunctional) {
		eSet(RelationsPackage.Literals.ASSOCIATION__IS_FUNCTIONAL, newIsFunctional);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetIsSymmetric() {
		eUnset(RelationsPackage.Literals.ASSOCIATION__IS_SYMMETRIC);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetIsSymmetric() {
		return eIsSet(RelationsPackage.Literals.ASSOCIATION__IS_SYMMETRIC);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean getIsTransitive() {
		return (Boolean) eGet(RelationsPackage.Literals.ASSOCIATION__IS_TRANSITIVE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsTransitive(Boolean newIsTransitive) {
		eSet(RelationsPackage.Literals.ASSOCIATION__IS_TRANSITIVE, newIsTransitive);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetIsAntiSymmetric() {
		eUnset(RelationsPackage.Literals.ASSOCIATION__IS_ANTI_SYMMETRIC);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetIsAntiSymmetric() {
		return eIsSet(RelationsPackage.Literals.ASSOCIATION__IS_ANTI_SYMMETRIC);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean getIsAntiTransitive() {
		return (Boolean) eGet(RelationsPackage.Literals.ASSOCIATION__IS_ANTI_TRANSITIVE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsAntiTransitive(Boolean newIsAntiTransitive) {
		eSet(RelationsPackage.Literals.ASSOCIATION__IS_ANTI_TRANSITIVE, newIsAntiTransitive);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetIsReflexive() {
		eUnset(RelationsPackage.Literals.ASSOCIATION__IS_REFLEXIVE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetIsReflexive() {
		return eIsSet(RelationsPackage.Literals.ASSOCIATION__IS_REFLEXIVE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean getIsReverseFunctional() {
		return (Boolean) eGet(RelationsPackage.Literals.ASSOCIATION__IS_REVERSE_FUNCTIONAL, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsReverseFunctional(Boolean newIsReverseFunctional) {
		eSet(RelationsPackage.Literals.ASSOCIATION__IS_REVERSE_FUNCTIONAL, newIsReverseFunctional);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetIsAntiReflexive() {
		eUnset(RelationsPackage.Literals.ASSOCIATION__IS_ANTI_REFLEXIVE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetIsAntiReflexive() {
		return eIsSet(RelationsPackage.Literals.ASSOCIATION__IS_ANTI_REFLEXIVE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean getIsAntiSymmetric() {
		return (Boolean) eGet(RelationsPackage.Literals.ASSOCIATION__IS_ANTI_SYMMETRIC, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsAntiSymmetric(Boolean newIsAntiSymmetric) {
		eSet(RelationsPackage.Literals.ASSOCIATION__IS_ANTI_SYMMETRIC, newIsAntiSymmetric);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetIsFunctional() {
		eUnset(RelationsPackage.Literals.ASSOCIATION__IS_FUNCTIONAL);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetIsFunctional() {
		return eIsSet(RelationsPackage.Literals.ASSOCIATION__IS_FUNCTIONAL);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean getIsNavigable() {
		return (Boolean) eGet(RelationsPackage.Literals.ASSOCIATION__IS_NAVIGABLE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsNavigable(Boolean newIsNavigable) {
		eSet(RelationsPackage.Literals.ASSOCIATION__IS_NAVIGABLE, newIsNavigable);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetIsNavigable() {
		eUnset(RelationsPackage.Literals.ASSOCIATION__IS_NAVIGABLE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetIsNavigable() {
		return eIsSet(RelationsPackage.Literals.ASSOCIATION__IS_NAVIGABLE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean getIsReflexive() {
		return (Boolean) eGet(RelationsPackage.Literals.ASSOCIATION__IS_REFLEXIVE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsReflexive(Boolean newIsReflexive) {
		eSet(RelationsPackage.Literals.ASSOCIATION__IS_REFLEXIVE, newIsReflexive);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetIsReverseFunctional() {
		eUnset(RelationsPackage.Literals.ASSOCIATION__IS_REVERSE_FUNCTIONAL);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetIsReverseFunctional() {
		return eIsSet(RelationsPackage.Literals.ASSOCIATION__IS_REVERSE_FUNCTIONAL);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean getIsSymmetric() {
		return (Boolean) eGet(RelationsPackage.Literals.ASSOCIATION__IS_SYMMETRIC, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsSymmetric(Boolean newIsSymmetric) {
		eSet(RelationsPackage.Literals.ASSOCIATION__IS_SYMMETRIC, newIsSymmetric);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetIsTranslationAssociation() {
		eUnset(RelationsPackage.Literals.ASSOCIATION__IS_TRANSLATION_ASSOCIATION);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetIsTranslationAssociation() {
		return eIsSet(RelationsPackage.Literals.ASSOCIATION__IS_TRANSLATION_ASSOCIATION);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTargetCodingScheme() {
		return (String) eGet(RelationsPackage.Literals.ASSOCIATION__TARGET_CODING_SCHEME, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTargetCodingScheme(String newTargetCodingScheme) {
		eSet(RelationsPackage.Literals.ASSOCIATION__TARGET_CODING_SCHEME, newTargetCodingScheme);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getSourceConcept() {
		return (List) eGet(RelationsPackage.Literals.ASSOCIATION__SOURCE_CONCEPT, true);
	}

	////////////////////////////////////////////////////////////
	// ************** BEGIN NON-GENERATED CODE ************** //
	//                                                        //
	// ****************************************************** //
	////////////////////////////////////////////////////////////

	/* (non-Javadoc)
	 * @see org.eclipse.emf.ecore.EObject#eGet(org.eclipse.emf.ecore.EStructuralFeature, boolean)
	 */
	public Object eGet(EStructuralFeature eFeature, boolean resolve) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
		// Control the makeup of the concept list to allow paging, etc
		case RelationsPackage.ASSOCIATION__SOURCE_CONCEPT: {
			if (!eIsSet(eFeature) && internalIsDirty(eFeature)) {
				EList sourceConcept = new LgEnhancedEListImpl(AssociationInstance.class, this,
						RelationsPackage.ASSOCIATION__SOURCE_CONCEPT);

				internalMarkClean(eFeature);
				eSettings().dynamicSet(eDynamicFeatureID(eFeature), sourceConcept);
				if (resolve)
					try {
						resolveFeature(eFeature);
					} catch (ResolveException e) {
						throw new UnexpectedException(e);
					}
			}
		}
		}
		return super.eGet(eFeature, resolve);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.emf.ecore.EObject#eSet(org.eclipse.emf.ecore.EStructuralFeature, java.lang.Object)
	 * @non-generated
	 */
	public void eSet(EStructuralFeature eFeature, Object newValue) {
		super.eSet(eFeature, newValue);

		switch (eDerivedStructuralFeatureID(eFeature)) {
		// Notify associated targets of changes to the encapsulating scheme
		case RelationsPackage.ASSOCIATION__TARGET_CODING_SCHEME: {
			if (eNotificationRequired())
				for (Iterator targets = getContent(AssociationTargetImpl.class, 0); targets.hasNext();) {
					AssociationTargetImpl target = (AssociationTargetImpl) targets.next();
					String schemeName = target.getTargetCodingScheme();
					if (schemeName == null || schemeName.length() == 0)
						target.associationTargetSchemeChanged();
				}
			break;
		}
		}
	}

	/**
	 * @see org.LexGrid.emf.base.LgCodedObj#getConceptCode()
	 * @non-generated
	 */
	public String getConceptCode() {
		return getAssociation();
	}

	/**
	 * @see org.LexGrid.emf.base.LgModelObj#getDisplayName()
	 * @non-generated
	 */
	public String getPreferredDisplayName() {
		String name = super.getPreferredDisplayName();
		String entityDescription = getEntityDescription();
		if (entityDescription != null && !entityDescription.equals(name)) {
			return new StringBuffer(128).append(name).append(": ").append(entityDescription).toString();
		}
		return name;
	}

} //AssociationImpl