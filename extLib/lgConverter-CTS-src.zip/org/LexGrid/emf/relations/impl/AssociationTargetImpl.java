/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.relations.impl;

import org.LexGrid.emf.codingSchemes.CodingSchemeType;
import org.LexGrid.emf.codingSchemes.util.CodingschemesUtil;
import org.LexGrid.emf.concepts.CodedEntry;
import org.LexGrid.emf.concepts.util.ConceptsUtil;
import org.LexGrid.emf.relations.Association;
import org.LexGrid.emf.relations.AssociationInstance;
import org.LexGrid.emf.relations.AssociationTarget;
import org.LexGrid.emf.relations.RelationsPackage;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Association Target</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.LexGrid.emf.relations.impl.AssociationTargetImpl#getTargetCodingScheme <em>Target Coding Scheme</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.impl.AssociationTargetImpl#getTargetConcept <em>Target Concept</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class AssociationTargetImpl extends AssociatableElementImpl implements AssociationTarget {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AssociationTargetImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return RelationsPackage.Literals.ASSOCIATION_TARGET;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTargetCodingScheme() {
		return (String) eGet(RelationsPackage.Literals.ASSOCIATION_TARGET__TARGET_CODING_SCHEME, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTargetCodingScheme(String newTargetCodingScheme) {
		eSet(RelationsPackage.Literals.ASSOCIATION_TARGET__TARGET_CODING_SCHEME, newTargetCodingScheme);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTargetConcept() {
		return (String) eGet(RelationsPackage.Literals.ASSOCIATION_TARGET__TARGET_CONCEPT, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTargetConcept(String newTargetConcept) {
		eSet(RelationsPackage.Literals.ASSOCIATION_TARGET__TARGET_CONCEPT, newTargetConcept);
	}

	////////////////////////////////////////////////////////////
	// ************** BEGIN NON-GENERATED CODE ************** //
	//                                                        //
	// ****************************************************** //
	////////////////////////////////////////////////////////////
	private String textDesc = null;

	/**
	 * Package-level interface for dependent targets that do not
	 * specify a target scheme to react to changes that occur
	 * to the coding scheme of the association container.
	 */
	void associationTargetSchemeChanged() {
		textDesc = null;
		eNotify(new ENotificationImpl(this, Notification.SET, RelationsPackage.eINSTANCE
				.getAssociationTarget_TargetCodingScheme(), null, null));
	}

	/**
	 * Returns the association class containing this target; null if not available.
	 * @return Association
	 * @non-generated
	 */
	protected Association getAssociation() {
		return (Association) getContainer(Association.class, 1);
	}

	/**
	 * Returns the association instance containing this target; null if not available.
	 * @return AssociationInstance
	 * @non-generated
	 */
	protected AssociationInstance getAssociationInstance() {
		return (AssociationInstance) getContainer(AssociationInstance.class, 0);
	}

	/**
	 * @see org.LexGrid.emf.base.LgCodedObj#getConceptCode()
	 * @non-generated
	 */
	public String getConceptCode() {
		return getTargetConcept();
	}

	/**
	 * @see org.LexGrid.emf.base.LgModelObj#getTextDescription()
	 * @non-generated
	 */
	public String getTextDescription() {
		String targetConcept = (String) eGet(RelationsPackage.eINSTANCE.getAssociationTarget_TargetConcept(), false);
		if (textDesc == null && targetConcept != null) {
			String schemeName = getTargetCodingScheme();
			if (schemeName == null || schemeName.length() == 0) {
				Association assoc = getAssociation();
				if (assoc != null)
					schemeName = assoc.getTargetCodingScheme();
			}
			CodedEntry ce = null;
			if (schemeName == null || schemeName.length() == 0)
				ce = ConceptsUtil.resolveCodedEntry(this, targetConcept);
			else {
				CodingSchemeType scheme = CodingschemesUtil.resolveCodingScheme(this, schemeName);
				if (scheme != null)
					ce = ConceptsUtil.resolveCodedEntry(scheme, targetConcept);
			}
			if (ce != null)
				textDesc = ce.getPreferredTextDescription();
		}
		return textDesc;
	}

}