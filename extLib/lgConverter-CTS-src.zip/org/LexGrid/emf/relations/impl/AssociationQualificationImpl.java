/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.relations.impl;

import org.LexGrid.emf.base.impl.LgModelObjImpl;
import org.LexGrid.emf.relations.AssociationQualification;
import org.LexGrid.emf.relations.RelationsPackage;
import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Association Qualification</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.LexGrid.emf.relations.impl.AssociationQualificationImpl#getAssociationQualifierValue <em>Association Qualifier Value</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.impl.AssociationQualificationImpl#getAssociationQualifier <em>Association Qualifier</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class AssociationQualificationImpl extends LgModelObjImpl implements AssociationQualification {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AssociationQualificationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return RelationsPackage.Literals.ASSOCIATION_QUALIFICATION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getAssociationQualifierValue() {
		return (String) eGet(RelationsPackage.Literals.ASSOCIATION_QUALIFICATION__ASSOCIATION_QUALIFIER_VALUE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAssociationQualifierValue(String newAssociationQualifierValue) {
		eSet(RelationsPackage.Literals.ASSOCIATION_QUALIFICATION__ASSOCIATION_QUALIFIER_VALUE,
				newAssociationQualifierValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getAssociationQualifier() {
		return (String) eGet(RelationsPackage.Literals.ASSOCIATION_QUALIFICATION__ASSOCIATION_QUALIFIER, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAssociationQualifier(String newAssociationQualifier) {
		eSet(RelationsPackage.Literals.ASSOCIATION_QUALIFICATION__ASSOCIATION_QUALIFIER, newAssociationQualifier);
	}

	////////////////////////////////////////////////////////////
	// ************** BEGIN NON-GENERATED CODE ************** //
	//                                                        //
	// ****************************************************** //
	////////////////////////////////////////////////////////////

	/**
	 * @see org.LexGrid.emf.base.LgModelObj#getPreferredTextDescription()
	 * @non-generated
	 */
	public String getPreferredTextDescription() {
		String associationQualifier = (String) eGet(RelationsPackage.eINSTANCE
				.getAssociationQualification_AssociationQualifier(), false);
		String associationQualifierValue = (String) eGet(RelationsPackage.eINSTANCE
				.getAssociationQualification_AssociationQualifierValue(), false);

		if (associationQualifier == null)
			return (associationQualifierValue == null) ? getPreferredDisplayNameDefault() : associationQualifierValue;

		return (associationQualifierValue == null) ? associationQualifier : new StringBuffer(128).append(
				associationQualifier).append(" [").append(associationQualifierValue).append(']').toString();
	}

} //AssociationQualificationImpl