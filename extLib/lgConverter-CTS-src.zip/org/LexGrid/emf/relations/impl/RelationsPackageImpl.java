/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.relations.impl;

import org.LexGrid.emf.base.impl.LgAttributeImpl;
import org.LexGrid.emf.base.impl.LgReferenceImpl;
import org.LexGrid.emf.builtins.BuiltinsPackage;
import org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl;
import org.LexGrid.emf.codingSchemes.CodingschemesPackage;
import org.LexGrid.emf.codingSchemes.impl.CodingschemesPackageImpl;
import org.LexGrid.emf.commonTypes.CommontypesPackage;
import org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl;
import org.LexGrid.emf.concepts.ConceptsPackage;
import org.LexGrid.emf.concepts.impl.ConceptsPackageImpl;
import org.LexGrid.emf.history.NCIHistoryPackage;
import org.LexGrid.emf.history.impl.NCIHistoryPackageImpl;
import org.LexGrid.emf.ldap.LdapPackage;
import org.LexGrid.emf.ldap.impl.LdapPackageImpl;
import org.LexGrid.emf.naming.NamingPackage;
import org.LexGrid.emf.naming.impl.NamingPackageImpl;
import org.LexGrid.emf.relations.AssociatableElement;
import org.LexGrid.emf.relations.Association;
import org.LexGrid.emf.relations.AssociationData;
import org.LexGrid.emf.relations.AssociationInstance;
import org.LexGrid.emf.relations.AssociationQualification;
import org.LexGrid.emf.relations.AssociationTarget;
import org.LexGrid.emf.relations.DocumentRoot;
import org.LexGrid.emf.relations.Relations;
import org.LexGrid.emf.relations.RelationsFactory;
import org.LexGrid.emf.relations.RelationsPackage;
import org.LexGrid.emf.service.ServiceTypePackage;
import org.LexGrid.emf.service.impl.ServiceTypePackageImpl;
import org.LexGrid.emf.valueDomains.ValuedomainsPackage;
import org.LexGrid.emf.valueDomains.impl.ValuedomainsPackageImpl;
import org.LexGrid.emf.versions.VersionsPackage;
import org.LexGrid.emf.versions.impl.VersionsPackageImpl;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class RelationsPackageImpl extends EPackageImpl implements RelationsPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass relationsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass associationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass associationInstanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass associationTargetEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass documentRootEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass associatableElementEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass associationQualificationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass associationDataEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see org.LexGrid.emf.relations.RelationsPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private RelationsPackageImpl() {
		super(eNS_URI, RelationsFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this
	 * model, and for any others upon which it depends.  Simple
	 * dependencies are satisfied by calling this method on all
	 * dependent packages before doing anything else.  This method drives
	 * initialization for interdependent packages directly, in parallel
	 * with this package, itself.
	 * <p>Of this package and its interdependencies, all packages which
	 * have not yet been registered by their URI values are first created
	 * and registered.  The packages are then initialized in two steps:
	 * meta-model objects for all of the packages are created before any
	 * are initialized, since one package's meta-model objects may refer to
	 * those of another.
	 * <p>Invocation of this method will not affect any packages that have
	 * already been initialized.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static RelationsPackage init() {
		if (isInited)
			return (RelationsPackage) EPackage.Registry.INSTANCE.getEPackage(RelationsPackage.eNS_URI);

		// Obtain or create and register package
		RelationsPackageImpl theRelationsPackage = (RelationsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(eNS_URI) instanceof RelationsPackageImpl ? EPackage.Registry.INSTANCE.getEPackage(eNS_URI)
				: new RelationsPackageImpl());

		isInited = true;

		// Obtain or create and register interdependencies
		ConceptsPackageImpl theConceptsPackage = (ConceptsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(ConceptsPackage.eNS_URI) instanceof ConceptsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(ConceptsPackage.eNS_URI) : ConceptsPackage.eINSTANCE);
		NCIHistoryPackageImpl theNCIHistoryPackage = (NCIHistoryPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(NCIHistoryPackage.eNS_URI) instanceof NCIHistoryPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(NCIHistoryPackage.eNS_URI) : NCIHistoryPackage.eINSTANCE);
		VersionsPackageImpl theVersionsPackage = (VersionsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(VersionsPackage.eNS_URI) instanceof VersionsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(VersionsPackage.eNS_URI) : VersionsPackage.eINSTANCE);
		CodingschemesPackageImpl theCodingschemesPackage = (CodingschemesPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(CodingschemesPackage.eNS_URI) instanceof CodingschemesPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(CodingschemesPackage.eNS_URI)
				: CodingschemesPackage.eINSTANCE);
		LdapPackageImpl theLdapPackage = (LdapPackageImpl) (EPackage.Registry.INSTANCE.getEPackage(LdapPackage.eNS_URI) instanceof LdapPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(LdapPackage.eNS_URI)
				: LdapPackage.eINSTANCE);
		BuiltinsPackageImpl theBuiltinsPackage = (BuiltinsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(BuiltinsPackage.eNS_URI) instanceof BuiltinsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(BuiltinsPackage.eNS_URI) : BuiltinsPackage.eINSTANCE);
		ValuedomainsPackageImpl theValuedomainsPackage = (ValuedomainsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(ValuedomainsPackage.eNS_URI) instanceof ValuedomainsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(ValuedomainsPackage.eNS_URI)
				: ValuedomainsPackage.eINSTANCE);
		CommontypesPackageImpl theCommontypesPackage = (CommontypesPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(CommontypesPackage.eNS_URI) instanceof CommontypesPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(CommontypesPackage.eNS_URI) : CommontypesPackage.eINSTANCE);
		ServiceTypePackageImpl theServiceTypePackage = (ServiceTypePackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(ServiceTypePackage.eNS_URI) instanceof ServiceTypePackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(ServiceTypePackage.eNS_URI) : ServiceTypePackage.eINSTANCE);
		NamingPackageImpl theNamingPackage = (NamingPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(NamingPackage.eNS_URI) instanceof NamingPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(NamingPackage.eNS_URI) : NamingPackage.eINSTANCE);

		// Create package meta-data objects
		theRelationsPackage.createPackageContents();
		theConceptsPackage.createPackageContents();
		theNCIHistoryPackage.createPackageContents();
		theVersionsPackage.createPackageContents();
		theCodingschemesPackage.createPackageContents();
		theLdapPackage.createPackageContents();
		theBuiltinsPackage.createPackageContents();
		theValuedomainsPackage.createPackageContents();
		theCommontypesPackage.createPackageContents();
		theServiceTypePackage.createPackageContents();
		theNamingPackage.createPackageContents();

		// Initialize created meta-data
		theRelationsPackage.initializePackageContents();
		theConceptsPackage.initializePackageContents();
		theNCIHistoryPackage.initializePackageContents();
		theVersionsPackage.initializePackageContents();
		theCodingschemesPackage.initializePackageContents();
		theLdapPackage.initializePackageContents();
		theBuiltinsPackage.initializePackageContents();
		theValuedomainsPackage.initializePackageContents();
		theCommontypesPackage.initializePackageContents();
		theServiceTypePackage.initializePackageContents();
		theNamingPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theRelationsPackage.freeze();

		return theRelationsPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRelations() {
		return relationsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRelations_Dc() {
		return (EAttribute) relationsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRelations_IsNative() {
		return (EAttribute) relationsEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRelations_Source() {
		return (EReference) relationsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRelations_Association() {
		return (EReference) relationsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAssociation() {
		return associationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAssociation_Association() {
		return (EAttribute) associationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAssociation_ForwardName() {
		return (EAttribute) associationEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAssociation_Inverse() {
		return (EAttribute) associationEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAssociation_ReverseName() {
		return (EAttribute) associationEClass.getEStructuralFeatures().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAssociation_IsTransitive() {
		return (EAttribute) associationEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAssociation_IsAntiTransitive() {
		return (EAttribute) associationEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAssociation_IsSymmetric() {
		return (EAttribute) associationEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAssociation_IsAntiSymmetric() {
		return (EAttribute) associationEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAssociation_IsReflexive() {
		return (EAttribute) associationEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAssociation_IsAntiReflexive() {
		return (EAttribute) associationEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAssociation_IsFunctional() {
		return (EAttribute) associationEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAssociation_IsNavigable() {
		return (EAttribute) associationEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAssociation_IsReverseFunctional() {
		return (EAttribute) associationEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAssociation_IsTranslationAssociation() {
		return (EAttribute) associationEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAssociation_TargetCodingScheme() {
		return (EAttribute) associationEClass.getEStructuralFeatures().get(15);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAssociation_SourceConcept() {
		return (EReference) associationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAssociationInstance() {
		return associationInstanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAssociationInstance_SourceCodingScheme() {
		return (EAttribute) associationInstanceEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAssociationInstance_SourceConcept() {
		return (EAttribute) associationInstanceEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAssociationInstance_TargetConcept() {
		return (EReference) associationInstanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAssociationInstance_TargetDataValue() {
		return (EReference) associationInstanceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAssociationTarget() {
		return associationTargetEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAssociationTarget_TargetCodingScheme() {
		return (EAttribute) associationTargetEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAssociationTarget_TargetConcept() {
		return (EAttribute) associationTargetEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDocumentRoot() {
		return documentRootEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDocumentRoot_Mixed() {
		return (EAttribute) documentRootEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_XMLNSPrefixMap() {
		return (EReference) documentRootEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_XSISchemaLocation() {
		return (EReference) documentRootEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_AssociationData() {
		return (EReference) documentRootEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_AssociationTarget() {
		return (EReference) documentRootEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAssociatableElement() {
		return associatableElementEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAssociatableElement_AssociationQualification() {
		return (EReference) associatableElementEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAssociationQualification() {
		return associationQualificationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAssociationQualification_AssociationQualifierValue() {
		return (EAttribute) associationQualificationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAssociationQualification_AssociationQualifier() {
		return (EAttribute) associationQualificationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAssociationData() {
		return associationDataEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAssociationData_Id() {
		return (EAttribute) associationDataEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAssociationData_DataValue() {
		return (EAttribute) associationDataEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RelationsFactory getRelationsFactory() {
		return (RelationsFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		associatableElementEClass = createEClass(ASSOCIATABLE_ELEMENT);
		createEReference(associatableElementEClass, ASSOCIATABLE_ELEMENT__ASSOCIATION_QUALIFICATION);

		associationEClass = createEClass(ASSOCIATION);
		createEReference(associationEClass, ASSOCIATION__SOURCE_CONCEPT);
		createEAttribute(associationEClass, ASSOCIATION__ASSOCIATION);
		createEAttribute(associationEClass, ASSOCIATION__FORWARD_NAME);
		createEAttribute(associationEClass, ASSOCIATION__INVERSE);
		createEAttribute(associationEClass, ASSOCIATION__IS_ANTI_REFLEXIVE);
		createEAttribute(associationEClass, ASSOCIATION__IS_ANTI_SYMMETRIC);
		createEAttribute(associationEClass, ASSOCIATION__IS_ANTI_TRANSITIVE);
		createEAttribute(associationEClass, ASSOCIATION__IS_FUNCTIONAL);
		createEAttribute(associationEClass, ASSOCIATION__IS_NAVIGABLE);
		createEAttribute(associationEClass, ASSOCIATION__IS_REFLEXIVE);
		createEAttribute(associationEClass, ASSOCIATION__IS_REVERSE_FUNCTIONAL);
		createEAttribute(associationEClass, ASSOCIATION__IS_SYMMETRIC);
		createEAttribute(associationEClass, ASSOCIATION__IS_TRANSITIVE);
		createEAttribute(associationEClass, ASSOCIATION__IS_TRANSLATION_ASSOCIATION);
		createEAttribute(associationEClass, ASSOCIATION__REVERSE_NAME);
		createEAttribute(associationEClass, ASSOCIATION__TARGET_CODING_SCHEME);

		associationDataEClass = createEClass(ASSOCIATION_DATA);
		createEAttribute(associationDataEClass, ASSOCIATION_DATA__DATA_VALUE);
		createEAttribute(associationDataEClass, ASSOCIATION_DATA__ID);

		associationInstanceEClass = createEClass(ASSOCIATION_INSTANCE);
		createEReference(associationInstanceEClass, ASSOCIATION_INSTANCE__TARGET_CONCEPT);
		createEReference(associationInstanceEClass, ASSOCIATION_INSTANCE__TARGET_DATA_VALUE);
		createEAttribute(associationInstanceEClass, ASSOCIATION_INSTANCE__SOURCE_CODING_SCHEME);
		createEAttribute(associationInstanceEClass, ASSOCIATION_INSTANCE__SOURCE_CONCEPT);

		associationQualificationEClass = createEClass(ASSOCIATION_QUALIFICATION);
		createEAttribute(associationQualificationEClass, ASSOCIATION_QUALIFICATION__ASSOCIATION_QUALIFIER_VALUE);
		createEAttribute(associationQualificationEClass, ASSOCIATION_QUALIFICATION__ASSOCIATION_QUALIFIER);

		associationTargetEClass = createEClass(ASSOCIATION_TARGET);
		createEAttribute(associationTargetEClass, ASSOCIATION_TARGET__TARGET_CODING_SCHEME);
		createEAttribute(associationTargetEClass, ASSOCIATION_TARGET__TARGET_CONCEPT);

		documentRootEClass = createEClass(DOCUMENT_ROOT);
		createEAttribute(documentRootEClass, DOCUMENT_ROOT__MIXED);
		createEReference(documentRootEClass, DOCUMENT_ROOT__XMLNS_PREFIX_MAP);
		createEReference(documentRootEClass, DOCUMENT_ROOT__XSI_SCHEMA_LOCATION);
		createEReference(documentRootEClass, DOCUMENT_ROOT__ASSOCIATION_DATA);
		createEReference(documentRootEClass, DOCUMENT_ROOT__ASSOCIATION_TARGET);

		relationsEClass = createEClass(RELATIONS);
		createEReference(relationsEClass, RELATIONS__SOURCE);
		createEReference(relationsEClass, RELATIONS__ASSOCIATION);
		createEAttribute(relationsEClass, RELATIONS__DC);
		createEAttribute(relationsEClass, RELATIONS__IS_NATIVE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContentsGen() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		CommontypesPackage theCommontypesPackage = (CommontypesPackage) EPackage.Registry.INSTANCE
				.getEPackage(CommontypesPackage.eNS_URI);
		BuiltinsPackage theBuiltinsPackage = (BuiltinsPackage) EPackage.Registry.INSTANCE
				.getEPackage(BuiltinsPackage.eNS_URI);

		// Add supertypes to classes
		associatableElementEClass.getESuperTypes().add(theCommontypesPackage.getVersionable());
		associationEClass.getESuperTypes().add(theCommontypesPackage.getDescribable());
		associationDataEClass.getESuperTypes().add(this.getAssociatableElement());
		associationTargetEClass.getESuperTypes().add(this.getAssociatableElement());
		relationsEClass.getESuperTypes().add(theCommontypesPackage.getDescribable());

		// Initialize classes and features; add operations and parameters
		initEClass(associatableElementEClass, AssociatableElement.class, "AssociatableElement", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getAssociatableElement_AssociationQualification(), this.getAssociationQualification(), null,
				"associationQualification", null, 0, -1, AssociatableElement.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(associationEClass, Association.class, "Association", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getAssociation_SourceConcept(), this.getAssociationInstance(), null, "sourceConcept", null, 0,
				-1, Association.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAssociation_Association(), theBuiltinsPackage.getLocalId(), "association", null, 1, 1,
				Association.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getAssociation_ForwardName(), theBuiltinsPackage.getTsCaseIgnoreIA5String(), "forwardName",
				null, 1, 1, Association.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				!IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAssociation_Inverse(), theBuiltinsPackage.getLocalId(), "inverse", null, 0, 1,
				Association.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getAssociation_IsAntiReflexive(), theBuiltinsPackage.getTsBooleanObject(), "isAntiReflexive",
				null, 0, 1, Association.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID,
				!IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAssociation_IsAntiSymmetric(), theBuiltinsPackage.getTsBooleanObject(), "isAntiSymmetric",
				null, 0, 1, Association.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID,
				!IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAssociation_IsAntiTransitive(), theBuiltinsPackage.getTsBooleanObject(), "isAntiTransitive",
				null, 0, 1, Association.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID,
				!IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAssociation_IsFunctional(), theBuiltinsPackage.getTsBooleanObject(), "isFunctional", null, 0,
				1, Association.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getAssociation_IsNavigable(), theBuiltinsPackage.getTsBooleanObject(), "isNavigable", "true", 0,
				1, Association.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getAssociation_IsReflexive(), theBuiltinsPackage.getTsBooleanObject(), "isReflexive", null, 0,
				1, Association.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getAssociation_IsReverseFunctional(), theBuiltinsPackage.getTsBooleanObject(),
				"isReverseFunctional", null, 0, 1, Association.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAssociation_IsSymmetric(), theBuiltinsPackage.getTsBooleanObject(), "isSymmetric", null, 0,
				1, Association.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getAssociation_IsTransitive(), theBuiltinsPackage.getTsBooleanObject(), "isTransitive", null, 0,
				1, Association.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getAssociation_IsTranslationAssociation(), theBuiltinsPackage.getTsBooleanObject(),
				"isTranslationAssociation", null, 0, 1, Association.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAssociation_ReverseName(), theBuiltinsPackage.getTsCaseIgnoreIA5String(), "reverseName",
				null, 0, 1, Association.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				!IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAssociation_TargetCodingScheme(), theBuiltinsPackage.getLocalId(), "targetCodingScheme",
				null, 0, 1, Association.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				!IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(associationDataEClass, AssociationData.class, "AssociationData", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAssociationData_DataValue(), theCommontypesPackage.getText(), "dataValue", null, 1, 1,
				AssociationData.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getAssociationData_Id(), theCommontypesPackage.getId(), "id", null, 1, 1, AssociationData.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(associationInstanceEClass, AssociationInstance.class, "AssociationInstance", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getAssociationInstance_TargetConcept(), this.getAssociationTarget(), null, "targetConcept",
				null, 0, -1, AssociationInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAssociationInstance_TargetDataValue(), this.getAssociationData(), null, "targetDataValue",
				null, 0, -1, AssociationInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAssociationInstance_SourceCodingScheme(), theBuiltinsPackage.getLocalId(),
				"sourceCodingScheme", null, 0, 1, AssociationInstance.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAssociationInstance_SourceConcept(), theCommontypesPackage.getConceptCode(), "sourceConcept",
				null, 1, 1, AssociationInstance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE,
				!IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(associationQualificationEClass, AssociationQualification.class, "AssociationQualification",
				!IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAssociationQualification_AssociationQualifierValue(), theCommontypesPackage.getText(),
				"associationQualifierValue", null, 1, 1, AssociationQualification.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAssociationQualification_AssociationQualifier(), theBuiltinsPackage.getLocalId(),
				"associationQualifier", null, 1, 1, AssociationQualification.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(associationTargetEClass, AssociationTarget.class, "AssociationTarget", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAssociationTarget_TargetCodingScheme(), theBuiltinsPackage.getLocalId(),
				"targetCodingScheme", null, 0, 1, AssociationTarget.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAssociationTarget_TargetConcept(), theCommontypesPackage.getConceptCode(), "targetConcept",
				null, 1, 1, AssociationTarget.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE,
				!IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(documentRootEClass, DocumentRoot.class, "DocumentRoot", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDocumentRoot_Mixed(), ecorePackage.getEFeatureMapEntry(), "mixed", null, 0, -1, null,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_XMLNSPrefixMap(), ecorePackage.getEStringToStringMapEntry(), null,
				"xMLNSPrefixMap", null, 0, -1, null, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_XSISchemaLocation(), ecorePackage.getEStringToStringMapEntry(), null,
				"xSISchemaLocation", null, 0, -1, null, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_AssociationData(), this.getAssociationData(), null, "associationData", null, 0,
				-2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_AssociationTarget(), this.getAssociationTarget(), null, "associationTarget",
				null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);

		initEClass(relationsEClass, Relations.class, "Relations", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getRelations_Source(), theCommontypesPackage.getSource(), null, "source", null, 0, -1,
				Relations.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRelations_Association(), this.getAssociation(), null, "association", null, 1, -1,
				Relations.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRelations_Dc(), theCommontypesPackage.getDc(), "dc", null, 1, 1, Relations.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRelations_IsNative(), theBuiltinsPackage.getTsBooleanObject(), "isNative", null, 0, 1,
				Relations.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// null
		createNullAnnotations();
		// http:///org/eclipse/emf/ecore/util/ExtendedMetaData
		createExtendedMetaDataAnnotations();
	}

	/**
	 * Initializes the annotations for <b>null</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createNullAnnotations() {
		String source = null;
		addAnnotation(
				associatableElementEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n                                <ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.7.85</ldap:oid>\r\n                        " });
		addAnnotation(
				associationEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n                                <ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.7.12</ldap:oid>\r\n                                <ldap:rdn xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">association</ldap:rdn>\r\n                                <ldap:objectClass xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">associationClass</ldap:objectClass>\r\n                        " });
		addAnnotation(
				associationDataEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n                                <ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.7.89</ldap:oid>\r\n                                <ldap:rdn xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">id</ldap:rdn>\r\n                        " });
		addAnnotation(
				associationInstanceEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n                                <ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.7.13</ldap:oid>\r\n                        " });
		addAnnotation(
				associationQualificationEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n                                <ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.7.90</ldap:oid>\r\n                                <ldap:rdn xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">associationQualifier</ldap:rdn>\r\n                        " });
		addAnnotation(
				associationTargetEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n                                <ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.7.15</ldap:oid>\r\n                                <ldap:rdn xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">targetConcept</ldap:rdn>\r\n                        " });
		addAnnotation(
				relationsEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n                                <ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.7.10</ldap:oid>\r\n                                <ldap:rdn xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">dc</ldap:rdn>\r\n                        " });
	}

	/**
	 * Initializes the annotations for <b>http:///org/eclipse/emf/ecore/util/ExtendedMetaData</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createExtendedMetaDataAnnotations() {
		String source = "http:///org/eclipse/emf/ecore/util/ExtendedMetaData";
		addAnnotation(associatableElementEClass, source, new String[] { "name", "associatableElement", "kind",
				"elementOnly" });
		addAnnotation(getAssociatableElement_AssociationQualification(), source, new String[] { "kind", "element",
				"name", "associationQualification", "namespace", "##targetNamespace" });
		addAnnotation(associationEClass, source, new String[] { "name", "association", "kind", "elementOnly" });
		addAnnotation(getAssociation_SourceConcept(), source, new String[] { "kind", "element", "name",
				"sourceConcept", "namespace", "##targetNamespace" });
		addAnnotation(getAssociation_Association(), source, new String[] { "kind", "attribute", "name", "association" });
		addAnnotation(getAssociation_ForwardName(), source, new String[] { "kind", "attribute", "name", "forwardName" });
		addAnnotation(getAssociation_Inverse(), source, new String[] { "kind", "attribute", "name", "inverse" });
		addAnnotation(getAssociation_IsAntiReflexive(), source, new String[] { "kind", "attribute", "name",
				"isAntiReflexive" });
		addAnnotation(getAssociation_IsAntiSymmetric(), source, new String[] { "kind", "attribute", "name",
				"isAntiSymmetric" });
		addAnnotation(getAssociation_IsAntiTransitive(), source, new String[] { "kind", "attribute", "name",
				"isAntiTransitive" });
		addAnnotation(getAssociation_IsFunctional(), source,
				new String[] { "kind", "attribute", "name", "isFunctional" });
		addAnnotation(getAssociation_IsNavigable(), source, new String[] { "kind", "attribute", "name", "isNavigable" });
		addAnnotation(getAssociation_IsReflexive(), source, new String[] { "kind", "attribute", "name", "isReflexive" });
		addAnnotation(getAssociation_IsReverseFunctional(), source, new String[] { "kind", "attribute", "name",
				"isReverseFunctional" });
		addAnnotation(getAssociation_IsSymmetric(), source, new String[] { "kind", "attribute", "name", "isSymmetric" });
		addAnnotation(getAssociation_IsTransitive(), source,
				new String[] { "kind", "attribute", "name", "isTransitive" });
		addAnnotation(getAssociation_IsTranslationAssociation(), source, new String[] { "kind", "attribute", "name",
				"isTranslationAssociation" });
		addAnnotation(getAssociation_ReverseName(), source, new String[] { "kind", "attribute", "name", "reverseName" });
		addAnnotation(getAssociation_TargetCodingScheme(), source, new String[] { "kind", "attribute", "name",
				"targetCodingScheme" });
		addAnnotation(associationDataEClass, source, new String[] { "name", "associationData", "kind", "elementOnly" });
		addAnnotation(getAssociationData_DataValue(), source, new String[] { "kind", "elementWildcard", "wildcards",
				"##other", "name", ":4", "processing", "lax" });
		addAnnotation(getAssociationData_Id(), source, new String[] { "kind", "attribute", "name", "id" });
		addAnnotation(associationInstanceEClass, source, new String[] { "name", "associationInstance", "kind",
				"elementOnly" });
		addAnnotation(getAssociationInstance_TargetConcept(), source, new String[] { "kind", "element", "name",
				"targetConcept", "namespace", "##targetNamespace" });
		addAnnotation(getAssociationInstance_TargetDataValue(), source, new String[] { "kind", "element", "name",
				"targetDataValue", "namespace", "##targetNamespace" });
		addAnnotation(getAssociationInstance_SourceCodingScheme(), source, new String[] { "kind", "attribute", "name",
				"sourceCodingScheme" });
		addAnnotation(getAssociationInstance_SourceConcept(), source, new String[] { "kind", "attribute", "name",
				"sourceConcept" });
		addAnnotation(associationQualificationEClass, source, new String[] { "name", "associationQualification",
				"kind", "mixed" });
		addAnnotation(getAssociationQualification_AssociationQualifierValue(), source, new String[] { "kind",
				"elementWildcard", "wildcards", "##other", "name", ":1", "processing", "lax" });
		addAnnotation(getAssociationQualification_AssociationQualifier(), source, new String[] { "kind", "attribute",
				"name", "associationQualifier" });
		addAnnotation(associationTargetEClass, source, new String[] { "name", "associationTarget", "kind",
				"elementOnly" });
		addAnnotation(getAssociationTarget_TargetCodingScheme(), source, new String[] { "kind", "attribute", "name",
				"targetCodingScheme" });
		addAnnotation(getAssociationTarget_TargetConcept(), source, new String[] { "kind", "attribute", "name",
				"targetConcept" });
		addAnnotation(documentRootEClass, source, new String[] { "name", "", "kind", "mixed" });
		addAnnotation(getDocumentRoot_Mixed(), source, new String[] { "kind", "elementWildcard", "name", ":mixed" });
		addAnnotation(getDocumentRoot_XMLNSPrefixMap(), source, new String[] { "kind", "attribute", "name",
				"xmlns:prefix" });
		addAnnotation(getDocumentRoot_XSISchemaLocation(), source, new String[] { "kind", "attribute", "name",
				"xsi:schemaLocation" });
		addAnnotation(getDocumentRoot_AssociationData(), source, new String[] { "kind", "element", "name",
				"associationData", "namespace", "##targetNamespace" });
		addAnnotation(getDocumentRoot_AssociationTarget(), source, new String[] { "kind", "element", "name",
				"associationTarget", "namespace", "##targetNamespace" });
		addAnnotation(relationsEClass, source, new String[] { "name", "relations", "kind", "elementOnly" });
		addAnnotation(getRelations_Source(), source, new String[] { "kind", "element", "name", "source", "namespace",
				"##targetNamespace" });
		addAnnotation(getRelations_Association(), source, new String[] { "kind", "element", "name", "association",
				"namespace", "##targetNamespace" });
		addAnnotation(getRelations_Dc(), source, new String[] { "kind", "attribute", "name", "dc" });
		addAnnotation(getRelations_IsNative(), source, new String[] { "kind", "attribute", "name", "isNative" });
	}

	////////////////////////////////////////////////////////////
	// ************** BEGIN NON-GENERATED CODE ************** //
	//                                                        //
	// ****************************************************** //
	////////////////////////////////////////////////////////////
	/**
	 * Override superclass to create a LexGrid-aware attribute.
	 * @non-generated
	 */
	protected void createEAttribute(EClass owner, int id) {
		LgAttributeImpl eAttribute = new LgAttributeImpl();
		eAttribute.setFeatureID(id);
		owner.getEStructuralFeatures().add(eAttribute);
	}

	/**
	 * Override superclass to create a LexGrid-aware reference.
	 * @non-generated
	 */
	protected void createEReference(EClass owner, int id) {
		LgReferenceImpl eReference = new LgReferenceImpl();
		eReference.setFeatureID(id);
		owner.getEStructuralFeatures().add(eReference);
	}

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * @non-generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		initializePackageContentsGen();

		((LgAttributeImpl) getAssociationData_Id()).setID(true);
		((LgAttributeImpl) getAssociation_Association()).setID(true);
		((LgAttributeImpl) getAssociationInstance_SourceConcept()).setID(true);
		((LgAttributeImpl) getAssociationQualification_AssociationQualifier()).setID(true);
		((LgAttributeImpl) getAssociationTarget_TargetConcept()).setID(true);
		((LgAttributeImpl) getRelations_Dc()).setID(true);
		((LgAttributeImpl) getRelations_Dc()).setDefaultValueLiteral("relations");

		// Ensures order of output in XML ...
		String source = "http:///org/eclipse/emf/mapping/xsd2ecore/XSD2Ecore";
		addAnnotation(relationsEClass, source, new String[] { "feature-order",
				"source association" });
	}
	////////////////////////////////////////////////////////////
	// *************** END NON-GENERATED CODE *************** //
	////////////////////////////////////////////////////////////

} //RelationsPackageImpl