/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.relations;

import org.LexGrid.emf.commonTypes.CommontypesPackage;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * <!-- begin-model-doc -->
 * 
 * 			<h2 xmlns="http://LexGrid.org/schema/2006/01/LexGrid/builtins">Core data types for the lexical grid.</h2>
 * 		
 * These types need to be mapped to the appropriate implementation specific data types. The mapping in this package represents the XML
 * 			Schema data types mapping
 * LDAP specific types for appinfo annotation
 * Basic builtin types
 * <!-- end-model-doc -->
 * @see org.LexGrid.emf.relations.RelationsFactory
 * @model kind="package"
 * @generated
 */
public interface RelationsPackage extends EPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "relations";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://LexGrid.org/schema/2006/01/LexGrid/relations";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "lgRel";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	RelationsPackage eINSTANCE = org.LexGrid.emf.relations.impl.RelationsPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.relations.impl.RelationsImpl <em>Relations</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.relations.impl.RelationsImpl
	 * @see org.LexGrid.emf.relations.impl.RelationsPackageImpl#getRelations()
	 * @generated
	 */
	int RELATIONS = 7;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.relations.impl.AssociationImpl <em>Association</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.relations.impl.AssociationImpl
	 * @see org.LexGrid.emf.relations.impl.RelationsPackageImpl#getAssociation()
	 * @generated
	 */
	int ASSOCIATION = 1;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.relations.impl.AssociationInstanceImpl <em>Association Instance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.relations.impl.AssociationInstanceImpl
	 * @see org.LexGrid.emf.relations.impl.RelationsPackageImpl#getAssociationInstance()
	 * @generated
	 */
	int ASSOCIATION_INSTANCE = 3;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.relations.impl.AssociatableElementImpl <em>Associatable Element</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.relations.impl.AssociatableElementImpl
	 * @see org.LexGrid.emf.relations.impl.RelationsPackageImpl#getAssociatableElement()
	 * @generated
	 */
	int ASSOCIATABLE_ELEMENT = 0;

	/**
	 * The feature id for the '<em><b>Deprecated</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATABLE_ELEMENT__DEPRECATED = CommontypesPackage.VERSIONABLE__DEPRECATED;

	/**
	 * The feature id for the '<em><b>First Release</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATABLE_ELEMENT__FIRST_RELEASE = CommontypesPackage.VERSIONABLE__FIRST_RELEASE;

	/**
	 * The feature id for the '<em><b>Modified In Release</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATABLE_ELEMENT__MODIFIED_IN_RELEASE = CommontypesPackage.VERSIONABLE__MODIFIED_IN_RELEASE;

	/**
	 * The feature id for the '<em><b>Association Qualification</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATABLE_ELEMENT__ASSOCIATION_QUALIFICATION = CommontypesPackage.VERSIONABLE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Associatable Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATABLE_ELEMENT_FEATURE_COUNT = CommontypesPackage.VERSIONABLE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Entity Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__ENTITY_DESCRIPTION = CommontypesPackage.DESCRIBABLE__ENTITY_DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Source Concept</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__SOURCE_CONCEPT = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Association</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__ASSOCIATION = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Forward Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__FORWARD_NAME = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Inverse</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__INVERSE = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Is Anti Reflexive</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__IS_ANTI_REFLEXIVE = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Is Anti Symmetric</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__IS_ANTI_SYMMETRIC = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Is Anti Transitive</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__IS_ANTI_TRANSITIVE = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Is Functional</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__IS_FUNCTIONAL = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 7;

	/**
	 * The feature id for the '<em><b>Is Navigable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__IS_NAVIGABLE = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 8;

	/**
	 * The feature id for the '<em><b>Is Reflexive</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__IS_REFLEXIVE = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 9;

	/**
	 * The feature id for the '<em><b>Is Reverse Functional</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__IS_REVERSE_FUNCTIONAL = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 10;

	/**
	 * The feature id for the '<em><b>Is Symmetric</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__IS_SYMMETRIC = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 11;

	/**
	 * The feature id for the '<em><b>Is Transitive</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__IS_TRANSITIVE = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 12;

	/**
	 * The feature id for the '<em><b>Is Translation Association</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__IS_TRANSLATION_ASSOCIATION = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 13;

	/**
	 * The feature id for the '<em><b>Reverse Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__REVERSE_NAME = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 14;

	/**
	 * The feature id for the '<em><b>Target Coding Scheme</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__TARGET_CODING_SCHEME = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 15;

	/**
	 * The number of structural features of the '<em>Association</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_FEATURE_COUNT = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 16;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.relations.impl.AssociationTargetImpl <em>Association Target</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.relations.impl.AssociationTargetImpl
	 * @see org.LexGrid.emf.relations.impl.RelationsPackageImpl#getAssociationTarget()
	 * @generated
	 */
	int ASSOCIATION_TARGET = 5;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.relations.impl.AssociationQualificationImpl <em>Association Qualification</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.relations.impl.AssociationQualificationImpl
	 * @see org.LexGrid.emf.relations.impl.RelationsPackageImpl#getAssociationQualification()
	 * @generated
	 */
	int ASSOCIATION_QUALIFICATION = 4;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.relations.impl.AssociationDataImpl <em>Association Data</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.relations.impl.AssociationDataImpl
	 * @see org.LexGrid.emf.relations.impl.RelationsPackageImpl#getAssociationData()
	 * @generated
	 */
	int ASSOCIATION_DATA = 2;

	/**
	 * The feature id for the '<em><b>Deprecated</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_DATA__DEPRECATED = ASSOCIATABLE_ELEMENT__DEPRECATED;

	/**
	 * The feature id for the '<em><b>First Release</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_DATA__FIRST_RELEASE = ASSOCIATABLE_ELEMENT__FIRST_RELEASE;

	/**
	 * The feature id for the '<em><b>Modified In Release</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_DATA__MODIFIED_IN_RELEASE = ASSOCIATABLE_ELEMENT__MODIFIED_IN_RELEASE;

	/**
	 * The feature id for the '<em><b>Association Qualification</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_DATA__ASSOCIATION_QUALIFICATION = ASSOCIATABLE_ELEMENT__ASSOCIATION_QUALIFICATION;

	/**
	 * The feature id for the '<em><b>Data Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_DATA__DATA_VALUE = ASSOCIATABLE_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_DATA__ID = ASSOCIATABLE_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Association Data</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_DATA_FEATURE_COUNT = ASSOCIATABLE_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Target Concept</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_INSTANCE__TARGET_CONCEPT = 0;

	/**
	 * The feature id for the '<em><b>Target Data Value</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_INSTANCE__TARGET_DATA_VALUE = 1;

	/**
	 * The feature id for the '<em><b>Source Coding Scheme</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_INSTANCE__SOURCE_CODING_SCHEME = 2;

	/**
	 * The feature id for the '<em><b>Source Concept</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_INSTANCE__SOURCE_CONCEPT = 3;

	/**
	 * The number of structural features of the '<em>Association Instance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_INSTANCE_FEATURE_COUNT = 4;

	/**
	 * The feature id for the '<em><b>Association Qualifier Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_QUALIFICATION__ASSOCIATION_QUALIFIER_VALUE = 0;

	/**
	 * The feature id for the '<em><b>Association Qualifier</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_QUALIFICATION__ASSOCIATION_QUALIFIER = 1;

	/**
	 * The number of structural features of the '<em>Association Qualification</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_QUALIFICATION_FEATURE_COUNT = 2;

	/**
	 * The feature id for the '<em><b>Deprecated</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_TARGET__DEPRECATED = ASSOCIATABLE_ELEMENT__DEPRECATED;

	/**
	 * The feature id for the '<em><b>First Release</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_TARGET__FIRST_RELEASE = ASSOCIATABLE_ELEMENT__FIRST_RELEASE;

	/**
	 * The feature id for the '<em><b>Modified In Release</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_TARGET__MODIFIED_IN_RELEASE = ASSOCIATABLE_ELEMENT__MODIFIED_IN_RELEASE;

	/**
	 * The feature id for the '<em><b>Association Qualification</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_TARGET__ASSOCIATION_QUALIFICATION = ASSOCIATABLE_ELEMENT__ASSOCIATION_QUALIFICATION;

	/**
	 * The feature id for the '<em><b>Target Coding Scheme</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_TARGET__TARGET_CODING_SCHEME = ASSOCIATABLE_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Target Concept</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_TARGET__TARGET_CONCEPT = ASSOCIATABLE_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Association Target</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_TARGET_FEATURE_COUNT = ASSOCIATABLE_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.relations.impl.DocumentRootImpl <em>Document Root</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.relations.impl.DocumentRootImpl
	 * @see org.LexGrid.emf.relations.impl.RelationsPackageImpl#getDocumentRoot()
	 * @generated
	 */
	int DOCUMENT_ROOT = 6;

	/**
	 * The feature id for the '<em><b>Mixed</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__MIXED = 0;

	/**
	 * The feature id for the '<em><b>XMLNS Prefix Map</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__XMLNS_PREFIX_MAP = 1;

	/**
	 * The feature id for the '<em><b>XSI Schema Location</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = 2;

	/**
	 * The feature id for the '<em><b>Association Data</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__ASSOCIATION_DATA = 3;

	/**
	 * The feature id for the '<em><b>Association Target</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__ASSOCIATION_TARGET = 4;

	/**
	 * The number of structural features of the '<em>Document Root</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT_FEATURE_COUNT = 5;

	/**
	 * The feature id for the '<em><b>Entity Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RELATIONS__ENTITY_DESCRIPTION = CommontypesPackage.DESCRIBABLE__ENTITY_DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Source</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RELATIONS__SOURCE = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Association</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RELATIONS__ASSOCIATION = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Dc</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RELATIONS__DC = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Is Native</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RELATIONS__IS_NATIVE = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Relations</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RELATIONS_FEATURE_COUNT = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 4;

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.relations.Relations <em>Relations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Relations</em>'.
	 * @see org.LexGrid.emf.relations.Relations
	 * @generated
	 */
	EClass getRelations();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.relations.Relations#getDc <em>Dc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Dc</em>'.
	 * @see org.LexGrid.emf.relations.Relations#getDc()
	 * @see #getRelations()
	 * @generated
	 */
	EAttribute getRelations_Dc();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.relations.Relations#getIsNative <em>Is Native</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Native</em>'.
	 * @see org.LexGrid.emf.relations.Relations#getIsNative()
	 * @see #getRelations()
	 * @generated
	 */
	EAttribute getRelations_IsNative();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.relations.Relations#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Source</em>'.
	 * @see org.LexGrid.emf.relations.Relations#getSource()
	 * @see #getRelations()
	 * @generated
	 */
	EReference getRelations_Source();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.relations.Relations#getAssociation <em>Association</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Association</em>'.
	 * @see org.LexGrid.emf.relations.Relations#getAssociation()
	 * @see #getRelations()
	 * @generated
	 */
	EReference getRelations_Association();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.relations.Association <em>Association</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Association</em>'.
	 * @see org.LexGrid.emf.relations.Association
	 * @generated
	 */
	EClass getAssociation();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.relations.Association#getAssociation <em>Association</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Association</em>'.
	 * @see org.LexGrid.emf.relations.Association#getAssociation()
	 * @see #getAssociation()
	 * @generated
	 */
	EAttribute getAssociation_Association();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.relations.Association#getForwardName <em>Forward Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Forward Name</em>'.
	 * @see org.LexGrid.emf.relations.Association#getForwardName()
	 * @see #getAssociation()
	 * @generated
	 */
	EAttribute getAssociation_ForwardName();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.relations.Association#getInverse <em>Inverse</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Inverse</em>'.
	 * @see org.LexGrid.emf.relations.Association#getInverse()
	 * @see #getAssociation()
	 * @generated
	 */
	EAttribute getAssociation_Inverse();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.relations.Association#getReverseName <em>Reverse Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Reverse Name</em>'.
	 * @see org.LexGrid.emf.relations.Association#getReverseName()
	 * @see #getAssociation()
	 * @generated
	 */
	EAttribute getAssociation_ReverseName();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.relations.Association#getIsTransitive <em>Is Transitive</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Transitive</em>'.
	 * @see org.LexGrid.emf.relations.Association#getIsTransitive()
	 * @see #getAssociation()
	 * @generated
	 */
	EAttribute getAssociation_IsTransitive();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.relations.Association#getIsAntiTransitive <em>Is Anti Transitive</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Anti Transitive</em>'.
	 * @see org.LexGrid.emf.relations.Association#getIsAntiTransitive()
	 * @see #getAssociation()
	 * @generated
	 */
	EAttribute getAssociation_IsAntiTransitive();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.relations.Association#getIsSymmetric <em>Is Symmetric</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Symmetric</em>'.
	 * @see org.LexGrid.emf.relations.Association#getIsSymmetric()
	 * @see #getAssociation()
	 * @generated
	 */
	EAttribute getAssociation_IsSymmetric();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.relations.Association#getIsAntiSymmetric <em>Is Anti Symmetric</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Anti Symmetric</em>'.
	 * @see org.LexGrid.emf.relations.Association#getIsAntiSymmetric()
	 * @see #getAssociation()
	 * @generated
	 */
	EAttribute getAssociation_IsAntiSymmetric();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.relations.Association#getIsReflexive <em>Is Reflexive</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Reflexive</em>'.
	 * @see org.LexGrid.emf.relations.Association#getIsReflexive()
	 * @see #getAssociation()
	 * @generated
	 */
	EAttribute getAssociation_IsReflexive();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.relations.Association#getIsAntiReflexive <em>Is Anti Reflexive</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Anti Reflexive</em>'.
	 * @see org.LexGrid.emf.relations.Association#getIsAntiReflexive()
	 * @see #getAssociation()
	 * @generated
	 */
	EAttribute getAssociation_IsAntiReflexive();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.relations.Association#getIsFunctional <em>Is Functional</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Functional</em>'.
	 * @see org.LexGrid.emf.relations.Association#getIsFunctional()
	 * @see #getAssociation()
	 * @generated
	 */
	EAttribute getAssociation_IsFunctional();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.relations.Association#getIsNavigable <em>Is Navigable</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Navigable</em>'.
	 * @see org.LexGrid.emf.relations.Association#getIsNavigable()
	 * @see #getAssociation()
	 * @generated
	 */
	EAttribute getAssociation_IsNavigable();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.relations.Association#getIsReverseFunctional <em>Is Reverse Functional</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Reverse Functional</em>'.
	 * @see org.LexGrid.emf.relations.Association#getIsReverseFunctional()
	 * @see #getAssociation()
	 * @generated
	 */
	EAttribute getAssociation_IsReverseFunctional();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.relations.Association#getIsTranslationAssociation <em>Is Translation Association</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Translation Association</em>'.
	 * @see org.LexGrid.emf.relations.Association#getIsTranslationAssociation()
	 * @see #getAssociation()
	 * @generated
	 */
	EAttribute getAssociation_IsTranslationAssociation();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.relations.Association#getTargetCodingScheme <em>Target Coding Scheme</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Target Coding Scheme</em>'.
	 * @see org.LexGrid.emf.relations.Association#getTargetCodingScheme()
	 * @see #getAssociation()
	 * @generated
	 */
	EAttribute getAssociation_TargetCodingScheme();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.relations.Association#getSourceConcept <em>Source Concept</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Source Concept</em>'.
	 * @see org.LexGrid.emf.relations.Association#getSourceConcept()
	 * @see #getAssociation()
	 * @generated
	 */
	EReference getAssociation_SourceConcept();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.relations.AssociationInstance <em>Association Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Association Instance</em>'.
	 * @see org.LexGrid.emf.relations.AssociationInstance
	 * @generated
	 */
	EClass getAssociationInstance();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.relations.AssociationInstance#getSourceCodingScheme <em>Source Coding Scheme</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Source Coding Scheme</em>'.
	 * @see org.LexGrid.emf.relations.AssociationInstance#getSourceCodingScheme()
	 * @see #getAssociationInstance()
	 * @generated
	 */
	EAttribute getAssociationInstance_SourceCodingScheme();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.relations.AssociationInstance#getSourceConcept <em>Source Concept</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Source Concept</em>'.
	 * @see org.LexGrid.emf.relations.AssociationInstance#getSourceConcept()
	 * @see #getAssociationInstance()
	 * @generated
	 */
	EAttribute getAssociationInstance_SourceConcept();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.relations.AssociationInstance#getTargetConcept <em>Target Concept</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Target Concept</em>'.
	 * @see org.LexGrid.emf.relations.AssociationInstance#getTargetConcept()
	 * @see #getAssociationInstance()
	 * @generated
	 */
	EReference getAssociationInstance_TargetConcept();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.relations.AssociationInstance#getTargetDataValue <em>Target Data Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Target Data Value</em>'.
	 * @see org.LexGrid.emf.relations.AssociationInstance#getTargetDataValue()
	 * @see #getAssociationInstance()
	 * @generated
	 */
	EReference getAssociationInstance_TargetDataValue();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.relations.AssociationTarget <em>Association Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Association Target</em>'.
	 * @see org.LexGrid.emf.relations.AssociationTarget
	 * @generated
	 */
	EClass getAssociationTarget();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.relations.AssociationTarget#getTargetCodingScheme <em>Target Coding Scheme</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Target Coding Scheme</em>'.
	 * @see org.LexGrid.emf.relations.AssociationTarget#getTargetCodingScheme()
	 * @see #getAssociationTarget()
	 * @generated
	 */
	EAttribute getAssociationTarget_TargetCodingScheme();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.relations.AssociationTarget#getTargetConcept <em>Target Concept</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Target Concept</em>'.
	 * @see org.LexGrid.emf.relations.AssociationTarget#getTargetConcept()
	 * @see #getAssociationTarget()
	 * @generated
	 */
	EAttribute getAssociationTarget_TargetConcept();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.relations.DocumentRoot <em>Document Root</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Document Root</em>'.
	 * @see org.LexGrid.emf.relations.DocumentRoot
	 * @generated
	 */
	EClass getDocumentRoot();

	/**
	 * Returns the meta object for the attribute list '{@link org.LexGrid.emf.relations.DocumentRoot#getMixed <em>Mixed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Mixed</em>'.
	 * @see org.LexGrid.emf.relations.DocumentRoot#getMixed()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EAttribute getDocumentRoot_Mixed();

	/**
	 * Returns the meta object for the map '{@link org.LexGrid.emf.relations.DocumentRoot#getXMLNSPrefixMap <em>XMLNS Prefix Map</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>XMLNS Prefix Map</em>'.
	 * @see org.LexGrid.emf.relations.DocumentRoot#getXMLNSPrefixMap()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_XMLNSPrefixMap();

	/**
	 * Returns the meta object for the map '{@link org.LexGrid.emf.relations.DocumentRoot#getXSISchemaLocation <em>XSI Schema Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>XSI Schema Location</em>'.
	 * @see org.LexGrid.emf.relations.DocumentRoot#getXSISchemaLocation()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_XSISchemaLocation();

	/**
	 * Returns the meta object for the containment reference '{@link org.LexGrid.emf.relations.DocumentRoot#getAssociationData <em>Association Data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Association Data</em>'.
	 * @see org.LexGrid.emf.relations.DocumentRoot#getAssociationData()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_AssociationData();

	/**
	 * Returns the meta object for the containment reference '{@link org.LexGrid.emf.relations.DocumentRoot#getAssociationTarget <em>Association Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Association Target</em>'.
	 * @see org.LexGrid.emf.relations.DocumentRoot#getAssociationTarget()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_AssociationTarget();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.relations.AssociatableElement <em>Associatable Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Associatable Element</em>'.
	 * @see org.LexGrid.emf.relations.AssociatableElement
	 * @generated
	 */
	EClass getAssociatableElement();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.relations.AssociatableElement#getAssociationQualification <em>Association Qualification</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Association Qualification</em>'.
	 * @see org.LexGrid.emf.relations.AssociatableElement#getAssociationQualification()
	 * @see #getAssociatableElement()
	 * @generated
	 */
	EReference getAssociatableElement_AssociationQualification();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.relations.AssociationQualification <em>Association Qualification</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Association Qualification</em>'.
	 * @see org.LexGrid.emf.relations.AssociationQualification
	 * @generated
	 */
	EClass getAssociationQualification();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.relations.AssociationQualification#getAssociationQualifierValue <em>Association Qualifier Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Association Qualifier Value</em>'.
	 * @see org.LexGrid.emf.relations.AssociationQualification#getAssociationQualifierValue()
	 * @see #getAssociationQualification()
	 * @generated
	 */
	EAttribute getAssociationQualification_AssociationQualifierValue();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.relations.AssociationQualification#getAssociationQualifier <em>Association Qualifier</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Association Qualifier</em>'.
	 * @see org.LexGrid.emf.relations.AssociationQualification#getAssociationQualifier()
	 * @see #getAssociationQualification()
	 * @generated
	 */
	EAttribute getAssociationQualification_AssociationQualifier();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.relations.AssociationData <em>Association Data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Association Data</em>'.
	 * @see org.LexGrid.emf.relations.AssociationData
	 * @generated
	 */
	EClass getAssociationData();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.relations.AssociationData#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see org.LexGrid.emf.relations.AssociationData#getId()
	 * @see #getAssociationData()
	 * @generated
	 */
	EAttribute getAssociationData_Id();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.relations.AssociationData#getDataValue <em>Data Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Value</em>'.
	 * @see org.LexGrid.emf.relations.AssociationData#getDataValue()
	 * @see #getAssociationData()
	 * @generated
	 */
	EAttribute getAssociationData_DataValue();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	RelationsFactory getRelationsFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.relations.impl.AssociatableElementImpl <em>Associatable Element</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.relations.impl.AssociatableElementImpl
		 * @see org.LexGrid.emf.relations.impl.RelationsPackageImpl#getAssociatableElement()
		 * @generated
		 */
		EClass ASSOCIATABLE_ELEMENT = eINSTANCE.getAssociatableElement();

		/**
		 * The meta object literal for the '<em><b>Association Qualification</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ASSOCIATABLE_ELEMENT__ASSOCIATION_QUALIFICATION = eINSTANCE
				.getAssociatableElement_AssociationQualification();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.relations.impl.AssociationImpl <em>Association</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.relations.impl.AssociationImpl
		 * @see org.LexGrid.emf.relations.impl.RelationsPackageImpl#getAssociation()
		 * @generated
		 */
		EClass ASSOCIATION = eINSTANCE.getAssociation();

		/**
		 * The meta object literal for the '<em><b>Source Concept</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ASSOCIATION__SOURCE_CONCEPT = eINSTANCE.getAssociation_SourceConcept();

		/**
		 * The meta object literal for the '<em><b>Association</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSOCIATION__ASSOCIATION = eINSTANCE.getAssociation_Association();

		/**
		 * The meta object literal for the '<em><b>Forward Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSOCIATION__FORWARD_NAME = eINSTANCE.getAssociation_ForwardName();

		/**
		 * The meta object literal for the '<em><b>Inverse</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSOCIATION__INVERSE = eINSTANCE.getAssociation_Inverse();

		/**
		 * The meta object literal for the '<em><b>Is Anti Reflexive</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSOCIATION__IS_ANTI_REFLEXIVE = eINSTANCE.getAssociation_IsAntiReflexive();

		/**
		 * The meta object literal for the '<em><b>Is Anti Symmetric</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSOCIATION__IS_ANTI_SYMMETRIC = eINSTANCE.getAssociation_IsAntiSymmetric();

		/**
		 * The meta object literal for the '<em><b>Is Anti Transitive</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSOCIATION__IS_ANTI_TRANSITIVE = eINSTANCE.getAssociation_IsAntiTransitive();

		/**
		 * The meta object literal for the '<em><b>Is Functional</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSOCIATION__IS_FUNCTIONAL = eINSTANCE.getAssociation_IsFunctional();

		/**
		 * The meta object literal for the '<em><b>Is Navigable</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSOCIATION__IS_NAVIGABLE = eINSTANCE.getAssociation_IsNavigable();

		/**
		 * The meta object literal for the '<em><b>Is Reflexive</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSOCIATION__IS_REFLEXIVE = eINSTANCE.getAssociation_IsReflexive();

		/**
		 * The meta object literal for the '<em><b>Is Reverse Functional</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSOCIATION__IS_REVERSE_FUNCTIONAL = eINSTANCE.getAssociation_IsReverseFunctional();

		/**
		 * The meta object literal for the '<em><b>Is Symmetric</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSOCIATION__IS_SYMMETRIC = eINSTANCE.getAssociation_IsSymmetric();

		/**
		 * The meta object literal for the '<em><b>Is Transitive</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSOCIATION__IS_TRANSITIVE = eINSTANCE.getAssociation_IsTransitive();

		/**
		 * The meta object literal for the '<em><b>Is Translation Association</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSOCIATION__IS_TRANSLATION_ASSOCIATION = eINSTANCE.getAssociation_IsTranslationAssociation();

		/**
		 * The meta object literal for the '<em><b>Reverse Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSOCIATION__REVERSE_NAME = eINSTANCE.getAssociation_ReverseName();

		/**
		 * The meta object literal for the '<em><b>Target Coding Scheme</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSOCIATION__TARGET_CODING_SCHEME = eINSTANCE.getAssociation_TargetCodingScheme();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.relations.impl.AssociationDataImpl <em>Association Data</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.relations.impl.AssociationDataImpl
		 * @see org.LexGrid.emf.relations.impl.RelationsPackageImpl#getAssociationData()
		 * @generated
		 */
		EClass ASSOCIATION_DATA = eINSTANCE.getAssociationData();

		/**
		 * The meta object literal for the '<em><b>Data Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSOCIATION_DATA__DATA_VALUE = eINSTANCE.getAssociationData_DataValue();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSOCIATION_DATA__ID = eINSTANCE.getAssociationData_Id();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.relations.impl.AssociationInstanceImpl <em>Association Instance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.relations.impl.AssociationInstanceImpl
		 * @see org.LexGrid.emf.relations.impl.RelationsPackageImpl#getAssociationInstance()
		 * @generated
		 */
		EClass ASSOCIATION_INSTANCE = eINSTANCE.getAssociationInstance();

		/**
		 * The meta object literal for the '<em><b>Target Concept</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ASSOCIATION_INSTANCE__TARGET_CONCEPT = eINSTANCE.getAssociationInstance_TargetConcept();

		/**
		 * The meta object literal for the '<em><b>Target Data Value</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ASSOCIATION_INSTANCE__TARGET_DATA_VALUE = eINSTANCE.getAssociationInstance_TargetDataValue();

		/**
		 * The meta object literal for the '<em><b>Source Coding Scheme</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSOCIATION_INSTANCE__SOURCE_CODING_SCHEME = eINSTANCE.getAssociationInstance_SourceCodingScheme();

		/**
		 * The meta object literal for the '<em><b>Source Concept</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSOCIATION_INSTANCE__SOURCE_CONCEPT = eINSTANCE.getAssociationInstance_SourceConcept();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.relations.impl.AssociationQualificationImpl <em>Association Qualification</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.relations.impl.AssociationQualificationImpl
		 * @see org.LexGrid.emf.relations.impl.RelationsPackageImpl#getAssociationQualification()
		 * @generated
		 */
		EClass ASSOCIATION_QUALIFICATION = eINSTANCE.getAssociationQualification();

		/**
		 * The meta object literal for the '<em><b>Association Qualifier Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSOCIATION_QUALIFICATION__ASSOCIATION_QUALIFIER_VALUE = eINSTANCE
				.getAssociationQualification_AssociationQualifierValue();

		/**
		 * The meta object literal for the '<em><b>Association Qualifier</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSOCIATION_QUALIFICATION__ASSOCIATION_QUALIFIER = eINSTANCE
				.getAssociationQualification_AssociationQualifier();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.relations.impl.AssociationTargetImpl <em>Association Target</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.relations.impl.AssociationTargetImpl
		 * @see org.LexGrid.emf.relations.impl.RelationsPackageImpl#getAssociationTarget()
		 * @generated
		 */
		EClass ASSOCIATION_TARGET = eINSTANCE.getAssociationTarget();

		/**
		 * The meta object literal for the '<em><b>Target Coding Scheme</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSOCIATION_TARGET__TARGET_CODING_SCHEME = eINSTANCE.getAssociationTarget_TargetCodingScheme();

		/**
		 * The meta object literal for the '<em><b>Target Concept</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSOCIATION_TARGET__TARGET_CONCEPT = eINSTANCE.getAssociationTarget_TargetConcept();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.relations.impl.DocumentRootImpl <em>Document Root</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.relations.impl.DocumentRootImpl
		 * @see org.LexGrid.emf.relations.impl.RelationsPackageImpl#getDocumentRoot()
		 * @generated
		 */
		EClass DOCUMENT_ROOT = eINSTANCE.getDocumentRoot();

		/**
		 * The meta object literal for the '<em><b>Mixed</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCUMENT_ROOT__MIXED = eINSTANCE.getDocumentRoot_Mixed();

		/**
		 * The meta object literal for the '<em><b>XMLNS Prefix Map</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__XMLNS_PREFIX_MAP = eINSTANCE.getDocumentRoot_XMLNSPrefixMap();

		/**
		 * The meta object literal for the '<em><b>XSI Schema Location</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = eINSTANCE.getDocumentRoot_XSISchemaLocation();

		/**
		 * The meta object literal for the '<em><b>Association Data</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__ASSOCIATION_DATA = eINSTANCE.getDocumentRoot_AssociationData();

		/**
		 * The meta object literal for the '<em><b>Association Target</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__ASSOCIATION_TARGET = eINSTANCE.getDocumentRoot_AssociationTarget();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.relations.impl.RelationsImpl <em>Relations</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.relations.impl.RelationsImpl
		 * @see org.LexGrid.emf.relations.impl.RelationsPackageImpl#getRelations()
		 * @generated
		 */
		EClass RELATIONS = eINSTANCE.getRelations();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RELATIONS__SOURCE = eINSTANCE.getRelations_Source();

		/**
		 * The meta object literal for the '<em><b>Association</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RELATIONS__ASSOCIATION = eINSTANCE.getRelations_Association();

		/**
		 * The meta object literal for the '<em><b>Dc</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RELATIONS__DC = eINSTANCE.getRelations_Dc();

		/**
		 * The meta object literal for the '<em><b>Is Native</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RELATIONS__IS_NATIVE = eINSTANCE.getRelations_IsNative();

	}

} //RelationsPackage