/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.relations.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.LexGrid.emf.base.LgEnhancedList;
import org.LexGrid.emf.base.LgKeyedList;
import org.LexGrid.emf.base.LgModelObj;
import org.LexGrid.emf.base.LgSearchable;
import org.LexGrid.emf.base.impl.LgModelObjImpl;
import org.LexGrid.emf.codingSchemes.CodingSchemeType;
import org.LexGrid.emf.codingSchemes.CodingSchemeVersion;
import org.LexGrid.emf.codingSchemes.CodingSchemesType;
import org.LexGrid.emf.codingSchemes.CodingschemesPackage;
import org.LexGrid.emf.codingSchemes.Versions;
import org.LexGrid.emf.codingSchemes.util.CodingschemesUtil;
import org.LexGrid.emf.concepts.CodedEntry;
import org.LexGrid.emf.concepts.util.ConceptsUtil;
import org.LexGrid.emf.relations.Association;
import org.LexGrid.emf.relations.AssociationInstance;
import org.LexGrid.emf.relations.AssociationTarget;
import org.LexGrid.emf.relations.Relations;
import org.LexGrid.emf.relations.RelationsPackage;
import org.LexGrid.emf.relations.impl.RelationsFactoryImpl;
import org.LexGrid.managedobj.QueryException;
import org.LexGrid.managedobj.ResolveException;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.IteratorUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;

/**
 * Common utility class to support relations and related model objects.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 * @non-generated
 */
public class RelationsUtil {
    protected final static Logger logger = Logger.getLogger("org.LexGrid.emf.relations.util.RelationsUtil");

    private RelationsUtil() {
		super();
	}

	/**
	 * Returns the list of relation containers within the given coding scheme.
	 * <p>
	 * RelationChanges are returned first (sorted by descending version order), followed by
	 * the primary relation container.
	 * @param scheme
	 * @return List
	 */
	public static List resolveRelationContainers(CodingSchemeType scheme) {
		List items = new ArrayList();
		
		if (scheme != null) {
			Versions versions = scheme.getVersions();
			if (versions != null)
				for (Iterator versionEntries = versions.getVersion().iterator(); versionEntries.hasNext(); )
					for (Iterator containers = ((CodingSchemeVersion) versionEntries.next()).getRelations().iterator(); containers.hasNext(); )
						items.add(containers.next());
					
			for (Iterator containers = scheme.getRelations().iterator(); containers.hasNext(); )
				items.add(containers.next());
		}
		return items;
	}
	
	/** 
	 * Reverse the direction of the association within a given coding scheme. The forward and reverse names are
	 * interchanged and the association source and targets are flipped.
	 * @param scheme, association_name
	 * @return void
	 */
	
	public static void reverseDirectionOfAssociation(CodingSchemeType scheme, String association_name) {
		RelationsFactoryImpl relationsFactory= new RelationsFactoryImpl();
		List associations= resolveAssociations( scheme,  association_name);
		for (Iterator item = associations.iterator(); item.hasNext(); ){
			Association association = (Association) item.next();
			String forward_name= association.getForwardName();
			String reverse_name= association.getReverseName();
			association.setForwardName(reverse_name);
			association.setReverseName(forward_name);
			
			
			AssociationInstance[] sourceArray= (AssociationInstance[])association.getSourceConcept().toArray();
			association.getSourceConcept().clear();
			for (int i=0; i < sourceArray.length;i++) {
				AssociationInstance ai= sourceArray[i];
				List targetList = ai.getTargetConcept();
				for (Iterator t= targetList.iterator(); t.hasNext();){
					AssociationTarget at= (AssociationTarget) t.next();
					AssociationInstance new_ai = relationsFactory.createAssociationInstance();
					new_ai.setSourceConcept(at.getConceptCode());
					new_ai = RelationsUtil.subsume(association, new_ai);
					
					AssociationTarget new_at = relationsFactory.createAssociationTarget();
					new_at.setTargetConcept(ai.getConceptCode());
					RelationsUtil.subsume(new_ai, new_at);
				}
			}
		}
	}
	
	
	/**
	 * Returns the list of associations within the given coding scheme
	 * @param scheme
	 * @return List
	 */
	public static List resolveAssociations(CodingSchemeType scheme) {
		List items = new ArrayList();
		for (Iterator containers = resolveRelationContainers(scheme).iterator(); containers.hasNext(); ){
			Relations container = (Relations) containers.next();
			for (Iterator classes = container.getAssociation().iterator(); classes.hasNext(); ) {
				Association ac = (Association) classes.next();
				items.add(ac);
			}
		}
		return items;
	}	
		
	
	/**
	 * Returns the list of associations within the given coding scheme that matches the association_name.
	 * @param scheme, association_name
	 * @return List
	 */
	public static List resolveAssociations(CodingSchemeType scheme, String association_name) {
		List items = new ArrayList();
		for (Iterator containers = resolveRelationContainers(scheme).iterator(); containers.hasNext(); ){
			Relations container = (Relations) containers.next();
			for (Iterator classes = container.getAssociation().iterator(); classes.hasNext(); ) {
				Association ac = (Association) classes.next();
				if (ac.getAssociation().equals(association_name)) {
					items.add(ac);
				}
			}
		}
		return items;
	}	
	
	/**
	 * Returns a source within a specific relation with the given code;
	 * null if not available.
	 * @param relation
	 * @param sourceCode
	 * @return AssociationInstance
	 */
	public static AssociationInstance resolveRelationSource(Association relation, String sourceCode) {
		if (sourceCode != null) {
			List sources = relation.getSourceConcept();
			if (sources instanceof LgKeyedList)
				return (AssociationInstance) ((LgKeyedList) sources).getByPrimaryKey(sourceCode);
			for (Iterator candidates = sources.iterator(); candidates.hasNext(); ) {
				AssociationInstance candidate = (AssociationInstance) candidates.next();
				if (sourceCode.equals(candidate.getSourceConcept()))
					return candidate;
			}
		}
		return null;
	}
	
	/**
	 * Returns a relation target within a specific source with the given code;
	 * null if not available.
	 * @param source
	 * @param targetCode
	 * @return AssociationTarget
	 */
	public static AssociationTarget resolveRelationTarget(AssociationInstance source, String targetCode) {
		if (targetCode != null) {
			List targets = source.getTargetConcept();
			if (targets instanceof LgKeyedList)
				return (AssociationTarget) ((LgKeyedList) targets).getByPrimaryKey(targetCode);
			for (Iterator candidates = targets.iterator(); candidates.hasNext(); ) {
				AssociationTarget candidate = (AssociationTarget) candidates.next();
				if (targetCode.equals(candidate.getTargetConcept()))
					return candidate;
			}
		}
		return null;
	}
	
	/**
	 * Returns the collection of relation sources (type AssociationInstance)
	 * that correspond to a concept within accessible coding schemes.   
	 * @param concept
	 * @return Collection
	 */
	public static Collection resolveRelationSources(CodedEntry concept) {
		Collection resolved = new ArrayList();
		Collection schemesToSearch = new ArrayList();
		CodingSchemesType schemes = ConceptsUtil.resolveCodingSchemes(concept);
		if (schemes != null)
			schemesToSearch.addAll(
				IteratorUtils.toList(schemes.getContent(CodingSchemeType.class, 0)));
		else {
			CodingSchemeType scheme = ConceptsUtil.resolveCodingScheme(concept);
			if (scheme != null)
				schemesToSearch.add(scheme);
		}

		for (Iterator schemeIt = schemesToSearch.iterator(); schemeIt.hasNext(); )
			resolved.addAll(resolveRelationSources((CodingSchemeType) schemeIt.next(), concept));
		return resolved;
	}

	/**
	 * Returns the collection of relation sources (type AssociationInstance)
	 * that correspond to a concept within the given coding scheme.   
	 * @param concept
	 * @return Collection
	 */
	public static Collection resolveRelationSources(CodingSchemeType scheme, CodedEntry concept) {
		Collection resolved = new ArrayList();
		String sourceCode = concept.getConceptCode();
		if (sourceCode != null && sourceCode.length() > 0) {
			CodingSchemeType sourceScheme = ConceptsUtil.resolveCodingScheme(concept);
			String sourceContext = sourceScheme == null ? null : sourceScheme.getCodingScheme();

			// Is the scheme accessed as part of a searchable resource?
			// If so, resolve by direct query ...
			Resource eResource = scheme.eResource();
			if (eResource instanceof LgSearchable) {
				try {
					CollectionUtils.addAll(resolved, ((LgSearchable) eResource).queryRelationSources(scheme, sourceCode, 0));
				} catch (QueryException e) {
					logger.error("Error resolving relation sources", e);
				}
			}
			else {
				// Scheme is referenced as part of content not supporting direct query ...
				for (Iterator containers = resolveRelationContainers(scheme).iterator(); containers.hasNext(); ) {
					Relations container = (Relations) containers.next();
					for (Iterator classes = container.getAssociation().iterator(); classes.hasNext(); ) {
						Association ac = (Association) classes.next();
						List candidates = ac.getSourceConcept();
						boolean done = false;
						// Keyed list indexed by source code only; this will need to be revisited.
						// For now, fall back on sequential lookup if a match is found for the right
						// concept code but the wrong source scheme. 
						if (candidates instanceof LgKeyedList) {
							AssociationInstance ai = (AssociationInstance)((LgKeyedList) candidates).getByPrimaryKey(sourceCode);
							if (ai != null) {
								String aiContext = ai.getSourceCodingScheme();
								if (aiContext == null || aiContext.length() == 0)
									aiContext = scheme.getCodingScheme();
								if (done = (sourceContext == null || aiContext == null || sourceContext == aiContext || sourceContext.equalsIgnoreCase(aiContext)))
									resolved.add(ai);
							} else
								done = true;
						}
						if (!done) {
							for (Iterator sources = candidates.iterator(); sources.hasNext(); ) {
								AssociationInstance ai = (AssociationInstance) sources.next();
								if (sourceCode.equals(ai.getSourceConcept())) {
									String aiContext = ai.getSourceCodingScheme();
									if (aiContext == null || aiContext.length() == 0)
										aiContext = scheme.getCodingScheme();
									if (sourceContext == null || aiContext == null || sourceContext == aiContext || sourceContext.equalsIgnoreCase(aiContext))
										resolved.add(ai);
								}
							}
						}
					}
				}
			}
		}
		return resolved;
	}
	
	
	/**
	 * Returns the collection of relation sources (type AssociationInstance)
	 * that correspond to a concept within the given coding scheme and association List.   
	 * @param scheme, concept, association
	 * @return Collection
	 */
	public static Collection resolveRelationSources(CodingSchemeType scheme, CodedEntry concept, Collection association_list) {
		Collection resolved = new ArrayList();
		String sourceCode = concept.getConceptCode();
		if (sourceCode != null && sourceCode.length() > 0) {
			CodingSchemeType sourceScheme = ConceptsUtil.resolveCodingScheme(concept);
			String sourceContext = sourceScheme == null ? null : sourceScheme.getCodingScheme();

			// Is the scheme accessed as part of a searchable resource?
			// If so, resolve by direct query ...
			/*
			Resource eResource = scheme.eResource();
			if (eResource instanceof LgSearchable) {
				try {
					CollectionUtils.addAll(resolved, ((LgSearchable) eResource).queryRelationSources(scheme, sourceCode, 0));
				} catch (QueryException e) {
					LgEmfPlugin.log(IStatus.ERROR, "Error resolving relation sources", e);
				}
			}
			else {
			*/
				// Scheme is referenced as part of content not supporting direct query ...
				for (Iterator containers = resolveRelationContainers(scheme).iterator(); containers.hasNext(); ) {
					Relations container = (Relations) containers.next();
					for (Iterator classes = container.getAssociation().iterator(); classes.hasNext(); ) {
						Association ac = (Association) classes.next();
						if (!association_list.contains(ac)) {
							continue;
						}
						List candidates = ac.getSourceConcept();
						boolean done = false;
						// Keyed list indexed by source code only; this will need to be revisited.
						// For now, fall back on sequential lookup if a match is found for the right
						// concept code but the wrong source scheme. 
						if (candidates instanceof LgKeyedList) {
							AssociationInstance ai = (AssociationInstance)((LgKeyedList) candidates).getByPrimaryKey(sourceCode);
							if (ai != null) {
								String aiContext = ai.getSourceCodingScheme();
								if (aiContext == null || aiContext.length() == 0)
									aiContext = scheme.getCodingScheme();
								if (done = (sourceContext == null || aiContext == null || sourceContext == aiContext || sourceContext.equalsIgnoreCase(aiContext)))
									resolved.add(ai);
							} else
								done = true;
						}
						if (!done) {
							for (Iterator sources = candidates.iterator(); sources.hasNext(); ) {
								AssociationInstance ai = (AssociationInstance) sources.next();
								if (sourceCode.equals(ai.getSourceConcept())) {
									String aiContext = ai.getSourceCodingScheme();
									if (aiContext == null || aiContext.length() == 0)
										aiContext = scheme.getCodingScheme();
									if (sourceContext == null || aiContext == null || sourceContext == aiContext || sourceContext.equalsIgnoreCase(aiContext))
										resolved.add(ai);
								}
							}
						}
					}
				}
			//}
		}
		return resolved;
	}	
	
	
	
	/**
	 * Returns the collection of relation targets (type AssociationTarget)
	 * that correspond to a concept within accessible coding schemes.   
	 * @param concept
	 * @return Collection
	 */
	public static Collection resolveRelationTargets(CodedEntry concept) {
		Collection resolved = new ArrayList();
		Collection schemesToSearch = new ArrayList();
		CodingSchemesType schemes = ConceptsUtil.resolveCodingSchemes(concept);
		if (schemes != null)
			schemesToSearch.addAll(IteratorUtils.toList(schemes.getContent(CodingSchemeType.class, 0)));
		else {
			CodingSchemeType scheme = ConceptsUtil.resolveCodingScheme(concept);
			if (scheme != null)
				schemesToSearch.add(scheme);
		}

		for (Iterator schemeIt = schemesToSearch.iterator(); schemeIt.hasNext(); )
			resolved.addAll(resolveRelationTargets((CodingSchemeType) schemeIt.next(), concept));
		return resolved;
	}

	/**
	 * Returns the collection of relation targets (type AssociationTarget)
	 * that correspond to a concept within the given coding scheme.   
	 * @param concept
	 * @return Collection
	 */
	public static Collection resolveRelationTargets(CodingSchemeType scheme, CodedEntry concept) {
		Collection resolved = new ArrayList();
		String targetCode = concept.getConceptCode();
		if (targetCode != null && targetCode.length() > 0) {
			CodingSchemeType targetScheme = ConceptsUtil.resolveCodingScheme(concept);
			String targetContext = targetScheme == null ? null : targetScheme.getCodingScheme();

			// Is the scheme accessed as part of a searchable resource?
			// If so, resolve by direct query ...
			Resource eResource = scheme.eResource();
			if (eResource instanceof LgSearchable) {
				try {
					CollectionUtils.addAll(resolved, ((LgSearchable) eResource).queryRelationTargets(scheme, targetContext, targetCode, 0));
				} catch (QueryException e) {
					logger.error("Error resolving relation targets", e);
				}
			}
			else {
				// Scheme is referenced as part of content not supporting direct query ...
				for (Iterator containers = resolveRelationContainers(scheme).iterator(); containers.hasNext(); ) {
					Relations container = (Relations) containers.next();
					for (Iterator classes = container.getAssociation().iterator(); classes.hasNext(); ) {
						Association ac = (Association) classes.next();
						String acContext = ac.getTargetCodingScheme();
						if (acContext == null || acContext.length() == 0)
							acContext = scheme.getCodingScheme();
						for (Iterator sources = ac.getSourceConcept().iterator(); sources.hasNext(); ) {
							for (Iterator candidates = ((AssociationInstance) sources.next()).getTargetConcept().iterator(); candidates.hasNext(); ) {
								AssociationTarget at = (AssociationTarget) candidates.next();
								if (targetCode.equals(at.getTargetConcept())) {
									String atContext = at.getTargetCodingScheme();
									if (atContext == null || atContext.length() == 0)
										atContext = acContext;
									if (targetContext == null || atContext == null || targetContext == atContext || targetContext.equalsIgnoreCase(atContext))
										resolved.add(at);
								}
							}
						}
					}
				}
			}
		}
		return resolved;
	}

	
	/**
	 * Returns the collection of relation targets (type AssociationTarget)
	 * that correspond to a concept within the given coding scheme and association.   
	 * @param scheme, concept, association
	 * @return Collection
	 */
	public static Collection resolveRelationTargets(CodingSchemeType scheme, CodedEntry concept, Collection association_list) {
		Collection resolved = new ArrayList();
		String targetCode = concept.getConceptCode();
		if (targetCode != null && targetCode.length() > 0) {
			CodingSchemeType targetScheme = ConceptsUtil.resolveCodingScheme(concept);
			String targetContext = targetScheme == null ? null : targetScheme.getCodingScheme();

			// Is the scheme accessed as part of a searchable resource?
			// If so, resolve by direct query ...
			/*
			 Resource eResource = scheme.eResource();
			 if (eResource instanceof LgSearchable) {
				Collection list= new ArrayList();
				try {
					CollectionUtils.addAll(list, ((LgSearchable) eResource).queryRelationTargets(scheme, targetContext, targetCode, 0));
				} catch (QueryException e) {
					LgEmfPlugin.log(IStatus.ERROR, "Error resolving relation targets", e);
				}
				
				
			}
			else {
			*/
				// Scheme is referenced as part of content not supporting direct query ...
				for (Iterator containers = resolveRelationContainers(scheme).iterator(); containers.hasNext(); ) {
					Relations container = (Relations) containers.next();
					for (Iterator classes = container.getAssociation().iterator(); classes.hasNext(); ) {
						Association ac = (Association) classes.next();
						if (!association_list.contains(ac)) {
							continue;
						}
						String acContext = ac.getTargetCodingScheme();
						if (acContext == null || acContext.length() == 0)
							acContext = scheme.getCodingScheme();
						for (Iterator sources = ac.getSourceConcept().iterator(); sources.hasNext(); ) {
							for (Iterator candidates = ((AssociationInstance) sources.next()).getTargetConcept().iterator(); candidates.hasNext(); ) {
								AssociationTarget at = (AssociationTarget) candidates.next();
								if (targetCode.equals(at.getTargetConcept())) {
									String atContext = at.getTargetCodingScheme();
									if (atContext == null || atContext.length() == 0)
										atContext = acContext;
									if (targetContext == null || atContext == null || targetContext == atContext || targetContext.equalsIgnoreCase(atContext))
										resolved.add(at);
								}
							}
						}
					}
				}
			}
		//}
		
		return resolved;
	}
	
	
	/**
	 * Returns the effective coding scheme for the given relation source;
	 * null if not accessible.
	 * @param source
	 * @return CodingSchemeType
	 */
	public static CodingSchemeType resolveSourceScheme(AssociationInstance source) {
		String schemeName = source.getSourceCodingScheme();
		if (schemeName != null && schemeName.length() > 0)
			return CodingschemesUtil.resolveCodingScheme(source, schemeName);
		return (CodingSchemeType) source.getContainer(CodingSchemeType.class, -1);
	}
	
	/**
	 * Returns the name of the effective coding scheme for the given relation source;
	 * empty if not accessible.
	 * @param source
	 * @return String
	 */
	public static String resolveSourceSchemeName(AssociationInstance source) {
		String schemeName = source.getSourceCodingScheme();
		if (schemeName != null && schemeName.length() > 0)
			return schemeName;
		
		CodingSchemeType scheme = (CodingSchemeType) source.getContainer(CodingSchemeType.class, -1);
		return (scheme != null)
			? scheme.getCodingScheme()
			: StringUtils.EMPTY;
	}
	
	/**
	 * Returns the effective coding scheme for the given relation type;
	 * null if not accessible.
	 * @param relation
	 * @return CodingSchemeType
	 */
	public static CodingSchemeType resolveTargetScheme(Association relation) {
		String schemeName = relation.getTargetCodingScheme();
		if (schemeName != null && schemeName.length() > 0)
			return CodingschemesUtil.resolveCodingScheme(relation, schemeName);
		return (CodingSchemeType) relation.getContainer(CodingSchemeType.class, 1);
	}
	
	/**
	 * Returns the name of the effective coding scheme for the given relation type;
	 * null if not accessible.
	 * @param relation
	 * @return String
	 */
	public static String resolveTargetSchemeName(Association relation) {
		String schemeName = relation.getTargetCodingScheme();
		if (schemeName != null && schemeName.length() > 0)
			return schemeName;
		
		CodingSchemeType scheme = (CodingSchemeType) relation.getContainer(CodingSchemeType.class, 1);
		return (scheme != null)
			? scheme.getCodingScheme()
			: StringUtils.EMPTY;
	}
	
	/**
	 * Returns the name of the coding scheme pointed to by the given target;
	 * null if not accessible.
	 * @param target
	 * @return CodingSchemeType
	 */
	public static CodingSchemeType resolveTargetScheme(AssociationTarget target) {
		String schemeName = target.getTargetCodingScheme();
		if (schemeName != null && schemeName.length() > 0)
			return CodingschemesUtil.resolveCodingScheme(target, schemeName);
		
		Association relation = (Association) target.getContainer(Association.class, 1);
		if (relation != null)
			return resolveTargetScheme(relation);
		return null;
	}
	
	/**
	 * Returns the name of the effective coding scheme for the given relation target;
	 * null if not accessible.
	 * @param target
	 * @return String
	 */
	public static String resolveTargetSchemeName(AssociationTarget target) {
		String schemeName = target.getTargetCodingScheme();
		if (schemeName != null && schemeName.length() > 0)
			return schemeName;
		
		Association relation = (Association) target.getContainer(Association.class, 1);
		if (relation != null)
			return resolveTargetSchemeName(relation);
		return StringUtils.EMPTY;
	}
	
	/**
	 * Incorporates a source within a given class of relations.
	 * <p>
	 * If an item already exists to match the one provided, nothing is added and the
	 * existing item remains unchanged. If not present, the given item is added.
	 * @param relationClass
	 * @param source
	 * @return The item as maintained by the relations class.
	 */
	public static AssociationInstance subsume(Association relationClass, AssociationInstance source) {
		return (AssociationInstance) subsume(relationClass, source, RelationsPackage.eINSTANCE.getAssociation_SourceConcept());
	}

	/**
	 * Incorporates a relation target within a source.
	 * <p>
	 * If an item already exists to match the one provided, nothing is added and the
	 * existing item remains unchanged. If not present, the given item is added.
	 * @param source
	 * @param target
	 * @return The item as maintained by the relations class.
	 */
	public static AssociationTarget subsume(AssociationInstance source, AssociationTarget target) {
		return (AssociationTarget) subsume(source, target, RelationsPackage.eINSTANCE.getAssociationInstance_TargetConcept());
	}
	
	/**
	 * Incorporates a relations container into the scheme.
	 * <p>
	 * If an item already exists to match the one provided, nothing is added and the
	 * existing item remains unchanged. If not present, the given item is added.
	 * @param scheme
	 * @param container
	 * @return The item as maintained by the scheme.
	 */
	public static Relations subsume(CodingSchemeType scheme, Relations container) {
		return (Relations) subsume(scheme, container, CodingschemesPackage.eINSTANCE.getCodingSchemeType_Relations());
	}
	
	/**
	 * Incorporates a class of relations into the relations container.
	 * <p>
	 * If an item already exists to match the one provided, nothing is added and the
	 * existing item remains unchanged. If not present, the given item is added.
	 * @param container
	 * @param relationClass
	 * @return The item as maintained by the container.
	 */
	public static Association subsume(Relations container, Association relationClass) {
		return (Association) subsume(container, relationClass, RelationsPackage.eINSTANCE.getRelations_Association());
	}
	
	/**
	 * Incorporates a source within a given class of relations.
	 * <p>
	 * If an item already exists to match the one provided, nothing is added and the
	 * existing item remains unchanged. If not present, the given item is added.
	 * @param relationClass
	 * @param source
	 * @return The item as maintained by the relations class.
	 */
	protected static LgModelObj subsume(LgModelObj container, LgModelObj item, EStructuralFeature listFeature) {
		LgModelObj maintainedItem = null;

		// Allow for keyed or enhanced EList optimization if provided.
		EList content = (EList) container.eGet(listFeature);
		int pos = 0;
		boolean inprogress = true;
		while (maintainedItem == null && inprogress) {
			if (content instanceof LgKeyedList)
				maintainedItem = ((LgKeyedList) content).getByPrimaryKey(item.getPrimaryKey());
			else
				for (int i = pos; maintainedItem == null && i < content.size(); i++) {
					Object o1, o2;
					LgModelObj candidate = (LgModelObj) content.get(i);
					if (candidate == item
							|| ((candidate instanceof LgModelObjImpl && candidate.getClass() == item.getClass())
									&& (((o1 = item.eResource()) == (o2 = candidate.eResource())) || (o1 != null && o1.equals(o2)))
									&& (((o1 = item.getPrimaryKey()) == (o2 = candidate.getPrimaryKey()) || (o1 != null && o1.equals(o2))))))
						maintainedItem = candidate;
				}
			if (inprogress = (content instanceof LgEnhancedList && !((LgEnhancedList) content).isPagingComplete()))
				try {
					((LgEnhancedList) content).resolvePage();
				} catch (ResolveException e) {
					logger.error("Unable to resolve paged list", e);
				}
		}

		// If not found, add it ...
		if (maintainedItem == null) {
			content.add(item);
			maintainedItem = item;
		}
		return maintainedItem;
	}
	
}