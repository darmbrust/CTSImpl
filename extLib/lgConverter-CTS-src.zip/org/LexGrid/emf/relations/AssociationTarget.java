/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.relations;

import org.LexGrid.emf.base.LgCodedObj;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Association Target</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * An instance of a target or RHS concept of an association.
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.LexGrid.emf.relations.AssociationTarget#getTargetCodingScheme <em>Target Coding Scheme</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.AssociationTarget#getTargetConcept <em>Target Concept</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.LexGrid.emf.relations.RelationsPackage#getAssociationTarget()
 * @model extendedMetaData="name='associationTarget' kind='elementOnly'"
 * @generated
 */
public interface AssociationTarget extends AssociatableElement, LgCodedObj {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Returns the value of the '<em><b>Target Coding Scheme</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Coding scheme of the target concept. If present must be in supportedCodingSchemes. If absent,
	 *                                                         the coding scheme is the targetCodingScheme of the containing association.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Target Coding Scheme</em>' attribute.
	 * @see #setTargetCodingScheme(String)
	 * @see org.LexGrid.emf.relations.RelationsPackage#getAssociationTarget_TargetCodingScheme()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.LocalId"
	 *        extendedMetaData="kind='attribute' name='targetCodingScheme'"
	 * @generated
	 */
	String getTargetCodingScheme();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.relations.AssociationTarget#getTargetCodingScheme <em>Target Coding Scheme</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target Coding Scheme</em>' attribute.
	 * @see #getTargetCodingScheme()
	 * @generated
	 */
	void setTargetCodingScheme(String value);

	/**
	 * Returns the value of the '<em><b>Target Concept</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Concept code from the target coding scheme.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Target Concept</em>' attribute.
	 * @see #setTargetConcept(String)
	 * @see org.LexGrid.emf.relations.RelationsPackage#getAssociationTarget_TargetConcept()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.ConceptCode" required="true"
	 *        extendedMetaData="kind='attribute' name='targetConcept'"
	 * @generated
	 */
	String getTargetConcept();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.relations.AssociationTarget#getTargetConcept <em>Target Concept</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target Concept</em>' attribute.
	 * @see #getTargetConcept()
	 * @generated
	 */
	void setTargetConcept(String value);

} // AssociationTarget