/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.relations;

import java.util.List;

import org.LexGrid.emf.base.LgCodedObj;
import org.LexGrid.emf.base.LgModelObj;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Association Instance</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * An instance of a 'source' or LHS of an association. An association instance references one or more 'targets' or RHS's
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.LexGrid.emf.relations.AssociationInstance#getSourceCodingScheme <em>Source Coding Scheme</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.AssociationInstance#getSourceConcept <em>Source Concept</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.AssociationInstance#getTargetConcept <em>Target Concept</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.AssociationInstance#getTargetDataValue <em>Target Data Value</em>}</li>
 *   <li>{@link org.LexGrid.emf.relations.AssociationInstance#getAssociation <em>Association</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.LexGrid.emf.relations.RelationsPackage#getAssociationInstance()
 * @model 
 */
public interface AssociationInstance extends LgModelObj, LgCodedObj {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Returns the value of the '<em><b>Source Coding Scheme</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Local name of the coding scheme that the source is drawn from. If present, must be in supportedCodingScheme.
	 *                                         If absent, the source coding scheme is the containing coding scheme.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Source Coding Scheme</em>' attribute.
	 * @see #setSourceCodingScheme(String)
	 * @see org.LexGrid.emf.relations.RelationsPackage#getAssociationInstance_SourceCodingScheme()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.LocalId"
	 *        extendedMetaData="kind='attribute' name='sourceCodingScheme'"
	 * @generated
	 */
	String getSourceCodingScheme();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.relations.AssociationInstance#getSourceCodingScheme <em>Source Coding Scheme</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source Coding Scheme</em>' attribute.
	 * @see #getSourceCodingScheme()
	 * @generated
	 */
	void setSourceCodingScheme(String value);

	/**
	 * Returns the value of the '<em><b>Source Concept</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The source concept code.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Source Concept</em>' attribute.
	 * @see #setSourceConcept(String)
	 * @see org.LexGrid.emf.relations.RelationsPackage#getAssociationInstance_SourceConcept()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.ConceptCode" required="true"
	 *        extendedMetaData="kind='attribute' name='sourceConcept'"
	 * @generated
	 */
	String getSourceConcept();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.relations.AssociationInstance#getSourceConcept <em>Source Concept</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source Concept</em>' attribute.
	 * @see #getSourceConcept()
	 * @generated
	 */
	void setSourceConcept(String value);

	/**
	 * Returns the value of the '<em><b>Target Concept</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.relations.AssociationTarget}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * An instance of a 'target' or RHS concept of an association.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Target Concept</em>' containment reference list.
	 * @see org.LexGrid.emf.relations.RelationsPackage#getAssociationInstance_TargetConcept()
	 * @model type="org.LexGrid.emf.relations.AssociationTarget" containment="true"
	 *        extendedMetaData="kind='element' name='targetConcept' namespace='##targetNamespace'"
	 * @generated
	 */
	List getTargetConcept();

	/**
	 * Returns the value of the '<em><b>Target Data Value</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.relations.AssociationData}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * An instance of a 'target' or RHS data element of an association.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Target Data Value</em>' containment reference list.
	 * @see org.LexGrid.emf.relations.RelationsPackage#getAssociationInstance_TargetDataValue()
	 * @model type="org.LexGrid.emf.relations.AssociationData" containment="true"
	 *        extendedMetaData="kind='element' name='targetDataValue' namespace='##targetNamespace'"
	 * @generated
	 */
	List getTargetDataValue();

} // AssociationInstance