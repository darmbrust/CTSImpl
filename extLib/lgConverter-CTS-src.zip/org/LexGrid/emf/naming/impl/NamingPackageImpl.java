/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.naming.impl;

import org.LexGrid.emf.base.impl.LgAttributeImpl;
import org.LexGrid.emf.base.impl.LgReferenceImpl;
import org.LexGrid.emf.builtins.BuiltinsPackage;
import org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl;
import org.LexGrid.emf.codingSchemes.CodingschemesPackage;
import org.LexGrid.emf.codingSchemes.impl.CodingschemesPackageImpl;
import org.LexGrid.emf.commonTypes.CommontypesPackage;
import org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl;
import org.LexGrid.emf.concepts.ConceptsPackage;
import org.LexGrid.emf.concepts.impl.ConceptsPackageImpl;
import org.LexGrid.emf.history.NCIHistoryPackage;
import org.LexGrid.emf.history.impl.NCIHistoryPackageImpl;
import org.LexGrid.emf.ldap.LdapPackage;
import org.LexGrid.emf.ldap.impl.LdapPackageImpl;
import org.LexGrid.emf.naming.NamingFactory;
import org.LexGrid.emf.naming.NamingPackage;
import org.LexGrid.emf.naming.SupportedAssociation;
import org.LexGrid.emf.naming.SupportedAssociationQualifier;
import org.LexGrid.emf.naming.SupportedCodingScheme;
import org.LexGrid.emf.naming.SupportedConceptStatus;
import org.LexGrid.emf.naming.SupportedContext;
import org.LexGrid.emf.naming.SupportedDegreeOfFidelity;
import org.LexGrid.emf.naming.SupportedFormat;
import org.LexGrid.emf.naming.SupportedLanguage;
import org.LexGrid.emf.naming.SupportedProperty;
import org.LexGrid.emf.naming.SupportedPropertyLink;
import org.LexGrid.emf.naming.SupportedPropertyQualifier;
import org.LexGrid.emf.naming.SupportedRepresentationalForm;
import org.LexGrid.emf.naming.SupportedSource;
import org.LexGrid.emf.naming.URNMap;
import org.LexGrid.emf.relations.RelationsPackage;
import org.LexGrid.emf.relations.impl.RelationsPackageImpl;
import org.LexGrid.emf.service.ServiceTypePackage;
import org.LexGrid.emf.service.impl.ServiceTypePackageImpl;
import org.LexGrid.emf.valueDomains.ValuedomainsPackage;
import org.LexGrid.emf.valueDomains.impl.ValuedomainsPackageImpl;
import org.LexGrid.emf.versions.VersionsPackage;
import org.LexGrid.emf.versions.impl.VersionsPackageImpl;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class NamingPackageImpl extends EPackageImpl implements NamingPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass urnMapEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass supportedPropertyQualifierEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass supportedLanguageEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass supportedRepresentationalFormEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass supportedConceptStatusEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass supportedContextEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass supportedDegreeOfFidelityEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass supportedAssociationQualifierEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass supportedAssociationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass supportedSourceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass supportedCodingSchemeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass supportedPropertyEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass supportedPropertyLinkEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass supportedFormatEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType urnEDataType = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see org.LexGrid.emf.naming.NamingPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private NamingPackageImpl() {
		super(eNS_URI, NamingFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this
	 * model, and for any others upon which it depends.  Simple
	 * dependencies are satisfied by calling this method on all
	 * dependent packages before doing anything else.  This method drives
	 * initialization for interdependent packages directly, in parallel
	 * with this package, itself.
	 * <p>Of this package and its interdependencies, all packages which
	 * have not yet been registered by their URI values are first created
	 * and registered.  The packages are then initialized in two steps:
	 * meta-model objects for all of the packages are created before any
	 * are initialized, since one package's meta-model objects may refer to
	 * those of another.
	 * <p>Invocation of this method will not affect any packages that have
	 * already been initialized.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static NamingPackage init() {
		if (isInited)
			return (NamingPackage) EPackage.Registry.INSTANCE.getEPackage(NamingPackage.eNS_URI);

		// Obtain or create and register package
		NamingPackageImpl theNamingPackage = (NamingPackageImpl) (EPackage.Registry.INSTANCE.getEPackage(eNS_URI) instanceof NamingPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(eNS_URI)
				: new NamingPackageImpl());

		isInited = true;

		// Obtain or create and register interdependencies
		ConceptsPackageImpl theConceptsPackage = (ConceptsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(ConceptsPackage.eNS_URI) instanceof ConceptsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(ConceptsPackage.eNS_URI) : ConceptsPackage.eINSTANCE);
		RelationsPackageImpl theRelationsPackage = (RelationsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(RelationsPackage.eNS_URI) instanceof RelationsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(RelationsPackage.eNS_URI) : RelationsPackage.eINSTANCE);
		NCIHistoryPackageImpl theNCIHistoryPackage = (NCIHistoryPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(NCIHistoryPackage.eNS_URI) instanceof NCIHistoryPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(NCIHistoryPackage.eNS_URI) : NCIHistoryPackage.eINSTANCE);
		VersionsPackageImpl theVersionsPackage = (VersionsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(VersionsPackage.eNS_URI) instanceof VersionsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(VersionsPackage.eNS_URI) : VersionsPackage.eINSTANCE);
		CodingschemesPackageImpl theCodingschemesPackage = (CodingschemesPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(CodingschemesPackage.eNS_URI) instanceof CodingschemesPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(CodingschemesPackage.eNS_URI)
				: CodingschemesPackage.eINSTANCE);
		LdapPackageImpl theLdapPackage = (LdapPackageImpl) (EPackage.Registry.INSTANCE.getEPackage(LdapPackage.eNS_URI) instanceof LdapPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(LdapPackage.eNS_URI)
				: LdapPackage.eINSTANCE);
		BuiltinsPackageImpl theBuiltinsPackage = (BuiltinsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(BuiltinsPackage.eNS_URI) instanceof BuiltinsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(BuiltinsPackage.eNS_URI) : BuiltinsPackage.eINSTANCE);
		ValuedomainsPackageImpl theValuedomainsPackage = (ValuedomainsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(ValuedomainsPackage.eNS_URI) instanceof ValuedomainsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(ValuedomainsPackage.eNS_URI)
				: ValuedomainsPackage.eINSTANCE);
		CommontypesPackageImpl theCommontypesPackage = (CommontypesPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(CommontypesPackage.eNS_URI) instanceof CommontypesPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(CommontypesPackage.eNS_URI) : CommontypesPackage.eINSTANCE);
		ServiceTypePackageImpl theServiceTypePackage = (ServiceTypePackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(ServiceTypePackage.eNS_URI) instanceof ServiceTypePackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(ServiceTypePackage.eNS_URI) : ServiceTypePackage.eINSTANCE);

		// Create package meta-data objects
		theNamingPackage.createPackageContents();
		theConceptsPackage.createPackageContents();
		theRelationsPackage.createPackageContents();
		theNCIHistoryPackage.createPackageContents();
		theVersionsPackage.createPackageContents();
		theCodingschemesPackage.createPackageContents();
		theLdapPackage.createPackageContents();
		theBuiltinsPackage.createPackageContents();
		theValuedomainsPackage.createPackageContents();
		theCommontypesPackage.createPackageContents();
		theServiceTypePackage.createPackageContents();

		// Initialize created meta-data
		theNamingPackage.initializePackageContents();
		theConceptsPackage.initializePackageContents();
		theRelationsPackage.initializePackageContents();
		theNCIHistoryPackage.initializePackageContents();
		theVersionsPackage.initializePackageContents();
		theCodingschemesPackage.initializePackageContents();
		theLdapPackage.initializePackageContents();
		theBuiltinsPackage.initializePackageContents();
		theValuedomainsPackage.initializePackageContents();
		theCommontypesPackage.initializePackageContents();
		theServiceTypePackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theNamingPackage.freeze();

		return theNamingPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getURNMap() {
		return urnMapEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getURNMap_Value() {
		return (EAttribute) urnMapEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getURNMap_LocalId() {
		return (EAttribute) urnMapEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getURNMap_Urn() {
		return (EAttribute) urnMapEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSupportedPropertyQualifier() {
		return supportedPropertyQualifierEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSupportedLanguage() {
		return supportedLanguageEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSupportedRepresentationalForm() {
		return supportedRepresentationalFormEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSupportedConceptStatus() {
		return supportedConceptStatusEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSupportedContext() {
		return supportedContextEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSupportedDegreeOfFidelity() {
		return supportedDegreeOfFidelityEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSupportedAssociationQualifier() {
		return supportedAssociationQualifierEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSupportedAssociation() {
		return supportedAssociationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSupportedSource() {
		return supportedSourceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSupportedSource_AgentRole() {
		return (EAttribute) supportedSourceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSupportedSource_AssemblyRule() {
		return (EAttribute) supportedSourceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSupportedCodingScheme() {
		return supportedCodingSchemeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSupportedProperty() {
		return supportedPropertyEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSupportedPropertyLink() {
		return supportedPropertyLinkEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSupportedFormat() {
		return supportedFormatEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getURN() {
		return urnEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NamingFactory getNamingFactory() {
		return (NamingFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		supportedAssociationEClass = createEClass(SUPPORTED_ASSOCIATION);

		supportedAssociationQualifierEClass = createEClass(SUPPORTED_ASSOCIATION_QUALIFIER);

		supportedCodingSchemeEClass = createEClass(SUPPORTED_CODING_SCHEME);

		supportedConceptStatusEClass = createEClass(SUPPORTED_CONCEPT_STATUS);

		supportedContextEClass = createEClass(SUPPORTED_CONTEXT);

		supportedDegreeOfFidelityEClass = createEClass(SUPPORTED_DEGREE_OF_FIDELITY);

		supportedFormatEClass = createEClass(SUPPORTED_FORMAT);

		supportedLanguageEClass = createEClass(SUPPORTED_LANGUAGE);

		supportedPropertyEClass = createEClass(SUPPORTED_PROPERTY);

		supportedPropertyLinkEClass = createEClass(SUPPORTED_PROPERTY_LINK);

		supportedPropertyQualifierEClass = createEClass(SUPPORTED_PROPERTY_QUALIFIER);

		supportedRepresentationalFormEClass = createEClass(SUPPORTED_REPRESENTATIONAL_FORM);

		supportedSourceEClass = createEClass(SUPPORTED_SOURCE);
		createEAttribute(supportedSourceEClass, SUPPORTED_SOURCE__AGENT_ROLE);
		createEAttribute(supportedSourceEClass, SUPPORTED_SOURCE__ASSEMBLY_RULE);

		urnMapEClass = createEClass(URN_MAP);
		createEAttribute(urnMapEClass, URN_MAP__VALUE);
		createEAttribute(urnMapEClass, URN_MAP__LOCAL_ID);
		createEAttribute(urnMapEClass, URN_MAP__URN);

		// Create data types
		urnEDataType = createEDataType(URN);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContentsGen() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		BuiltinsPackage theBuiltinsPackage = (BuiltinsPackage) EPackage.Registry.INSTANCE
				.getEPackage(BuiltinsPackage.eNS_URI);

		// Add supertypes to classes
		supportedAssociationEClass.getESuperTypes().add(this.getURNMap());
		supportedAssociationQualifierEClass.getESuperTypes().add(this.getURNMap());
		supportedCodingSchemeEClass.getESuperTypes().add(this.getURNMap());
		supportedConceptStatusEClass.getESuperTypes().add(this.getURNMap());
		supportedContextEClass.getESuperTypes().add(this.getURNMap());
		supportedDegreeOfFidelityEClass.getESuperTypes().add(this.getURNMap());
		supportedFormatEClass.getESuperTypes().add(this.getURNMap());
		supportedLanguageEClass.getESuperTypes().add(this.getURNMap());
		supportedPropertyEClass.getESuperTypes().add(this.getURNMap());
		supportedPropertyLinkEClass.getESuperTypes().add(this.getURNMap());
		supportedPropertyQualifierEClass.getESuperTypes().add(this.getURNMap());
		supportedRepresentationalFormEClass.getESuperTypes().add(this.getURNMap());
		supportedSourceEClass.getESuperTypes().add(this.getURNMap());

		// Initialize classes and features; add operations and parameters
		initEClass(supportedAssociationEClass, SupportedAssociation.class, "SupportedAssociation", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(supportedAssociationQualifierEClass, SupportedAssociationQualifier.class,
				"SupportedAssociationQualifier", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(supportedCodingSchemeEClass, SupportedCodingScheme.class, "SupportedCodingScheme", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(supportedConceptStatusEClass, SupportedConceptStatus.class, "SupportedConceptStatus", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(supportedContextEClass, SupportedContext.class, "SupportedContext", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(supportedDegreeOfFidelityEClass, SupportedDegreeOfFidelity.class, "SupportedDegreeOfFidelity",
				!IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(supportedFormatEClass, SupportedFormat.class, "SupportedFormat", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(supportedLanguageEClass, SupportedLanguage.class, "SupportedLanguage", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(supportedPropertyEClass, SupportedProperty.class, "SupportedProperty", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(supportedPropertyLinkEClass, SupportedPropertyLink.class, "SupportedPropertyLink", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(supportedPropertyQualifierEClass, SupportedPropertyQualifier.class, "SupportedPropertyQualifier",
				!IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(supportedRepresentationalFormEClass, SupportedRepresentationalForm.class,
				"SupportedRepresentationalForm", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(supportedSourceEClass, SupportedSource.class, "SupportedSource", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSupportedSource_AgentRole(), theBuiltinsPackage.getTsCaseIgnoreIA5String(), "agentRole",
				null, 0, 1, SupportedSource.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				!IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSupportedSource_AssemblyRule(), theBuiltinsPackage.getTsCaseIgnoreIA5String(),
				"assemblyRule", null, 0, 1, SupportedSource.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(urnMapEClass, URNMap.class, "URNMap", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getURNMap_Value(), theBuiltinsPackage.getTsCaseIgnoreIA5String(), "value", null, 0, 1,
				URNMap.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getURNMap_LocalId(), theBuiltinsPackage.getLocalId(), "localId", null, 1, 1, URNMap.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getURNMap_Urn(), this.getURN(), "urn", null, 0, 1, URNMap.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize data types
		initEDataType(urnEDataType, String.class, "URN", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// null
		createNullAnnotations();
		// http:///org/eclipse/emf/ecore/util/ExtendedMetaData
		createExtendedMetaDataAnnotations();
	}

	/**
	 * Initializes the annotations for <b>null</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createNullAnnotations() {
		String source = null;
		addAnnotation(
				supportedAssociationEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n                                <oid xmlns=\"http://LexGrid.org/schema/2006/01/LexGrid/naming\">1.3.6.1.4.1.2114.108.1.6.60</oid>\r\n                        " });
		addAnnotation(
				supportedAssociationQualifierEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n                                <oid xmlns=\"http://LexGrid.org/schema/2006/01/LexGrid/naming\">1.3.6.1.4.1.2114.108.1.6.61</oid>\r\n                        " });
		addAnnotation(
				supportedCodingSchemeEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n                                <oid xmlns=\"http://LexGrid.org/schema/2006/01/LexGrid/naming\">1.3.6.1.4.1.2114.108.1.6.100</oid>\r\n                        " });
		addAnnotation(
				supportedConceptStatusEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n                                <oid xmlns=\"http://LexGrid.org/schema/2006/01/LexGrid/naming\">1.3.6.1.4.1.2114.108.1.6.96</oid>\r\n                        " });
		addAnnotation(
				supportedContextEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n                                <oid xmlns=\"http://LexGrid.org/schema/2006/01/LexGrid/naming\">1.3.6.1.4.1.2114.108.1.6.58</oid>\r\n                        " });
		addAnnotation(
				supportedFormatEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n                                <oid xmlns=\"http://LexGrid.org/schema/2006/01/LexGrid/naming\">1.3.6.1.4.1.2114.108.1.6.57</oid>\r\n                        " });
		addAnnotation(
				supportedLanguageEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n                                <oid xmlns=\"http://LexGrid.org/schema/2006/01/LexGrid/naming\">1.3.6.1.4.1.2114.108.1.6.56</oid>\r\n                        " });
		addAnnotation(
				supportedPropertyEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n                                <oid xmlns=\"http://LexGrid.org/schema/2006/01/LexGrid/naming\">1.3.6.1.4.1.2114.108.1.6.59</oid>\r\n                        " });
		addAnnotation(
				supportedRepresentationalFormEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n                                <oid xmlns=\"http://LexGrid.org/schema/2006/01/LexGrid/naming\">1.3.6.1.4.1.2114.108.1.6.101</oid>\r\n                        " });
		addAnnotation(
				supportedSourceEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n                                <oid xmlns=\"http://LexGrid.org/schema/2006/01/LexGrid/naming\">1.3.6.1.4.1.2114.108.1.6.85</oid>\r\n                        " });
		addAnnotation(
				urnEDataType,
				source,
				new String[] {
						"appinfo",
						"\r\n                                <oid xmlns=\"http://LexGrid.org/schema/2006/01/LexGrid/naming\">1.3.6.1.4.1.2114.108.1.5.6</oid>\r\n                        " });
	}

	/**
	 * Initializes the annotations for <b>http:///org/eclipse/emf/ecore/util/ExtendedMetaData</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createExtendedMetaDataAnnotations() {
		String source = "http:///org/eclipse/emf/ecore/util/ExtendedMetaData";
		addAnnotation(supportedAssociationEClass, source, new String[] { "name", "supportedAssociation", "kind",
				"simple" });
		addAnnotation(supportedAssociationQualifierEClass, source, new String[] { "name",
				"supportedAssociationQualifier", "kind", "simple" });
		addAnnotation(supportedCodingSchemeEClass, source, new String[] { "name", "supportedCodingScheme", "kind",
				"simple" });
		addAnnotation(supportedConceptStatusEClass, source, new String[] { "name", "supportedConceptStatus", "kind",
				"simple" });
		addAnnotation(supportedContextEClass, source, new String[] { "name", "supportedContext", "kind", "simple" });
		addAnnotation(supportedDegreeOfFidelityEClass, source, new String[] { "name", "supportedDegreeOfFidelity",
				"kind", "simple" });
		addAnnotation(supportedFormatEClass, source, new String[] { "name", "supportedFormat", "kind", "simple" });
		addAnnotation(supportedLanguageEClass, source, new String[] { "name", "supportedLanguage", "kind", "simple" });
		addAnnotation(supportedPropertyEClass, source, new String[] { "name", "supportedProperty", "kind", "simple" });
		addAnnotation(supportedPropertyLinkEClass, source, new String[] { "name", "supportedPropertyLink", "kind",
				"simple" });
		addAnnotation(supportedPropertyQualifierEClass, source, new String[] { "name", "supportedPropertyQualifier",
				"kind", "simple" });
		addAnnotation(supportedRepresentationalFormEClass, source, new String[] { "name",
				"supportedRepresentationalForm", "kind", "simple" });
		addAnnotation(supportedSourceEClass, source, new String[] { "name", "supportedSource", "kind", "simple" });
		addAnnotation(getSupportedSource_AgentRole(), source, new String[] { "kind", "attribute", "name", "agentRole" });
		addAnnotation(getSupportedSource_AssemblyRule(), source, new String[] { "kind", "attribute", "name",
				"assemblyRule" });
		addAnnotation(urnEDataType, source, new String[] { "name", "URN", "baseType",
				"http://LexGrid.org/schema/2006/01/LexGrid/builtins#tsURN" });
		addAnnotation(urnMapEClass, source, new String[] { "name", "URNMap", "kind", "simple" });
		addAnnotation(getURNMap_Value(), source, new String[] { "name", ":0", "kind", "simple" });
		addAnnotation(getURNMap_LocalId(), source, new String[] { "kind", "attribute", "name", "localId" });
		addAnnotation(getURNMap_Urn(), source, new String[] { "kind", "attribute", "name", "urn" });
	}

	////////////////////////////////////////////////////////////
	// ************** BEGIN NON-GENERATED CODE ************** //
	//                                                        //
	// ****************************************************** //
	////////////////////////////////////////////////////////////
	/**
	 * Override superclass to create a LexGrid-aware attribute.
	 * @non-generated
	 */
	protected void createEAttribute(EClass owner, int id) {
		LgAttributeImpl eAttribute = new LgAttributeImpl();
		eAttribute.setFeatureID(id);
		owner.getEStructuralFeatures().add(eAttribute);
	}

	/**
	 * Override superclass to create a LexGrid-aware reference.
	 * @non-generated
	 */
	protected void createEReference(EClass owner, int id) {
		LgReferenceImpl eReference = new LgReferenceImpl();
		eReference.setFeatureID(id);
		owner.getEStructuralFeatures().add(eReference);
	}

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * @non-generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		initializePackageContentsGen();

		((LgAttributeImpl) getURNMap_LocalId()).setID(true);
	}
	////////////////////////////////////////////////////////////
	// *************** END NON-GENERATED CODE *************** //
	////////////////////////////////////////////////////////////

} //NamingPackageImpl