/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.naming.impl;

import org.LexGrid.emf.base.impl.LgModelObjImpl;
import org.LexGrid.emf.naming.NamingPackage;
import org.LexGrid.emf.naming.URNMap;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>URN Map</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.LexGrid.emf.naming.impl.URNMapImpl#getUrn <em>Urn</em>}</li>
 *   <li>{@link org.LexGrid.emf.naming.impl.URNMapImpl#getLocalName <em>Local Name</em>}</li>
 * </ul>
 * </p>
 */
public class URNMapImpl extends LgModelObjImpl implements URNMap {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected URNMapImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return NamingPackage.Literals.URN_MAP;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getValue() {
		return (String) eGet(NamingPackage.Literals.URN_MAP__VALUE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setValue(String newValue) {
		eSet(NamingPackage.Literals.URN_MAP__VALUE, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLocalId() {
		return (String) eGet(NamingPackage.Literals.URN_MAP__LOCAL_ID, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLocalId(String newLocalId) {
		eSet(NamingPackage.Literals.URN_MAP__LOCAL_ID, newLocalId);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getUrn() {
		return (String) eGet(NamingPackage.Literals.URN_MAP__URN, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUrn(String newUrn) {
		eSet(NamingPackage.Literals.URN_MAP__URN, newUrn);
	}

	////////////////////////////////////////////////////////////
	// ************** BEGIN NON-GENERATED CODE ************** //
	//                                                        //
	// ****************************************************** //
	////////////////////////////////////////////////////////////

	public String getPreferredDisplayName() {
		String localName = (String) eGet(NamingPackage.eINSTANCE.getURNMap_LocalId(), false);
		String urn = (String) eGet(NamingPackage.eINSTANCE.getURNMap_Urn(), false);

		if (localName == null)
			return urn == null ? getPreferredDisplayNameDefault() : urn;
		if (urn == null || urn.length() == 0)
			return localName;
		return new StringBuffer(128).append(localName).append(" [").append(urn).append(']').toString();
	}

	public void eSet(EStructuralFeature eFeature, Object newValue) {
		super.eSet(eFeature, newValue);

		// Provide backward compatibility with 2005 mappings, where the
		// value was the ID.  Unless explicitly overridden, the local ID will
		// be the same as the value.
		if (NamingPackage.eINSTANCE.getURNMap_Value().equals(eFeature)) {
			Object o = eGet(NamingPackage.eINSTANCE.getURNMap_LocalId(), false);
			if (o == null)
				super.eSet(NamingPackage.eINSTANCE.getURNMap_LocalId(), newValue);
		}
	}

} //URNMapImpl