/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.naming.impl;

import org.LexGrid.emf.builtins.BuiltinsFactory;
import org.LexGrid.emf.builtins.BuiltinsPackage;
import org.LexGrid.emf.naming.NamingFactory;
import org.LexGrid.emf.naming.NamingPackage;
import org.LexGrid.emf.naming.SupportedAssociation;
import org.LexGrid.emf.naming.SupportedAssociationQualifier;
import org.LexGrid.emf.naming.SupportedCodingScheme;
import org.LexGrid.emf.naming.SupportedConceptStatus;
import org.LexGrid.emf.naming.SupportedContext;
import org.LexGrid.emf.naming.SupportedDegreeOfFidelity;
import org.LexGrid.emf.naming.SupportedFormat;
import org.LexGrid.emf.naming.SupportedLanguage;
import org.LexGrid.emf.naming.SupportedProperty;
import org.LexGrid.emf.naming.SupportedPropertyLink;
import org.LexGrid.emf.naming.SupportedPropertyQualifier;
import org.LexGrid.emf.naming.SupportedRepresentationalForm;
import org.LexGrid.emf.naming.SupportedSource;
import org.LexGrid.emf.naming.URNMap;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EFactoryImpl;
import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class NamingFactoryImpl extends EFactoryImpl implements NamingFactory {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static NamingFactory init() {
		try {
			NamingFactory theNamingFactory = (NamingFactory) EPackage.Registry.INSTANCE
					.getEFactory("http://LexGrid.org/schema/2006/01/LexGrid/naming");
			if (theNamingFactory != null) {
				return theNamingFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new NamingFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NamingFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case NamingPackage.SUPPORTED_ASSOCIATION:
			return (EObject) createSupportedAssociation();
		case NamingPackage.SUPPORTED_ASSOCIATION_QUALIFIER:
			return (EObject) createSupportedAssociationQualifier();
		case NamingPackage.SUPPORTED_CODING_SCHEME:
			return (EObject) createSupportedCodingScheme();
		case NamingPackage.SUPPORTED_CONCEPT_STATUS:
			return (EObject) createSupportedConceptStatus();
		case NamingPackage.SUPPORTED_CONTEXT:
			return (EObject) createSupportedContext();
		case NamingPackage.SUPPORTED_DEGREE_OF_FIDELITY:
			return (EObject) createSupportedDegreeOfFidelity();
		case NamingPackage.SUPPORTED_FORMAT:
			return (EObject) createSupportedFormat();
		case NamingPackage.SUPPORTED_LANGUAGE:
			return (EObject) createSupportedLanguage();
		case NamingPackage.SUPPORTED_PROPERTY:
			return (EObject) createSupportedProperty();
		case NamingPackage.SUPPORTED_PROPERTY_LINK:
			return (EObject) createSupportedPropertyLink();
		case NamingPackage.SUPPORTED_PROPERTY_QUALIFIER:
			return (EObject) createSupportedPropertyQualifier();
		case NamingPackage.SUPPORTED_REPRESENTATIONAL_FORM:
			return (EObject) createSupportedRepresentationalForm();
		case NamingPackage.SUPPORTED_SOURCE:
			return (EObject) createSupportedSource();
		case NamingPackage.URN_MAP:
			return (EObject) createURNMap();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
		case NamingPackage.URN:
			return createURNFromString(eDataType, initialValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
		case NamingPackage.URN:
			return convertURNToString(eDataType, instanceValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public URNMap createURNMap() {
		URNMapImpl urnMap = new URNMapImpl();
		return urnMap;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SupportedPropertyQualifier createSupportedPropertyQualifier() {
		SupportedPropertyQualifierImpl supportedPropertyQualifier = new SupportedPropertyQualifierImpl();
		return supportedPropertyQualifier;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SupportedLanguage createSupportedLanguage() {
		SupportedLanguageImpl supportedLanguage = new SupportedLanguageImpl();
		return supportedLanguage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SupportedRepresentationalForm createSupportedRepresentationalForm() {
		SupportedRepresentationalFormImpl supportedRepresentationalForm = new SupportedRepresentationalFormImpl();
		return supportedRepresentationalForm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SupportedConceptStatus createSupportedConceptStatus() {
		SupportedConceptStatusImpl supportedConceptStatus = new SupportedConceptStatusImpl();
		return supportedConceptStatus;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SupportedContext createSupportedContext() {
		SupportedContextImpl supportedContext = new SupportedContextImpl();
		return supportedContext;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SupportedDegreeOfFidelity createSupportedDegreeOfFidelity() {
		SupportedDegreeOfFidelityImpl supportedDegreeOfFidelity = new SupportedDegreeOfFidelityImpl();
		return supportedDegreeOfFidelity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SupportedAssociationQualifier createSupportedAssociationQualifier() {
		SupportedAssociationQualifierImpl supportedAssociationQualifier = new SupportedAssociationQualifierImpl();
		return supportedAssociationQualifier;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SupportedAssociation createSupportedAssociation() {
		SupportedAssociationImpl supportedAssociation = new SupportedAssociationImpl();
		return supportedAssociation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SupportedSource createSupportedSource() {
		SupportedSourceImpl supportedSource = new SupportedSourceImpl();
		return supportedSource;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SupportedCodingScheme createSupportedCodingScheme() {
		SupportedCodingSchemeImpl supportedCodingScheme = new SupportedCodingSchemeImpl();
		return supportedCodingScheme;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SupportedProperty createSupportedProperty() {
		SupportedPropertyImpl supportedProperty = new SupportedPropertyImpl();
		return supportedProperty;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SupportedPropertyLink createSupportedPropertyLink() {
		SupportedPropertyLinkImpl supportedPropertyLink = new SupportedPropertyLinkImpl();
		return supportedPropertyLink;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SupportedFormat createSupportedFormat() {
		SupportedFormatImpl supportedFormat = new SupportedFormatImpl();
		return supportedFormat;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createURNFromString(EDataType eDataType, String initialValue) {
		return (String) BuiltinsFactory.eINSTANCE.createFromString(BuiltinsPackage.Literals.TS_URN, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertURNToString(EDataType eDataType, Object instanceValue) {
		return BuiltinsFactory.eINSTANCE.convertToString(BuiltinsPackage.Literals.TS_URN, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NamingPackage getNamingPackage() {
		return (NamingPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	public static NamingPackage getPackage() {
		return NamingPackage.eINSTANCE;
	}

} //NamingFactoryImpl