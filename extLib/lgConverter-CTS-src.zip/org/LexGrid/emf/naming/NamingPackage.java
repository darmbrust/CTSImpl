/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.naming;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * <!-- begin-model-doc -->
 * Basic builtin types
 * 
 * 			<h2 xmlns="http://LexGrid.org/schema/2006/01/LexGrid/builtins">Core data types for the lexical grid.</h2>
 * 		
 * These types need to be mapped to the appropriate implementation specific data types. The mapping in this package represents the XML
 * 			Schema data types mapping
 * LDAP specific types for appinfo annotation
 * <!-- end-model-doc -->
 * @see org.LexGrid.emf.naming.NamingFactory
 * @model kind="package"
 * @generated
 */
public interface NamingPackage extends EPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "naming";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://LexGrid.org/schema/2006/01/LexGrid/naming";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "lgNaming";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	NamingPackage eINSTANCE = org.LexGrid.emf.naming.impl.NamingPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.naming.impl.URNMapImpl <em>URN Map</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.naming.impl.URNMapImpl
	 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getURNMap()
	 * @generated
	 */
	int URN_MAP = 13;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int URN_MAP__VALUE = 0;

	/**
	 * The feature id for the '<em><b>Local Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int URN_MAP__LOCAL_ID = 1;

	/**
	 * The feature id for the '<em><b>Urn</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int URN_MAP__URN = 2;

	/**
	 * The number of structural features of the '<em>URN Map</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int URN_MAP_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.naming.impl.SupportedLanguageImpl <em>Supported Language</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.naming.impl.SupportedLanguageImpl
	 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedLanguage()
	 * @generated
	 */
	int SUPPORTED_LANGUAGE = 7;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.naming.impl.SupportedRepresentationalFormImpl <em>Supported Representational Form</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.naming.impl.SupportedRepresentationalFormImpl
	 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedRepresentationalForm()
	 * @generated
	 */
	int SUPPORTED_REPRESENTATIONAL_FORM = 11;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.naming.impl.SupportedConceptStatusImpl <em>Supported Concept Status</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.naming.impl.SupportedConceptStatusImpl
	 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedConceptStatus()
	 * @generated
	 */
	int SUPPORTED_CONCEPT_STATUS = 3;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.naming.impl.SupportedContextImpl <em>Supported Context</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.naming.impl.SupportedContextImpl
	 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedContext()
	 * @generated
	 */
	int SUPPORTED_CONTEXT = 4;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.naming.impl.SupportedAssociationQualifierImpl <em>Supported Association Qualifier</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.naming.impl.SupportedAssociationQualifierImpl
	 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedAssociationQualifier()
	 * @generated
	 */
	int SUPPORTED_ASSOCIATION_QUALIFIER = 1;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.naming.impl.SupportedAssociationImpl <em>Supported Association</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.naming.impl.SupportedAssociationImpl
	 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedAssociation()
	 * @generated
	 */
	int SUPPORTED_ASSOCIATION = 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_ASSOCIATION__VALUE = URN_MAP__VALUE;

	/**
	 * The feature id for the '<em><b>Local Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_ASSOCIATION__LOCAL_ID = URN_MAP__LOCAL_ID;

	/**
	 * The feature id for the '<em><b>Urn</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_ASSOCIATION__URN = URN_MAP__URN;

	/**
	 * The number of structural features of the '<em>Supported Association</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_ASSOCIATION_FEATURE_COUNT = URN_MAP_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_ASSOCIATION_QUALIFIER__VALUE = URN_MAP__VALUE;

	/**
	 * The feature id for the '<em><b>Local Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_ASSOCIATION_QUALIFIER__LOCAL_ID = URN_MAP__LOCAL_ID;

	/**
	 * The feature id for the '<em><b>Urn</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_ASSOCIATION_QUALIFIER__URN = URN_MAP__URN;

	/**
	 * The number of structural features of the '<em>Supported Association Qualifier</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_ASSOCIATION_QUALIFIER_FEATURE_COUNT = URN_MAP_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.naming.impl.SupportedSourceImpl <em>Supported Source</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.naming.impl.SupportedSourceImpl
	 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedSource()
	 * @generated
	 */
	int SUPPORTED_SOURCE = 12;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.naming.impl.SupportedCodingSchemeImpl <em>Supported Coding Scheme</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.naming.impl.SupportedCodingSchemeImpl
	 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedCodingScheme()
	 * @generated
	 */
	int SUPPORTED_CODING_SCHEME = 2;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_CODING_SCHEME__VALUE = URN_MAP__VALUE;

	/**
	 * The feature id for the '<em><b>Local Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_CODING_SCHEME__LOCAL_ID = URN_MAP__LOCAL_ID;

	/**
	 * The feature id for the '<em><b>Urn</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_CODING_SCHEME__URN = URN_MAP__URN;

	/**
	 * The number of structural features of the '<em>Supported Coding Scheme</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_CODING_SCHEME_FEATURE_COUNT = URN_MAP_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_CONCEPT_STATUS__VALUE = URN_MAP__VALUE;

	/**
	 * The feature id for the '<em><b>Local Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_CONCEPT_STATUS__LOCAL_ID = URN_MAP__LOCAL_ID;

	/**
	 * The feature id for the '<em><b>Urn</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_CONCEPT_STATUS__URN = URN_MAP__URN;

	/**
	 * The number of structural features of the '<em>Supported Concept Status</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_CONCEPT_STATUS_FEATURE_COUNT = URN_MAP_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_CONTEXT__VALUE = URN_MAP__VALUE;

	/**
	 * The feature id for the '<em><b>Local Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_CONTEXT__LOCAL_ID = URN_MAP__LOCAL_ID;

	/**
	 * The feature id for the '<em><b>Urn</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_CONTEXT__URN = URN_MAP__URN;

	/**
	 * The number of structural features of the '<em>Supported Context</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_CONTEXT_FEATURE_COUNT = URN_MAP_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.naming.impl.SupportedDegreeOfFidelityImpl <em>Supported Degree Of Fidelity</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.naming.impl.SupportedDegreeOfFidelityImpl
	 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedDegreeOfFidelity()
	 * @generated
	 */
	int SUPPORTED_DEGREE_OF_FIDELITY = 5;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_DEGREE_OF_FIDELITY__VALUE = URN_MAP__VALUE;

	/**
	 * The feature id for the '<em><b>Local Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_DEGREE_OF_FIDELITY__LOCAL_ID = URN_MAP__LOCAL_ID;

	/**
	 * The feature id for the '<em><b>Urn</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_DEGREE_OF_FIDELITY__URN = URN_MAP__URN;

	/**
	 * The number of structural features of the '<em>Supported Degree Of Fidelity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_DEGREE_OF_FIDELITY_FEATURE_COUNT = URN_MAP_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.naming.impl.SupportedPropertyImpl <em>Supported Property</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.naming.impl.SupportedPropertyImpl
	 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedProperty()
	 * @generated
	 */
	int SUPPORTED_PROPERTY = 8;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.naming.impl.SupportedPropertyLinkImpl <em>Supported Property Link</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.naming.impl.SupportedPropertyLinkImpl
	 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedPropertyLink()
	 * @generated
	 */
	int SUPPORTED_PROPERTY_LINK = 9;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.naming.impl.SupportedFormatImpl <em>Supported Format</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.naming.impl.SupportedFormatImpl
	 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedFormat()
	 * @generated
	 */
	int SUPPORTED_FORMAT = 6;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_FORMAT__VALUE = URN_MAP__VALUE;

	/**
	 * The feature id for the '<em><b>Local Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_FORMAT__LOCAL_ID = URN_MAP__LOCAL_ID;

	/**
	 * The feature id for the '<em><b>Urn</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_FORMAT__URN = URN_MAP__URN;

	/**
	 * The number of structural features of the '<em>Supported Format</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_FORMAT_FEATURE_COUNT = URN_MAP_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_LANGUAGE__VALUE = URN_MAP__VALUE;

	/**
	 * The feature id for the '<em><b>Local Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_LANGUAGE__LOCAL_ID = URN_MAP__LOCAL_ID;

	/**
	 * The feature id for the '<em><b>Urn</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_LANGUAGE__URN = URN_MAP__URN;

	/**
	 * The number of structural features of the '<em>Supported Language</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_LANGUAGE_FEATURE_COUNT = URN_MAP_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_PROPERTY__VALUE = URN_MAP__VALUE;

	/**
	 * The feature id for the '<em><b>Local Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_PROPERTY__LOCAL_ID = URN_MAP__LOCAL_ID;

	/**
	 * The feature id for the '<em><b>Urn</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_PROPERTY__URN = URN_MAP__URN;

	/**
	 * The number of structural features of the '<em>Supported Property</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_PROPERTY_FEATURE_COUNT = URN_MAP_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_PROPERTY_LINK__VALUE = URN_MAP__VALUE;

	/**
	 * The feature id for the '<em><b>Local Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_PROPERTY_LINK__LOCAL_ID = URN_MAP__LOCAL_ID;

	/**
	 * The feature id for the '<em><b>Urn</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_PROPERTY_LINK__URN = URN_MAP__URN;

	/**
	 * The number of structural features of the '<em>Supported Property Link</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_PROPERTY_LINK_FEATURE_COUNT = URN_MAP_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.naming.impl.SupportedPropertyQualifierImpl <em>Supported Property Qualifier</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.naming.impl.SupportedPropertyQualifierImpl
	 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedPropertyQualifier()
	 * @generated
	 */
	int SUPPORTED_PROPERTY_QUALIFIER = 10;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_PROPERTY_QUALIFIER__VALUE = URN_MAP__VALUE;

	/**
	 * The feature id for the '<em><b>Local Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_PROPERTY_QUALIFIER__LOCAL_ID = URN_MAP__LOCAL_ID;

	/**
	 * The feature id for the '<em><b>Urn</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_PROPERTY_QUALIFIER__URN = URN_MAP__URN;

	/**
	 * The number of structural features of the '<em>Supported Property Qualifier</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_PROPERTY_QUALIFIER_FEATURE_COUNT = URN_MAP_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_REPRESENTATIONAL_FORM__VALUE = URN_MAP__VALUE;

	/**
	 * The feature id for the '<em><b>Local Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_REPRESENTATIONAL_FORM__LOCAL_ID = URN_MAP__LOCAL_ID;

	/**
	 * The feature id for the '<em><b>Urn</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_REPRESENTATIONAL_FORM__URN = URN_MAP__URN;

	/**
	 * The number of structural features of the '<em>Supported Representational Form</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_REPRESENTATIONAL_FORM_FEATURE_COUNT = URN_MAP_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_SOURCE__VALUE = URN_MAP__VALUE;

	/**
	 * The feature id for the '<em><b>Local Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_SOURCE__LOCAL_ID = URN_MAP__LOCAL_ID;

	/**
	 * The feature id for the '<em><b>Urn</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_SOURCE__URN = URN_MAP__URN;

	/**
	 * The feature id for the '<em><b>Agent Role</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_SOURCE__AGENT_ROLE = URN_MAP_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Assembly Rule</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_SOURCE__ASSEMBLY_RULE = URN_MAP_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Supported Source</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORTED_SOURCE_FEATURE_COUNT = URN_MAP_FEATURE_COUNT + 2;

	/**
	 * The meta object id for the '<em>URN</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getURN()
	 * @generated
	 */
	int URN = 14;

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.naming.URNMap <em>URN Map</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>URN Map</em>'.
	 * @see org.LexGrid.emf.naming.URNMap
	 * @generated
	 */
	EClass getURNMap();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.naming.URNMap#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see org.LexGrid.emf.naming.URNMap#getValue()
	 * @see #getURNMap()
	 * @generated
	 */
	EAttribute getURNMap_Value();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.naming.URNMap#getLocalId <em>Local Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Local Id</em>'.
	 * @see org.LexGrid.emf.naming.URNMap#getLocalId()
	 * @see #getURNMap()
	 * @generated
	 */
	EAttribute getURNMap_LocalId();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.naming.URNMap#getUrn <em>Urn</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Urn</em>'.
	 * @see org.LexGrid.emf.naming.URNMap#getUrn()
	 * @see #getURNMap()
	 * @generated
	 */
	EAttribute getURNMap_Urn();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.naming.SupportedPropertyQualifier <em>Supported Property Qualifier</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Supported Property Qualifier</em>'.
	 * @see org.LexGrid.emf.naming.SupportedPropertyQualifier
	 * @generated
	 */
	EClass getSupportedPropertyQualifier();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.naming.SupportedLanguage <em>Supported Language</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Supported Language</em>'.
	 * @see org.LexGrid.emf.naming.SupportedLanguage
	 * @generated
	 */
	EClass getSupportedLanguage();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.naming.SupportedRepresentationalForm <em>Supported Representational Form</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Supported Representational Form</em>'.
	 * @see org.LexGrid.emf.naming.SupportedRepresentationalForm
	 * @generated
	 */
	EClass getSupportedRepresentationalForm();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.naming.SupportedConceptStatus <em>Supported Concept Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Supported Concept Status</em>'.
	 * @see org.LexGrid.emf.naming.SupportedConceptStatus
	 * @generated
	 */
	EClass getSupportedConceptStatus();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.naming.SupportedContext <em>Supported Context</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Supported Context</em>'.
	 * @see org.LexGrid.emf.naming.SupportedContext
	 * @generated
	 */
	EClass getSupportedContext();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.naming.SupportedDegreeOfFidelity <em>Supported Degree Of Fidelity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Supported Degree Of Fidelity</em>'.
	 * @see org.LexGrid.emf.naming.SupportedDegreeOfFidelity
	 * @generated
	 */
	EClass getSupportedDegreeOfFidelity();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.naming.SupportedAssociationQualifier <em>Supported Association Qualifier</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Supported Association Qualifier</em>'.
	 * @see org.LexGrid.emf.naming.SupportedAssociationQualifier
	 * @generated
	 */
	EClass getSupportedAssociationQualifier();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.naming.SupportedAssociation <em>Supported Association</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Supported Association</em>'.
	 * @see org.LexGrid.emf.naming.SupportedAssociation
	 * @generated
	 */
	EClass getSupportedAssociation();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.naming.SupportedSource <em>Supported Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Supported Source</em>'.
	 * @see org.LexGrid.emf.naming.SupportedSource
	 * @generated
	 */
	EClass getSupportedSource();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.naming.SupportedSource#getAgentRole <em>Agent Role</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Agent Role</em>'.
	 * @see org.LexGrid.emf.naming.SupportedSource#getAgentRole()
	 * @see #getSupportedSource()
	 * @generated
	 */
	EAttribute getSupportedSource_AgentRole();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.naming.SupportedSource#getAssemblyRule <em>Assembly Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Assembly Rule</em>'.
	 * @see org.LexGrid.emf.naming.SupportedSource#getAssemblyRule()
	 * @see #getSupportedSource()
	 * @generated
	 */
	EAttribute getSupportedSource_AssemblyRule();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.naming.SupportedCodingScheme <em>Supported Coding Scheme</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Supported Coding Scheme</em>'.
	 * @see org.LexGrid.emf.naming.SupportedCodingScheme
	 * @generated
	 */
	EClass getSupportedCodingScheme();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.naming.SupportedProperty <em>Supported Property</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Supported Property</em>'.
	 * @see org.LexGrid.emf.naming.SupportedProperty
	 * @generated
	 */
	EClass getSupportedProperty();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.naming.SupportedPropertyLink <em>Supported Property Link</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Supported Property Link</em>'.
	 * @see org.LexGrid.emf.naming.SupportedPropertyLink
	 * @generated
	 */
	EClass getSupportedPropertyLink();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.naming.SupportedFormat <em>Supported Format</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Supported Format</em>'.
	 * @see org.LexGrid.emf.naming.SupportedFormat
	 * @generated
	 */
	EClass getSupportedFormat();

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>URN</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>URN</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 *        extendedMetaData="name='URN' baseType='http://LexGrid.org/schema/2006/01/LexGrid/builtins#tsURN'" 
	 * @generated
	 */
	EDataType getURN();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	NamingFactory getNamingFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.naming.impl.SupportedAssociationImpl <em>Supported Association</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.naming.impl.SupportedAssociationImpl
		 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedAssociation()
		 * @generated
		 */
		EClass SUPPORTED_ASSOCIATION = eINSTANCE.getSupportedAssociation();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.naming.impl.SupportedAssociationQualifierImpl <em>Supported Association Qualifier</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.naming.impl.SupportedAssociationQualifierImpl
		 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedAssociationQualifier()
		 * @generated
		 */
		EClass SUPPORTED_ASSOCIATION_QUALIFIER = eINSTANCE.getSupportedAssociationQualifier();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.naming.impl.SupportedCodingSchemeImpl <em>Supported Coding Scheme</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.naming.impl.SupportedCodingSchemeImpl
		 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedCodingScheme()
		 * @generated
		 */
		EClass SUPPORTED_CODING_SCHEME = eINSTANCE.getSupportedCodingScheme();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.naming.impl.SupportedConceptStatusImpl <em>Supported Concept Status</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.naming.impl.SupportedConceptStatusImpl
		 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedConceptStatus()
		 * @generated
		 */
		EClass SUPPORTED_CONCEPT_STATUS = eINSTANCE.getSupportedConceptStatus();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.naming.impl.SupportedContextImpl <em>Supported Context</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.naming.impl.SupportedContextImpl
		 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedContext()
		 * @generated
		 */
		EClass SUPPORTED_CONTEXT = eINSTANCE.getSupportedContext();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.naming.impl.SupportedDegreeOfFidelityImpl <em>Supported Degree Of Fidelity</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.naming.impl.SupportedDegreeOfFidelityImpl
		 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedDegreeOfFidelity()
		 * @generated
		 */
		EClass SUPPORTED_DEGREE_OF_FIDELITY = eINSTANCE.getSupportedDegreeOfFidelity();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.naming.impl.SupportedFormatImpl <em>Supported Format</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.naming.impl.SupportedFormatImpl
		 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedFormat()
		 * @generated
		 */
		EClass SUPPORTED_FORMAT = eINSTANCE.getSupportedFormat();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.naming.impl.SupportedLanguageImpl <em>Supported Language</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.naming.impl.SupportedLanguageImpl
		 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedLanguage()
		 * @generated
		 */
		EClass SUPPORTED_LANGUAGE = eINSTANCE.getSupportedLanguage();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.naming.impl.SupportedPropertyImpl <em>Supported Property</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.naming.impl.SupportedPropertyImpl
		 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedProperty()
		 * @generated
		 */
		EClass SUPPORTED_PROPERTY = eINSTANCE.getSupportedProperty();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.naming.impl.SupportedPropertyLinkImpl <em>Supported Property Link</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.naming.impl.SupportedPropertyLinkImpl
		 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedPropertyLink()
		 * @generated
		 */
		EClass SUPPORTED_PROPERTY_LINK = eINSTANCE.getSupportedPropertyLink();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.naming.impl.SupportedRepresentationalFormImpl <em>Supported Representational Form</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.naming.impl.SupportedRepresentationalFormImpl
		 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedRepresentationalForm()
		 * @generated
		 */
		EClass SUPPORTED_REPRESENTATIONAL_FORM = eINSTANCE.getSupportedRepresentationalForm();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.naming.impl.SupportedSourceImpl <em>Supported Source</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.naming.impl.SupportedSourceImpl
		 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedSource()
		 * @generated
		 */
		EClass SUPPORTED_SOURCE = eINSTANCE.getSupportedSource();

		/**
		 * The meta object literal for the '<em><b>Agent Role</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUPPORTED_SOURCE__AGENT_ROLE = eINSTANCE.getSupportedSource_AgentRole();

		/**
		 * The meta object literal for the '<em><b>Assembly Rule</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUPPORTED_SOURCE__ASSEMBLY_RULE = eINSTANCE.getSupportedSource_AssemblyRule();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.naming.impl.URNMapImpl <em>URN Map</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.naming.impl.URNMapImpl
		 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getURNMap()
		 * @generated
		 */
		EClass URN_MAP = eINSTANCE.getURNMap();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute URN_MAP__VALUE = eINSTANCE.getURNMap_Value();

		/**
		 * The meta object literal for the '<em><b>Local Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute URN_MAP__LOCAL_ID = eINSTANCE.getURNMap_LocalId();

		/**
		 * The meta object literal for the '<em><b>Urn</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute URN_MAP__URN = eINSTANCE.getURNMap_Urn();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.naming.impl.SupportedPropertyQualifierImpl <em>Supported Property Qualifier</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.naming.impl.SupportedPropertyQualifierImpl
		 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getSupportedPropertyQualifier()
		 * @generated
		 */
		EClass SUPPORTED_PROPERTY_QUALIFIER = eINSTANCE.getSupportedPropertyQualifier();

		/**
		 * The meta object literal for the '<em>URN</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see org.LexGrid.emf.naming.impl.NamingPackageImpl#getURN()
		 * @generated
		 */
		EDataType URN = eINSTANCE.getURN();

	}

} //NamingPackage