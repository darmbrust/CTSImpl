/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.naming;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see org.LexGrid.emf.naming.NamingPackage
 * @generated
 */
public interface NamingFactory extends EFactory {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	NamingFactory eINSTANCE = org.LexGrid.emf.naming.impl.NamingFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>URN Map</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>URN Map</em>'.
	 * @generated
	 */
	URNMap createURNMap();

	/**
	 * Returns a new object of class '<em>Supported Property Qualifier</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Supported Property Qualifier</em>'.
	 * @generated
	 */
	SupportedPropertyQualifier createSupportedPropertyQualifier();

	/**
	 * Returns a new object of class '<em>Supported Language</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Supported Language</em>'.
	 * @generated
	 */
	SupportedLanguage createSupportedLanguage();

	/**
	 * Returns a new object of class '<em>Supported Representational Form</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Supported Representational Form</em>'.
	 * @generated
	 */
	SupportedRepresentationalForm createSupportedRepresentationalForm();

	/**
	 * Returns a new object of class '<em>Supported Concept Status</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Supported Concept Status</em>'.
	 * @generated
	 */
	SupportedConceptStatus createSupportedConceptStatus();

	/**
	 * Returns a new object of class '<em>Supported Context</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Supported Context</em>'.
	 * @generated
	 */
	SupportedContext createSupportedContext();

	/**
	 * Returns a new object of class '<em>Supported Degree Of Fidelity</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Supported Degree Of Fidelity</em>'.
	 * @generated
	 */
	SupportedDegreeOfFidelity createSupportedDegreeOfFidelity();

	/**
	 * Returns a new object of class '<em>Supported Association Qualifier</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Supported Association Qualifier</em>'.
	 * @generated
	 */
	SupportedAssociationQualifier createSupportedAssociationQualifier();

	/**
	 * Returns a new object of class '<em>Supported Association</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Supported Association</em>'.
	 * @generated
	 */
	SupportedAssociation createSupportedAssociation();

	/**
	 * Returns a new object of class '<em>Supported Source</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Supported Source</em>'.
	 * @generated
	 */
	SupportedSource createSupportedSource();

	/**
	 * Returns a new object of class '<em>Supported Coding Scheme</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Supported Coding Scheme</em>'.
	 * @generated
	 */
	SupportedCodingScheme createSupportedCodingScheme();

	/**
	 * Returns a new object of class '<em>Supported Property</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Supported Property</em>'.
	 * @generated
	 */
	SupportedProperty createSupportedProperty();

	/**
	 * Returns a new object of class '<em>Supported Property Link</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Supported Property Link</em>'.
	 * @generated
	 */
	SupportedPropertyLink createSupportedPropertyLink();

	/**
	 * Returns a new object of class '<em>Supported Format</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Supported Format</em>'.
	 * @generated
	 */
	SupportedFormat createSupportedFormat();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	NamingPackage getNamingPackage();

} //NamingFactory