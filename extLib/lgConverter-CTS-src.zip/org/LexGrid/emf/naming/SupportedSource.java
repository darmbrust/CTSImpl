/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.naming;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Supported Source</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The URI and local name of an external source reference. Source references can also carry an additional compositional
 *                                 rule section that describes how to combine a subpart such as a page number, section name, etc. with the core URI in order to
 *                                 form a meaningful URL. An optional role can also be specified.
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.LexGrid.emf.naming.SupportedSource#getAgentRole <em>Agent Role</em>}</li>
 *   <li>{@link org.LexGrid.emf.naming.SupportedSource#getAssemblyRule <em>Assembly Rule</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.LexGrid.emf.naming.NamingPackage#getSupportedSource()
 * @model extendedMetaData="name='supportedSource' kind='simple'"
 * @generated
 */
public interface SupportedSource extends URNMap {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Returns the value of the '<em><b>Agent Role</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Allows further explanation of the contribution of an agent to the resource &gt;(e.g. author vs maintainer vs distributer)
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Agent Role</em>' attribute.
	 * @see #setAgentRole(String)
	 * @see org.LexGrid.emf.naming.NamingPackage#getSupportedSource_AgentRole()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.TsCaseIgnoreIA5String"
	 *        extendedMetaData="kind='attribute' name='agentRole'"
	 * @generated
	 */
	String getAgentRole();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.naming.SupportedSource#getAgentRole <em>Agent Role</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Agent Role</em>' attribute.
	 * @see #getAgentRole()
	 * @generated
	 */
	void setAgentRole(String value);

	/**
	 * Returns the value of the '<em><b>Assembly Rule</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Rule for combining source-specific information such as page numbers, sections and the like
	 *                                                         with the source URL. Syntax: [ID] - names the identifier. Everythinng else is literal.
	 *                                                 
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Assembly Rule</em>' attribute.
	 * @see #setAssemblyRule(String)
	 * @see org.LexGrid.emf.naming.NamingPackage#getSupportedSource_AssemblyRule()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.TsCaseIgnoreIA5String"
	 *        extendedMetaData="kind='attribute' name='assemblyRule'"
	 * @generated
	 */
	String getAssemblyRule();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.naming.SupportedSource#getAssemblyRule <em>Assembly Rule</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Assembly Rule</em>' attribute.
	 * @see #getAssemblyRule()
	 * @generated
	 */
	void setAssemblyRule(String value);

} // SupportedSource