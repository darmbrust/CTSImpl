/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.naming.util;

import org.LexGrid.emf.naming.NamingPackage;
import org.LexGrid.emf.naming.SupportedAssociation;
import org.LexGrid.emf.naming.SupportedAssociationQualifier;
import org.LexGrid.emf.naming.SupportedCodingScheme;
import org.LexGrid.emf.naming.SupportedConceptStatus;
import org.LexGrid.emf.naming.SupportedContext;
import org.LexGrid.emf.naming.SupportedDegreeOfFidelity;
import org.LexGrid.emf.naming.SupportedFormat;
import org.LexGrid.emf.naming.SupportedLanguage;
import org.LexGrid.emf.naming.SupportedProperty;
import org.LexGrid.emf.naming.SupportedPropertyLink;
import org.LexGrid.emf.naming.SupportedPropertyQualifier;
import org.LexGrid.emf.naming.SupportedRepresentationalForm;
import org.LexGrid.emf.naming.SupportedSource;
import org.LexGrid.emf.naming.URNMap;
import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;
import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see org.LexGrid.emf.naming.NamingPackage
 * @generated
 */
public class NamingAdapterFactory extends AdapterFactoryImpl {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static NamingPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NamingAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = NamingPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch the delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NamingSwitch modelSwitch = new NamingSwitch() {
		public Object caseSupportedAssociation(SupportedAssociation object) {
			return createSupportedAssociationAdapter();
		}

		public Object caseSupportedAssociationQualifier(SupportedAssociationQualifier object) {
			return createSupportedAssociationQualifierAdapter();
		}

		public Object caseSupportedCodingScheme(SupportedCodingScheme object) {
			return createSupportedCodingSchemeAdapter();
		}

		public Object caseSupportedConceptStatus(SupportedConceptStatus object) {
			return createSupportedConceptStatusAdapter();
		}

		public Object caseSupportedContext(SupportedContext object) {
			return createSupportedContextAdapter();
		}

		public Object caseSupportedDegreeOfFidelity(SupportedDegreeOfFidelity object) {
			return createSupportedDegreeOfFidelityAdapter();
		}

		public Object caseSupportedFormat(SupportedFormat object) {
			return createSupportedFormatAdapter();
		}

		public Object caseSupportedLanguage(SupportedLanguage object) {
			return createSupportedLanguageAdapter();
		}

		public Object caseSupportedProperty(SupportedProperty object) {
			return createSupportedPropertyAdapter();
		}

		public Object caseSupportedPropertyLink(SupportedPropertyLink object) {
			return createSupportedPropertyLinkAdapter();
		}

		public Object caseSupportedPropertyQualifier(SupportedPropertyQualifier object) {
			return createSupportedPropertyQualifierAdapter();
		}

		public Object caseSupportedRepresentationalForm(SupportedRepresentationalForm object) {
			return createSupportedRepresentationalFormAdapter();
		}

		public Object caseSupportedSource(SupportedSource object) {
			return createSupportedSourceAdapter();
		}

		public Object caseURNMap(URNMap object) {
			return createURNMapAdapter();
		}

		public Object defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	public Adapter createAdapter(Notifier target) {
		return (Adapter) modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.LexGrid.emf.naming.URNMap <em>URN Map</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.LexGrid.emf.naming.URNMap
	 * @generated
	 */
	public Adapter createURNMapAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.LexGrid.emf.naming.SupportedPropertyQualifier <em>Supported Property Qualifier</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.LexGrid.emf.naming.SupportedPropertyQualifier
	 * @generated
	 */
	public Adapter createSupportedPropertyQualifierAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.LexGrid.emf.naming.SupportedLanguage <em>Supported Language</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.LexGrid.emf.naming.SupportedLanguage
	 * @generated
	 */
	public Adapter createSupportedLanguageAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.LexGrid.emf.naming.SupportedRepresentationalForm <em>Supported Representational Form</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.LexGrid.emf.naming.SupportedRepresentationalForm
	 * @generated
	 */
	public Adapter createSupportedRepresentationalFormAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.LexGrid.emf.naming.SupportedConceptStatus <em>Supported Concept Status</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.LexGrid.emf.naming.SupportedConceptStatus
	 * @generated
	 */
	public Adapter createSupportedConceptStatusAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.LexGrid.emf.naming.SupportedContext <em>Supported Context</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.LexGrid.emf.naming.SupportedContext
	 * @generated
	 */
	public Adapter createSupportedContextAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.LexGrid.emf.naming.SupportedDegreeOfFidelity <em>Supported Degree Of Fidelity</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.LexGrid.emf.naming.SupportedDegreeOfFidelity
	 * @generated
	 */
	public Adapter createSupportedDegreeOfFidelityAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.LexGrid.emf.naming.SupportedAssociationQualifier <em>Supported Association Qualifier</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.LexGrid.emf.naming.SupportedAssociationQualifier
	 * @generated
	 */
	public Adapter createSupportedAssociationQualifierAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.LexGrid.emf.naming.SupportedAssociation <em>Supported Association</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.LexGrid.emf.naming.SupportedAssociation
	 * @generated
	 */
	public Adapter createSupportedAssociationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.LexGrid.emf.naming.SupportedSource <em>Supported Source</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.LexGrid.emf.naming.SupportedSource
	 * @generated
	 */
	public Adapter createSupportedSourceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.LexGrid.emf.naming.SupportedCodingScheme <em>Supported Coding Scheme</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.LexGrid.emf.naming.SupportedCodingScheme
	 * @generated
	 */
	public Adapter createSupportedCodingSchemeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.LexGrid.emf.naming.SupportedProperty <em>Supported Property</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.LexGrid.emf.naming.SupportedProperty
	 * @generated
	 */
	public Adapter createSupportedPropertyAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.LexGrid.emf.naming.SupportedPropertyLink <em>Supported Property Link</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.LexGrid.emf.naming.SupportedPropertyLink
	 * @generated
	 */
	public Adapter createSupportedPropertyLinkAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.LexGrid.emf.naming.SupportedFormat <em>Supported Format</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.LexGrid.emf.naming.SupportedFormat
	 * @generated
	 */
	public Adapter createSupportedFormatAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //NamingAdapterFactory