/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.naming.util;

import java.util.List;

import org.LexGrid.emf.naming.NamingPackage;
import org.LexGrid.emf.naming.SupportedAssociation;
import org.LexGrid.emf.naming.SupportedAssociationQualifier;
import org.LexGrid.emf.naming.SupportedCodingScheme;
import org.LexGrid.emf.naming.SupportedConceptStatus;
import org.LexGrid.emf.naming.SupportedContext;
import org.LexGrid.emf.naming.SupportedDegreeOfFidelity;
import org.LexGrid.emf.naming.SupportedFormat;
import org.LexGrid.emf.naming.SupportedLanguage;
import org.LexGrid.emf.naming.SupportedProperty;
import org.LexGrid.emf.naming.SupportedPropertyLink;
import org.LexGrid.emf.naming.SupportedPropertyQualifier;
import org.LexGrid.emf.naming.SupportedRepresentationalForm;
import org.LexGrid.emf.naming.SupportedSource;
import org.LexGrid.emf.naming.URNMap;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see org.LexGrid.emf.naming.NamingPackage
 * @generated
 */
public class NamingSwitch {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static NamingPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NamingSwitch() {
		if (modelPackage == null) {
			modelPackage = NamingPackage.eINSTANCE;
		}
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	public Object doSwitch(EObject theEObject) {
		return doSwitch(theEObject.eClass(), theEObject);
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	protected Object doSwitch(EClass theEClass, EObject theEObject) {
		if (theEClass.eContainer() == modelPackage) {
			return doSwitch(theEClass.getClassifierID(), theEObject);
		} else {
			List eSuperTypes = theEClass.getESuperTypes();
			return eSuperTypes.isEmpty() ? defaultCase(theEObject) : doSwitch((EClass) eSuperTypes.get(0), theEObject);
		}
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	protected Object doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case NamingPackage.SUPPORTED_ASSOCIATION: {
			SupportedAssociation supportedAssociation = (SupportedAssociation) theEObject;
			Object result = caseSupportedAssociation(supportedAssociation);
			if (result == null)
				result = caseURNMap(supportedAssociation);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case NamingPackage.SUPPORTED_ASSOCIATION_QUALIFIER: {
			SupportedAssociationQualifier supportedAssociationQualifier = (SupportedAssociationQualifier) theEObject;
			Object result = caseSupportedAssociationQualifier(supportedAssociationQualifier);
			if (result == null)
				result = caseURNMap(supportedAssociationQualifier);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case NamingPackage.SUPPORTED_CODING_SCHEME: {
			SupportedCodingScheme supportedCodingScheme = (SupportedCodingScheme) theEObject;
			Object result = caseSupportedCodingScheme(supportedCodingScheme);
			if (result == null)
				result = caseURNMap(supportedCodingScheme);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case NamingPackage.SUPPORTED_CONCEPT_STATUS: {
			SupportedConceptStatus supportedConceptStatus = (SupportedConceptStatus) theEObject;
			Object result = caseSupportedConceptStatus(supportedConceptStatus);
			if (result == null)
				result = caseURNMap(supportedConceptStatus);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case NamingPackage.SUPPORTED_CONTEXT: {
			SupportedContext supportedContext = (SupportedContext) theEObject;
			Object result = caseSupportedContext(supportedContext);
			if (result == null)
				result = caseURNMap(supportedContext);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case NamingPackage.SUPPORTED_DEGREE_OF_FIDELITY: {
			SupportedDegreeOfFidelity supportedDegreeOfFidelity = (SupportedDegreeOfFidelity) theEObject;
			Object result = caseSupportedDegreeOfFidelity(supportedDegreeOfFidelity);
			if (result == null)
				result = caseURNMap(supportedDegreeOfFidelity);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case NamingPackage.SUPPORTED_FORMAT: {
			SupportedFormat supportedFormat = (SupportedFormat) theEObject;
			Object result = caseSupportedFormat(supportedFormat);
			if (result == null)
				result = caseURNMap(supportedFormat);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case NamingPackage.SUPPORTED_LANGUAGE: {
			SupportedLanguage supportedLanguage = (SupportedLanguage) theEObject;
			Object result = caseSupportedLanguage(supportedLanguage);
			if (result == null)
				result = caseURNMap(supportedLanguage);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case NamingPackage.SUPPORTED_PROPERTY: {
			SupportedProperty supportedProperty = (SupportedProperty) theEObject;
			Object result = caseSupportedProperty(supportedProperty);
			if (result == null)
				result = caseURNMap(supportedProperty);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case NamingPackage.SUPPORTED_PROPERTY_LINK: {
			SupportedPropertyLink supportedPropertyLink = (SupportedPropertyLink) theEObject;
			Object result = caseSupportedPropertyLink(supportedPropertyLink);
			if (result == null)
				result = caseURNMap(supportedPropertyLink);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case NamingPackage.SUPPORTED_PROPERTY_QUALIFIER: {
			SupportedPropertyQualifier supportedPropertyQualifier = (SupportedPropertyQualifier) theEObject;
			Object result = caseSupportedPropertyQualifier(supportedPropertyQualifier);
			if (result == null)
				result = caseURNMap(supportedPropertyQualifier);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case NamingPackage.SUPPORTED_REPRESENTATIONAL_FORM: {
			SupportedRepresentationalForm supportedRepresentationalForm = (SupportedRepresentationalForm) theEObject;
			Object result = caseSupportedRepresentationalForm(supportedRepresentationalForm);
			if (result == null)
				result = caseURNMap(supportedRepresentationalForm);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case NamingPackage.SUPPORTED_SOURCE: {
			SupportedSource supportedSource = (SupportedSource) theEObject;
			Object result = caseSupportedSource(supportedSource);
			if (result == null)
				result = caseURNMap(supportedSource);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case NamingPackage.URN_MAP: {
			URNMap urnMap = (URNMap) theEObject;
			Object result = caseURNMap(urnMap);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>URN Map</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>URN Map</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseURNMap(URNMap object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Supported Property Qualifier</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Supported Property Qualifier</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseSupportedPropertyQualifier(SupportedPropertyQualifier object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Supported Language</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Supported Language</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseSupportedLanguage(SupportedLanguage object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Supported Representational Form</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Supported Representational Form</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseSupportedRepresentationalForm(SupportedRepresentationalForm object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Supported Concept Status</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Supported Concept Status</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseSupportedConceptStatus(SupportedConceptStatus object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Supported Context</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Supported Context</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseSupportedContext(SupportedContext object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Supported Degree Of Fidelity</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Supported Degree Of Fidelity</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseSupportedDegreeOfFidelity(SupportedDegreeOfFidelity object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Supported Association Qualifier</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Supported Association Qualifier</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseSupportedAssociationQualifier(SupportedAssociationQualifier object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Supported Association</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Supported Association</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseSupportedAssociation(SupportedAssociation object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Supported Source</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Supported Source</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseSupportedSource(SupportedSource object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Supported Coding Scheme</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Supported Coding Scheme</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseSupportedCodingScheme(SupportedCodingScheme object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Supported Property</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Supported Property</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseSupportedProperty(SupportedProperty object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Supported Property Link</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Supported Property Link</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseSupportedPropertyLink(SupportedPropertyLink object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Supported Format</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Supported Format</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseSupportedFormat(SupportedFormat object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	public Object defaultCase(EObject object) {
		return null;
	}

} //NamingSwitch