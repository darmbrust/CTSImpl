/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.commonTypes;

import org.LexGrid.emf.base.LgModelObj;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Versionable</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * An entity which can be introduced or removed at a specific version.
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.LexGrid.emf.commonTypes.Versionable#getDeprecated <em>Deprecated</em>}</li>
 *   <li>{@link org.LexGrid.emf.commonTypes.Versionable#getFirstRelease <em>First Release</em>}</li>
 *   <li>{@link org.LexGrid.emf.commonTypes.Versionable#getModifiedInRelease <em>Modified In Release</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.LexGrid.emf.commonTypes.CommontypesPackage#getVersionable()
 * @model extendedMetaData="name='versionable' kind='empty'"
 * @extends LgModelObj
 * @generated
 */
public interface Versionable extends LgModelObj {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Returns the value of the '<em><b>Deprecated</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * TRUE means that this entity is scheduled to be retired or removed at some future release
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Deprecated</em>' attribute.
	 * @see #isSetDeprecated()
	 * @see #unsetDeprecated()
	 * @see #setDeprecated(Boolean)
	 * @see org.LexGrid.emf.commonTypes.CommontypesPackage#getVersionable_Deprecated()
	 * @model unique="false" unsettable="true" dataType="org.LexGrid.emf.builtins.TsBooleanObject"
	 *        extendedMetaData="kind='attribute' name='deprecated'"
	 * @generated
	 */
	Boolean getDeprecated();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.commonTypes.Versionable#getDeprecated <em>Deprecated</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Deprecated</em>' attribute.
	 * @see #isSetDeprecated()
	 * @see #unsetDeprecated()
	 * @see #getDeprecated()
	 * @generated
	 */
	void setDeprecated(Boolean value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.commonTypes.Versionable#getDeprecated <em>Deprecated</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetDeprecated()
	 * @see #getDeprecated()
	 * @see #setDeprecated(Boolean)
	 * @generated
	 */
	void unsetDeprecated();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.commonTypes.Versionable#getDeprecated <em>Deprecated</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Deprecated</em>' attribute is set.
	 * @see #unsetDeprecated()
	 * @see #getDeprecated()
	 * @see #setDeprecated(Boolean)
	 * @generated
	 */
	boolean isSetDeprecated();

	/**
	 * Returns the value of the '<em><b>First Release</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * TRUE means that entity was introduced in the current release
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>First Release</em>' attribute.
	 * @see #isSetFirstRelease()
	 * @see #unsetFirstRelease()
	 * @see #setFirstRelease(Boolean)
	 * @see org.LexGrid.emf.commonTypes.CommontypesPackage#getVersionable_FirstRelease()
	 * @model unique="false" unsettable="true" dataType="org.LexGrid.emf.builtins.TsBooleanObject"
	 *        extendedMetaData="kind='attribute' name='firstRelease'"
	 * @generated
	 */
	Boolean getFirstRelease();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.commonTypes.Versionable#getFirstRelease <em>First Release</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>First Release</em>' attribute.
	 * @see #isSetFirstRelease()
	 * @see #unsetFirstRelease()
	 * @see #getFirstRelease()
	 * @generated
	 */
	void setFirstRelease(Boolean value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.commonTypes.Versionable#getFirstRelease <em>First Release</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetFirstRelease()
	 * @see #getFirstRelease()
	 * @see #setFirstRelease(Boolean)
	 * @generated
	 */
	void unsetFirstRelease();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.commonTypes.Versionable#getFirstRelease <em>First Release</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>First Release</em>' attribute is set.
	 * @see #unsetFirstRelease()
	 * @see #getFirstRelease()
	 * @see #setFirstRelease(Boolean)
	 * @generated
	 */
	boolean isSetFirstRelease();

	/**
	 * Returns the value of the '<em><b>Modified In Release</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * TRUE means that entity isn't new but was modified since the last release.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Modified In Release</em>' attribute.
	 * @see #isSetModifiedInRelease()
	 * @see #unsetModifiedInRelease()
	 * @see #setModifiedInRelease(Boolean)
	 * @see org.LexGrid.emf.commonTypes.CommontypesPackage#getVersionable_ModifiedInRelease()
	 * @model unique="false" unsettable="true" dataType="org.LexGrid.emf.builtins.TsBooleanObject"
	 *        extendedMetaData="kind='attribute' name='modifiedInRelease'"
	 * @generated
	 */
	Boolean getModifiedInRelease();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.commonTypes.Versionable#getModifiedInRelease <em>Modified In Release</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Modified In Release</em>' attribute.
	 * @see #isSetModifiedInRelease()
	 * @see #unsetModifiedInRelease()
	 * @see #getModifiedInRelease()
	 * @generated
	 */
	void setModifiedInRelease(Boolean value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.commonTypes.Versionable#getModifiedInRelease <em>Modified In Release</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetModifiedInRelease()
	 * @see #getModifiedInRelease()
	 * @see #setModifiedInRelease(Boolean)
	 * @generated
	 */
	void unsetModifiedInRelease();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.commonTypes.Versionable#getModifiedInRelease <em>Modified In Release</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Modified In Release</em>' attribute is set.
	 * @see #unsetModifiedInRelease()
	 * @see #getModifiedInRelease()
	 * @see #setModifiedInRelease(Boolean)
	 * @generated
	 */
	boolean isSetModifiedInRelease();

} // Versionable