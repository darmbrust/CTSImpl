/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.commonTypes;

import org.LexGrid.emf.naming.NamingPackage;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * <!-- begin-model-doc -->
 * 
 * 			<h2 xmlns="http://LexGrid.org/schema/2006/01/LexGrid/builtins">Core data types for the lexical grid.</h2>
 * 		
 * These types need to be mapped to the appropriate implementation specific data types. The mapping in this package represents the XML
 * 			Schema data types mapping
 * LDAP specific types for appinfo annotation
 * Basic builtin types
 * <!-- end-model-doc -->
 * @see org.LexGrid.emf.commonTypes.CommontypesFactory
 * @model kind="package"
 * @generated
 */
public interface CommontypesPackage extends EPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "commonTypes";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://LexGrid.org/schema/2006/01/LexGrid/commonTypes";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "lgCommon";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	CommontypesPackage eINSTANCE = org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.commonTypes.impl.CodedContextImpl <em>Coded Context</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.commonTypes.impl.CodedContextImpl
	 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getCodedContext()
	 * @generated
	 */
	int CODED_CONTEXT = 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODED_CONTEXT__VALUE = 0;

	/**
	 * The feature id for the '<em><b>Coding Scheme</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODED_CONTEXT__CODING_SCHEME = 1;

	/**
	 * The feature id for the '<em><b>Concept Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODED_CONTEXT__CONCEPT_CODE = 2;

	/**
	 * The number of structural features of the '<em>Coded Context</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODED_CONTEXT_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.commonTypes.impl.VersionableAndDescribableImpl <em>Versionable And Describable</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.commonTypes.impl.VersionableAndDescribableImpl
	 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getVersionableAndDescribable()
	 * @generated
	 */
	int VERSIONABLE_AND_DESCRIBABLE = 7;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.commonTypes.impl.VersionableImpl <em>Versionable</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.commonTypes.impl.VersionableImpl
	 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getVersionable()
	 * @generated
	 */
	int VERSIONABLE = 6;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.commonTypes.impl.DescribableImpl <em>Describable</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.commonTypes.impl.DescribableImpl
	 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getDescribable()
	 * @generated
	 */
	int DESCRIBABLE = 1;

	/**
	 * The feature id for the '<em><b>Entity Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DESCRIBABLE__ENTITY_DESCRIPTION = 0;

	/**
	 * The number of structural features of the '<em>Describable</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DESCRIBABLE_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.commonTypes.impl.PropertiesImpl <em>Properties</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.commonTypes.impl.PropertiesImpl
	 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getProperties()
	 * @generated
	 */
	int PROPERTIES = 2;

	/**
	 * The feature id for the '<em><b>Property</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTIES__PROPERTY = 0;

	/**
	 * The feature id for the '<em><b>Dc</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTIES__DC = 1;

	/**
	 * The number of structural features of the '<em>Properties</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTIES_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.commonTypes.impl.PropertyImpl <em>Property</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.commonTypes.impl.PropertyImpl
	 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getProperty()
	 * @generated
	 */
	int PROPERTY = 3;

	/**
	 * The feature id for the '<em><b>Source</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY__SOURCE = 0;

	/**
	 * The feature id for the '<em><b>Usage Context</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY__USAGE_CONTEXT = 1;

	/**
	 * The feature id for the '<em><b>Property Qualifier</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY__PROPERTY_QUALIFIER = 2;

	/**
	 * The feature id for the '<em><b>Text</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY__TEXT = 3;

	/**
	 * The feature id for the '<em><b>Language</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY__LANGUAGE = 4;

	/**
	 * The feature id for the '<em><b>Presentation Format</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY__PRESENTATION_FORMAT = 5;

	/**
	 * The feature id for the '<em><b>Property</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY__PROPERTY = 6;

	/**
	 * The feature id for the '<em><b>Property Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY__PROPERTY_ID = 7;

	/**
	 * The number of structural features of the '<em>Property</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY_FEATURE_COUNT = 8;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.commonTypes.impl.PropertyQualifierImpl <em>Property Qualifier</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.commonTypes.impl.PropertyQualifierImpl
	 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getPropertyQualifier()
	 * @generated
	 */
	int PROPERTY_QUALIFIER = 4;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY_QUALIFIER__VALUE = 0;

	/**
	 * The feature id for the '<em><b>Property Qualifier Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY_QUALIFIER__PROPERTY_QUALIFIER_ID = 1;

	/**
	 * The number of structural features of the '<em>Property Qualifier</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY_QUALIFIER_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '<em>Version</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getVersion()
	 * @generated
	 */
	int VERSION = 22;

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.commonTypes.CodedContext <em>Coded Context</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Coded Context</em>'.
	 * @see org.LexGrid.emf.commonTypes.CodedContext
	 * @generated
	 */
	EClass getCodedContext();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.commonTypes.CodedContext#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see org.LexGrid.emf.commonTypes.CodedContext#getValue()
	 * @see #getCodedContext()
	 * @generated
	 */
	EAttribute getCodedContext_Value();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.commonTypes.CodedContext#getCodingScheme <em>Coding Scheme</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Coding Scheme</em>'.
	 * @see org.LexGrid.emf.commonTypes.CodedContext#getCodingScheme()
	 * @see #getCodedContext()
	 * @generated
	 */
	EAttribute getCodedContext_CodingScheme();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.commonTypes.CodedContext#getConceptCode <em>Concept Code</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Concept Code</em>'.
	 * @see org.LexGrid.emf.commonTypes.CodedContext#getConceptCode()
	 * @see #getCodedContext()
	 * @generated
	 */
	EAttribute getCodedContext_ConceptCode();

	/**
	 * The meta object id for the '<em>Dc</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getDc()
	 * @generated
	 */
	int DC = 11;

	/**
	 * The meta object id for the '<em>Registered Name</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getRegisteredName()
	 * @generated
	 */
	int REGISTERED_NAME = 20;

	/**
	 * The meta object id for the '<em>Default Language</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getDefaultLanguage()
	 * @generated
	 */
	int DEFAULT_LANGUAGE = 13;

	/**
	 * The meta object id for the '<em>Language</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getLanguage()
	 * @generated
	 */
	int LANGUAGE = 17;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.commonTypes.impl.SourceImpl <em>Source</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.commonTypes.impl.SourceImpl
	 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getSource()
	 * @generated
	 */
	int SOURCE = 5;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOURCE__VALUE = 0;

	/**
	 * The feature id for the '<em><b>Role</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOURCE__ROLE = 1;

	/**
	 * The feature id for the '<em><b>Sub Ref</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOURCE__SUB_REF = 2;

	/**
	 * The number of structural features of the '<em>Source</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOURCE_FEATURE_COUNT = 3;

	/**
	 * The feature id for the '<em><b>Deprecated</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VERSIONABLE__DEPRECATED = 0;

	/**
	 * The feature id for the '<em><b>First Release</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VERSIONABLE__FIRST_RELEASE = 1;

	/**
	 * The feature id for the '<em><b>Modified In Release</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VERSIONABLE__MODIFIED_IN_RELEASE = 2;

	/**
	 * The meta object id for the '<em>Concept Code</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getConceptCode()
	 * @generated
	 */
	int CONCEPT_CODE = 9;

	/**
	 * The meta object id for the '<em>Context</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getContext()
	 * @generated
	 */
	int CONTEXT = 10;

	/**
	 * The meta object id for the '<em>Property Id</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getPropertyId()
	 * @generated
	 */
	int PROPERTY_ID = 18;

	/**
	 * The meta object id for the '<em>Property Qualifier Id</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getPropertyQualifierId()
	 * @generated
	 */
	int PROPERTY_QUALIFIER_ID = 19;

	/**
	 * The meta object id for the '<em>Text</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getText()
	 * @generated
	 */
	int TEXT = 21;

	/**
	 * The meta object id for the '<em>Entity Description</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getEntityDescription()
	 * @generated
	 */
	int ENTITY_DESCRIPTION = 14;

	/**
	 * The number of structural features of the '<em>Versionable</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VERSIONABLE_FEATURE_COUNT = 3;

	/**
	 * The feature id for the '<em><b>Deprecated</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VERSIONABLE_AND_DESCRIBABLE__DEPRECATED = VERSIONABLE__DEPRECATED;

	/**
	 * The feature id for the '<em><b>First Release</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VERSIONABLE_AND_DESCRIBABLE__FIRST_RELEASE = VERSIONABLE__FIRST_RELEASE;

	/**
	 * The feature id for the '<em><b>Modified In Release</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VERSIONABLE_AND_DESCRIBABLE__MODIFIED_IN_RELEASE = VERSIONABLE__MODIFIED_IN_RELEASE;

	/**
	 * The feature id for the '<em><b>Entity Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VERSIONABLE_AND_DESCRIBABLE__ENTITY_DESCRIPTION = VERSIONABLE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Versionable And Describable</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT = VERSIONABLE_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.commonTypes.impl.VersionReferenceImpl <em>Version Reference</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.commonTypes.impl.VersionReferenceImpl
	 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getVersionReference()
	 * @generated
	 */
	int VERSION_REFERENCE = 8;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VERSION_REFERENCE__VALUE = NamingPackage.URN_MAP__VALUE;

	/**
	 * The feature id for the '<em><b>Local Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VERSION_REFERENCE__LOCAL_ID = NamingPackage.URN_MAP__LOCAL_ID;

	/**
	 * The feature id for the '<em><b>Urn</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VERSION_REFERENCE__URN = NamingPackage.URN_MAP__URN;

	/**
	 * The feature id for the '<em><b>Version</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VERSION_REFERENCE__VERSION = NamingPackage.URN_MAP_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Version Reference</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VERSION_REFERENCE_FEATURE_COUNT = NamingPackage.URN_MAP_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '<em>Id</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getId()
	 * @generated
	 */
	int ID = 16;

	/**
	 * The meta object id for the '<em>Default Coding Scheme</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getDefaultCodingScheme()
	 * @generated
	 */
	int DEFAULT_CODING_SCHEME = 12;

	/**
	 * The meta object id for the '<em>Entry Order</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getEntryOrder()
	 * @generated
	 */
	int ENTRY_ORDER = 15;

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.commonTypes.VersionableAndDescribable <em>Versionable And Describable</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Versionable And Describable</em>'.
	 * @see org.LexGrid.emf.commonTypes.VersionableAndDescribable
	 * @generated
	 */
	EClass getVersionableAndDescribable();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.commonTypes.VersionableAndDescribable#getEntityDescription <em>Entity Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Entity Description</em>'.
	 * @see org.LexGrid.emf.commonTypes.VersionableAndDescribable#getEntityDescription()
	 * @see #getVersionableAndDescribable()
	 * @generated
	 */
	EAttribute getVersionableAndDescribable_EntityDescription();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.commonTypes.VersionReference <em>Version Reference</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Version Reference</em>'.
	 * @see org.LexGrid.emf.commonTypes.VersionReference
	 * @generated
	 */
	EClass getVersionReference();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.commonTypes.VersionReference#getVersion <em>Version</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Version</em>'.
	 * @see org.LexGrid.emf.commonTypes.VersionReference#getVersion()
	 * @see #getVersionReference()
	 * @generated
	 */
	EAttribute getVersionReference_Version();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.commonTypes.Versionable <em>Versionable</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Versionable</em>'.
	 * @see org.LexGrid.emf.commonTypes.Versionable
	 * @generated
	 */
	EClass getVersionable();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.commonTypes.Versionable#getDeprecated <em>Deprecated</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Deprecated</em>'.
	 * @see org.LexGrid.emf.commonTypes.Versionable#getDeprecated()
	 * @see #getVersionable()
	 * @generated
	 */
	EAttribute getVersionable_Deprecated();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.commonTypes.Versionable#getFirstRelease <em>First Release</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>First Release</em>'.
	 * @see org.LexGrid.emf.commonTypes.Versionable#getFirstRelease()
	 * @see #getVersionable()
	 * @generated
	 */
	EAttribute getVersionable_FirstRelease();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.commonTypes.Versionable#getModifiedInRelease <em>Modified In Release</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Modified In Release</em>'.
	 * @see org.LexGrid.emf.commonTypes.Versionable#getModifiedInRelease()
	 * @see #getVersionable()
	 * @generated
	 */
	EAttribute getVersionable_ModifiedInRelease();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.commonTypes.Describable <em>Describable</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Describable</em>'.
	 * @see org.LexGrid.emf.commonTypes.Describable
	 * @generated
	 */
	EClass getDescribable();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.commonTypes.Describable#getEntityDescription <em>Entity Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Entity Description</em>'.
	 * @see org.LexGrid.emf.commonTypes.Describable#getEntityDescription()
	 * @see #getDescribable()
	 * @generated
	 */
	EAttribute getDescribable_EntityDescription();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.commonTypes.Properties <em>Properties</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Properties</em>'.
	 * @see org.LexGrid.emf.commonTypes.Properties
	 * @generated
	 */
	EClass getProperties();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.commonTypes.Properties#getProperty <em>Property</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Property</em>'.
	 * @see org.LexGrid.emf.commonTypes.Properties#getProperty()
	 * @see #getProperties()
	 * @generated
	 */
	EReference getProperties_Property();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.commonTypes.Properties#getDc <em>Dc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Dc</em>'.
	 * @see org.LexGrid.emf.commonTypes.Properties#getDc()
	 * @see #getProperties()
	 * @generated
	 */
	EAttribute getProperties_Dc();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.commonTypes.Property <em>Property</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Property</em>'.
	 * @see org.LexGrid.emf.commonTypes.Property
	 * @generated
	 */
	EClass getProperty();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.commonTypes.Property#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Source</em>'.
	 * @see org.LexGrid.emf.commonTypes.Property#getSource()
	 * @see #getProperty()
	 * @generated
	 */
	EReference getProperty_Source();

	/**
	 * Returns the meta object for the attribute list '{@link org.LexGrid.emf.commonTypes.Property#getUsageContext <em>Usage Context</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Usage Context</em>'.
	 * @see org.LexGrid.emf.commonTypes.Property#getUsageContext()
	 * @see #getProperty()
	 * @generated
	 */
	EAttribute getProperty_UsageContext();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.commonTypes.Property#getPropertyQualifier <em>Property Qualifier</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Property Qualifier</em>'.
	 * @see org.LexGrid.emf.commonTypes.Property#getPropertyQualifier()
	 * @see #getProperty()
	 * @generated
	 */
	EReference getProperty_PropertyQualifier();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.commonTypes.Property#getText <em>Text</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Text</em>'.
	 * @see org.LexGrid.emf.commonTypes.Property#getText()
	 * @see #getProperty()
	 * @generated
	 */
	EAttribute getProperty_Text();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.commonTypes.Property#getLanguage <em>Language</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Language</em>'.
	 * @see org.LexGrid.emf.commonTypes.Property#getLanguage()
	 * @see #getProperty()
	 * @generated
	 */
	EAttribute getProperty_Language();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.commonTypes.Property#getPresentationFormat <em>Presentation Format</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Presentation Format</em>'.
	 * @see org.LexGrid.emf.commonTypes.Property#getPresentationFormat()
	 * @see #getProperty()
	 * @generated
	 */
	EAttribute getProperty_PresentationFormat();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.commonTypes.Property#getProperty <em>Property</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Property</em>'.
	 * @see org.LexGrid.emf.commonTypes.Property#getProperty()
	 * @see #getProperty()
	 * @generated
	 */
	EAttribute getProperty_Property();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.commonTypes.Property#getPropertyId <em>Property Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Property Id</em>'.
	 * @see org.LexGrid.emf.commonTypes.Property#getPropertyId()
	 * @see #getProperty()
	 * @generated
	 */
	EAttribute getProperty_PropertyId();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.commonTypes.PropertyQualifier <em>Property Qualifier</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Property Qualifier</em>'.
	 * @see org.LexGrid.emf.commonTypes.PropertyQualifier
	 * @generated
	 */
	EClass getPropertyQualifier();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.commonTypes.PropertyQualifier#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see org.LexGrid.emf.commonTypes.PropertyQualifier#getValue()
	 * @see #getPropertyQualifier()
	 * @generated
	 */
	EAttribute getPropertyQualifier_Value();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.commonTypes.PropertyQualifier#getPropertyQualifierId <em>Property Qualifier Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Property Qualifier Id</em>'.
	 * @see org.LexGrid.emf.commonTypes.PropertyQualifier#getPropertyQualifierId()
	 * @see #getPropertyQualifier()
	 * @generated
	 */
	EAttribute getPropertyQualifier_PropertyQualifierId();

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>Version</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Version</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 *        extendedMetaData="name='version' baseType='http://LexGrid.org/schema/2006/01/LexGrid/builtins#tsCaseIgnoreIA5String' minLength='1'" 
	 * @generated
	 */
	EDataType getVersion();

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>Dc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Dc</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 *        extendedMetaData="name='dc' baseType='http://LexGrid.org/schema/2006/01/LexGrid/builtins#tsCaseIgnoreIA5String'" 
	 * @generated
	 */
	EDataType getDc();

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>Registered Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Registered Name</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 *        extendedMetaData="name='registeredName' baseType='http://LexGrid.org/schema/2006/01/LexGrid/builtins#tsURN'" 
	 * @generated
	 */
	EDataType getRegisteredName();

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>Default Language</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Default Language</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 *        extendedMetaData="name='defaultLanguage' baseType='language'" 
	 * @generated
	 */
	EDataType getDefaultLanguage();

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>Language</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Language</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 *        extendedMetaData="name='language' baseType='http://LexGrid.org/schema/2006/01/LexGrid/builtins#localId'" 
	 * @generated
	 */
	EDataType getLanguage();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.commonTypes.Source <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Source</em>'.
	 * @see org.LexGrid.emf.commonTypes.Source
	 * @generated
	 */
	EClass getSource();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.commonTypes.Source#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see org.LexGrid.emf.commonTypes.Source#getValue()
	 * @see #getSource()
	 * @generated
	 */
	EAttribute getSource_Value();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.commonTypes.Source#getRole <em>Role</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Role</em>'.
	 * @see org.LexGrid.emf.commonTypes.Source#getRole()
	 * @see #getSource()
	 * @generated
	 */
	EAttribute getSource_Role();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.commonTypes.Source#getSubRef <em>Sub Ref</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sub Ref</em>'.
	 * @see org.LexGrid.emf.commonTypes.Source#getSubRef()
	 * @see #getSource()
	 * @generated
	 */
	EAttribute getSource_SubRef();

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>Concept Code</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Concept Code</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 *        extendedMetaData="name='conceptCode' baseType='http://LexGrid.org/schema/2006/01/LexGrid/builtins#tsCaseIgnoreIA5String' minLength='1'" 
	 * @generated
	 */
	EDataType getConceptCode();

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>Context</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Context</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 *        extendedMetaData="name='context' baseType='http://LexGrid.org/schema/2006/01/LexGrid/builtins#localId'" 
	 * @generated
	 */
	EDataType getContext();

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>Property Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Property Id</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 *        extendedMetaData="name='propertyId' baseType='http://LexGrid.org/schema/2006/01/LexGrid/builtins#tsCaseIgnoreIA5String'" 
	 * @generated
	 */
	EDataType getPropertyId();

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>Property Qualifier Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Property Qualifier Id</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 *        extendedMetaData="name='propertyQualifierId' baseType='http://LexGrid.org/schema/2006/01/LexGrid/builtins#localId'" 
	 * @generated
	 */
	EDataType getPropertyQualifierId();

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>Text</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Text</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 *        extendedMetaData="name='text' baseType='http://www.eclipse.org/emf/2003/XMLType#string'" 
	 * @generated
	 */
	EDataType getText();

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>Entity Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Entity Description</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 *        extendedMetaData="name='entityDescription' baseType='http://www.eclipse.org/emf/2003/XMLType#string'" 
	 * @generated
	 */
	EDataType getEntityDescription();

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Id</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 *        extendedMetaData="name='id' baseType='http://LexGrid.org/schema/2006/01/LexGrid/builtins#tsCaseIgnoreIA5String'" 
	 * @generated
	 */
	EDataType getId();

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>Default Coding Scheme</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Default Coding Scheme</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 *        extendedMetaData="name='defaultCodingScheme' baseType='http://LexGrid.org/schema/2006/01/LexGrid/builtins#localId'" 
	 * @generated
	 */
	EDataType getDefaultCodingScheme();

	/**
	 * Returns the meta object for data type '<em>Entry Order</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Entry Order</em>'.
	 * @model instanceClass="int"
	 *        extendedMetaData="name='entryOrder' baseType='http://LexGrid.org/schema/2006/01/LexGrid/builtins#tsInteger'" 
	 * @generated
	 */
	EDataType getEntryOrder();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	CommontypesFactory getCommontypesFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.commonTypes.impl.CodedContextImpl <em>Coded Context</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.commonTypes.impl.CodedContextImpl
		 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getCodedContext()
		 * @generated
		 */
		EClass CODED_CONTEXT = eINSTANCE.getCodedContext();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CODED_CONTEXT__VALUE = eINSTANCE.getCodedContext_Value();

		/**
		 * The meta object literal for the '<em><b>Coding Scheme</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CODED_CONTEXT__CODING_SCHEME = eINSTANCE.getCodedContext_CodingScheme();

		/**
		 * The meta object literal for the '<em><b>Concept Code</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CODED_CONTEXT__CONCEPT_CODE = eINSTANCE.getCodedContext_ConceptCode();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.commonTypes.impl.DescribableImpl <em>Describable</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.commonTypes.impl.DescribableImpl
		 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getDescribable()
		 * @generated
		 */
		EClass DESCRIBABLE = eINSTANCE.getDescribable();

		/**
		 * The meta object literal for the '<em><b>Entity Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DESCRIBABLE__ENTITY_DESCRIPTION = eINSTANCE.getDescribable_EntityDescription();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.commonTypes.impl.PropertiesImpl <em>Properties</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.commonTypes.impl.PropertiesImpl
		 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getProperties()
		 * @generated
		 */
		EClass PROPERTIES = eINSTANCE.getProperties();

		/**
		 * The meta object literal for the '<em><b>Property</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROPERTIES__PROPERTY = eINSTANCE.getProperties_Property();

		/**
		 * The meta object literal for the '<em><b>Dc</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROPERTIES__DC = eINSTANCE.getProperties_Dc();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.commonTypes.impl.PropertyImpl <em>Property</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.commonTypes.impl.PropertyImpl
		 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getProperty()
		 * @generated
		 */
		EClass PROPERTY = eINSTANCE.getProperty();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROPERTY__SOURCE = eINSTANCE.getProperty_Source();

		/**
		 * The meta object literal for the '<em><b>Usage Context</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROPERTY__USAGE_CONTEXT = eINSTANCE.getProperty_UsageContext();

		/**
		 * The meta object literal for the '<em><b>Property Qualifier</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROPERTY__PROPERTY_QUALIFIER = eINSTANCE.getProperty_PropertyQualifier();

		/**
		 * The meta object literal for the '<em><b>Text</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROPERTY__TEXT = eINSTANCE.getProperty_Text();

		/**
		 * The meta object literal for the '<em><b>Language</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROPERTY__LANGUAGE = eINSTANCE.getProperty_Language();

		/**
		 * The meta object literal for the '<em><b>Presentation Format</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROPERTY__PRESENTATION_FORMAT = eINSTANCE.getProperty_PresentationFormat();

		/**
		 * The meta object literal for the '<em><b>Property</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROPERTY__PROPERTY = eINSTANCE.getProperty_Property();

		/**
		 * The meta object literal for the '<em><b>Property Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROPERTY__PROPERTY_ID = eINSTANCE.getProperty_PropertyId();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.commonTypes.impl.PropertyQualifierImpl <em>Property Qualifier</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.commonTypes.impl.PropertyQualifierImpl
		 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getPropertyQualifier()
		 * @generated
		 */
		EClass PROPERTY_QUALIFIER = eINSTANCE.getPropertyQualifier();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROPERTY_QUALIFIER__VALUE = eINSTANCE.getPropertyQualifier_Value();

		/**
		 * The meta object literal for the '<em><b>Property Qualifier Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROPERTY_QUALIFIER__PROPERTY_QUALIFIER_ID = eINSTANCE.getPropertyQualifier_PropertyQualifierId();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.commonTypes.impl.VersionableImpl <em>Versionable</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.commonTypes.impl.VersionableImpl
		 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getVersionable()
		 * @generated
		 */
		EClass VERSIONABLE = eINSTANCE.getVersionable();

		/**
		 * The meta object literal for the '<em><b>Deprecated</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VERSIONABLE__DEPRECATED = eINSTANCE.getVersionable_Deprecated();

		/**
		 * The meta object literal for the '<em><b>First Release</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VERSIONABLE__FIRST_RELEASE = eINSTANCE.getVersionable_FirstRelease();

		/**
		 * The meta object literal for the '<em><b>Modified In Release</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VERSIONABLE__MODIFIED_IN_RELEASE = eINSTANCE.getVersionable_ModifiedInRelease();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.commonTypes.impl.VersionableAndDescribableImpl <em>Versionable And Describable</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.commonTypes.impl.VersionableAndDescribableImpl
		 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getVersionableAndDescribable()
		 * @generated
		 */
		EClass VERSIONABLE_AND_DESCRIBABLE = eINSTANCE.getVersionableAndDescribable();

		/**
		 * The meta object literal for the '<em><b>Entity Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VERSIONABLE_AND_DESCRIBABLE__ENTITY_DESCRIPTION = eINSTANCE
				.getVersionableAndDescribable_EntityDescription();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.commonTypes.impl.VersionReferenceImpl <em>Version Reference</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.commonTypes.impl.VersionReferenceImpl
		 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getVersionReference()
		 * @generated
		 */
		EClass VERSION_REFERENCE = eINSTANCE.getVersionReference();

		/**
		 * The meta object literal for the '<em><b>Version</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VERSION_REFERENCE__VERSION = eINSTANCE.getVersionReference_Version();

		/**
		 * The meta object literal for the '<em>Concept Code</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getConceptCode()
		 * @generated
		 */
		EDataType CONCEPT_CODE = eINSTANCE.getConceptCode();

		/**
		 * The meta object literal for the '<em>Context</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getContext()
		 * @generated
		 */
		EDataType CONTEXT = eINSTANCE.getContext();

		/**
		 * The meta object literal for the '<em>Dc</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getDc()
		 * @generated
		 */
		EDataType DC = eINSTANCE.getDc();

		/**
		 * The meta object literal for the '<em>Default Coding Scheme</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getDefaultCodingScheme()
		 * @generated
		 */
		EDataType DEFAULT_CODING_SCHEME = eINSTANCE.getDefaultCodingScheme();

		/**
		 * The meta object literal for the '<em>Default Language</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getDefaultLanguage()
		 * @generated
		 */
		EDataType DEFAULT_LANGUAGE = eINSTANCE.getDefaultLanguage();

		/**
		 * The meta object literal for the '<em>Entity Description</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getEntityDescription()
		 * @generated
		 */
		EDataType ENTITY_DESCRIPTION = eINSTANCE.getEntityDescription();

		/**
		 * The meta object literal for the '<em>Entry Order</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getEntryOrder()
		 * @generated
		 */
		EDataType ENTRY_ORDER = eINSTANCE.getEntryOrder();

		/**
		 * The meta object literal for the '<em>Id</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getId()
		 * @generated
		 */
		EDataType ID = eINSTANCE.getId();

		/**
		 * The meta object literal for the '<em>Language</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getLanguage()
		 * @generated
		 */
		EDataType LANGUAGE = eINSTANCE.getLanguage();

		/**
		 * The meta object literal for the '<em>Property Id</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getPropertyId()
		 * @generated
		 */
		EDataType PROPERTY_ID = eINSTANCE.getPropertyId();

		/**
		 * The meta object literal for the '<em>Property Qualifier Id</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getPropertyQualifierId()
		 * @generated
		 */
		EDataType PROPERTY_QUALIFIER_ID = eINSTANCE.getPropertyQualifierId();

		/**
		 * The meta object literal for the '<em>Registered Name</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getRegisteredName()
		 * @generated
		 */
		EDataType REGISTERED_NAME = eINSTANCE.getRegisteredName();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.commonTypes.impl.SourceImpl <em>Source</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.commonTypes.impl.SourceImpl
		 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getSource()
		 * @generated
		 */
		EClass SOURCE = eINSTANCE.getSource();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SOURCE__VALUE = eINSTANCE.getSource_Value();

		/**
		 * The meta object literal for the '<em><b>Role</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SOURCE__ROLE = eINSTANCE.getSource_Role();

		/**
		 * The meta object literal for the '<em><b>Sub Ref</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SOURCE__SUB_REF = eINSTANCE.getSource_SubRef();

		/**
		 * The meta object literal for the '<em>Text</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getText()
		 * @generated
		 */
		EDataType TEXT = eINSTANCE.getText();

		/**
		 * The meta object literal for the '<em>Version</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl#getVersion()
		 * @generated
		 */
		EDataType VERSION = eINSTANCE.getVersion();

	}

} //CommontypesPackage