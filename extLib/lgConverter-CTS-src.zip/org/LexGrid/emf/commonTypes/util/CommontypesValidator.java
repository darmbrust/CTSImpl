/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.LexGrid.emf.commonTypes.util;

import java.util.Map;

import org.LexGrid.emf.builtins.util.BuiltinsValidator;
import org.LexGrid.emf.commonTypes.CodedContext;
import org.LexGrid.emf.commonTypes.CommontypesPackage;
import org.LexGrid.emf.commonTypes.Describable;
import org.LexGrid.emf.commonTypes.Properties;
import org.LexGrid.emf.commonTypes.Property;
import org.LexGrid.emf.commonTypes.PropertyQualifier;
import org.LexGrid.emf.commonTypes.Source;
import org.LexGrid.emf.commonTypes.VersionReference;
import org.LexGrid.emf.commonTypes.Versionable;
import org.LexGrid.emf.commonTypes.VersionableAndDescribable;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.util.EObjectValidator;
import org.eclipse.emf.ecore.xml.type.util.XMLTypeValidator;

/**
 * <!-- begin-user-doc -->
 * The <b>Validator</b> for the model.
 * <!-- end-user-doc -->
 * @see org.LexGrid.emf.commonTypes.CommontypesPackage
 * @generated
 */
public class CommontypesValidator extends EObjectValidator {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final CommontypesValidator INSTANCE = new CommontypesValidator();

	/**
	 * A constant for the {@link org.eclipse.emf.common.util.Diagnostic#getSource() source} of diagnostic {@link org.eclipse.emf.common.util.Diagnostic#getCode() codes} from this package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.common.util.Diagnostic#getSource()
	 * @see org.eclipse.emf.common.util.Diagnostic#getCode()
	 * @generated
	 */
	public static final String DIAGNOSTIC_SOURCE = "org.LexGrid.emf.commonTypes";

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final int GENERATED_DIAGNOSTIC_CODE_COUNT = 0;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants in a derived class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final int DIAGNOSTIC_CODE_COUNT = GENERATED_DIAGNOSTIC_CODE_COUNT;

	/**
	 * The cached base package validator.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BuiltinsValidator builtinsValidator;

	/**
	 * The cached base package validator.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected XMLTypeValidator xmlTypeValidator;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CommontypesValidator() {
		super();
		builtinsValidator = BuiltinsValidator.INSTANCE;
		xmlTypeValidator = XMLTypeValidator.INSTANCE;
	}

	/**
	 * Returns the package of this validator switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EPackage getEPackage() {
		return CommontypesPackage.eINSTANCE;
	}

	/**
	 * Calls <code>validateXXX</code> for the corresonding classifier of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected boolean validate(int classifierID, Object value, DiagnosticChain diagnostics, Map context) {
		switch (classifierID) {
		case CommontypesPackage.CODED_CONTEXT:
			return validateCodedContext((CodedContext) value, diagnostics, context);
		case CommontypesPackage.DESCRIBABLE:
			return validateDescribable((Describable) value, diagnostics, context);
		case CommontypesPackage.PROPERTIES:
			return validateProperties((Properties) value, diagnostics, context);
		case CommontypesPackage.PROPERTY:
			return validateProperty((Property) value, diagnostics, context);
		case CommontypesPackage.PROPERTY_QUALIFIER:
			return validatePropertyQualifier((PropertyQualifier) value, diagnostics, context);
		case CommontypesPackage.SOURCE:
			return validateSource((Source) value, diagnostics, context);
		case CommontypesPackage.VERSIONABLE:
			return validateVersionable((Versionable) value, diagnostics, context);
		case CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE:
			return validateVersionableAndDescribable((VersionableAndDescribable) value, diagnostics, context);
		case CommontypesPackage.VERSION_REFERENCE:
			return validateVersionReference((VersionReference) value, diagnostics, context);
		case CommontypesPackage.CONCEPT_CODE:
			return validateConceptCode((String) value, diagnostics, context);
		case CommontypesPackage.CONTEXT:
			return validateContext((String) value, diagnostics, context);
		case CommontypesPackage.DC:
			return validateDc((String) value, diagnostics, context);
		case CommontypesPackage.DEFAULT_CODING_SCHEME:
			return validateDefaultCodingScheme((String) value, diagnostics, context);
		case CommontypesPackage.DEFAULT_LANGUAGE:
			return validateDefaultLanguage((String) value, diagnostics, context);
		case CommontypesPackage.ENTITY_DESCRIPTION:
			return validateEntityDescription((String) value, diagnostics, context);
		case CommontypesPackage.ENTRY_ORDER:
			return validateEntryOrder(((Integer) value).intValue(), diagnostics, context);
		case CommontypesPackage.ID:
			return validateId((String) value, diagnostics, context);
		case CommontypesPackage.LANGUAGE:
			return validateLanguage((String) value, diagnostics, context);
		case CommontypesPackage.PROPERTY_ID:
			return validatePropertyId((String) value, diagnostics, context);
		case CommontypesPackage.PROPERTY_QUALIFIER_ID:
			return validatePropertyQualifierId((String) value, diagnostics, context);
		case CommontypesPackage.REGISTERED_NAME:
			return validateRegisteredName((String) value, diagnostics, context);
		case CommontypesPackage.TEXT:
			return validateText((String) value, diagnostics, context);
		case CommontypesPackage.VERSION:
			return validateVersion((String) value, diagnostics, context);
		default:
			return true;
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCodedContext(CodedContext codedContext, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint((EObject) codedContext, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDescribable(Describable describable, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint((EObject) describable, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateProperties(Properties properties, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint((EObject) properties, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateProperty(Property property, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint((EObject) property, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePropertyQualifier(PropertyQualifier propertyQualifier, DiagnosticChain diagnostics,
			Map context) {
		return validate_EveryDefaultConstraint((EObject) propertyQualifier, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSource(Source source, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint((EObject) source, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateVersionable(Versionable versionable, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint((EObject) versionable, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateVersionableAndDescribable(VersionableAndDescribable versionableAndDescribable,
			DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint((EObject) versionableAndDescribable, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateVersionReference(VersionReference versionReference, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint((EObject) versionReference, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateConceptCode(String conceptCode, DiagnosticChain diagnostics, Map context) {
		boolean result = validateConceptCode_MinLength(conceptCode, diagnostics, context);
		return result;
	}

	/**
	 * Validates the MinLength constraint of '<em>Concept Code</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateConceptCode_MinLength(String conceptCode, DiagnosticChain diagnostics, Map context) {
		int length = conceptCode.length();
		boolean result = length >= 1;
		if (!result && diagnostics != null)
			reportMinLengthViolation(CommontypesPackage.Literals.CONCEPT_CODE, conceptCode, length, 1, diagnostics,
					context);
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateContext(String context, DiagnosticChain diagnostics, Map theContext) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDc(String dc, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDefaultCodingScheme(String defaultCodingScheme, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDefaultLanguage(String defaultLanguage, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEntityDescription(String entityDescription, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEntryOrder(int entryOrder, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateId(String id, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateLanguage(String language, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePropertyId(String propertyId, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePropertyQualifierId(String propertyQualifierId, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateRegisteredName(String registeredName, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateText(String text, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateVersion(String version, DiagnosticChain diagnostics, Map context) {
		boolean result = validateVersion_MinLength(version, diagnostics, context);
		return result;
	}

	/**
	 * Validates the MinLength constraint of '<em>Version</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateVersion_MinLength(String version, DiagnosticChain diagnostics, Map context) {
		int length = version.length();
		boolean result = length >= 1;
		if (!result && diagnostics != null)
			reportMinLengthViolation(CommontypesPackage.Literals.VERSION, version, length, 1, diagnostics, context);
		return result;
	}

} //CommontypesValidator
