/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.LexGrid.emf.commonTypes;

import org.LexGrid.emf.base.LgModelObj;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Property Qualifier</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Additional information about the property and/or its association with the codedEntry.
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.LexGrid.emf.commonTypes.PropertyQualifier#getValue <em>Value</em>}</li>
 *   <li>{@link org.LexGrid.emf.commonTypes.PropertyQualifier#getPropertyQualifierId <em>Property Qualifier Id</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.LexGrid.emf.commonTypes.CommontypesPackage#getPropertyQualifier()
 * @model extendedMetaData="name='propertyQualifier' kind='mixed'"
 * @extends LgModelObj
 * @generated
 */
public interface PropertyQualifier extends LgModelObj {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Returns the value of the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Value</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Value</em>' attribute.
	 * @see #setValue(String)
	 * @see org.LexGrid.emf.commonTypes.CommontypesPackage#getPropertyQualifier_Value()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.Text" required="true"
	 *        extendedMetaData="kind='elementWildcard' wildcards='##other' name=':1' processing='lax'"
	 * @generated
	 */
	String getValue();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.commonTypes.PropertyQualifier#getValue <em>Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Value</em>' attribute.
	 * @see #getValue()
	 * @generated
	 */
	void setValue(String value);

	/**
	 * Returns the value of the '<em><b>Property Qualifier Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The local name of the qualifier type. Must be in supportedPropertyQualifier
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Property Qualifier Id</em>' attribute.
	 * @see #setPropertyQualifierId(String)
	 * @see org.LexGrid.emf.commonTypes.CommontypesPackage#getPropertyQualifier_PropertyQualifierId()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.PropertyQualifierId" required="true"
	 *        extendedMetaData="kind='attribute' name='propertyQualifierId'"
	 * @generated
	 */
	String getPropertyQualifierId();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.commonTypes.PropertyQualifier#getPropertyQualifierId <em>Property Qualifier Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Property Qualifier Id</em>' attribute.
	 * @see #getPropertyQualifierId()
	 * @generated
	 */
	void setPropertyQualifierId(String value);

} // PropertyQualifier