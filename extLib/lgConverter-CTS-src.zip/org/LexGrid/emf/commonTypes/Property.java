/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.LexGrid.emf.commonTypes;

import java.util.List;

import org.LexGrid.emf.base.LgModelObj;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Property</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A description, definition, annotation or other attribute that serves to further define or identify an entity.
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.LexGrid.emf.commonTypes.Property#getSource <em>Source</em>}</li>
 *   <li>{@link org.LexGrid.emf.commonTypes.Property#getUsageContext <em>Usage Context</em>}</li>
 *   <li>{@link org.LexGrid.emf.commonTypes.Property#getPropertyQualifier <em>Property Qualifier</em>}</li>
 *   <li>{@link org.LexGrid.emf.commonTypes.Property#getText <em>Text</em>}</li>
 *   <li>{@link org.LexGrid.emf.commonTypes.Property#getLanguage <em>Language</em>}</li>
 *   <li>{@link org.LexGrid.emf.commonTypes.Property#getPresentationFormat <em>Presentation Format</em>}</li>
 *   <li>{@link org.LexGrid.emf.commonTypes.Property#getProperty <em>Property</em>}</li>
 *   <li>{@link org.LexGrid.emf.commonTypes.Property#getPropertyId <em>Property Id</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.LexGrid.emf.commonTypes.CommontypesPackage#getProperty()
 * @model extendedMetaData="name='property' kind='elementOnly'"
 * @extends LgModelObj
 * @generated
 */
public interface Property extends LgModelObj {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Returns the value of the '<em><b>Source</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.commonTypes.Source}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The source(s) of this property. Must be in supportedSource.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Source</em>' containment reference list.
	 * @see org.LexGrid.emf.commonTypes.CommontypesPackage#getProperty_Source()
	 * @model type="org.LexGrid.emf.commonTypes.Source" containment="true"
	 *        extendedMetaData="kind='element' name='source' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSource();

	/**
	 * Returns the value of the '<em><b>Usage Context</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.String}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The context(s) in which this property applies. Must be in supportedContext.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Usage Context</em>' attribute list.
	 * @see org.LexGrid.emf.commonTypes.CommontypesPackage#getProperty_UsageContext()
	 * @model type="java.lang.String" unique="false" dataType="org.LexGrid.emf.commonTypes.Context"
	 *        extendedMetaData="kind='element' name='usageContext' namespace='##targetNamespace'"
	 * @generated
	 */
	List getUsageContext();

	/**
	 * Returns the value of the '<em><b>Property Qualifier</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.commonTypes.PropertyQualifier}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Qualifiers that describe property usage, source, etc.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Property Qualifier</em>' containment reference list.
	 * @see org.LexGrid.emf.commonTypes.CommontypesPackage#getProperty_PropertyQualifier()
	 * @model type="org.LexGrid.emf.commonTypes.PropertyQualifier" containment="true"
	 *        extendedMetaData="kind='element' name='propertyQualifier' namespace='##targetNamespace'"
	 * @generated
	 */
	List getPropertyQualifier();

	/**
	 * Returns the value of the '<em><b>Text</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Actual property text.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Text</em>' attribute.
	 * @see #setText(String)
	 * @see org.LexGrid.emf.commonTypes.CommontypesPackage#getProperty_Text()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.Text" required="true"
	 *        extendedMetaData="kind='element' name='text' namespace='##targetNamespace'"
	 * @generated
	 */
	String getText();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.commonTypes.Property#getText <em>Text</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Text</em>' attribute.
	 * @see #getText()
	 * @generated
	 */
	void setText(String value);

	/**
	 * Returns the value of the '<em><b>Language</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The written or spoken language of the property. Must be in supportedLanguage. Default- defaultLanguage for coding
	 * 				Scheme
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Language</em>' attribute.
	 * @see #setLanguage(String)
	 * @see org.LexGrid.emf.commonTypes.CommontypesPackage#getProperty_Language()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.Language"
	 *        extendedMetaData="kind='attribute' name='language'"
	 * @generated
	 */
	String getLanguage();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.commonTypes.Property#getLanguage <em>Language</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Language</em>' attribute.
	 * @see #getLanguage()
	 * @generated
	 */
	void setLanguage(String value);

	/**
	 * Returns the value of the '<em><b>Presentation Format</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Format or mime type of the property. Must be in supportedFormat. Default: text/plain
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Presentation Format</em>' attribute.
	 * @see #setPresentationFormat(String)
	 * @see org.LexGrid.emf.commonTypes.CommontypesPackage#getProperty_PresentationFormat()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.LocalId"
	 *        extendedMetaData="kind='attribute' name='presentationFormat'"
	 * @generated
	 */
	String getPresentationFormat();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.commonTypes.Property#getPresentationFormat <em>Presentation Format</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Presentation Format</em>' attribute.
	 * @see #getPresentationFormat()
	 * @generated
	 */
	void setPresentationFormat(String value);

	/**
	 * Returns the value of the '<em><b>Property</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The local name or tag of the property. Must be in supportedProperty
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Property</em>' attribute.
	 * @see #setProperty(String)
	 * @see org.LexGrid.emf.commonTypes.CommontypesPackage#getProperty_Property()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.LocalId" required="true"
	 *        extendedMetaData="kind='attribute' name='property'"
	 * @generated
	 */
	String getProperty();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.commonTypes.Property#getProperty <em>Property</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Property</em>' attribute.
	 * @see #getProperty()
	 * @generated
	 */
	void setProperty(String value);

	/**
	 * Returns the value of the '<em><b>Property Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The unique name of the property within the context of the coded entry
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Property Id</em>' attribute.
	 * @see #setPropertyId(String)
	 * @see org.LexGrid.emf.commonTypes.CommontypesPackage#getProperty_PropertyId()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.PropertyId" required="true"
	 *        extendedMetaData="kind='attribute' name='propertyId'"
	 * @generated
	 */
	String getPropertyId();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.commonTypes.Property#getPropertyId <em>Property Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Property Id</em>' attribute.
	 * @see #getPropertyId()
	 * @generated
	 */
	void setPropertyId(String value);

} // Property