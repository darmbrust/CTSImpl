/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.commonTypes.impl;

import org.LexGrid.emf.builtins.BuiltinsFactory;
import org.LexGrid.emf.builtins.BuiltinsPackage;
import org.LexGrid.emf.commonTypes.CodedContext;
import org.LexGrid.emf.commonTypes.CommontypesFactory;
import org.LexGrid.emf.commonTypes.CommontypesPackage;
import org.LexGrid.emf.commonTypes.Describable;
import org.LexGrid.emf.commonTypes.Properties;
import org.LexGrid.emf.commonTypes.Property;
import org.LexGrid.emf.commonTypes.PropertyQualifier;
import org.LexGrid.emf.commonTypes.Source;
import org.LexGrid.emf.commonTypes.VersionReference;
import org.LexGrid.emf.commonTypes.Versionable;
import org.LexGrid.emf.commonTypes.VersionableAndDescribable;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EFactoryImpl;
import org.eclipse.emf.ecore.plugin.EcorePlugin;
import org.eclipse.emf.ecore.xml.type.XMLTypeFactory;
import org.eclipse.emf.ecore.xml.type.XMLTypePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class CommontypesFactoryImpl extends EFactoryImpl implements CommontypesFactory {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static CommontypesFactory init() {
		try {
			CommontypesFactory theCommontypesFactory = (CommontypesFactory) EPackage.Registry.INSTANCE
					.getEFactory("http://LexGrid.org/schema/2006/01/LexGrid/commonTypes");
			if (theCommontypesFactory != null) {
				return theCommontypesFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new CommontypesFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CommontypesFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case CommontypesPackage.CODED_CONTEXT:
			return (EObject) createCodedContext();
		case CommontypesPackage.DESCRIBABLE:
			return (EObject) createDescribable();
		case CommontypesPackage.PROPERTIES:
			return (EObject) createProperties();
		case CommontypesPackage.PROPERTY:
			return (EObject) createProperty();
		case CommontypesPackage.PROPERTY_QUALIFIER:
			return (EObject) createPropertyQualifier();
		case CommontypesPackage.SOURCE:
			return (EObject) createSource();
		case CommontypesPackage.VERSIONABLE:
			return (EObject) createVersionable();
		case CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE:
			return (EObject) createVersionableAndDescribable();
		case CommontypesPackage.VERSION_REFERENCE:
			return (EObject) createVersionReference();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
		case CommontypesPackage.CONCEPT_CODE:
			return createConceptCodeFromString(eDataType, initialValue);
		case CommontypesPackage.CONTEXT:
			return createContextFromString(eDataType, initialValue);
		case CommontypesPackage.DC:
			return createDcFromString(eDataType, initialValue);
		case CommontypesPackage.DEFAULT_CODING_SCHEME:
			return createDefaultCodingSchemeFromString(eDataType, initialValue);
		case CommontypesPackage.DEFAULT_LANGUAGE:
			return createDefaultLanguageFromString(eDataType, initialValue);
		case CommontypesPackage.ENTITY_DESCRIPTION:
			return createEntityDescriptionFromString(eDataType, initialValue);
		case CommontypesPackage.ENTRY_ORDER:
			return createEntryOrderFromString(eDataType, initialValue);
		case CommontypesPackage.ID:
			return createIdFromString(eDataType, initialValue);
		case CommontypesPackage.LANGUAGE:
			return createLanguageFromString(eDataType, initialValue);
		case CommontypesPackage.PROPERTY_ID:
			return createPropertyIdFromString(eDataType, initialValue);
		case CommontypesPackage.PROPERTY_QUALIFIER_ID:
			return createPropertyQualifierIdFromString(eDataType, initialValue);
		case CommontypesPackage.REGISTERED_NAME:
			return createRegisteredNameFromString(eDataType, initialValue);
		case CommontypesPackage.TEXT:
			return createTextFromString(eDataType, initialValue);
		case CommontypesPackage.VERSION:
			return createVersionFromString(eDataType, initialValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
		case CommontypesPackage.CONCEPT_CODE:
			return convertConceptCodeToString(eDataType, instanceValue);
		case CommontypesPackage.CONTEXT:
			return convertContextToString(eDataType, instanceValue);
		case CommontypesPackage.DC:
			return convertDcToString(eDataType, instanceValue);
		case CommontypesPackage.DEFAULT_CODING_SCHEME:
			return convertDefaultCodingSchemeToString(eDataType, instanceValue);
		case CommontypesPackage.DEFAULT_LANGUAGE:
			return convertDefaultLanguageToString(eDataType, instanceValue);
		case CommontypesPackage.ENTITY_DESCRIPTION:
			return convertEntityDescriptionToString(eDataType, instanceValue);
		case CommontypesPackage.ENTRY_ORDER:
			return convertEntryOrderToString(eDataType, instanceValue);
		case CommontypesPackage.ID:
			return convertIdToString(eDataType, instanceValue);
		case CommontypesPackage.LANGUAGE:
			return convertLanguageToString(eDataType, instanceValue);
		case CommontypesPackage.PROPERTY_ID:
			return convertPropertyIdToString(eDataType, instanceValue);
		case CommontypesPackage.PROPERTY_QUALIFIER_ID:
			return convertPropertyQualifierIdToString(eDataType, instanceValue);
		case CommontypesPackage.REGISTERED_NAME:
			return convertRegisteredNameToString(eDataType, instanceValue);
		case CommontypesPackage.TEXT:
			return convertTextToString(eDataType, instanceValue);
		case CommontypesPackage.VERSION:
			return convertVersionToString(eDataType, instanceValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CodedContext createCodedContext() {
		CodedContextImpl codedContext = new CodedContextImpl();
		return codedContext;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VersionableAndDescribable createVersionableAndDescribable() {
		VersionableAndDescribableImpl versionableAndDescribable = new VersionableAndDescribableImpl();
		return versionableAndDescribable;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VersionReference createVersionReference() {
		VersionReferenceImpl versionReference = new VersionReferenceImpl();
		return versionReference;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Versionable createVersionable() {
		VersionableImpl versionable = new VersionableImpl();
		return versionable;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Describable createDescribable() {
		DescribableImpl describable = new DescribableImpl();
		return describable;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Properties createProperties() {
		PropertiesImpl properties = new PropertiesImpl();
		return properties;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Property createProperty() {
		PropertyImpl property = new PropertyImpl();
		return property;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PropertyQualifier createPropertyQualifier() {
		PropertyQualifierImpl propertyQualifier = new PropertyQualifierImpl();
		return propertyQualifier;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Source createSource() {
		SourceImpl source = new SourceImpl();
		return source;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createVersionFromString(EDataType eDataType, String initialValue) {
		return (String) BuiltinsFactory.eINSTANCE.createFromString(BuiltinsPackage.Literals.TS_CASE_IGNORE_IA5_STRING,
				initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertVersionToString(EDataType eDataType, Object instanceValue) {
		return BuiltinsFactory.eINSTANCE.convertToString(BuiltinsPackage.Literals.TS_CASE_IGNORE_IA5_STRING,
				instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createTextFromString(EDataType eDataType, String initialValue) {
		return (String) XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.Literals.STRING, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTextToString(EDataType eDataType, Object instanceValue) {
		return XMLTypeFactory.eINSTANCE.convertToString(XMLTypePackage.Literals.STRING, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createEntityDescriptionFromString(EDataType eDataType, String initialValue) {
		return (String) XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.Literals.STRING, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertEntityDescriptionToString(EDataType eDataType, Object instanceValue) {
		return XMLTypeFactory.eINSTANCE.convertToString(XMLTypePackage.Literals.STRING, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createDcFromString(EDataType eDataType, String initialValue) {
		return (String) BuiltinsFactory.eINSTANCE.createFromString(BuiltinsPackage.Literals.TS_CASE_IGNORE_IA5_STRING,
				initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertDcToString(EDataType eDataType, Object instanceValue) {
		return BuiltinsFactory.eINSTANCE.convertToString(BuiltinsPackage.Literals.TS_CASE_IGNORE_IA5_STRING,
				instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createRegisteredNameFromString(EDataType eDataType, String initialValue) {
		return (String) BuiltinsFactory.eINSTANCE.createFromString(BuiltinsPackage.Literals.TS_URN, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertRegisteredNameToString(EDataType eDataType, Object instanceValue) {
		return BuiltinsFactory.eINSTANCE.convertToString(BuiltinsPackage.Literals.TS_URN, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createDefaultLanguageFromString(EDataType eDataType, String initialValue) {
		return (String) createLanguageFromString(CommontypesPackage.Literals.LANGUAGE, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertDefaultLanguageToString(EDataType eDataType, Object instanceValue) {
		return convertLanguageToString(CommontypesPackage.Literals.LANGUAGE, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createLanguageFromString(EDataType eDataType, String initialValue) {
		return (String) BuiltinsFactory.eINSTANCE.createFromString(BuiltinsPackage.Literals.LOCAL_ID, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertLanguageToString(EDataType eDataType, Object instanceValue) {
		return BuiltinsFactory.eINSTANCE.convertToString(BuiltinsPackage.Literals.LOCAL_ID, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createConceptCodeFromString(EDataType eDataType, String initialValue) {
		return (String) BuiltinsFactory.eINSTANCE.createFromString(BuiltinsPackage.Literals.TS_CASE_IGNORE_IA5_STRING,
				initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertConceptCodeToString(EDataType eDataType, Object instanceValue) {
		return BuiltinsFactory.eINSTANCE.convertToString(BuiltinsPackage.Literals.TS_CASE_IGNORE_IA5_STRING,
				instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createContextFromString(EDataType eDataType, String initialValue) {
		return (String) BuiltinsFactory.eINSTANCE.createFromString(BuiltinsPackage.Literals.LOCAL_ID, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertContextToString(EDataType eDataType, Object instanceValue) {
		return BuiltinsFactory.eINSTANCE.convertToString(BuiltinsPackage.Literals.LOCAL_ID, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createPropertyIdFromString(EDataType eDataType, String initialValue) {
		return (String) BuiltinsFactory.eINSTANCE.createFromString(BuiltinsPackage.Literals.TS_CASE_IGNORE_IA5_STRING,
				initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertPropertyIdToString(EDataType eDataType, Object instanceValue) {
		return BuiltinsFactory.eINSTANCE.convertToString(BuiltinsPackage.Literals.TS_CASE_IGNORE_IA5_STRING,
				instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createPropertyQualifierIdFromString(EDataType eDataType, String initialValue) {
		return (String) BuiltinsFactory.eINSTANCE.createFromString(BuiltinsPackage.Literals.LOCAL_ID, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertPropertyQualifierIdToString(EDataType eDataType, Object instanceValue) {
		return BuiltinsFactory.eINSTANCE.convertToString(BuiltinsPackage.Literals.LOCAL_ID, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createIdFromString(EDataType eDataType, String initialValue) {
		return (String) BuiltinsFactory.eINSTANCE.createFromString(BuiltinsPackage.Literals.TS_CASE_IGNORE_IA5_STRING,
				initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertIdToString(EDataType eDataType, Object instanceValue) {
		return BuiltinsFactory.eINSTANCE.convertToString(BuiltinsPackage.Literals.TS_CASE_IGNORE_IA5_STRING,
				instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createDefaultCodingSchemeFromString(EDataType eDataType, String initialValue) {
		return (String) BuiltinsFactory.eINSTANCE.createFromString(BuiltinsPackage.Literals.LOCAL_ID, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertDefaultCodingSchemeToString(EDataType eDataType, Object instanceValue) {
		return BuiltinsFactory.eINSTANCE.convertToString(BuiltinsPackage.Literals.LOCAL_ID, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Integer createEntryOrderFromString(EDataType eDataType, String initialValue) {
		return (Integer) BuiltinsFactory.eINSTANCE.createFromString(BuiltinsPackage.Literals.TS_INTEGER, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertEntryOrderToString(EDataType eDataType, Object instanceValue) {
		return BuiltinsFactory.eINSTANCE.convertToString(BuiltinsPackage.Literals.TS_INTEGER, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CommontypesPackage getCommontypesPackage() {
		return (CommontypesPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	public static CommontypesPackage getPackage() {
		return CommontypesPackage.eINSTANCE;
	}

} //CommontypesFactoryImpl