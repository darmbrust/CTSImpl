/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.commonTypes.impl;

import org.LexGrid.emf.base.impl.LgAttributeImpl;
import org.LexGrid.emf.base.impl.LgReferenceImpl;
import org.LexGrid.emf.builtins.BuiltinsPackage;
import org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl;
import org.LexGrid.emf.codingSchemes.CodingschemesPackage;
import org.LexGrid.emf.codingSchemes.impl.CodingschemesPackageImpl;
import org.LexGrid.emf.commonTypes.CodedContext;
import org.LexGrid.emf.commonTypes.CommontypesFactory;
import org.LexGrid.emf.commonTypes.CommontypesPackage;
import org.LexGrid.emf.commonTypes.Describable;
import org.LexGrid.emf.commonTypes.Properties;
import org.LexGrid.emf.commonTypes.Property;
import org.LexGrid.emf.commonTypes.PropertyQualifier;
import org.LexGrid.emf.commonTypes.Source;
import org.LexGrid.emf.commonTypes.VersionReference;
import org.LexGrid.emf.commonTypes.Versionable;
import org.LexGrid.emf.commonTypes.VersionableAndDescribable;
import org.LexGrid.emf.commonTypes.util.CommontypesValidator;
import org.LexGrid.emf.concepts.ConceptsPackage;
import org.LexGrid.emf.concepts.impl.ConceptsPackageImpl;
import org.LexGrid.emf.history.NCIHistoryPackage;
import org.LexGrid.emf.history.impl.NCIHistoryPackageImpl;
import org.LexGrid.emf.ldap.LdapPackage;
import org.LexGrid.emf.ldap.impl.LdapPackageImpl;
import org.LexGrid.emf.naming.NamingPackage;
import org.LexGrid.emf.naming.impl.NamingPackageImpl;
import org.LexGrid.emf.relations.RelationsPackage;
import org.LexGrid.emf.relations.impl.RelationsPackageImpl;
import org.LexGrid.emf.service.ServiceTypePackage;
import org.LexGrid.emf.service.impl.ServiceTypePackageImpl;
import org.LexGrid.emf.valueDomains.ValuedomainsPackage;
import org.LexGrid.emf.valueDomains.impl.ValuedomainsPackageImpl;
import org.LexGrid.emf.versions.VersionsPackage;
import org.LexGrid.emf.versions.impl.VersionsPackageImpl;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EValidator;
import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class CommontypesPackageImpl extends EPackageImpl implements CommontypesPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass codedContextEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass versionableAndDescribableEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass versionReferenceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass versionableEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass describableEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass propertiesEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass propertyEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass propertyQualifierEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sourceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType versionEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType textEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType entityDescriptionEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType dcEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType registeredNameEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType defaultLanguageEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType languageEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType conceptCodeEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType contextEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType propertyIdEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType propertyQualifierIdEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType idEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType defaultCodingSchemeEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType entryOrderEDataType = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see org.LexGrid.emf.commonTypes.CommontypesPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private CommontypesPackageImpl() {
		super(eNS_URI, CommontypesFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this
	 * model, and for any others upon which it depends.  Simple
	 * dependencies are satisfied by calling this method on all
	 * dependent packages before doing anything else.  This method drives
	 * initialization for interdependent packages directly, in parallel
	 * with this package, itself.
	 * <p>Of this package and its interdependencies, all packages which
	 * have not yet been registered by their URI values are first created
	 * and registered.  The packages are then initialized in two steps:
	 * meta-model objects for all of the packages are created before any
	 * are initialized, since one package's meta-model objects may refer to
	 * those of another.
	 * <p>Invocation of this method will not affect any packages that have
	 * already been initialized.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static CommontypesPackage init() {
		if (isInited)
			return (CommontypesPackage) EPackage.Registry.INSTANCE.getEPackage(CommontypesPackage.eNS_URI);

		// Obtain or create and register package
		CommontypesPackageImpl theCommontypesPackage = (CommontypesPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(eNS_URI) instanceof CommontypesPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(eNS_URI) : new CommontypesPackageImpl());

		isInited = true;

		// Obtain or create and register interdependencies
		ConceptsPackageImpl theConceptsPackage = (ConceptsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(ConceptsPackage.eNS_URI) instanceof ConceptsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(ConceptsPackage.eNS_URI) : ConceptsPackage.eINSTANCE);
		RelationsPackageImpl theRelationsPackage = (RelationsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(RelationsPackage.eNS_URI) instanceof RelationsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(RelationsPackage.eNS_URI) : RelationsPackage.eINSTANCE);
		NCIHistoryPackageImpl theNCIHistoryPackage = (NCIHistoryPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(NCIHistoryPackage.eNS_URI) instanceof NCIHistoryPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(NCIHistoryPackage.eNS_URI) : NCIHistoryPackage.eINSTANCE);
		VersionsPackageImpl theVersionsPackage = (VersionsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(VersionsPackage.eNS_URI) instanceof VersionsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(VersionsPackage.eNS_URI) : VersionsPackage.eINSTANCE);
		CodingschemesPackageImpl theCodingschemesPackage = (CodingschemesPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(CodingschemesPackage.eNS_URI) instanceof CodingschemesPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(CodingschemesPackage.eNS_URI)
				: CodingschemesPackage.eINSTANCE);
		LdapPackageImpl theLdapPackage = (LdapPackageImpl) (EPackage.Registry.INSTANCE.getEPackage(LdapPackage.eNS_URI) instanceof LdapPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(LdapPackage.eNS_URI)
				: LdapPackage.eINSTANCE);
		BuiltinsPackageImpl theBuiltinsPackage = (BuiltinsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(BuiltinsPackage.eNS_URI) instanceof BuiltinsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(BuiltinsPackage.eNS_URI) : BuiltinsPackage.eINSTANCE);
		ValuedomainsPackageImpl theValuedomainsPackage = (ValuedomainsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(ValuedomainsPackage.eNS_URI) instanceof ValuedomainsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(ValuedomainsPackage.eNS_URI)
				: ValuedomainsPackage.eINSTANCE);
		ServiceTypePackageImpl theServiceTypePackage = (ServiceTypePackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(ServiceTypePackage.eNS_URI) instanceof ServiceTypePackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(ServiceTypePackage.eNS_URI) : ServiceTypePackage.eINSTANCE);
		NamingPackageImpl theNamingPackage = (NamingPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(NamingPackage.eNS_URI) instanceof NamingPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(NamingPackage.eNS_URI) : NamingPackage.eINSTANCE);

		// Create package meta-data objects
		theCommontypesPackage.createPackageContents();
		theConceptsPackage.createPackageContents();
		theRelationsPackage.createPackageContents();
		theNCIHistoryPackage.createPackageContents();
		theVersionsPackage.createPackageContents();
		theCodingschemesPackage.createPackageContents();
		theLdapPackage.createPackageContents();
		theBuiltinsPackage.createPackageContents();
		theValuedomainsPackage.createPackageContents();
		theServiceTypePackage.createPackageContents();
		theNamingPackage.createPackageContents();

		// Initialize created meta-data
		theCommontypesPackage.initializePackageContents();
		theConceptsPackage.initializePackageContents();
		theRelationsPackage.initializePackageContents();
		theNCIHistoryPackage.initializePackageContents();
		theVersionsPackage.initializePackageContents();
		theCodingschemesPackage.initializePackageContents();
		theLdapPackage.initializePackageContents();
		theBuiltinsPackage.initializePackageContents();
		theValuedomainsPackage.initializePackageContents();
		theServiceTypePackage.initializePackageContents();
		theNamingPackage.initializePackageContents();

		// Register package validator
		EValidator.Registry.INSTANCE.put(theCommontypesPackage, new EValidator.Descriptor() {
			public EValidator getEValidator() {
				return CommontypesValidator.INSTANCE;
			}
		});

		// Mark meta-data to indicate it can't be changed
		theCommontypesPackage.freeze();

		return theCommontypesPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCodedContext() {
		return codedContextEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCodedContext_Value() {
		return (EAttribute) codedContextEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCodedContext_CodingScheme() {
		return (EAttribute) codedContextEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCodedContext_ConceptCode() {
		return (EAttribute) codedContextEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getVersionableAndDescribable() {
		return versionableAndDescribableEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVersionableAndDescribable_EntityDescription() {
		return (EAttribute) versionableAndDescribableEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getVersionReference() {
		return versionReferenceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVersionReference_Version() {
		return (EAttribute) versionReferenceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getVersionable() {
		return versionableEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVersionable_Deprecated() {
		return (EAttribute) versionableEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVersionable_FirstRelease() {
		return (EAttribute) versionableEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVersionable_ModifiedInRelease() {
		return (EAttribute) versionableEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDescribable() {
		return describableEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDescribable_EntityDescription() {
		return (EAttribute) describableEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getProperties() {
		return propertiesEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getProperties_Property() {
		return (EReference) propertiesEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProperties_Dc() {
		return (EAttribute) propertiesEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getProperty() {
		return propertyEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getProperty_Source() {
		return (EReference) propertyEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProperty_UsageContext() {
		return (EAttribute) propertyEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getProperty_PropertyQualifier() {
		return (EReference) propertyEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProperty_Text() {
		return (EAttribute) propertyEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProperty_Language() {
		return (EAttribute) propertyEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProperty_PresentationFormat() {
		return (EAttribute) propertyEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProperty_Property() {
		return (EAttribute) propertyEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProperty_PropertyId() {
		return (EAttribute) propertyEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPropertyQualifier() {
		return propertyQualifierEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPropertyQualifier_Value() {
		return (EAttribute) propertyQualifierEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPropertyQualifier_PropertyQualifierId() {
		return (EAttribute) propertyQualifierEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getVersion() {
		return versionEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getDc() {
		return dcEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getRegisteredName() {
		return registeredNameEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getDefaultLanguage() {
		return defaultLanguageEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getLanguage() {
		return languageEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSource() {
		return sourceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSource_Value() {
		return (EAttribute) sourceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSource_Role() {
		return (EAttribute) sourceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSource_SubRef() {
		return (EAttribute) sourceEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getConceptCode() {
		return conceptCodeEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getContext() {
		return contextEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getPropertyId() {
		return propertyIdEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getPropertyQualifierId() {
		return propertyQualifierIdEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getText() {
		return textEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getEntityDescription() {
		return entityDescriptionEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getId() {
		return idEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getDefaultCodingScheme() {
		return defaultCodingSchemeEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getEntryOrder() {
		return entryOrderEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CommontypesFactory getCommontypesFactory() {
		return (CommontypesFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		codedContextEClass = createEClass(CODED_CONTEXT);
		createEAttribute(codedContextEClass, CODED_CONTEXT__VALUE);
		createEAttribute(codedContextEClass, CODED_CONTEXT__CODING_SCHEME);
		createEAttribute(codedContextEClass, CODED_CONTEXT__CONCEPT_CODE);

		describableEClass = createEClass(DESCRIBABLE);
		createEAttribute(describableEClass, DESCRIBABLE__ENTITY_DESCRIPTION);

		propertiesEClass = createEClass(PROPERTIES);
		createEReference(propertiesEClass, PROPERTIES__PROPERTY);
		createEAttribute(propertiesEClass, PROPERTIES__DC);

		propertyEClass = createEClass(PROPERTY);
		createEReference(propertyEClass, PROPERTY__SOURCE);
		createEAttribute(propertyEClass, PROPERTY__USAGE_CONTEXT);
		createEReference(propertyEClass, PROPERTY__PROPERTY_QUALIFIER);
		createEAttribute(propertyEClass, PROPERTY__TEXT);
		createEAttribute(propertyEClass, PROPERTY__LANGUAGE);
		createEAttribute(propertyEClass, PROPERTY__PRESENTATION_FORMAT);
		createEAttribute(propertyEClass, PROPERTY__PROPERTY);
		createEAttribute(propertyEClass, PROPERTY__PROPERTY_ID);

		propertyQualifierEClass = createEClass(PROPERTY_QUALIFIER);
		createEAttribute(propertyQualifierEClass, PROPERTY_QUALIFIER__VALUE);
		createEAttribute(propertyQualifierEClass, PROPERTY_QUALIFIER__PROPERTY_QUALIFIER_ID);

		sourceEClass = createEClass(SOURCE);
		createEAttribute(sourceEClass, SOURCE__VALUE);
		createEAttribute(sourceEClass, SOURCE__ROLE);
		createEAttribute(sourceEClass, SOURCE__SUB_REF);

		versionableEClass = createEClass(VERSIONABLE);
		createEAttribute(versionableEClass, VERSIONABLE__DEPRECATED);
		createEAttribute(versionableEClass, VERSIONABLE__FIRST_RELEASE);
		createEAttribute(versionableEClass, VERSIONABLE__MODIFIED_IN_RELEASE);

		versionableAndDescribableEClass = createEClass(VERSIONABLE_AND_DESCRIBABLE);
		createEAttribute(versionableAndDescribableEClass, VERSIONABLE_AND_DESCRIBABLE__ENTITY_DESCRIPTION);

		versionReferenceEClass = createEClass(VERSION_REFERENCE);
		createEAttribute(versionReferenceEClass, VERSION_REFERENCE__VERSION);

		// Create data types
		conceptCodeEDataType = createEDataType(CONCEPT_CODE);
		contextEDataType = createEDataType(CONTEXT);
		dcEDataType = createEDataType(DC);
		defaultCodingSchemeEDataType = createEDataType(DEFAULT_CODING_SCHEME);
		defaultLanguageEDataType = createEDataType(DEFAULT_LANGUAGE);
		entityDescriptionEDataType = createEDataType(ENTITY_DESCRIPTION);
		entryOrderEDataType = createEDataType(ENTRY_ORDER);
		idEDataType = createEDataType(ID);
		languageEDataType = createEDataType(LANGUAGE);
		propertyIdEDataType = createEDataType(PROPERTY_ID);
		propertyQualifierIdEDataType = createEDataType(PROPERTY_QUALIFIER_ID);
		registeredNameEDataType = createEDataType(REGISTERED_NAME);
		textEDataType = createEDataType(TEXT);
		versionEDataType = createEDataType(VERSION);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContentsGen() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		BuiltinsPackage theBuiltinsPackage = (BuiltinsPackage) EPackage.Registry.INSTANCE
				.getEPackage(BuiltinsPackage.eNS_URI);
		NamingPackage theNamingPackage = (NamingPackage) EPackage.Registry.INSTANCE.getEPackage(NamingPackage.eNS_URI);

		// Add supertypes to classes
		versionableAndDescribableEClass.getESuperTypes().add(this.getVersionable());
		versionReferenceEClass.getESuperTypes().add(theNamingPackage.getURNMap());

		// Initialize classes and features; add operations and parameters
		initEClass(codedContextEClass, CodedContext.class, "CodedContext", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCodedContext_Value(), this.getContext(), "value", null, 0, 1, CodedContext.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCodedContext_CodingScheme(), theBuiltinsPackage.getLocalId(), "codingScheme", null, 0, 1,
				CodedContext.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getCodedContext_ConceptCode(), this.getConceptCode(), "conceptCode", null, 0, 1,
				CodedContext.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(describableEClass, Describable.class, "Describable", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDescribable_EntityDescription(), this.getEntityDescription(), "entityDescription", null, 0,
				1, Describable.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(propertiesEClass, Properties.class, "Properties", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getProperties_Property(), this.getProperty(), null, "property", null, 0, -1, Properties.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getProperties_Dc(), this.getDc(), "dc", "properties", 1, 1, Properties.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(propertyEClass, Property.class, "Property", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getProperty_Source(), this.getSource(), null, "source", null, 0, -1, Property.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getProperty_UsageContext(), this.getContext(), "usageContext", null, 0, -1, Property.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getProperty_PropertyQualifier(), this.getPropertyQualifier(), null, "propertyQualifier", null,
				0, -1, Property.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getProperty_Text(), this.getText(), "text", null, 1, 1, Property.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getProperty_Language(), this.getLanguage(), "language", null, 0, 1, Property.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getProperty_PresentationFormat(), theBuiltinsPackage.getLocalId(), "presentationFormat", null,
				0, 1, Property.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getProperty_Property(), theBuiltinsPackage.getLocalId(), "property", null, 1, 1, Property.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getProperty_PropertyId(), this.getPropertyId(), "propertyId", null, 1, 1, Property.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(propertyQualifierEClass, PropertyQualifier.class, "PropertyQualifier", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPropertyQualifier_Value(), this.getText(), "value", null, 1, 1, PropertyQualifier.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPropertyQualifier_PropertyQualifierId(), this.getPropertyQualifierId(),
				"propertyQualifierId", null, 1, 1, PropertyQualifier.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(sourceEClass, Source.class, "Source", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSource_Value(), theBuiltinsPackage.getLocalId(), "value", null, 0, 1, Source.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSource_Role(), theBuiltinsPackage.getTsCaseIgnoreIA5String(), "role", null, 0, 1,
				Source.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getSource_SubRef(), theBuiltinsPackage.getTsCaseIgnoreIA5String(), "subRef", null, 0, 1,
				Source.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(versionableEClass, Versionable.class, "Versionable", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getVersionable_Deprecated(), theBuiltinsPackage.getTsBooleanObject(), "deprecated", null, 0, 1,
				Versionable.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getVersionable_FirstRelease(), theBuiltinsPackage.getTsBooleanObject(), "firstRelease", null, 0,
				1, Versionable.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getVersionable_ModifiedInRelease(), theBuiltinsPackage.getTsBooleanObject(),
				"modifiedInRelease", null, 0, 1, Versionable.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(versionableAndDescribableEClass, VersionableAndDescribable.class, "VersionableAndDescribable",
				!IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getVersionableAndDescribable_EntityDescription(), this.getEntityDescription(),
				"entityDescription", null, 0, 1, VersionableAndDescribable.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(versionReferenceEClass, VersionReference.class, "VersionReference", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getVersionReference_Version(), this.getVersion(), "version", null, 1, 1, VersionReference.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize data types
		initEDataType(conceptCodeEDataType, String.class, "ConceptCode", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
		initEDataType(contextEDataType, String.class, "Context", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
		initEDataType(dcEDataType, String.class, "Dc", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
		initEDataType(defaultCodingSchemeEDataType, String.class, "DefaultCodingScheme", IS_SERIALIZABLE,
				!IS_GENERATED_INSTANCE_CLASS);
		initEDataType(defaultLanguageEDataType, String.class, "DefaultLanguage", IS_SERIALIZABLE,
				!IS_GENERATED_INSTANCE_CLASS);
		initEDataType(entityDescriptionEDataType, String.class, "EntityDescription", IS_SERIALIZABLE,
				!IS_GENERATED_INSTANCE_CLASS);
		initEDataType(entryOrderEDataType, int.class, "EntryOrder", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
		initEDataType(idEDataType, String.class, "Id", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
		initEDataType(languageEDataType, String.class, "Language", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
		initEDataType(propertyIdEDataType, String.class, "PropertyId", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
		initEDataType(propertyQualifierIdEDataType, String.class, "PropertyQualifierId", IS_SERIALIZABLE,
				!IS_GENERATED_INSTANCE_CLASS);
		initEDataType(registeredNameEDataType, String.class, "RegisteredName", IS_SERIALIZABLE,
				!IS_GENERATED_INSTANCE_CLASS);
		initEDataType(textEDataType, String.class, "Text", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
		initEDataType(versionEDataType, String.class, "Version", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http:///org/eclipse/emf/ecore/util/ExtendedMetaData
		createExtendedMetaDataAnnotations();
		// null
		createNullAnnotations();
	}

	/**
	 * Initializes the annotations for <b>null</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createNullAnnotations() {
		String source = null;
		addAnnotation(
				conceptCodeEDataType,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.6.6</ldap:oid>\r\n\t\t\t" });
		addAnnotation(
				dcEDataType,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">0.9.2342.19200300.100.1.25</ldap:oid>\r\n\t\t\t" });
		addAnnotation(
				defaultCodingSchemeEDataType,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.6.39</ldap:oid>\r\n\t\t\t" });
		addAnnotation(
				defaultLanguageEDataType,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.6.11</ldap:oid>\r\n\t\t\t" });
		addAnnotation(
				describableEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.5.1.4.1.2114.108.1.7.1</ldap:oid>\r\n\t\t\t" });
		addAnnotation(
				entityDescriptionEDataType,
				source,
				new String[] {
						"appinfo",
						"\r\n                                <ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.6.21</ldap:oid>\r\n                        " });
		addAnnotation(
				entryOrderEDataType,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.6.27</ldap:oid>\r\n\t\t\t" });
		addAnnotation(
				idEDataType,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.6.102</ldap:oid>\r\n\t\t\t" });
		addAnnotation(
				languageEDataType,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.6.10</ldap:oid>\r\n\t\t\t" });
		addAnnotation(
				propertyEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.7.24</ldap:oid>\r\n\t\t\t\t<ldap:rdn xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">propertyId</ldap:rdn>\r\n\t\t\t" });
		addAnnotation(
				propertyIdEDataType,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.6.90</ldap:oid>\r\n\t\t\t" });
		addAnnotation(
				registeredNameEDataType,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.6.5</ldap:oid>\r\n\t\t\t" });
		addAnnotation(
				sourceEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.6.8</ldap:oid>\r\n\t\t\t" });
		addAnnotation(
				textEDataType,
				source,
				new String[] {
						"appinfo",
						"\r\n                                <ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.6.20</ldap:oid>\r\n                        " });
		addAnnotation(
				versionEDataType,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.6.52</ldap:oid>\r\n\t\t\t" });
		addAnnotation(
				versionableEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.5.1.4.1.2114.108.1.7.2</ldap:oid>\r\n\t\t\t" });
		addAnnotation(
				versionableAndDescribableEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.5.1.4.1.2114.108.1.7.26</ldap:oid>\r\n\t\t\t" });
	}

	/**
	 * Initializes the annotations for <b>http:///org/eclipse/emf/ecore/util/ExtendedMetaData</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createExtendedMetaDataAnnotations() {
		String source = "http:///org/eclipse/emf/ecore/util/ExtendedMetaData";
		addAnnotation(codedContextEClass, source, new String[] { "name", "codedContext", "kind", "simple" });
		addAnnotation(getCodedContext_Value(), source, new String[] { "name", ":0", "kind", "simple" });
		addAnnotation(getCodedContext_CodingScheme(), source, new String[] { "kind", "attribute", "name",
				"codingScheme" });
		addAnnotation(getCodedContext_ConceptCode(), source,
				new String[] { "kind", "attribute", "name", "conceptCode" });
		addAnnotation(conceptCodeEDataType, source, new String[] { "name", "conceptCode", "baseType",
				"http://LexGrid.org/schema/2006/01/LexGrid/builtins#tsCaseIgnoreIA5String", "minLength", "1" });
		addAnnotation(contextEDataType, source, new String[] { "name", "context", "baseType",
				"http://LexGrid.org/schema/2006/01/LexGrid/builtins#localId" });
		addAnnotation(dcEDataType, source, new String[] { "name", "dc", "baseType",
				"http://LexGrid.org/schema/2006/01/LexGrid/builtins#tsCaseIgnoreIA5String" });
		addAnnotation(defaultCodingSchemeEDataType, source, new String[] { "name", "defaultCodingScheme", "baseType",
				"http://LexGrid.org/schema/2006/01/LexGrid/builtins#localId" });
		addAnnotation(defaultLanguageEDataType, source, new String[] { "name", "defaultLanguage", "baseType",
				"language" });
		addAnnotation(describableEClass, source, new String[] { "name", "describable", "kind", "elementOnly" });
		addAnnotation(getDescribable_EntityDescription(), source, new String[] { "kind", "element", "name",
				"entityDescription", "namespace", "##targetNamespace" });
		addAnnotation(entityDescriptionEDataType, source, new String[] { "name", "entityDescription", "baseType",
				"http://www.eclipse.org/emf/2003/XMLType#string" });
		addAnnotation(entryOrderEDataType, source, new String[] { "name", "entryOrder", "baseType",
				"http://LexGrid.org/schema/2006/01/LexGrid/builtins#tsInteger" });
		addAnnotation(idEDataType, source, new String[] { "name", "id", "baseType",
				"http://LexGrid.org/schema/2006/01/LexGrid/builtins#tsCaseIgnoreIA5String" });
		addAnnotation(languageEDataType, source, new String[] { "name", "language", "baseType",
				"http://LexGrid.org/schema/2006/01/LexGrid/builtins#localId" });
		addAnnotation(propertiesEClass, source, new String[] { "name", "properties", "kind", "elementOnly" });
		addAnnotation(getProperties_Property(), source, new String[] { "kind", "element", "name", "property",
				"namespace", "##targetNamespace" });
		addAnnotation(getProperties_Dc(), source, new String[] { "kind", "attribute", "name", "dc" });
		addAnnotation(propertyEClass, source, new String[] { "name", "property", "kind", "elementOnly" });
		addAnnotation(getProperty_Source(), source, new String[] { "kind", "element", "name", "source", "namespace",
				"##targetNamespace" });
		addAnnotation(getProperty_UsageContext(), source, new String[] { "kind", "element", "name", "usageContext",
				"namespace", "##targetNamespace" });
		addAnnotation(getProperty_PropertyQualifier(), source, new String[] { "kind", "element", "name",
				"propertyQualifier", "namespace", "##targetNamespace" });
		addAnnotation(getProperty_Text(), source, new String[] { "kind", "element", "name", "text", "namespace",
				"##targetNamespace" });
		addAnnotation(getProperty_Language(), source, new String[] { "kind", "attribute", "name", "language" });
		addAnnotation(getProperty_PresentationFormat(), source, new String[] { "kind", "attribute", "name",
				"presentationFormat" });
		addAnnotation(getProperty_Property(), source, new String[] { "kind", "attribute", "name", "property" });
		addAnnotation(getProperty_PropertyId(), source, new String[] { "kind", "attribute", "name", "propertyId" });
		addAnnotation(propertyIdEDataType, source, new String[] { "name", "propertyId", "baseType",
				"http://LexGrid.org/schema/2006/01/LexGrid/builtins#tsCaseIgnoreIA5String" });
		addAnnotation(propertyQualifierEClass, source, new String[] { "name", "propertyQualifier", "kind", "mixed" });
		addAnnotation(getPropertyQualifier_Value(), source, new String[] { "kind", "elementWildcard", "wildcards",
				"##other", "name", ":1", "processing", "lax" });
		addAnnotation(getPropertyQualifier_PropertyQualifierId(), source, new String[] { "kind", "attribute", "name",
				"propertyQualifierId" });
		addAnnotation(propertyQualifierIdEDataType, source, new String[] { "name", "propertyQualifierId", "baseType",
				"http://LexGrid.org/schema/2006/01/LexGrid/builtins#localId" });
		addAnnotation(registeredNameEDataType, source, new String[] { "name", "registeredName", "baseType",
				"http://LexGrid.org/schema/2006/01/LexGrid/builtins#tsURN" });
		addAnnotation(sourceEClass, source, new String[] { "name", "source", "kind", "simple" });
		addAnnotation(getSource_Value(), source, new String[] { "name", ":0", "kind", "simple" });
		addAnnotation(getSource_Role(), source, new String[] { "kind", "attribute", "name", "role" });
		addAnnotation(getSource_SubRef(), source, new String[] { "kind", "attribute", "name", "subRef" });
		addAnnotation(textEDataType, source, new String[] { "name", "text", "baseType",
				"http://www.eclipse.org/emf/2003/XMLType#string" });
		addAnnotation(versionEDataType, source, new String[] { "name", "version", "baseType",
				"http://LexGrid.org/schema/2006/01/LexGrid/builtins#tsCaseIgnoreIA5String", "minLength", "1" });
		addAnnotation(versionableEClass, source, new String[] { "name", "versionable", "kind", "empty" });
		addAnnotation(getVersionable_Deprecated(), source, new String[] { "kind", "attribute", "name", "deprecated" });
		addAnnotation(getVersionable_FirstRelease(), source,
				new String[] { "kind", "attribute", "name", "firstRelease" });
		addAnnotation(getVersionable_ModifiedInRelease(), source, new String[] { "kind", "attribute", "name",
				"modifiedInRelease" });
		addAnnotation(versionableAndDescribableEClass, source, new String[] { "name", "versionableAndDescribable",
				"kind", "elementOnly" });
		addAnnotation(getVersionableAndDescribable_EntityDescription(), source, new String[] { "kind", "element",
				"name", "entityDescription", "namespace", "##targetNamespace" });
		addAnnotation(versionReferenceEClass, source, new String[] { "name", "versionReference", "kind", "simple" });
		addAnnotation(getVersionReference_Version(), source, new String[] { "kind", "attribute", "name", "version" });
	}

	////////////////////////////////////////////////////////////
	// ************** BEGIN NON-GENERATED CODE ************** //
	//                                                        //
	// ****************************************************** //
	////////////////////////////////////////////////////////////
	/**
	 * Override superclass to create a LexGrid-aware attribute.
	 * @non-generated
	 */
	protected void createEAttribute(EClass owner, int id) {
		LgAttributeImpl eAttribute = new LgAttributeImpl();
		eAttribute.setFeatureID(id);
		owner.getEStructuralFeatures().add(eAttribute);
	}

	/**
	 * Override superclass to create a LexGrid-aware reference.
	 * @non-generated
	 */
	protected void createEReference(EClass owner, int id) {
		LgReferenceImpl eReference = new LgReferenceImpl();
		eReference.setFeatureID(id);
		owner.getEStructuralFeatures().add(eReference);
	}

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * @non-generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		initializePackageContentsGen();

		((LgAttributeImpl) getDescribable_EntityDescription()).setValueMaxLength(2048);
		((LgAttributeImpl) getDescribable_EntityDescription()).setMultiLine(true);
		((LgAttributeImpl) getProperties_Dc()).setID(true);
		((LgAttributeImpl) getProperties_Dc()).setDefaultValueLiteral("properties");
		((LgAttributeImpl) getProperty_PropertyId()).setID(true);
		((LgAttributeImpl) getProperty_Text()).setValueMaxLength(2048);
		((LgAttributeImpl) getProperty_Text()).setMultiLine(true);
		((LgAttributeImpl) getPropertyQualifier_PropertyQualifierId()).setID(true);
		((LgAttributeImpl) getVersionableAndDescribable_EntityDescription()).setValueMaxLength(2048);
		((LgAttributeImpl) getVersionableAndDescribable_EntityDescription()).setMultiLine(true);

		// Ensures order of output in XML ...
		String source = "http:///org/eclipse/emf/mapping/xsd2ecore/XSD2Ecore";
		addAnnotation(propertyEClass, source, new String[] { "feature-order",
				"source usageContext propertyQualifier text" });
	}
	////////////////////////////////////////////////////////////
	// *************** END NON-GENERATED CODE *************** //
	////////////////////////////////////////////////////////////

} //CommontypesPackageImpl