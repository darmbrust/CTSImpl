/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.LexGrid.emf.commonTypes.impl;

import java.util.List;

import org.LexGrid.emf.base.impl.LgModelObjImpl;
import org.LexGrid.emf.commonTypes.CommontypesPackage;
import org.LexGrid.emf.commonTypes.Property;
import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Property</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.LexGrid.emf.commonTypes.impl.PropertyImpl#getSource <em>Source</em>}</li>
 *   <li>{@link org.LexGrid.emf.commonTypes.impl.PropertyImpl#getUsageContext <em>Usage Context</em>}</li>
 *   <li>{@link org.LexGrid.emf.commonTypes.impl.PropertyImpl#getPropertyQualifier <em>Property Qualifier</em>}</li>
 *   <li>{@link org.LexGrid.emf.commonTypes.impl.PropertyImpl#getText <em>Text</em>}</li>
 *   <li>{@link org.LexGrid.emf.commonTypes.impl.PropertyImpl#getLanguage <em>Language</em>}</li>
 *   <li>{@link org.LexGrid.emf.commonTypes.impl.PropertyImpl#getPresentationFormat <em>Presentation Format</em>}</li>
 *   <li>{@link org.LexGrid.emf.commonTypes.impl.PropertyImpl#getProperty <em>Property</em>}</li>
 *   <li>{@link org.LexGrid.emf.commonTypes.impl.PropertyImpl#getPropertyId <em>Property Id</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class PropertyImpl extends LgModelObjImpl implements Property {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PropertyImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return CommontypesPackage.Literals.PROPERTY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getSource() {
		return (List) eGet(CommontypesPackage.Literals.PROPERTY__SOURCE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getUsageContext() {
		return (List) eGet(CommontypesPackage.Literals.PROPERTY__USAGE_CONTEXT, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getPropertyQualifier() {
		return (List) eGet(CommontypesPackage.Literals.PROPERTY__PROPERTY_QUALIFIER, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getText() {
		return (String) eGet(CommontypesPackage.Literals.PROPERTY__TEXT, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setText(String newText) {
		eSet(CommontypesPackage.Literals.PROPERTY__TEXT, newText);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLanguage() {
		return (String) eGet(CommontypesPackage.Literals.PROPERTY__LANGUAGE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLanguage(String newLanguage) {
		eSet(CommontypesPackage.Literals.PROPERTY__LANGUAGE, newLanguage);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPresentationFormat() {
		return (String) eGet(CommontypesPackage.Literals.PROPERTY__PRESENTATION_FORMAT, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPresentationFormat(String newPresentationFormat) {
		eSet(CommontypesPackage.Literals.PROPERTY__PRESENTATION_FORMAT, newPresentationFormat);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getProperty() {
		return (String) eGet(CommontypesPackage.Literals.PROPERTY__PROPERTY, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProperty(String newProperty) {
		eSet(CommontypesPackage.Literals.PROPERTY__PROPERTY, newProperty);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPropertyId() {
		return (String) eGet(CommontypesPackage.Literals.PROPERTY__PROPERTY_ID, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPropertyId(String newPropertyId) {
		eSet(CommontypesPackage.Literals.PROPERTY__PROPERTY_ID, newPropertyId);
	}

	////////////////////////////////////////////////////////////
	// ************** BEGIN NON-GENERATED CODE ************** //
	//                                                        //
	// ****************************************************** //
	////////////////////////////////////////////////////////////

	/**
	 * @see org.LexGrid.emf.base.impl.LgModelObjImpl#getDisplayName()
	 * @non-generated
	 */
	public String getPreferredDisplayName() {
		String displayText = null;
		String text = getText();
		String prop = getProperty();

		int textLen = text == null ? 0 : text.length();
		int propLen = prop == null ? 0 : prop.length();

		if (textLen > 0 || propLen > 0) {
			StringBuffer sb = new StringBuffer(128);
			if (propLen > 0)
				sb.append(prop).append(": ");
			if (textLen > 0)
				sb.append(text.length() > 64 ? text.substring(0, 65) + "..." : text);
			displayText = sb.toString();
			displayText = displayText.replace('\n', ' ');
			displayText = displayText.replace('\r', ' ');
		}
		return displayText == null ? super.getPreferredDisplayName() : displayText;
	}

} //PropertyImpl