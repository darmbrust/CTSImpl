/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.LexGrid.emf.commonTypes;

import org.LexGrid.emf.base.LgModelObj;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Source</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A local source identifier.
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.LexGrid.emf.commonTypes.Source#getValue <em>Value</em>}</li>
 *   <li>{@link org.LexGrid.emf.commonTypes.Source#getRole <em>Role</em>}</li>
 *   <li>{@link org.LexGrid.emf.commonTypes.Source#getSubRef <em>Sub Ref</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.LexGrid.emf.commonTypes.CommontypesPackage#getSource()
 * @model extendedMetaData="name='source' kind='simple'"
 * @extends LgModelObj
 * @generated
 */
public interface Source extends LgModelObj {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Returns the value of the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Value</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Value</em>' attribute.
	 * @see #setValue(String)
	 * @see org.LexGrid.emf.commonTypes.CommontypesPackage#getSource_Value()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.LocalId"
	 *        extendedMetaData="name=':0' kind='simple'"
	 * @generated
	 */
	String getValue();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.commonTypes.Source#getValue <em>Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Value</em>' attribute.
	 * @see #getValue()
	 * @generated
	 */
	void setValue(String value);

	/**
	 * Returns the value of the '<em><b>Role</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Optional identifies the purpose and contribution of this source (e.g. author, distributor).
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Role</em>' attribute.
	 * @see #setRole(String)
	 * @see org.LexGrid.emf.commonTypes.CommontypesPackage#getSource_Role()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.TsCaseIgnoreIA5String"
	 *        extendedMetaData="kind='attribute' name='role'"
	 * @generated
	 */
	String getRole();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.commonTypes.Source#getRole <em>Role</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Role</em>' attribute.
	 * @see #getRole()
	 * @generated
	 */
	void setRole(String value);

	/**
	 * Returns the value of the '<em><b>Sub Ref</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The page, subheading, id or other localized information within the source itself. 
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Sub Ref</em>' attribute.
	 * @see #setSubRef(String)
	 * @see org.LexGrid.emf.commonTypes.CommontypesPackage#getSource_SubRef()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.TsCaseIgnoreIA5String"
	 *        extendedMetaData="kind='attribute' name='subRef'"
	 * @generated
	 */
	String getSubRef();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.commonTypes.Source#getSubRef <em>Sub Ref</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sub Ref</em>' attribute.
	 * @see #getSubRef()
	 * @generated
	 */
	void setSubRef(String value);

} // Source