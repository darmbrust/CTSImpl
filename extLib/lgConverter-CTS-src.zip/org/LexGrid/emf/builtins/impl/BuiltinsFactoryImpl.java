/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.builtins.impl;

import java.util.Date;

import org.LexGrid.emf.builtins.BuiltinsFactory;
import org.LexGrid.emf.builtins.BuiltinsPackage;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EFactoryImpl;
import org.eclipse.emf.ecore.plugin.EcorePlugin;
import org.eclipse.emf.ecore.xml.type.XMLTypeFactory;
import org.eclipse.emf.ecore.xml.type.XMLTypePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class BuiltinsFactoryImpl extends EFactoryImpl implements BuiltinsFactory {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static BuiltinsFactory init() {
		try {
			BuiltinsFactory theBuiltinsFactory = (BuiltinsFactory) EPackage.Registry.INSTANCE
					.getEFactory("http://LexGrid.org/schema/2006/01/LexGrid/builtins");
			if (theBuiltinsFactory != null) {
				return theBuiltinsFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new BuiltinsFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BuiltinsFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
		case BuiltinsPackage.LOCAL_ID:
			return createLocalIdFromString(eDataType, initialValue);
		case BuiltinsPackage.NUMERIC_OID:
			return createNumericOIDFromString(eDataType, initialValue);
		case BuiltinsPackage.TS_BOOLEAN:
			return createTsBooleanFromString(eDataType, initialValue);
		case BuiltinsPackage.TS_BOOLEAN_OBJECT:
			return createTsBooleanObjectFromString(eDataType, initialValue);
		case BuiltinsPackage.TS_CASE_IGNORE_DIRECTORY_STRING:
			return createTsCaseIgnoreDirectoryStringFromString(eDataType, initialValue);
		case BuiltinsPackage.TS_CASE_IGNORE_IA5_STRING:
			return createTsCaseIgnoreIA5StringFromString(eDataType, initialValue);
		case BuiltinsPackage.TS_CASE_SENSITIVE_DIRECTORY_STRING:
			return createTsCaseSensitiveDirectoryStringFromString(eDataType, initialValue);
		case BuiltinsPackage.TS_CASE_SENSITIVE_IA5_STRING:
			return createTsCaseSensitiveIA5StringFromString(eDataType, initialValue);
		case BuiltinsPackage.TS_INTEGER:
			return createTsIntegerFromString(eDataType, initialValue);
		case BuiltinsPackage.TS_TIMESTAMP:
			return createTsTimestampFromString(eDataType, initialValue);
		case BuiltinsPackage.TS_URN:
			return createTsURNFromString(eDataType, initialValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
		case BuiltinsPackage.LOCAL_ID:
			return convertLocalIdToString(eDataType, instanceValue);
		case BuiltinsPackage.NUMERIC_OID:
			return convertNumericOIDToString(eDataType, instanceValue);
		case BuiltinsPackage.TS_BOOLEAN:
			return convertTsBooleanToString(eDataType, instanceValue);
		case BuiltinsPackage.TS_BOOLEAN_OBJECT:
			return convertTsBooleanObjectToString(eDataType, instanceValue);
		case BuiltinsPackage.TS_CASE_IGNORE_DIRECTORY_STRING:
			return convertTsCaseIgnoreDirectoryStringToString(eDataType, instanceValue);
		case BuiltinsPackage.TS_CASE_IGNORE_IA5_STRING:
			return convertTsCaseIgnoreIA5StringToString(eDataType, instanceValue);
		case BuiltinsPackage.TS_CASE_SENSITIVE_DIRECTORY_STRING:
			return convertTsCaseSensitiveDirectoryStringToString(eDataType, instanceValue);
		case BuiltinsPackage.TS_CASE_SENSITIVE_IA5_STRING:
			return convertTsCaseSensitiveIA5StringToString(eDataType, instanceValue);
		case BuiltinsPackage.TS_INTEGER:
			return convertTsIntegerToString(eDataType, instanceValue);
		case BuiltinsPackage.TS_TIMESTAMP:
			return convertTsTimestampToString(eDataType, instanceValue);
		case BuiltinsPackage.TS_URN:
			return convertTsURNToString(eDataType, instanceValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createLocalIdFromString(EDataType eDataType, String initialValue) {
		return (String) XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.Literals.TOKEN, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertLocalIdToString(EDataType eDataType, Object instanceValue) {
		return XMLTypeFactory.eINSTANCE.convertToString(XMLTypePackage.Literals.TOKEN, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createTsCaseIgnoreIA5StringFromString(EDataType eDataType, String initialValue) {
		return (String) XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.Literals.STRING, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTsCaseIgnoreIA5StringToString(EDataType eDataType, Object instanceValue) {
		return XMLTypeFactory.eINSTANCE.convertToString(XMLTypePackage.Literals.STRING, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createTsURNFromString(EDataType eDataType, String initialValue) {
		return (String) XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.Literals.ANY_URI, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTsURNToString(EDataType eDataType, Object instanceValue) {
		return XMLTypeFactory.eINSTANCE.convertToString(XMLTypePackage.Literals.ANY_URI, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createTsCaseIgnoreDirectoryStringFromString(EDataType eDataType, String initialValue) {
		return (String) XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.Literals.STRING, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTsCaseIgnoreDirectoryStringToString(EDataType eDataType, Object instanceValue) {
		return XMLTypeFactory.eINSTANCE.convertToString(XMLTypePackage.Literals.STRING, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean createTsBooleanFromString(EDataType eDataType, String initialValue) {
		return (Boolean) XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.Literals.BOOLEAN, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTsBooleanToString(EDataType eDataType, Object instanceValue) {
		return XMLTypeFactory.eINSTANCE.convertToString(XMLTypePackage.Literals.BOOLEAN, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTsBooleanObjectToString(EDataType eDataType, Object instanceValue) {
		return convertTsBooleanToString(BuiltinsPackage.Literals.TS_BOOLEAN, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Date createTsTimestampFromString(EDataType eDataType, String initialValue) {
		return (Date) XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.Literals.DATE_TIME, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTsTimestampToString(EDataType eDataType, Object instanceValue) {
		return XMLTypeFactory.eINSTANCE.convertToString(XMLTypePackage.Literals.DATE_TIME, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createTsCaseSensitiveDirectoryStringFromString(EDataType eDataType, String initialValue) {
		return (String) XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.Literals.STRING, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTsCaseSensitiveDirectoryStringToString(EDataType eDataType, Object instanceValue) {
		return XMLTypeFactory.eINSTANCE.convertToString(XMLTypePackage.Literals.STRING, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createTsCaseSensitiveIA5StringFromString(EDataType eDataType, String initialValue) {
		return (String) XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.Literals.STRING, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTsCaseSensitiveIA5StringToString(EDataType eDataType, Object instanceValue) {
		return XMLTypeFactory.eINSTANCE.convertToString(XMLTypePackage.Literals.STRING, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createNumericOIDFromString(EDataType eDataType, String initialValue) {
		return (String) XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.Literals.STRING, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertNumericOIDToString(EDataType eDataType, Object instanceValue) {
		return XMLTypeFactory.eINSTANCE.convertToString(XMLTypePackage.Literals.STRING, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BuiltinsPackage getBuiltinsPackage() {
		return (BuiltinsPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	public static BuiltinsPackage getPackage() {
		return BuiltinsPackage.eINSTANCE;
	}

	////////////////////////////////////////////////////////////
	// ************** BEGIN NON-GENERATED CODE ************** //
	//                                                        //
	// ****************************************************** //
	////////////////////////////////////////////////////////////
	/**
	 * Return an Integer representation for the given value.
	 * <p>
	 * Note: Generated method resulted in runtime exception.
	 * @non-generated
	 */
	public Integer createTsIntegerFromString(EDataType eDataType, String initialValue) {
		try {
			return Integer.valueOf(initialValue);
		} catch (Exception e) {
		}
		return new Integer(0);
	}

	/**
	 * Return an Integer representation for the given value.
	 * @non-generated
	 */
	public String convertTsIntegerToString(EDataType eDataType, Object instanceValue) {
		return (instanceValue instanceof Integer && instanceValue != null) ? instanceValue.toString() : "0";
	}

	/**
	 * Return a Boolean representation for the given value.
	 * @non-generated
	 */
	public Boolean createTsBooleanObjectFromString(EDataType eDataType, String initialValue) {
		String val = (initialValue == null || initialValue.trim().length() == 0) ? null : initialValue;
		return (Boolean) BuiltinsFactory.eINSTANCE.createFromString(BuiltinsPackage.eINSTANCE.getTsBoolean(), val);
	}

	/**
	 * Return a byte representation for the given value.
	 * @non-generated
	 */
	public byte[] createTsOctetStringFromString(EDataType eDataType, String initialValue) {
		return initialValue.getBytes();
	}

	/**
	 * Return a string representation for the given value.
	 * @non-generated
	 */
	public String convertTsOctetStringToString(EDataType eDataType, Object instanceValue) {
		if (instanceValue instanceof byte[])
			return String.valueOf(instanceValue);
		throw new UnsupportedOperationException("Conversion not successful for TsOctetString value: " + instanceValue);
	}
	////////////////////////////////////////////////////////////
	// *************** END NON-GENERATED CODE *************** //
	////////////////////////////////////////////////////////////

} //BuiltinsFactoryImpl