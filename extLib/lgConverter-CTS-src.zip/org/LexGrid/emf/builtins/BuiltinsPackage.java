/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.builtins;

import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * <!-- begin-model-doc -->
 * 
 * 			<h2 xmlns="http://LexGrid.org/schema/2006/01/LexGrid/builtins">Core data types for the lexical grid.</h2>
 * 		
 * These types need to be mapped to the appropriate implementation specific data types. The mapping in this package represents the XML
 * 			Schema data types mapping
 * LDAP specific types for appinfo annotation
 * <!-- end-model-doc -->
 * @see org.LexGrid.emf.builtins.BuiltinsFactory
 * @model kind="package"
 * @generated
 */
public interface BuiltinsPackage extends EPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "builtins";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://LexGrid.org/schema/2006/01/LexGrid/builtins";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "lgBuiltin";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	BuiltinsPackage eINSTANCE = org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl.init();

	/**
	 * The meta object id for the '<em>Local Id</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl#getLocalId()
	 * @generated
	 */
	int LOCAL_ID = 0;

	/**
	 * The meta object id for the '<em>Ts Case Ignore IA5 String</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl#getTsCaseIgnoreIA5String()
	 * @generated
	 */
	int TS_CASE_IGNORE_IA5_STRING = 5;

	/**
	 * The meta object id for the '<em>Ts URN</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl#getTsURN()
	 * @generated
	 */
	int TS_URN = 10;

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>Local Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Local Id</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 *        extendedMetaData="name='localId' baseType='http://www.eclipse.org/emf/2003/XMLType#token'" 
	 * @generated
	 */
	EDataType getLocalId();

	/**
	 * The meta object id for the '<em>Ts Boolean</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl#getTsBoolean()
	 * @generated
	 */
	int TS_BOOLEAN = 2;

	/**
	 * The meta object id for the '<em>Ts Boolean Object</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.Boolean
	 * @see org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl#getTsBooleanObject()
	 * @generated
	 */
	int TS_BOOLEAN_OBJECT = 3;

	/**
	 * The meta object id for the '<em>Ts Integer</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl#getTsInteger()
	 * @generated
	 */
	int TS_INTEGER = 8;

	/**
	 * The meta object id for the '<em>Ts Case Ignore Directory String</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl#getTsCaseIgnoreDirectoryString()
	 * @generated
	 */
	int TS_CASE_IGNORE_DIRECTORY_STRING = 4;

	/**
	 * The meta object id for the '<em>Ts Timestamp</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.util.Date
	 * @see org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl#getTsTimestamp()
	 * @generated
	 */
	int TS_TIMESTAMP = 9;

	/**
	 * The meta object id for the '<em>Ts Case Sensitive Directory String</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl#getTsCaseSensitiveDirectoryString()
	 * @generated
	 */
	int TS_CASE_SENSITIVE_DIRECTORY_STRING = 6;

	/**
	 * The meta object id for the '<em>Ts Case Sensitive IA5 String</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl#getTsCaseSensitiveIA5String()
	 * @generated
	 */
	int TS_CASE_SENSITIVE_IA5_STRING = 7;

	/**
	 * The meta object id for the '<em>Numeric OID</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl#getNumericOID()
	 * @generated
	 */
	int NUMERIC_OID = 1;

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>Ts Case Ignore IA5 String</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Ts Case Ignore IA5 String</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 *        extendedMetaData="name='tsCaseIgnoreIA5String' baseType='http://www.eclipse.org/emf/2003/XMLType#string'" 
	 * @generated
	 */
	EDataType getTsCaseIgnoreIA5String();

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>Ts URN</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Ts URN</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 *        extendedMetaData="name='tsURN' baseType='http://www.eclipse.org/emf/2003/XMLType#anyURI'" 
	 * @generated
	 */
	EDataType getTsURN();

	/**
	 * Returns the meta object for data type '<em>Ts Boolean</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Ts Boolean</em>'.
	 * @model instanceClass="boolean"
	 *        extendedMetaData="name='tsBoolean' baseType='http://www.eclipse.org/emf/2003/XMLType#boolean'" 
	 * @generated
	 */
	EDataType getTsBoolean();

	/**
	 * Returns the meta object for data type '{@link java.lang.Boolean <em>Ts Boolean Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Ts Boolean Object</em>'.
	 * @see java.lang.Boolean
	 * @model instanceClass="java.lang.Boolean"
	 *        extendedMetaData="name='tsBoolean:Object' baseType='tsBoolean'" 
	 * @generated
	 */
	EDataType getTsBooleanObject();

	/**
	 * Returns the meta object for data type '<em>Ts Integer</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Ts Integer</em>'.
	 * @model instanceClass="int"
	 *        extendedMetaData="name='tsInteger' baseType='http://www.eclipse.org/emf/2003/XMLType#integer'" 
	 * @generated
	 */
	EDataType getTsInteger();

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>Ts Case Ignore Directory String</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Ts Case Ignore Directory String</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 *        extendedMetaData="name='tsCaseIgnoreDirectoryString' baseType='http://www.eclipse.org/emf/2003/XMLType#string'" 
	 * @generated
	 */
	EDataType getTsCaseIgnoreDirectoryString();

	/**
	 * Returns the meta object for data type '{@link java.util.Date <em>Ts Timestamp</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Ts Timestamp</em>'.
	 * @see java.util.Date
	 * @model instanceClass="java.util.Date"
	 *        extendedMetaData="name='tsTimestamp' baseType='http://www.eclipse.org/emf/2003/XMLType#dateTime'" 
	 * @generated
	 */
	EDataType getTsTimestamp();

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>Ts Case Sensitive Directory String</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Ts Case Sensitive Directory String</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 *        extendedMetaData="name='tsCaseSensitiveDirectoryString' baseType='http://www.eclipse.org/emf/2003/XMLType#string'" 
	 * @generated
	 */
	EDataType getTsCaseSensitiveDirectoryString();

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>Ts Case Sensitive IA5 String</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Ts Case Sensitive IA5 String</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 *        extendedMetaData="name='tsCaseSensitiveIA5String' baseType='http://www.eclipse.org/emf/2003/XMLType#string'" 
	 * @generated
	 */
	EDataType getTsCaseSensitiveIA5String();

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>Numeric OID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Numeric OID</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 *        extendedMetaData="name='NumericOID' baseType='http://www.eclipse.org/emf/2003/XMLType#string' pattern='[0-2]\\.[0-9]+(\\.[0-9]+)*'" 
	 * @generated
	 */
	EDataType getNumericOID();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	BuiltinsFactory getBuiltinsFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '<em>Local Id</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl#getLocalId()
		 * @generated
		 */
		EDataType LOCAL_ID = eINSTANCE.getLocalId();

		/**
		 * The meta object literal for the '<em>Numeric OID</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl#getNumericOID()
		 * @generated
		 */
		EDataType NUMERIC_OID = eINSTANCE.getNumericOID();

		/**
		 * The meta object literal for the '<em>Ts Boolean</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl#getTsBoolean()
		 * @generated
		 */
		EDataType TS_BOOLEAN = eINSTANCE.getTsBoolean();

		/**
		 * The meta object literal for the '<em>Ts Boolean Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.Boolean
		 * @see org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl#getTsBooleanObject()
		 * @generated
		 */
		EDataType TS_BOOLEAN_OBJECT = eINSTANCE.getTsBooleanObject();

		/**
		 * The meta object literal for the '<em>Ts Case Ignore Directory String</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl#getTsCaseIgnoreDirectoryString()
		 * @generated
		 */
		EDataType TS_CASE_IGNORE_DIRECTORY_STRING = eINSTANCE.getTsCaseIgnoreDirectoryString();

		/**
		 * The meta object literal for the '<em>Ts Case Ignore IA5 String</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl#getTsCaseIgnoreIA5String()
		 * @generated
		 */
		EDataType TS_CASE_IGNORE_IA5_STRING = eINSTANCE.getTsCaseIgnoreIA5String();

		/**
		 * The meta object literal for the '<em>Ts Case Sensitive Directory String</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl#getTsCaseSensitiveDirectoryString()
		 * @generated
		 */
		EDataType TS_CASE_SENSITIVE_DIRECTORY_STRING = eINSTANCE.getTsCaseSensitiveDirectoryString();

		/**
		 * The meta object literal for the '<em>Ts Case Sensitive IA5 String</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl#getTsCaseSensitiveIA5String()
		 * @generated
		 */
		EDataType TS_CASE_SENSITIVE_IA5_STRING = eINSTANCE.getTsCaseSensitiveIA5String();

		/**
		 * The meta object literal for the '<em>Ts Integer</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl#getTsInteger()
		 * @generated
		 */
		EDataType TS_INTEGER = eINSTANCE.getTsInteger();

		/**
		 * The meta object literal for the '<em>Ts Timestamp</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.util.Date
		 * @see org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl#getTsTimestamp()
		 * @generated
		 */
		EDataType TS_TIMESTAMP = eINSTANCE.getTsTimestamp();

		/**
		 * The meta object literal for the '<em>Ts URN</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl#getTsURN()
		 * @generated
		 */
		EDataType TS_URN = eINSTANCE.getTsURN();

	}

} //BuiltinsPackage