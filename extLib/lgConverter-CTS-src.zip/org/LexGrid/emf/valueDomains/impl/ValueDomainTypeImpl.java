/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.valueDomains.impl;

import java.util.List;

import org.LexGrid.emf.commonTypes.Properties;
import org.LexGrid.emf.commonTypes.impl.VersionableAndDescribableImpl;
import org.LexGrid.emf.valueDomains.Mappings;
import org.LexGrid.emf.valueDomains.ValueDomainType;
import org.LexGrid.emf.valueDomains.ValuedomainsPackage;
import org.LexGrid.emf.valueDomains.VdVersions;
import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Value Domain Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.ValueDomainTypeImpl#getSource <em>Source</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.ValueDomainTypeImpl#getMappings <em>Mappings</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.ValueDomainTypeImpl#getProperties <em>Properties</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.ValueDomainTypeImpl#getDomainConcept <em>Domain Concept</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.ValueDomainTypeImpl#getVersions <em>Versions</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.ValueDomainTypeImpl#getRepresentsRealmOrContext <em>Represents Realm Or Context</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.ValueDomainTypeImpl#getDefaultCodingScheme <em>Default Coding Scheme</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.ValueDomainTypeImpl#getDefaultLanguage <em>Default Language</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.ValueDomainTypeImpl#getRegisteredName <em>Registered Name</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.ValueDomainTypeImpl#getRepresentsValueDomainVersion <em>Represents Value Domain Version</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.ValueDomainTypeImpl#getValueDomain <em>Value Domain</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ValueDomainTypeImpl extends VersionableAndDescribableImpl implements ValueDomainType {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ValueDomainTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return ValuedomainsPackage.Literals.VALUE_DOMAIN_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getSource() {
		return (List) eGet(ValuedomainsPackage.Literals.VALUE_DOMAIN_TYPE__SOURCE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Mappings getMappings() {
		return (Mappings) eGet(ValuedomainsPackage.Literals.VALUE_DOMAIN_TYPE__MAPPINGS, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMappings(Mappings newMappings) {
		eSet(ValuedomainsPackage.Literals.VALUE_DOMAIN_TYPE__MAPPINGS, newMappings);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Properties getProperties() {
		return (Properties) eGet(ValuedomainsPackage.Literals.VALUE_DOMAIN_TYPE__PROPERTIES, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProperties(Properties newProperties) {
		eSet(ValuedomainsPackage.Literals.VALUE_DOMAIN_TYPE__PROPERTIES, newProperties);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getDomainConcept() {
		return (List) eGet(ValuedomainsPackage.Literals.VALUE_DOMAIN_TYPE__DOMAIN_CONCEPT, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VdVersions getVersions() {
		return (VdVersions) eGet(ValuedomainsPackage.Literals.VALUE_DOMAIN_TYPE__VERSIONS, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVersions(VdVersions newVersions) {
		eSet(ValuedomainsPackage.Literals.VALUE_DOMAIN_TYPE__VERSIONS, newVersions);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDefaultCodingScheme() {
		return (String) eGet(ValuedomainsPackage.Literals.VALUE_DOMAIN_TYPE__DEFAULT_CODING_SCHEME, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDefaultCodingScheme(String newDefaultCodingScheme) {
		eSet(ValuedomainsPackage.Literals.VALUE_DOMAIN_TYPE__DEFAULT_CODING_SCHEME, newDefaultCodingScheme);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDefaultLanguage() {
		return (String) eGet(ValuedomainsPackage.Literals.VALUE_DOMAIN_TYPE__DEFAULT_LANGUAGE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDefaultLanguage(String newDefaultLanguage) {
		eSet(ValuedomainsPackage.Literals.VALUE_DOMAIN_TYPE__DEFAULT_LANGUAGE, newDefaultLanguage);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getRegisteredName() {
		return (String) eGet(ValuedomainsPackage.Literals.VALUE_DOMAIN_TYPE__REGISTERED_NAME, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRegisteredName(String newRegisteredName) {
		eSet(ValuedomainsPackage.Literals.VALUE_DOMAIN_TYPE__REGISTERED_NAME, newRegisteredName);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getRepresentsValueDomainVersion() {
		return (String) eGet(ValuedomainsPackage.Literals.VALUE_DOMAIN_TYPE__REPRESENTS_VALUE_DOMAIN_VERSION, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRepresentsValueDomainVersion(String newRepresentsValueDomainVersion) {
		eSet(ValuedomainsPackage.Literals.VALUE_DOMAIN_TYPE__REPRESENTS_VALUE_DOMAIN_VERSION,
				newRepresentsValueDomainVersion);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getValueDomain() {
		return (String) eGet(ValuedomainsPackage.Literals.VALUE_DOMAIN_TYPE__VALUE_DOMAIN, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setValueDomain(String newValueDomain) {
		eSet(ValuedomainsPackage.Literals.VALUE_DOMAIN_TYPE__VALUE_DOMAIN, newValueDomain);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getRepresentsRealmOrContext() {
		return (List) eGet(ValuedomainsPackage.Literals.VALUE_DOMAIN_TYPE__REPRESENTS_REALM_OR_CONTEXT, true);
	}

	////////////////////////////////////////////////////////////
	// ************** BEGIN NON-GENERATED CODE ************** //
	//                                                        //
	// ****************************************************** //
	////////////////////////////////////////////////////////////

	/**
	 * @see org.LexGrid.emf.base.LgModelObj#getDisplayName()
	 * @non-generated
	 */
	public String getPreferredDisplayName() {
		String base = super.getPreferredDisplayName();
		StringBuffer sb = new StringBuffer(base);
		String text = getPreferredTextDescription();
		String version = getRepresentsValueDomainVersion();
		if (text != null && !text.equals(base))
			sb.append(": ").append(text);
		if (version != null && version.length() > 0)
			sb.append(" [").append(version).append("]");
		return sb.toString();
	}

} //ValueDomainTypeImpl