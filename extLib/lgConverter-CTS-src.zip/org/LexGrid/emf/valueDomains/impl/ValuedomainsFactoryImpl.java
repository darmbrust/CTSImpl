/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.valueDomains.impl;

import org.LexGrid.emf.valueDomains.DocumentRoot;
import org.LexGrid.emf.valueDomains.Mappings;
import org.LexGrid.emf.valueDomains.PickListEntry;
import org.LexGrid.emf.valueDomains.ValueDomainEntry;
import org.LexGrid.emf.valueDomains.ValueDomainType;
import org.LexGrid.emf.valueDomains.ValueDomainVersion;
import org.LexGrid.emf.valueDomains.ValueDomains;
import org.LexGrid.emf.valueDomains.ValuedomainsFactory;
import org.LexGrid.emf.valueDomains.ValuedomainsPackage;
import org.LexGrid.emf.valueDomains.VdVersions;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EFactoryImpl;
import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ValuedomainsFactoryImpl extends EFactoryImpl implements ValuedomainsFactory {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static ValuedomainsFactory init() {
		try {
			ValuedomainsFactory theValuedomainsFactory = (ValuedomainsFactory) EPackage.Registry.INSTANCE
					.getEFactory("http://LexGrid.org/schema/2006/01/LexGrid/valueDomains");
			if (theValuedomainsFactory != null) {
				return theValuedomainsFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new ValuedomainsFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ValuedomainsFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case ValuedomainsPackage.MAPPINGS:
			return (EObject) createMappings();
		case ValuedomainsPackage.PICK_LIST_ENTRY:
			return (EObject) createPickListEntry();
		case ValuedomainsPackage.VALUE_DOMAIN_ENTRY:
			return (EObject) createValueDomainEntry();
		case ValuedomainsPackage.VALUE_DOMAINS:
			return (EObject) createValueDomains();
		case ValuedomainsPackage.VALUE_DOMAIN_TYPE:
			return (EObject) createValueDomainType();
		case ValuedomainsPackage.VALUE_DOMAIN_VERSION:
			return (EObject) createValueDomainVersion();
		case ValuedomainsPackage.VD_VERSIONS:
			return (EObject) createVdVersions();
		case ValuedomainsPackage.DOCUMENT_ROOT:
			return (EObject) createDocumentRoot();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Mappings createMappings() {
		MappingsImpl mappings = new MappingsImpl();
		return mappings;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ValueDomainType createValueDomainType() {
		ValueDomainTypeImpl valueDomainType = new ValueDomainTypeImpl();
		return valueDomainType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ValueDomainEntry createValueDomainEntry() {
		ValueDomainEntryImpl valueDomainEntry = new ValueDomainEntryImpl();
		return valueDomainEntry;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ValueDomains createValueDomains() {
		ValueDomainsImpl valueDomains = new ValueDomainsImpl();
		return valueDomains;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PickListEntry createPickListEntry() {
		PickListEntryImpl pickListEntry = new PickListEntryImpl();
		return pickListEntry;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ValueDomainVersion createValueDomainVersion() {
		ValueDomainVersionImpl valueDomainVersion = new ValueDomainVersionImpl();
		return valueDomainVersion;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VdVersions createVdVersions() {
		VdVersionsImpl vdVersions = new VdVersionsImpl();
		return vdVersions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DocumentRoot createDocumentRoot() {
		DocumentRootImpl documentRoot = new DocumentRootImpl();
		return documentRoot;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ValuedomainsPackage getValuedomainsPackage() {
		return (ValuedomainsPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	public static ValuedomainsPackage getPackage() {
		return ValuedomainsPackage.eINSTANCE;
	}

} //ValuedomainsFactoryImpl