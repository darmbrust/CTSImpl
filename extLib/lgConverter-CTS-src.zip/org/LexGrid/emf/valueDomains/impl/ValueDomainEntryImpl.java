/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.valueDomains.impl;

import java.util.List;

import org.LexGrid.emf.commonTypes.impl.VersionableImpl;
import org.LexGrid.emf.valueDomains.ValueDomainEntry;
import org.LexGrid.emf.valueDomains.ValuedomainsPackage;
import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Value Domain Entry</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.ValueDomainEntryImpl#getPickListEntry <em>Pick List Entry</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.ValueDomainEntryImpl#getIncludesValueDomain <em>Includes Value Domain</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.ValueDomainEntryImpl#getProperty <em>Property</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.ValueDomainEntryImpl#getCodingScheme <em>Coding Scheme</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.ValueDomainEntryImpl#getConceptCode <em>Concept Code</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.ValueDomainEntryImpl#getEntryOrder <em>Entry Order</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.ValueDomainEntryImpl#getId <em>Id</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.ValueDomainEntryImpl#isIncludeChildren <em>Include Children</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.ValueDomainEntryImpl#isIsSelectable <em>Is Selectable</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.ValueDomainEntryImpl#isTestSubsumption <em>Test Subsumption</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ValueDomainEntryImpl extends VersionableImpl implements ValueDomainEntry {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ValueDomainEntryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return ValuedomainsPackage.Literals.VALUE_DOMAIN_ENTRY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getId() {
		return (String) eGet(ValuedomainsPackage.Literals.VALUE_DOMAIN_ENTRY__ID, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setId(String newId) {
		eSet(ValuedomainsPackage.Literals.VALUE_DOMAIN_ENTRY__ID, newId);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isIncludeChildren() {
		return ((Boolean) eGet(ValuedomainsPackage.Literals.VALUE_DOMAIN_ENTRY__INCLUDE_CHILDREN, true)).booleanValue();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIncludeChildren(boolean newIncludeChildren) {
		eSet(ValuedomainsPackage.Literals.VALUE_DOMAIN_ENTRY__INCLUDE_CHILDREN, new Boolean(newIncludeChildren));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetIncludeChildren() {
		eUnset(ValuedomainsPackage.Literals.VALUE_DOMAIN_ENTRY__INCLUDE_CHILDREN);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetIncludeChildren() {
		return eIsSet(ValuedomainsPackage.Literals.VALUE_DOMAIN_ENTRY__INCLUDE_CHILDREN);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCodingScheme() {
		return (String) eGet(ValuedomainsPackage.Literals.VALUE_DOMAIN_ENTRY__CODING_SCHEME, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCodingScheme(String newCodingScheme) {
		eSet(ValuedomainsPackage.Literals.VALUE_DOMAIN_ENTRY__CODING_SCHEME, newCodingScheme);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getConceptCode() {
		return (String) eGet(ValuedomainsPackage.Literals.VALUE_DOMAIN_ENTRY__CONCEPT_CODE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setConceptCode(String newConceptCode) {
		eSet(ValuedomainsPackage.Literals.VALUE_DOMAIN_ENTRY__CONCEPT_CODE, newConceptCode);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getEntryOrder() {
		return ((Integer) eGet(ValuedomainsPackage.Literals.VALUE_DOMAIN_ENTRY__ENTRY_ORDER, true)).intValue();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEntryOrder(int newEntryOrder) {
		eSet(ValuedomainsPackage.Literals.VALUE_DOMAIN_ENTRY__ENTRY_ORDER, new Integer(newEntryOrder));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getPickListEntry() {
		return (List) eGet(ValuedomainsPackage.Literals.VALUE_DOMAIN_ENTRY__PICK_LIST_ENTRY, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isIsSelectable() {
		return ((Boolean) eGet(ValuedomainsPackage.Literals.VALUE_DOMAIN_ENTRY__IS_SELECTABLE, true)).booleanValue();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsSelectable(boolean newIsSelectable) {
		eSet(ValuedomainsPackage.Literals.VALUE_DOMAIN_ENTRY__IS_SELECTABLE, new Boolean(newIsSelectable));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetIsSelectable() {
		eUnset(ValuedomainsPackage.Literals.VALUE_DOMAIN_ENTRY__IS_SELECTABLE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetIsSelectable() {
		return eIsSet(ValuedomainsPackage.Literals.VALUE_DOMAIN_ENTRY__IS_SELECTABLE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isTestSubsumption() {
		return ((Boolean) eGet(ValuedomainsPackage.Literals.VALUE_DOMAIN_ENTRY__TEST_SUBSUMPTION, true)).booleanValue();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTestSubsumption(boolean newTestSubsumption) {
		eSet(ValuedomainsPackage.Literals.VALUE_DOMAIN_ENTRY__TEST_SUBSUMPTION, new Boolean(newTestSubsumption));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetTestSubsumption() {
		eUnset(ValuedomainsPackage.Literals.VALUE_DOMAIN_ENTRY__TEST_SUBSUMPTION);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetTestSubsumption() {
		return eIsSet(ValuedomainsPackage.Literals.VALUE_DOMAIN_ENTRY__TEST_SUBSUMPTION);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getProperty() {
		return (List) eGet(ValuedomainsPackage.Literals.VALUE_DOMAIN_ENTRY__PROPERTY, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getIncludesValueDomain() {
		return (String) eGet(ValuedomainsPackage.Literals.VALUE_DOMAIN_ENTRY__INCLUDES_VALUE_DOMAIN, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIncludesValueDomain(String newIncludesValueDomain) {
		eSet(ValuedomainsPackage.Literals.VALUE_DOMAIN_ENTRY__INCLUDES_VALUE_DOMAIN, newIncludesValueDomain);
	}

	////////////////////////////////////////////////////////////
	// ************** BEGIN NON-GENERATED CODE ************** //
	//                                                        //
	// ****************************************************** //
	////////////////////////////////////////////////////////////

	/**
	 * @see org.LexGrid.emf.base.LgModelObj#getDisplayName()
	 * @non-generated
	 */
	public String getPreferredDisplayName() {
		String base = super.getPreferredDisplayName();
		String text = getPreferredTextDescription();
		if (text != null && !text.equals(base))
			return base + " (" + text + ')';
		return base;
	}

} //ValueDomainEntryImpl