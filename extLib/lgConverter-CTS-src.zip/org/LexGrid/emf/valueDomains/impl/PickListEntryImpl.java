/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.valueDomains.impl;

import java.util.List;

import org.LexGrid.emf.base.impl.LgModelObjImpl;
import org.LexGrid.emf.valueDomains.PickListEntry;
import org.LexGrid.emf.valueDomains.ValuedomainsPackage;
import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Pick List Entry</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.PickListEntryImpl#getPickText <em>Pick Text</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.PickListEntryImpl#getPickContext <em>Pick Context</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.PickListEntryImpl#getId <em>Id</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.PickListEntryImpl#getIsDefault <em>Is Default</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.PickListEntryImpl#getLanguage <em>Language</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.impl.PickListEntryImpl#getMatchIfNoContext <em>Match If No Context</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class PickListEntryImpl extends LgModelObjImpl implements PickListEntry {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PickListEntryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return ValuedomainsPackage.Literals.PICK_LIST_ENTRY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getId() {
		return (String) eGet(ValuedomainsPackage.Literals.PICK_LIST_ENTRY__ID, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setId(String newId) {
		eSet(ValuedomainsPackage.Literals.PICK_LIST_ENTRY__ID, newId);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean getIsDefault() {
		return (Boolean) eGet(ValuedomainsPackage.Literals.PICK_LIST_ENTRY__IS_DEFAULT, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsDefault(Boolean newIsDefault) {
		eSet(ValuedomainsPackage.Literals.PICK_LIST_ENTRY__IS_DEFAULT, newIsDefault);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetIsDefault() {
		eUnset(ValuedomainsPackage.Literals.PICK_LIST_ENTRY__IS_DEFAULT);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetIsDefault() {
		return eIsSet(ValuedomainsPackage.Literals.PICK_LIST_ENTRY__IS_DEFAULT);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetMatchIfNoContext() {
		eUnset(ValuedomainsPackage.Literals.PICK_LIST_ENTRY__MATCH_IF_NO_CONTEXT);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetMatchIfNoContext() {
		return eIsSet(ValuedomainsPackage.Literals.PICK_LIST_ENTRY__MATCH_IF_NO_CONTEXT);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLanguage() {
		return (String) eGet(ValuedomainsPackage.Literals.PICK_LIST_ENTRY__LANGUAGE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLanguage(String newLanguage) {
		eSet(ValuedomainsPackage.Literals.PICK_LIST_ENTRY__LANGUAGE, newLanguage);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean getMatchIfNoContext() {
		return (Boolean) eGet(ValuedomainsPackage.Literals.PICK_LIST_ENTRY__MATCH_IF_NO_CONTEXT, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMatchIfNoContext(Boolean newMatchIfNoContext) {
		eSet(ValuedomainsPackage.Literals.PICK_LIST_ENTRY__MATCH_IF_NO_CONTEXT, newMatchIfNoContext);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPickText() {
		return (String) eGet(ValuedomainsPackage.Literals.PICK_LIST_ENTRY__PICK_TEXT, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPickText(String newPickText) {
		eSet(ValuedomainsPackage.Literals.PICK_LIST_ENTRY__PICK_TEXT, newPickText);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getPickContext() {
		return (List) eGet(ValuedomainsPackage.Literals.PICK_LIST_ENTRY__PICK_CONTEXT, true);
	}

	////////////////////////////////////////////////////////////
	// ************** BEGIN NON-GENERATED CODE ************** //
	//                                                        //
	// ****************************************************** //
	////////////////////////////////////////////////////////////

	/**
	 * @see org.LexGrid.emf.base.LgModelObj#getDisplayName()
	 * @non-generated
	 */
	public String getPreferredDisplayName() {
		String base = super.getPreferredDisplayName();
		String text = getPreferredTextDescription();
		if (text != null && !text.equals(base)) {
			StringBuffer sb = new StringBuffer(base);
			sb.append(": ").append(text);
			return sb.toString();
		}
		return base;
	}

} //PickListEntryImpl