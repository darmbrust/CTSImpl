/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.valueDomains.impl;

import org.LexGrid.emf.base.impl.LgAttributeImpl;
import org.LexGrid.emf.base.impl.LgReferenceImpl;
import org.LexGrid.emf.builtins.BuiltinsPackage;
import org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl;
import org.LexGrid.emf.codingSchemes.CodingschemesPackage;
import org.LexGrid.emf.codingSchemes.impl.CodingschemesPackageImpl;
import org.LexGrid.emf.commonTypes.CommontypesPackage;
import org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl;
import org.LexGrid.emf.concepts.ConceptsPackage;
import org.LexGrid.emf.concepts.impl.ConceptsPackageImpl;
import org.LexGrid.emf.history.NCIHistoryPackage;
import org.LexGrid.emf.history.impl.NCIHistoryPackageImpl;
import org.LexGrid.emf.ldap.LdapPackage;
import org.LexGrid.emf.ldap.impl.LdapPackageImpl;
import org.LexGrid.emf.naming.NamingPackage;
import org.LexGrid.emf.naming.impl.NamingPackageImpl;
import org.LexGrid.emf.relations.RelationsPackage;
import org.LexGrid.emf.relations.impl.RelationsPackageImpl;
import org.LexGrid.emf.service.ServiceTypePackage;
import org.LexGrid.emf.service.impl.ServiceTypePackageImpl;
import org.LexGrid.emf.valueDomains.DocumentRoot;
import org.LexGrid.emf.valueDomains.Mappings;
import org.LexGrid.emf.valueDomains.PickListEntry;
import org.LexGrid.emf.valueDomains.ValueDomainEntry;
import org.LexGrid.emf.valueDomains.ValueDomainType;
import org.LexGrid.emf.valueDomains.ValueDomainVersion;
import org.LexGrid.emf.valueDomains.ValueDomains;
import org.LexGrid.emf.valueDomains.ValuedomainsFactory;
import org.LexGrid.emf.valueDomains.ValuedomainsPackage;
import org.LexGrid.emf.valueDomains.VdVersions;
import org.LexGrid.emf.versions.VersionsPackage;
import org.LexGrid.emf.versions.impl.VersionsPackageImpl;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.impl.EPackageImpl;
import org.eclipse.emf.ecore.xml.type.XMLTypePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ValuedomainsPackageImpl extends EPackageImpl implements ValuedomainsPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass mappingsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass valueDomainsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass valueDomainTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass valueDomainEntryEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass pickListEntryEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass valueDomainVersionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass vdVersionsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass documentRootEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private ValuedomainsPackageImpl() {
		super(eNS_URI, ValuedomainsFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this
	 * model, and for any others upon which it depends.  Simple
	 * dependencies are satisfied by calling this method on all
	 * dependent packages before doing anything else.  This method drives
	 * initialization for interdependent packages directly, in parallel
	 * with this package, itself.
	 * <p>Of this package and its interdependencies, all packages which
	 * have not yet been registered by their URI values are first created
	 * and registered.  The packages are then initialized in two steps:
	 * meta-model objects for all of the packages are created before any
	 * are initialized, since one package's meta-model objects may refer to
	 * those of another.
	 * <p>Invocation of this method will not affect any packages that have
	 * already been initialized.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static ValuedomainsPackage init() {
		if (isInited)
			return (ValuedomainsPackage) EPackage.Registry.INSTANCE.getEPackage(ValuedomainsPackage.eNS_URI);

		// Obtain or create and register package
		ValuedomainsPackageImpl theValuedomainsPackage = (ValuedomainsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(eNS_URI) instanceof ValuedomainsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(eNS_URI) : new ValuedomainsPackageImpl());

		isInited = true;

		// Initialize simple dependencies
		XMLTypePackage.eINSTANCE.eClass();

		// Obtain or create and register interdependencies
		ConceptsPackageImpl theConceptsPackage = (ConceptsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(ConceptsPackage.eNS_URI) instanceof ConceptsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(ConceptsPackage.eNS_URI) : ConceptsPackage.eINSTANCE);
		RelationsPackageImpl theRelationsPackage = (RelationsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(RelationsPackage.eNS_URI) instanceof RelationsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(RelationsPackage.eNS_URI) : RelationsPackage.eINSTANCE);
		NCIHistoryPackageImpl theNCIHistoryPackage = (NCIHistoryPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(NCIHistoryPackage.eNS_URI) instanceof NCIHistoryPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(NCIHistoryPackage.eNS_URI) : NCIHistoryPackage.eINSTANCE);
		VersionsPackageImpl theVersionsPackage = (VersionsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(VersionsPackage.eNS_URI) instanceof VersionsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(VersionsPackage.eNS_URI) : VersionsPackage.eINSTANCE);
		CodingschemesPackageImpl theCodingschemesPackage = (CodingschemesPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(CodingschemesPackage.eNS_URI) instanceof CodingschemesPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(CodingschemesPackage.eNS_URI)
				: CodingschemesPackage.eINSTANCE);
		LdapPackageImpl theLdapPackage = (LdapPackageImpl) (EPackage.Registry.INSTANCE.getEPackage(LdapPackage.eNS_URI) instanceof LdapPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(LdapPackage.eNS_URI)
				: LdapPackage.eINSTANCE);
		BuiltinsPackageImpl theBuiltinsPackage = (BuiltinsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(BuiltinsPackage.eNS_URI) instanceof BuiltinsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(BuiltinsPackage.eNS_URI) : BuiltinsPackage.eINSTANCE);
		CommontypesPackageImpl theCommontypesPackage = (CommontypesPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(CommontypesPackage.eNS_URI) instanceof CommontypesPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(CommontypesPackage.eNS_URI) : CommontypesPackage.eINSTANCE);
		ServiceTypePackageImpl theServiceTypePackage = (ServiceTypePackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(ServiceTypePackage.eNS_URI) instanceof ServiceTypePackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(ServiceTypePackage.eNS_URI) : ServiceTypePackage.eINSTANCE);
		NamingPackageImpl theNamingPackage = (NamingPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(NamingPackage.eNS_URI) instanceof NamingPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(NamingPackage.eNS_URI) : NamingPackage.eINSTANCE);

		// Create package meta-data objects
		theValuedomainsPackage.createPackageContents();
		theConceptsPackage.createPackageContents();
		theRelationsPackage.createPackageContents();
		theNCIHistoryPackage.createPackageContents();
		theVersionsPackage.createPackageContents();
		theCodingschemesPackage.createPackageContents();
		theLdapPackage.createPackageContents();
		theBuiltinsPackage.createPackageContents();
		theCommontypesPackage.createPackageContents();
		theServiceTypePackage.createPackageContents();
		theNamingPackage.createPackageContents();

		// Initialize created meta-data
		theValuedomainsPackage.initializePackageContents();
		theConceptsPackage.initializePackageContents();
		theRelationsPackage.initializePackageContents();
		theNCIHistoryPackage.initializePackageContents();
		theVersionsPackage.initializePackageContents();
		theCodingschemesPackage.initializePackageContents();
		theLdapPackage.initializePackageContents();
		theBuiltinsPackage.initializePackageContents();
		theCommontypesPackage.initializePackageContents();
		theServiceTypePackage.initializePackageContents();
		theNamingPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theValuedomainsPackage.freeze();

		return theValuedomainsPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMappings() {
		return mappingsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMappings_SupportedCodingScheme() {
		return (EReference) mappingsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMappings_SupportedSource() {
		return (EReference) mappingsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMappings_SupportedLanguage() {
		return (EReference) mappingsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMappings_SupportedContext() {
		return (EReference) mappingsEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMappings_Dc() {
		return (EAttribute) mappingsEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getValueDomains() {
		return valueDomainsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getValueDomainType() {
		return valueDomainTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getValueDomainType_Source() {
		return (EReference) valueDomainTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getValueDomainType_Mappings() {
		return (EReference) valueDomainTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getValueDomainType_Properties() {
		return (EReference) valueDomainTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getValueDomainType_DomainConcept() {
		return (EReference) valueDomainTypeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getValueDomainType_Versions() {
		return (EReference) valueDomainTypeEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getValueDomainType_DefaultCodingScheme() {
		return (EAttribute) valueDomainTypeEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getValueDomainType_DefaultLanguage() {
		return (EAttribute) valueDomainTypeEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getValueDomainType_RegisteredName() {
		return (EAttribute) valueDomainTypeEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getValueDomainType_RepresentsValueDomainVersion() {
		return (EAttribute) valueDomainTypeEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getValueDomainType_ValueDomain() {
		return (EAttribute) valueDomainTypeEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getValueDomainType_RepresentsRealmOrContext() {
		return (EAttribute) valueDomainTypeEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getValueDomains_Dc() {
		return (EAttribute) valueDomainsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getValueDomains_ValueDomain() {
		return (EReference) valueDomainsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getValueDomainEntry() {
		return valueDomainEntryEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getValueDomainEntry_Id() {
		return (EAttribute) valueDomainEntryEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getValueDomainEntry_IncludeChildren() {
		return (EAttribute) valueDomainEntryEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getValueDomainEntry_CodingScheme() {
		return (EAttribute) valueDomainEntryEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getValueDomainEntry_ConceptCode() {
		return (EAttribute) valueDomainEntryEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getValueDomainEntry_EntryOrder() {
		return (EAttribute) valueDomainEntryEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getValueDomainEntry_PickListEntry() {
		return (EReference) valueDomainEntryEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getValueDomainEntry_IsSelectable() {
		return (EAttribute) valueDomainEntryEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getValueDomainEntry_TestSubsumption() {
		return (EAttribute) valueDomainEntryEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getValueDomainEntry_Property() {
		return (EReference) valueDomainEntryEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getValueDomainEntry_IncludesValueDomain() {
		return (EAttribute) valueDomainEntryEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPickListEntry() {
		return pickListEntryEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPickListEntry_Id() {
		return (EAttribute) pickListEntryEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPickListEntry_IsDefault() {
		return (EAttribute) pickListEntryEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPickListEntry_MatchIfNoContext() {
		return (EAttribute) pickListEntryEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPickListEntry_Language() {
		return (EAttribute) pickListEntryEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPickListEntry_PickText() {
		return (EAttribute) pickListEntryEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPickListEntry_PickContext() {
		return (EReference) pickListEntryEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getValueDomainVersion() {
		return valueDomainVersionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getValueDomainVersion_DomainConcept() {
		return (EReference) valueDomainVersionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getVdVersions() {
		return vdVersionsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVdVersions_Version() {
		return (EReference) vdVersionsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVdVersions_Dc() {
		return (EAttribute) vdVersionsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDocumentRoot() {
		return documentRootEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDocumentRoot_Mixed() {
		return (EAttribute) documentRootEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_XMLNSPrefixMap() {
		return (EReference) documentRootEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_XSISchemaLocation() {
		return (EReference) documentRootEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_ValueDomain() {
		return (EReference) documentRootEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_ValueDomains() {
		return (EReference) documentRootEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ValuedomainsFactory getValuedomainsFactory() {
		return (ValuedomainsFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		mappingsEClass = createEClass(MAPPINGS);
		createEReference(mappingsEClass, MAPPINGS__SUPPORTED_CODING_SCHEME);
		createEReference(mappingsEClass, MAPPINGS__SUPPORTED_SOURCE);
		createEReference(mappingsEClass, MAPPINGS__SUPPORTED_LANGUAGE);
		createEReference(mappingsEClass, MAPPINGS__SUPPORTED_CONTEXT);
		createEAttribute(mappingsEClass, MAPPINGS__DC);

		pickListEntryEClass = createEClass(PICK_LIST_ENTRY);
		createEAttribute(pickListEntryEClass, PICK_LIST_ENTRY__PICK_TEXT);
		createEReference(pickListEntryEClass, PICK_LIST_ENTRY__PICK_CONTEXT);
		createEAttribute(pickListEntryEClass, PICK_LIST_ENTRY__ID);
		createEAttribute(pickListEntryEClass, PICK_LIST_ENTRY__IS_DEFAULT);
		createEAttribute(pickListEntryEClass, PICK_LIST_ENTRY__LANGUAGE);
		createEAttribute(pickListEntryEClass, PICK_LIST_ENTRY__MATCH_IF_NO_CONTEXT);

		valueDomainEntryEClass = createEClass(VALUE_DOMAIN_ENTRY);
		createEReference(valueDomainEntryEClass, VALUE_DOMAIN_ENTRY__PICK_LIST_ENTRY);
		createEAttribute(valueDomainEntryEClass, VALUE_DOMAIN_ENTRY__INCLUDES_VALUE_DOMAIN);
		createEReference(valueDomainEntryEClass, VALUE_DOMAIN_ENTRY__PROPERTY);
		createEAttribute(valueDomainEntryEClass, VALUE_DOMAIN_ENTRY__CODING_SCHEME);
		createEAttribute(valueDomainEntryEClass, VALUE_DOMAIN_ENTRY__CONCEPT_CODE);
		createEAttribute(valueDomainEntryEClass, VALUE_DOMAIN_ENTRY__ENTRY_ORDER);
		createEAttribute(valueDomainEntryEClass, VALUE_DOMAIN_ENTRY__ID);
		createEAttribute(valueDomainEntryEClass, VALUE_DOMAIN_ENTRY__INCLUDE_CHILDREN);
		createEAttribute(valueDomainEntryEClass, VALUE_DOMAIN_ENTRY__IS_SELECTABLE);
		createEAttribute(valueDomainEntryEClass, VALUE_DOMAIN_ENTRY__TEST_SUBSUMPTION);

		valueDomainsEClass = createEClass(VALUE_DOMAINS);
		createEReference(valueDomainsEClass, VALUE_DOMAINS__VALUE_DOMAIN);
		createEAttribute(valueDomainsEClass, VALUE_DOMAINS__DC);

		valueDomainTypeEClass = createEClass(VALUE_DOMAIN_TYPE);
		createEReference(valueDomainTypeEClass, VALUE_DOMAIN_TYPE__SOURCE);
		createEReference(valueDomainTypeEClass, VALUE_DOMAIN_TYPE__MAPPINGS);
		createEReference(valueDomainTypeEClass, VALUE_DOMAIN_TYPE__PROPERTIES);
		createEReference(valueDomainTypeEClass, VALUE_DOMAIN_TYPE__DOMAIN_CONCEPT);
		createEReference(valueDomainTypeEClass, VALUE_DOMAIN_TYPE__VERSIONS);
		createEAttribute(valueDomainTypeEClass, VALUE_DOMAIN_TYPE__REPRESENTS_REALM_OR_CONTEXT);
		createEAttribute(valueDomainTypeEClass, VALUE_DOMAIN_TYPE__DEFAULT_CODING_SCHEME);
		createEAttribute(valueDomainTypeEClass, VALUE_DOMAIN_TYPE__DEFAULT_LANGUAGE);
		createEAttribute(valueDomainTypeEClass, VALUE_DOMAIN_TYPE__REGISTERED_NAME);
		createEAttribute(valueDomainTypeEClass, VALUE_DOMAIN_TYPE__REPRESENTS_VALUE_DOMAIN_VERSION);
		createEAttribute(valueDomainTypeEClass, VALUE_DOMAIN_TYPE__VALUE_DOMAIN);

		valueDomainVersionEClass = createEClass(VALUE_DOMAIN_VERSION);
		createEReference(valueDomainVersionEClass, VALUE_DOMAIN_VERSION__DOMAIN_CONCEPT);

		vdVersionsEClass = createEClass(VD_VERSIONS);
		createEReference(vdVersionsEClass, VD_VERSIONS__VERSION);
		createEAttribute(vdVersionsEClass, VD_VERSIONS__DC);

		documentRootEClass = createEClass(DOCUMENT_ROOT);
		createEAttribute(documentRootEClass, DOCUMENT_ROOT__MIXED);
		createEReference(documentRootEClass, DOCUMENT_ROOT__XMLNS_PREFIX_MAP);
		createEReference(documentRootEClass, DOCUMENT_ROOT__XSI_SCHEMA_LOCATION);
		createEReference(documentRootEClass, DOCUMENT_ROOT__VALUE_DOMAIN);
		createEReference(documentRootEClass, DOCUMENT_ROOT__VALUE_DOMAINS);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContentsGen() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		NamingPackage theNamingPackage = (NamingPackage) EPackage.Registry.INSTANCE.getEPackage(NamingPackage.eNS_URI);
		CommontypesPackage theCommontypesPackage = (CommontypesPackage) EPackage.Registry.INSTANCE
				.getEPackage(CommontypesPackage.eNS_URI);
		BuiltinsPackage theBuiltinsPackage = (BuiltinsPackage) EPackage.Registry.INSTANCE
				.getEPackage(BuiltinsPackage.eNS_URI);
		XMLTypePackage theXMLTypePackage = (XMLTypePackage) EPackage.Registry.INSTANCE
				.getEPackage(XMLTypePackage.eNS_URI);
		VersionsPackage theVersionsPackage = (VersionsPackage) EPackage.Registry.INSTANCE
				.getEPackage(VersionsPackage.eNS_URI);

		// Add supertypes to classes
		valueDomainEntryEClass.getESuperTypes().add(theCommontypesPackage.getVersionable());
		valueDomainTypeEClass.getESuperTypes().add(theCommontypesPackage.getVersionableAndDescribable());
		valueDomainVersionEClass.getESuperTypes().add(theVersionsPackage.getEntityVersion());

		// Initialize classes and features; add operations and parameters
		initEClass(mappingsEClass, Mappings.class, "Mappings", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getMappings_SupportedCodingScheme(), theNamingPackage.getSupportedCodingScheme(), null,
				"supportedCodingScheme", null, 0, -1, Mappings.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMappings_SupportedSource(), theNamingPackage.getSupportedSource(), null, "supportedSource",
				null, 0, -1, Mappings.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMappings_SupportedLanguage(), theNamingPackage.getSupportedLanguage(), null,
				"supportedLanguage", null, 0, -1, Mappings.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMappings_SupportedContext(), theNamingPackage.getSupportedContext(), null,
				"supportedContext", null, 0, -1, Mappings.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMappings_Dc(), theCommontypesPackage.getDc(), "dc", "mappings", 1, 1, Mappings.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(pickListEntryEClass, PickListEntry.class, "PickListEntry", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPickListEntry_PickText(), theBuiltinsPackage.getTsCaseSensitiveDirectoryString(), "pickText",
				null, 1, 1, PickListEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				!IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPickListEntry_PickContext(), theCommontypesPackage.getCodedContext(), null, "pickContext",
				null, 0, -1, PickListEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPickListEntry_Id(), theCommontypesPackage.getId(), "id", null, 1, 1, PickListEntry.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPickListEntry_IsDefault(), theBuiltinsPackage.getTsBooleanObject(), "isDefault", null, 0, 1,
				PickListEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getPickListEntry_Language(), theCommontypesPackage.getLanguage(), "language", null, 0, 1,
				PickListEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getPickListEntry_MatchIfNoContext(), theBuiltinsPackage.getTsBooleanObject(),
				"matchIfNoContext", null, 0, 1, PickListEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(valueDomainEntryEClass, ValueDomainEntry.class, "ValueDomainEntry", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getValueDomainEntry_PickListEntry(), this.getPickListEntry(), null, "pickListEntry", null, 0,
				-1, ValueDomainEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getValueDomainEntry_IncludesValueDomain(), theCommontypesPackage.getRegisteredName(),
				"includesValueDomain", null, 0, 1, ValueDomainEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getValueDomainEntry_Property(), theCommontypesPackage.getProperty(), null, "property", null, 0,
				-1, ValueDomainEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getValueDomainEntry_CodingScheme(), theBuiltinsPackage.getLocalId(), "codingScheme", null, 0, 1,
				ValueDomainEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getValueDomainEntry_ConceptCode(), theCommontypesPackage.getConceptCode(), "conceptCode", null,
				0, 1, ValueDomainEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				!IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getValueDomainEntry_EntryOrder(), theCommontypesPackage.getEntryOrder(), "entryOrder", null, 0,
				1, ValueDomainEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				!IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getValueDomainEntry_Id(), theCommontypesPackage.getId(), "id", null, 1, 1,
				ValueDomainEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getValueDomainEntry_IncludeChildren(), theXMLTypePackage.getBoolean(), "includeChildren",
				"false", 0, 1, ValueDomainEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE,
				!IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getValueDomainEntry_IsSelectable(), theXMLTypePackage.getBoolean(), "isSelectable", "true", 0,
				1, ValueDomainEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID,
				!IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getValueDomainEntry_TestSubsumption(), theXMLTypePackage.getBoolean(), "testSubsumption",
				"false", 0, 1, ValueDomainEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE,
				!IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(valueDomainsEClass, ValueDomains.class, "ValueDomains", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getValueDomains_ValueDomain(), this.getValueDomainType(), null, "valueDomain", null, 1, -1,
				ValueDomains.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getValueDomains_Dc(), theCommontypesPackage.getDc(), "dc", "valueDomains", 1, 1,
				ValueDomains.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(valueDomainTypeEClass, ValueDomainType.class, "ValueDomainType", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getValueDomainType_Source(), theCommontypesPackage.getSource(), null, "source", null, 0, -1,
				ValueDomainType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getValueDomainType_Mappings(), this.getMappings(), null, "mappings", null, 1, 1,
				ValueDomainType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getValueDomainType_Properties(), theCommontypesPackage.getProperties(), null, "properties",
				null, 0, 1, ValueDomainType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getValueDomainType_DomainConcept(), this.getValueDomainEntry(), null, "domainConcept", null, 0,
				-1, ValueDomainType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getValueDomainType_Versions(), this.getVdVersions(), null, "versions", null, 0, 1,
				ValueDomainType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getValueDomainType_RepresentsRealmOrContext(), theBuiltinsPackage.getLocalId(),
				"representsRealmOrContext", null, 0, -1, ValueDomainType.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getValueDomainType_DefaultCodingScheme(), theCommontypesPackage.getDefaultCodingScheme(),
				"defaultCodingScheme", null, 0, 1, ValueDomainType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getValueDomainType_DefaultLanguage(), theCommontypesPackage.getDefaultLanguage(),
				"defaultLanguage", null, 0, 1, ValueDomainType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getValueDomainType_RegisteredName(), theCommontypesPackage.getRegisteredName(),
				"registeredName", null, 1, 1, ValueDomainType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getValueDomainType_RepresentsValueDomainVersion(), theCommontypesPackage.getVersion(),
				"representsValueDomainVersion", null, 0, 1, ValueDomainType.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getValueDomainType_ValueDomain(), theBuiltinsPackage.getLocalId(), "valueDomain", null, 1, 1,
				ValueDomainType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(valueDomainVersionEClass, ValueDomainVersion.class, "ValueDomainVersion", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getValueDomainVersion_DomainConcept(), this.getValueDomainEntry(), null, "domainConcept", null,
				0, -1, ValueDomainVersion.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(vdVersionsEClass, VdVersions.class, "VdVersions", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getVdVersions_Version(), this.getValueDomainVersion(), null, "version", null, 1, -1,
				VdVersions.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVdVersions_Dc(), theCommontypesPackage.getDc(), "dc", "versions", 1, 1, VdVersions.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(documentRootEClass, DocumentRoot.class, "DocumentRoot", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDocumentRoot_Mixed(), ecorePackage.getEFeatureMapEntry(), "mixed", null, 0, -1, null,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_XMLNSPrefixMap(), ecorePackage.getEStringToStringMapEntry(), null,
				"xMLNSPrefixMap", null, 0, -1, null, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_XSISchemaLocation(), ecorePackage.getEStringToStringMapEntry(), null,
				"xSISchemaLocation", null, 0, -1, null, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_ValueDomain(), this.getValueDomainType(), null, "valueDomain", null, 0, -2,
				null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_ValueDomains(), this.getValueDomains(), null, "valueDomains", null, 0, -2, null,
				IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE,
				IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http:///org/eclipse/emf/ecore/util/ExtendedMetaData
		createExtendedMetaDataAnnotations();
		// null
		createNullAnnotations();
	}

	/**
	 * Initializes the annotations for <b>null</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createNullAnnotations() {
		String source = null;
		addAnnotation(
				pickListEntryEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.7.19</ldap:oid>\r\n\t\t\t\t<ldap:rdn xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">id</ldap:rdn>\r\n\t\t\t" });
		addAnnotation(
				valueDomainEntryEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.5.1.4.1.2114.108.1.7.16</ldap:oid>\r\n\t\t\t\t<ldap:rdn xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">id</ldap:rdn>\r\n\t\t\t" });
		addAnnotation(
				valueDomainsEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.7.87</ldap:oid>\r\n\t\t\t\t<ldap:rdn xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">dc</ldap:rdn>\r\n\t\t\t" });
		addAnnotation(
				getValueDomains_ValueDomain(),
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.5.1.4.1.2114.108.1.7.15</ldap:oid>\r\n\t\t\t\t<ldap:rdn xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">valueDomain</ldap:rdn>\r\n\t\t\t" });
		addAnnotation(
				valueDomainVersionEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.7.18</ldap:oid>\r\n\t\t\t\t<ldap:rdn xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">versionId</ldap:rdn>\r\n\t\t\t" });
		addAnnotation(
				vdVersionsEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.7.88</ldap:oid>\r\n\t\t\t\t<ldap:rdn xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">dc</ldap:rdn>\r\n\t\t\t" });
		addAnnotation(
				getDocumentRoot_ValueDomain(),
				source,
				new String[] {
						"appinfo",
						"\r\n\t\t\t\t<ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.5.1.4.1.2114.108.1.7.15</ldap:oid>\r\n\t\t\t\t<ldap:rdn xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">valueDomain</ldap:rdn>\r\n\t\t\t" });
	}

	/**
	 * Initializes the annotations for <b>http:///org/eclipse/emf/ecore/util/ExtendedMetaData</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createExtendedMetaDataAnnotations() {
		String source = "http:///org/eclipse/emf/ecore/util/ExtendedMetaData";
		addAnnotation(mappingsEClass, source, new String[] { "name", "mappings", "kind", "elementOnly" });
		addAnnotation(getMappings_SupportedCodingScheme(), source, new String[] { "kind", "element", "name",
				"supportedCodingScheme", "namespace", "##targetNamespace" });
		addAnnotation(getMappings_SupportedSource(), source, new String[] { "kind", "element", "name",
				"supportedSource", "namespace", "##targetNamespace" });
		addAnnotation(getMappings_SupportedLanguage(), source, new String[] { "kind", "element", "name",
				"supportedLanguage", "namespace", "##targetNamespace" });
		addAnnotation(getMappings_SupportedContext(), source, new String[] { "kind", "element", "name",
				"supportedContext", "namespace", "##targetNamespace" });
		addAnnotation(getMappings_Dc(), source, new String[] { "kind", "attribute", "name", "dc" });
		addAnnotation(pickListEntryEClass, source, new String[] { "name", "pickListEntry", "kind", "elementOnly" });
		addAnnotation(getPickListEntry_PickText(), source, new String[] { "kind", "element", "name", "pickText",
				"namespace", "##targetNamespace" });
		addAnnotation(getPickListEntry_PickContext(), source, new String[] { "kind", "element", "name", "pickContext",
				"namespace", "##targetNamespace" });
		addAnnotation(getPickListEntry_Id(), source, new String[] { "kind", "attribute", "name", "id" });
		addAnnotation(getPickListEntry_IsDefault(), source, new String[] { "kind", "attribute", "name", "isDefault" });
		addAnnotation(getPickListEntry_Language(), source, new String[] { "kind", "attribute", "name", "language" });
		addAnnotation(getPickListEntry_MatchIfNoContext(), source, new String[] { "kind", "attribute", "name",
				"matchIfNoContext" });
		addAnnotation(valueDomainEntryEClass, source,
				new String[] { "name", "valueDomainEntry", "kind", "elementOnly" });
		addAnnotation(getValueDomainEntry_PickListEntry(), source, new String[] { "kind", "element", "name",
				"pickListEntry", "namespace", "##targetNamespace" });
		addAnnotation(getValueDomainEntry_IncludesValueDomain(), source, new String[] { "kind", "element", "name",
				"includesValueDomain", "namespace", "##targetNamespace" });
		addAnnotation(getValueDomainEntry_Property(), source, new String[] { "kind", "element", "name", "property",
				"namespace", "##targetNamespace" });
		addAnnotation(getValueDomainEntry_CodingScheme(), source, new String[] { "kind", "attribute", "name",
				"codingScheme" });
		addAnnotation(getValueDomainEntry_ConceptCode(), source, new String[] { "kind", "attribute", "name",
				"conceptCode" });
		addAnnotation(getValueDomainEntry_EntryOrder(), source, new String[] { "kind", "attribute", "name",
				"entryOrder" });
		addAnnotation(getValueDomainEntry_Id(), source, new String[] { "kind", "attribute", "name", "id" });
		addAnnotation(getValueDomainEntry_IncludeChildren(), source, new String[] { "kind", "attribute", "name",
				"includeChildren" });
		addAnnotation(getValueDomainEntry_IsSelectable(), source, new String[] { "kind", "attribute", "name",
				"isSelectable" });
		addAnnotation(getValueDomainEntry_TestSubsumption(), source, new String[] { "kind", "attribute", "name",
				"testSubsumption" });
		addAnnotation(valueDomainsEClass, source, new String[] { "name", "valueDomains", "kind", "elementOnly" });
		addAnnotation(getValueDomains_ValueDomain(), source, new String[] { "kind", "element", "name", "valueDomain",
				"namespace", "##targetNamespace" });
		addAnnotation(getValueDomains_Dc(), source, new String[] { "kind", "attribute", "name", "dc" });
		addAnnotation(valueDomainTypeEClass, source,
				new String[] { "name", "valueDomain_._type", "kind", "elementOnly" });
		addAnnotation(getValueDomainType_Source(), source, new String[] { "kind", "element", "name", "source",
				"namespace", "##targetNamespace" });
		addAnnotation(getValueDomainType_Mappings(), source, new String[] { "kind", "element", "name", "mappings",
				"namespace", "##targetNamespace" });
		addAnnotation(getValueDomainType_Properties(), source, new String[] { "kind", "element", "name", "properties",
				"namespace", "##targetNamespace" });
		addAnnotation(getValueDomainType_DomainConcept(), source, new String[] { "kind", "element", "name",
				"domainConcept", "namespace", "##targetNamespace" });
		addAnnotation(getValueDomainType_Versions(), source, new String[] { "kind", "element", "name", "versions",
				"namespace", "##targetNamespace" });
		addAnnotation(getValueDomainType_RepresentsRealmOrContext(), source, new String[] { "kind", "element", "name",
				"representsRealmOrContext", "namespace", "##targetNamespace" });
		addAnnotation(getValueDomainType_DefaultCodingScheme(), source, new String[] { "kind", "attribute", "name",
				"defaultCodingScheme" });
		addAnnotation(getValueDomainType_DefaultLanguage(), source, new String[] { "kind", "attribute", "name",
				"defaultLanguage" });
		addAnnotation(getValueDomainType_RegisteredName(), source, new String[] { "kind", "attribute", "name",
				"registeredName" });
		addAnnotation(getValueDomainType_RepresentsValueDomainVersion(), source, new String[] { "kind", "attribute",
				"name", "representsValueDomainVersion" });
		addAnnotation(getValueDomainType_ValueDomain(), source, new String[] { "kind", "attribute", "name",
				"valueDomain" });
		addAnnotation(valueDomainVersionEClass, source, new String[] { "name", "valueDomainVersion", "kind",
				"elementOnly" });
		addAnnotation(getValueDomainVersion_DomainConcept(), source, new String[] { "kind", "element", "name",
				"domainConcept", "namespace", "##targetNamespace" });
		addAnnotation(vdVersionsEClass, source, new String[] { "name", "vdVersions", "kind", "elementOnly" });
		addAnnotation(getVdVersions_Version(), source, new String[] { "kind", "element", "name", "version",
				"namespace", "##targetNamespace" });
		addAnnotation(getVdVersions_Dc(), source, new String[] { "kind", "attribute", "name", "dc" });
		addAnnotation(documentRootEClass, source, new String[] { "name", "", "kind", "mixed" });
		addAnnotation(getDocumentRoot_Mixed(), source, new String[] { "kind", "elementWildcard", "name", ":mixed" });
		addAnnotation(getDocumentRoot_XMLNSPrefixMap(), source, new String[] { "kind", "attribute", "name",
				"xmlns:prefix" });
		addAnnotation(getDocumentRoot_XSISchemaLocation(), source, new String[] { "kind", "attribute", "name",
				"xsi:schemaLocation" });
		addAnnotation(getDocumentRoot_ValueDomain(), source, new String[] { "kind", "element", "name", "valueDomain",
				"namespace", "##targetNamespace" });
		addAnnotation(getDocumentRoot_ValueDomains(), source, new String[] { "kind", "element", "name", "valueDomains",
				"namespace", "##targetNamespace" });
	}

	////////////////////////////////////////////////////////////
	// ************** BEGIN NON-GENERATED CODE ************** //
	//                                                        //
	// ****************************************************** //
	////////////////////////////////////////////////////////////
	/**
	 * Override superclass to create a LexGrid-aware attribute.
	 * @non-generated
	 */
	protected void createEAttribute(EClass owner, int id) {
		LgAttributeImpl eAttribute = new LgAttributeImpl();
		eAttribute.setFeatureID(id);
		owner.getEStructuralFeatures().add(eAttribute);
	}

	/**
	 * Override superclass to create a LexGrid-aware reference.
	 * @non-generated
	 */
	protected void createEReference(EClass owner, int id) {
		LgReferenceImpl eReference = new LgReferenceImpl();
		eReference.setFeatureID(id);
		owner.getEStructuralFeatures().add(eReference);
	}

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * @non-generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		initializePackageContentsGen();

		((LgAttributeImpl) getPickListEntry_Id()).setID(true);
		((LgAttributeImpl) getValueDomainEntry_Id()).setID(true);
		((LgAttributeImpl) getValueDomains_Dc()).setID(true);
		((LgAttributeImpl) getValueDomains_Dc()).setDefaultValueLiteral("valueDomains");
		((LgAttributeImpl) getValueDomainType_ValueDomain()).setID(true);
		((LgAttributeImpl) getVdVersions_Dc()).setID(true);
		((LgAttributeImpl) getVdVersions_Dc()).setDefaultValueLiteral("versions");

		// Ensures order of output in XML ...
		String source = "http:///org/eclipse/emf/mapping/xsd2ecore/XSD2Ecore";
		addAnnotation(valueDomainTypeEClass, source, new String[] { "feature-order",
				"source mappings properties domainConcept versions representsRealmOrContext" });
		addAnnotation(valueDomainEntryEClass, source, new String[] { "feature-order",
				"pickListEntry includesValueDomain property" });
		addAnnotation(pickListEntryEClass, source, new String[] { "feature-order",
				"pickText pickContext" });
		addAnnotation(mappingsEClass, source, new String[] { "feature-order",
				"supportedCodingScheme supportedSource supportedLanguage supportedContext" });
	}
	////////////////////////////////////////////////////////////
	// *************** END NON-GENERATED CODE *************** //
	////////////////////////////////////////////////////////////

} //ValuedomainsPackageImpl