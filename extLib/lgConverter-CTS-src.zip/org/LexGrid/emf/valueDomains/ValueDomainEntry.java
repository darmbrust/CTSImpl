/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.valueDomains;

import java.util.List;

import org.LexGrid.emf.commonTypes.Versionable;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Value Domain Entry</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The representation of a coded concept that belongs to the value domain. A value domain entry may either reference a concept code
 * 				and, optionally, all of the "children" (via. the hasSubtype relationship for the time being) or if may reference a second value domain entry. If
 * 				it references a second value domain entry, the concept code reference represents the "headcode" of the second entry. It may be selectable or
 * 				not, but it *cannot* include the children of the headcode. Rule: not(null(includesValueDomain)) -&gt; includeChildren = false
 * 				includeChildren=false and null(includesValueDomain) -&gt; isSelectable=true 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#getPickListEntry <em>Pick List Entry</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#getIncludesValueDomain <em>Includes Value Domain</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#getProperty <em>Property</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#getCodingScheme <em>Coding Scheme</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#getConceptCode <em>Concept Code</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#getEntryOrder <em>Entry Order</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#getId <em>Id</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#isIncludeChildren <em>Include Children</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#isIsSelectable <em>Is Selectable</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#isTestSubsumption <em>Test Subsumption</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getValueDomainEntry()
 * @model extendedMetaData="name='valueDomainEntry' kind='elementOnly'"
 * @generated
 */
public interface ValueDomainEntry extends Versionable {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Returns the value of the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Unique list identifier
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Id</em>' attribute.
	 * @see #setId(String)
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getValueDomainEntry_Id()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.Id" required="true"
	 *        extendedMetaData="kind='attribute' name='id'"
	 * @generated
	 */
	String getId();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#getId <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id</em>' attribute.
	 * @see #getId()
	 * @generated
	 */
	void setId(String value);

	/**
	 * Returns the value of the '<em><b>Include Children</b></em>' attribute.
	 * The default value is <code>"false"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Indicates whether the valueDomainEntry includes "child" concepts in a hasSubtype hierarchy.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Include Children</em>' attribute.
	 * @see #isSetIncludeChildren()
	 * @see #unsetIncludeChildren()
	 * @see #setIncludeChildren(boolean)
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getValueDomainEntry_IncludeChildren()
	 * @model default="false" unique="false" unsettable="true" dataType="org.eclipse.emf.ecore.xml.type.Boolean"
	 *        extendedMetaData="kind='attribute' name='includeChildren'"
	 * @generated
	 */
	boolean isIncludeChildren();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#isIncludeChildren <em>Include Children</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Include Children</em>' attribute.
	 * @see #isSetIncludeChildren()
	 * @see #unsetIncludeChildren()
	 * @see #isIncludeChildren()
	 * @generated
	 */
	void setIncludeChildren(boolean value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#isIncludeChildren <em>Include Children</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIncludeChildren()
	 * @see #isIncludeChildren()
	 * @see #setIncludeChildren(boolean)
	 * @generated
	 */
	void unsetIncludeChildren();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#isIncludeChildren <em>Include Children</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Include Children</em>' attribute is set.
	 * @see #unsetIncludeChildren()
	 * @see #isIncludeChildren()
	 * @see #setIncludeChildren(boolean)
	 * @generated
	 */
	boolean isSetIncludeChildren();

	/**
	 * Returns the value of the '<em><b>Coding Scheme</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The coding scheme from which conceptCode is drawn. Default: defaultCodingScheme. Must reference supportedCodingScheme.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Coding Scheme</em>' attribute.
	 * @see #setCodingScheme(String)
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getValueDomainEntry_CodingScheme()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.LocalId"
	 *        extendedMetaData="kind='attribute' name='codingScheme'"
	 * @generated
	 */
	String getCodingScheme();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#getCodingScheme <em>Coding Scheme</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Coding Scheme</em>' attribute.
	 * @see #getCodingScheme()
	 * @generated
	 */
	void setCodingScheme(String value);

	/**
	 * Returns the value of the '<em><b>Concept Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * A coded concept that is a member of this domain
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Concept Code</em>' attribute.
	 * @see #setConceptCode(String)
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getValueDomainEntry_ConceptCode()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.ConceptCode"
	 *        extendedMetaData="kind='attribute' name='conceptCode'"
	 * @generated
	 */
	String getConceptCode();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#getConceptCode <em>Concept Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Concept Code</em>' attribute.
	 * @see #getConceptCode()
	 * @generated
	 */
	void setConceptCode(String value);

	/**
	 * Returns the value of the '<em><b>Entry Order</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The relative order to of this concept within the value domain. if entry order is not supplied, conceptCodes will sort
	 * 							in ascending id, but AFTER any codes that have an order.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Entry Order</em>' attribute.
	 * @see #setEntryOrder(int)
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getValueDomainEntry_EntryOrder()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.EntryOrder"
	 *        extendedMetaData="kind='attribute' name='entryOrder'"
	 * @generated
	 */
	int getEntryOrder();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#getEntryOrder <em>Entry Order</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Entry Order</em>' attribute.
	 * @see #getEntryOrder()
	 * @generated
	 */
	void setEntryOrder(int value);

	/**
	 * Returns the value of the '<em><b>Pick List Entry</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.valueDomains.PickListEntry}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The term or terms that can represent the concept code in the list
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Pick List Entry</em>' containment reference list.
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getValueDomainEntry_PickListEntry()
	 * @model type="org.LexGrid.emf.valueDomains.PickListEntry" containment="true"
	 *        extendedMetaData="kind='element' name='pickListEntry' namespace='##targetNamespace'"
	 * @generated
	 */
	List getPickListEntry();

	/**
	 * Returns the value of the '<em><b>Is Selectable</b></em>' attribute.
	 * The default value is <code>"true"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Is Selectable</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Indicates that the specified valueDomainEntry is selectable or not. A valueDomainEntry with the isSelectable flag set
	 * 							to true indicates that the valueDomainEntry is not atomic., and may contain child valueDomainEntries.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Is Selectable</em>' attribute.
	 * @see #isSetIsSelectable()
	 * @see #unsetIsSelectable()
	 * @see #setIsSelectable(boolean)
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getValueDomainEntry_IsSelectable()
	 * @model default="true" unique="false" unsettable="true" dataType="org.eclipse.emf.ecore.xml.type.Boolean"
	 *        extendedMetaData="kind='attribute' name='isSelectable'"
	 * @generated
	 */
	boolean isIsSelectable();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#isIsSelectable <em>Is Selectable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Selectable</em>' attribute.
	 * @see #isSetIsSelectable()
	 * @see #unsetIsSelectable()
	 * @see #isIsSelectable()
	 * @generated
	 */
	void setIsSelectable(boolean value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#isIsSelectable <em>Is Selectable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsSelectable()
	 * @see #isIsSelectable()
	 * @see #setIsSelectable(boolean)
	 * @generated
	 */
	void unsetIsSelectable();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#isIsSelectable <em>Is Selectable</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Selectable</em>' attribute is set.
	 * @see #unsetIsSelectable()
	 * @see #isIsSelectable()
	 * @see #setIsSelectable(boolean)
	 * @generated
	 */
	boolean isSetIsSelectable();

	/**
	 * Returns the value of the '<em><b>Test Subsumption</b></em>' attribute.
	 * The default value is <code>"false"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * True indicates that any concept or post-coordinated expression that is logically subsumed by the conceptCode
	 * 								<i xmlns="http://LexGrid.org/schema/2006/01/LexGrid/valueDomains">according to the rules of the corresponding code system</i> is valid for this value set.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Test Subsumption</em>' attribute.
	 * @see #isSetTestSubsumption()
	 * @see #unsetTestSubsumption()
	 * @see #setTestSubsumption(boolean)
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getValueDomainEntry_TestSubsumption()
	 * @model default="false" unique="false" unsettable="true" dataType="org.eclipse.emf.ecore.xml.type.Boolean"
	 *        extendedMetaData="kind='attribute' name='testSubsumption'"
	 * @generated
	 */
	boolean isTestSubsumption();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#isTestSubsumption <em>Test Subsumption</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Test Subsumption</em>' attribute.
	 * @see #isSetTestSubsumption()
	 * @see #unsetTestSubsumption()
	 * @see #isTestSubsumption()
	 * @generated
	 */
	void setTestSubsumption(boolean value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#isTestSubsumption <em>Test Subsumption</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetTestSubsumption()
	 * @see #isTestSubsumption()
	 * @see #setTestSubsumption(boolean)
	 * @generated
	 */
	void unsetTestSubsumption();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#isTestSubsumption <em>Test Subsumption</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Test Subsumption</em>' attribute is set.
	 * @see #unsetTestSubsumption()
	 * @see #isTestSubsumption()
	 * @see #setTestSubsumption(boolean)
	 * @generated
	 */
	boolean isSetTestSubsumption();

	/**
	 * Returns the value of the '<em><b>Property</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.commonTypes.Property}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Property</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Additional tag and associated value that further identifies or describes the intent of the concept
	 * 								code.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Property</em>' containment reference list.
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getValueDomainEntry_Property()
	 * @model type="org.LexGrid.emf.commonTypes.Property" containment="true"
	 *        extendedMetaData="kind='element' name='property' namespace='##targetNamespace'"
	 * @generated
	 */
	List getProperty();

	/**
	 * Returns the value of the '<em><b>Includes Value Domain</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Includes Value Domain</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The name of a valueDomainEntry that is include as part of this domain.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Includes Value Domain</em>' attribute.
	 * @see #setIncludesValueDomain(String)
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getValueDomainEntry_IncludesValueDomain()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.RegisteredName"
	 *        extendedMetaData="kind='element' name='includesValueDomain' namespace='##targetNamespace'"
	 * @generated
	 */
	String getIncludesValueDomain();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#getIncludesValueDomain <em>Includes Value Domain</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Includes Value Domain</em>' attribute.
	 * @see #getIncludesValueDomain()
	 * @generated
	 */
	void setIncludesValueDomain(String value);

} // ValueDomainEntry