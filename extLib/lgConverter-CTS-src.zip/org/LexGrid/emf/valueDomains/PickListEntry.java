/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.valueDomains;

import java.util.List;

import org.LexGrid.emf.base.LgModelObj;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pick List Entry</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A qualified concept code accompanied by the appropriate textual representation. Each concept within a value domain may be represented in a selection list or lists for various contexts. There may be multiple pickList entries per value domain entry and there may be multiple context identifiers per pick list.
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.LexGrid.emf.valueDomains.PickListEntry#getId <em>Id</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.PickListEntry#isIsDefault <em>Is Default</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.PickListEntry#isMatchIfNoContext <em>Match If No Context</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.PickListEntry#getLanguage <em>Language</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.PickListEntry#getPickText <em>Pick Text</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.PickListEntry#getUsageContext <em>Usage Context</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.PickListEntry#getValueDomainEntry <em>Value Domain Entry</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getPickListEntry()
 * @model 
 */
public interface PickListEntry extends LgModelObj {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Returns the value of the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Unique identifier of this entry. Used solely to make it uinque.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Id</em>' attribute.
	 * @see #setId(String)
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getPickListEntry_Id()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.Id" required="true"
	 *        extendedMetaData="kind='attribute' name='id'"
	 * @generated
	 */
	String getId();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.valueDomains.PickListEntry#getId <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id</em>' attribute.
	 * @see #getId()
	 * @generated
	 */
	void setId(String value);

	/**
	 * Returns the value of the '<em><b>Is Default</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * TRUE means that this is the default entry for the supplied language and context.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Is Default</em>' attribute.
	 * @see #isSetIsDefault()
	 * @see #unsetIsDefault()
	 * @see #setIsDefault(Boolean)
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getPickListEntry_IsDefault()
	 * @model unique="false" unsettable="true" dataType="org.LexGrid.emf.builtins.TsBooleanObject"
	 *        extendedMetaData="kind='attribute' name='isDefault'"
	 * @generated
	 */
	Boolean getIsDefault();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.valueDomains.PickListEntry#getIsDefault <em>Is Default</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Default</em>' attribute.
	 * @see #isSetIsDefault()
	 * @see #unsetIsDefault()
	 * @see #getIsDefault()
	 * @generated
	 */
	void setIsDefault(Boolean value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.valueDomains.PickListEntry#getIsDefault <em>Is Default</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsDefault()
	 * @see #getIsDefault()
	 * @see #setIsDefault(Boolean)
	 * @generated
	 */
	void unsetIsDefault();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.valueDomains.PickListEntry#getIsDefault <em>Is Default</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Default</em>' attribute is set.
	 * @see #unsetIsDefault()
	 * @see #getIsDefault()
	 * @see #setIsDefault(Boolean)
	 * @generated
	 */
	boolean isSetIsDefault();

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.valueDomains.PickListEntry#getMatchIfNoContext <em>Match If No Context</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetMatchIfNoContext()
	 * @see #getMatchIfNoContext()
	 * @see #setMatchIfNoContext(Boolean)
	 * @generated
	 */
	void unsetMatchIfNoContext();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.valueDomains.PickListEntry#getMatchIfNoContext <em>Match If No Context</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Match If No Context</em>' attribute is set.
	 * @see #unsetMatchIfNoContext()
	 * @see #getMatchIfNoContext()
	 * @see #setMatchIfNoContext(Boolean)
	 * @generated
	 */
	boolean isSetMatchIfNoContext();

	/**
	 * Returns the value of the '<em><b>Language</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Local name for the pick text language. Must be in supportedLanguage.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Language</em>' attribute.
	 * @see #setLanguage(String)
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getPickListEntry_Language()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.Language"
	 *        extendedMetaData="kind='attribute' name='language'"
	 * @generated
	 */
	String getLanguage();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.valueDomains.PickListEntry#getLanguage <em>Language</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Language</em>' attribute.
	 * @see #getLanguage()
	 * @generated
	 */
	void setLanguage(String value);

	/**
	 * Returns the value of the '<em><b>Match If No Context</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * TRUE means that this entry can be used if no contexts are supplied.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Match If No Context</em>' attribute.
	 * @see #isSetMatchIfNoContext()
	 * @see #unsetMatchIfNoContext()
	 * @see #setMatchIfNoContext(Boolean)
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getPickListEntry_MatchIfNoContext()
	 * @model unique="false" unsettable="true" dataType="org.LexGrid.emf.builtins.TsBooleanObject"
	 *        extendedMetaData="kind='attribute' name='matchIfNoContext'"
	 * @generated
	 */
	Boolean getMatchIfNoContext();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.valueDomains.PickListEntry#getMatchIfNoContext <em>Match If No Context</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Match If No Context</em>' attribute.
	 * @see #isSetMatchIfNoContext()
	 * @see #unsetMatchIfNoContext()
	 * @see #getMatchIfNoContext()
	 * @generated
	 */
	void setMatchIfNoContext(Boolean value);

	/**
	 * Returns the value of the '<em><b>Pick Text</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Text that represents the concept code in this language and context
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Pick Text</em>' attribute.
	 * @see #setPickText(String)
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getPickListEntry_PickText()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.TsCaseSensitiveDirectoryString" required="true"
	 *        extendedMetaData="kind='element' name='pickText' namespace='##targetNamespace'"
	 * @generated
	 */
	String getPickText();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.valueDomains.PickListEntry#getPickText <em>Pick Text</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Pick Text</em>' attribute.
	 * @see #getPickText()
	 * @generated
	 */
	void setPickText(String value);

	/**
	 * Returns the value of the '<em><b>Pick Context</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.commonTypes.CodedContext}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Local identifiers and optional codes for the contexts in which pickText applies.
	 * 					Embedded usageContext must be in supportedContext list
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Pick Context</em>' containment reference list.
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getPickListEntry_PickContext()
	 * @model type="org.LexGrid.emf.commonTypes.CodedContext" containment="true"
	 *        extendedMetaData="kind='element' name='pickContext' namespace='##targetNamespace'"
	 * @generated
	 */
	List getPickContext();

} // PickListEntry