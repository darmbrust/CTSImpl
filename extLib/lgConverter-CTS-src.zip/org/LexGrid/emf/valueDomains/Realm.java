/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.valueDomains;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.AbstractEnumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Realm</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getRealm()
 * @model
 * @generated
 */
public final class Realm extends AbstractEnumerator {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * The '<em><b>Universal</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Universal</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #UNIVERSAL_LITERAL
	 * @model name="Universal"
	 * @generated
	 * @ordered
	 */
	public static final int UNIVERSAL = 0;

	/**
	 * The '<em><b>Unclassified</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Unclassified</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #UNCLASSIFIED_LITERAL
	 * @model name="Unclassified"
	 * @generated
	 * @ordered
	 */
	public static final int UNCLASSIFIED = 1;

	/**
	 * The '<em><b>Representative</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Representative</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #REPRESENTATIVE_LITERAL
	 * @model name="Representative"
	 * @generated
	 * @ordered
	 */
	public static final int REPRESENTATIVE = 2;

	/**
	 * The '<em><b>Example</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Example</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #EXAMPLE_LITERAL
	 * @model name="Example"
	 * @generated
	 * @ordered
	 */
	public static final int EXAMPLE = 3;

	/**
	 * The '<em><b>Universal</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #UNIVERSAL
	 * @generated
	 * @ordered
	 */
	public static final Realm UNIVERSAL_LITERAL = new Realm(UNIVERSAL, "Universal", "Universal");

	/**
	 * The '<em><b>Unclassified</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #UNCLASSIFIED
	 * @generated
	 * @ordered
	 */
	public static final Realm UNCLASSIFIED_LITERAL = new Realm(UNCLASSIFIED, "Unclassified", "Unclassified");

	/**
	 * The '<em><b>Representative</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #REPRESENTATIVE
	 * @generated
	 * @ordered
	 */
	public static final Realm REPRESENTATIVE_LITERAL = new Realm(REPRESENTATIVE, "Representative", "Representative");

	/**
	 * The '<em><b>Example</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #EXAMPLE
	 * @generated
	 * @ordered
	 */
	public static final Realm EXAMPLE_LITERAL = new Realm(EXAMPLE, "Example", "Example");

	/**
	 * An array of all the '<em><b>Realm</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final Realm[] VALUES_ARRAY =
		new Realm[] {
			UNIVERSAL_LITERAL,
			UNCLASSIFIED_LITERAL,
			REPRESENTATIVE_LITERAL,
			EXAMPLE_LITERAL,
		};

	/**
	 * A public read-only list of all the '<em><b>Realm</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Realm</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Realm get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			Realm result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Realm</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Realm getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			Realm result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Realm</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Realm get(int value) {
		switch (value) {
			case UNIVERSAL: return UNIVERSAL_LITERAL;
			case UNCLASSIFIED: return UNCLASSIFIED_LITERAL;
			case REPRESENTATIVE: return REPRESENTATIVE_LITERAL;
			case EXAMPLE: return EXAMPLE_LITERAL;
		}
		return null;	
	}

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private Realm(int value, String name, String literal) {
		super(value, name, literal);
	}

} //Realm