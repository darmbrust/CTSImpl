/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.valueDomains;

import java.util.List;

import org.LexGrid.emf.commonTypes.Properties;
import org.LexGrid.emf.commonTypes.VersionableAndDescribable;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Value Domain</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.LexGrid.emf.valueDomains.ValueDomainType#getSource <em>Source</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.ValueDomainType#getMappings <em>Mappings</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.ValueDomainType#getProperties <em>Properties</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.ValueDomainType#getDomainConcept <em>Domain Concept</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.ValueDomainType#getVersions <em>Versions</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.ValueDomainType#getRepresentsRealmOrContext <em>Represents Realm Or Context</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.ValueDomainType#getDefaultCodingScheme <em>Default Coding Scheme</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.ValueDomainType#getDefaultLanguage <em>Default Language</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.ValueDomainType#getRegisteredName <em>Registered Name</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.ValueDomainType#getRepresentsValueDomainVersion <em>Represents Value Domain Version</em>}</li>
 *   <li>{@link org.LexGrid.emf.valueDomains.ValueDomainType#getValueDomain <em>Value Domain</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getValueDomainType()
 * @model extendedMetaData="name='valueDomain_._type' kind='elementOnly'"
 * @generated
 */
public interface ValueDomainType extends VersionableAndDescribable {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Returns the value of the '<em><b>Source</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.commonTypes.Source}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The source or orginator of the value domain.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Source</em>' containment reference list.
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getValueDomainType_Source()
	 * @model type="org.LexGrid.emf.commonTypes.Source" containment="true"
	 *        extendedMetaData="kind='element' name='source' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSource();

	/**
	 * Returns the value of the '<em><b>Mappings</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Mappings from local names to URN.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Mappings</em>' containment reference.
	 * @see #setMappings(Mappings)
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getValueDomainType_Mappings()
	 * @model containment="true" required="true"
	 *        extendedMetaData="kind='element' name='mappings' namespace='##targetNamespace'"
	 * @generated
	 */
	Mappings getMappings();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.valueDomains.ValueDomainType#getMappings <em>Mappings</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Mappings</em>' containment reference.
	 * @see #getMappings()
	 * @generated
	 */
	void setMappings(Mappings value);

	/**
	 * Returns the value of the '<em><b>Value Domain</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Unique name of the domain within the service.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Value Domain</em>' attribute.
	 * @see #setValueDomain(String)
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getValueDomainType_ValueDomain()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.LocalId" required="true"
	 *        extendedMetaData="kind='attribute' name='valueDomain'"
	 * @generated
	 */
	String getValueDomain();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.valueDomains.ValueDomainType#getValueDomain <em>Value Domain</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Value Domain</em>' attribute.
	 * @see #getValueDomain()
	 * @generated
	 */
	void setValueDomain(String value);

	/**
	 * Returns the value of the '<em><b>Default Coding Scheme</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Local name of the primary coding scheme from which the domain is drawn. Must be in supportedCodingScheme.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Default Coding Scheme</em>' attribute.
	 * @see #setDefaultCodingScheme(String)
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getValueDomainType_DefaultCodingScheme()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.DefaultCodingScheme"
	 *        extendedMetaData="kind='attribute' name='defaultCodingScheme'"
	 * @generated
	 */
	String getDefaultCodingScheme();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.valueDomains.ValueDomainType#getDefaultCodingScheme <em>Default Coding Scheme</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Default Coding Scheme</em>' attribute.
	 * @see #getDefaultCodingScheme()
	 * @generated
	 */
	void setDefaultCodingScheme(String value);

	/**
	 * Returns the value of the '<em><b>Default Language</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Default language used in the domain if not otherwise specified. Must be in supportedLanguage list.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Default Language</em>' attribute.
	 * @see #setDefaultLanguage(String)
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getValueDomainType_DefaultLanguage()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.DefaultLanguage"
	 *        extendedMetaData="kind='attribute' name='defaultLanguage'"
	 * @generated
	 */
	String getDefaultLanguage();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.valueDomains.ValueDomainType#getDefaultLanguage <em>Default Language</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Default Language</em>' attribute.
	 * @see #getDefaultLanguage()
	 * @generated
	 */
	void setDefaultLanguage(String value);

	/**
	 * Returns the value of the '<em><b>Registered Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Official URN of this value domain.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Registered Name</em>' attribute.
	 * @see #setRegisteredName(String)
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getValueDomainType_RegisteredName()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.RegisteredName" required="true"
	 *        extendedMetaData="kind='attribute' name='registeredName'"
	 * @generated
	 */
	String getRegisteredName();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.valueDomains.ValueDomainType#getRegisteredName <em>Registered Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Registered Name</em>' attribute.
	 * @see #getRegisteredName()
	 * @generated
	 */
	void setRegisteredName(String value);

	/**
	 * Returns the value of the '<em><b>Represents Value Domain Version</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Version that this value domain represents. If absent, the value domain cannot be bound to a coding scheme 	version.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Represents Value Domain Version</em>' attribute.
	 * @see #setRepresentsValueDomainVersion(String)
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getValueDomainType_RepresentsValueDomainVersion()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.Version"
	 *        extendedMetaData="kind='attribute' name='representsValueDomainVersion'"
	 * @generated
	 */
	String getRepresentsValueDomainVersion();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.valueDomains.ValueDomainType#getRepresentsValueDomainVersion <em>Represents Value Domain Version</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Represents Value Domain Version</em>' attribute.
	 * @see #getRepresentsValueDomainVersion()
	 * @generated
	 */
	void setRepresentsValueDomainVersion(String value);

	/**
	 * Returns the value of the '<em><b>Properties</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Additional tags and associated values that further describe or identify the coding scheme.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Properties</em>' containment reference.
	 * @see #setProperties(Properties)
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getValueDomainType_Properties()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='properties' namespace='##targetNamespace'"
	 * @generated
	 */
	Properties getProperties();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.valueDomains.ValueDomainType#getProperties <em>Properties</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Properties</em>' containment reference.
	 * @see #getProperties()
	 * @generated
	 */
	void setProperties(Properties value);

	/**
	 * Returns the value of the '<em><b>Domain Concept</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.valueDomains.ValueDomainEntry}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * An ordered list of coded concepts represented by this value domain.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Domain Concept</em>' containment reference list.
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getValueDomainType_DomainConcept()
	 * @model type="org.LexGrid.emf.valueDomains.ValueDomainEntry" containment="true"
	 *        extendedMetaData="kind='element' name='domainConcept' namespace='##targetNamespace'"
	 * @generated
	 */
	List getDomainConcept();

	/**
	 * Returns the value of the '<em><b>Versions</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Previous versions of this value domain.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Versions</em>' containment reference.
	 * @see #setVersions(VdVersions)
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getValueDomainType_Versions()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='versions' namespace='##targetNamespace'"
	 * @generated
	 */
	VdVersions getVersions();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.valueDomains.ValueDomainType#getVersions <em>Versions</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Versions</em>' containment reference.
	 * @see #getVersions()
	 * @generated
	 */
	void setVersions(VdVersions value);

	/**
	 * Returns the value of the '<em><b>Represents Realm Or Context</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.String}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Represents Realm Or Context</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The realm or context in which this value domain applies. Note the overloading of the "context" field - in this
	 * 									case, the assumption is that this is a geopolitical or some broader realm. 
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Represents Realm Or Context</em>' attribute list.
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getValueDomainType_RepresentsRealmOrContext()
	 * @model type="java.lang.String" unique="false" dataType="org.LexGrid.emf.builtins.LocalId"
	 *        extendedMetaData="kind='element' name='representsRealmOrContext' namespace='##targetNamespace'"
	 * @generated
	 */
	List getRepresentsRealmOrContext();

} // ValueDomainType