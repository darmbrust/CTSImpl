/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.valueDomains;

import java.util.List;

import org.LexGrid.emf.versions.EntityVersion;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Value Domain Version</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * 
 * 				<p xmlns="http://LexGrid.org/schema/2006/01/LexGrid/valueDomains">A static snapshot of a value domain at a point in time.</p>
 * 			
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.LexGrid.emf.valueDomains.ValueDomainVersion#getDomainConcept <em>Domain Concept</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getValueDomainVersion()
 * @model extendedMetaData="name='valueDomainVersion' kind='elementOnly'"
 * @generated
 */
public interface ValueDomainVersion extends EntityVersion {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Returns the value of the '<em><b>Domain Concept</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.valueDomains.ValueDomainEntry}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * An entry at a point in time in a value domain.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Domain Concept</em>' containment reference list.
	 * @see org.LexGrid.emf.valueDomains.ValuedomainsPackage#getValueDomainVersion_DomainConcept()
	 * @model type="org.LexGrid.emf.valueDomains.ValueDomainEntry" containment="true"
	 *        extendedMetaData="kind='element' name='domainConcept' namespace='##targetNamespace'"
	 * @generated
	 */
	List getDomainConcept();

} // ValueDomainVersion