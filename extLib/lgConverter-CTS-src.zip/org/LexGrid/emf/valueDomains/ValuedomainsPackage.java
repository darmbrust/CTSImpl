/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.valueDomains;

import org.LexGrid.emf.commonTypes.CommontypesPackage;
import org.LexGrid.emf.versions.VersionsPackage;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * <!-- begin-model-doc -->
 * 
 * 			<h2 xmlns="http://LexGrid.org/schema/2006/01/LexGrid/builtins">Core data types for the lexical grid.</h2>
 * 		
 * These types need to be mapped to the appropriate implementation specific data types. The mapping in this package represents the XML
 * 			Schema data types mapping
 * LDAP specific types for appinfo annotation
 * Basic builtin types
 * <!-- end-model-doc -->
 * @see org.LexGrid.emf.valueDomains.ValuedomainsFactory
 * @model kind="package"
 * @generated
 */
public interface ValuedomainsPackage extends EPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "valueDomains";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://LexGrid.org/schema/2006/01/LexGrid/valueDomains";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "lgVD";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ValuedomainsPackage eINSTANCE = org.LexGrid.emf.valueDomains.impl.ValuedomainsPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.valueDomains.impl.MappingsImpl <em>Mappings</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.valueDomains.impl.MappingsImpl
	 * @see org.LexGrid.emf.valueDomains.impl.ValuedomainsPackageImpl#getMappings()
	 * @generated
	 */
	int MAPPINGS = 0;

	/**
	 * The feature id for the '<em><b>Supported Coding Scheme</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAPPINGS__SUPPORTED_CODING_SCHEME = 0;

	/**
	 * The feature id for the '<em><b>Supported Source</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAPPINGS__SUPPORTED_SOURCE = 1;

	/**
	 * The feature id for the '<em><b>Supported Language</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAPPINGS__SUPPORTED_LANGUAGE = 2;

	/**
	 * The feature id for the '<em><b>Supported Context</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAPPINGS__SUPPORTED_CONTEXT = 3;

	/**
	 * The feature id for the '<em><b>Dc</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAPPINGS__DC = 4;

	/**
	 * The number of structural features of the '<em>Mappings</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAPPINGS_FEATURE_COUNT = 5;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.valueDomains.impl.ValueDomainsImpl <em>Value Domains</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.valueDomains.impl.ValueDomainsImpl
	 * @see org.LexGrid.emf.valueDomains.impl.ValuedomainsPackageImpl#getValueDomains()
	 * @generated
	 */
	int VALUE_DOMAINS = 3;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.valueDomains.impl.ValueDomainTypeImpl <em>Value Domain Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.valueDomains.impl.ValueDomainTypeImpl
	 * @see org.LexGrid.emf.valueDomains.impl.ValuedomainsPackageImpl#getValueDomainType()
	 * @generated
	 */
	int VALUE_DOMAIN_TYPE = 4;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.valueDomains.impl.ValueDomainEntryImpl <em>Value Domain Entry</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.valueDomains.impl.ValueDomainEntryImpl
	 * @see org.LexGrid.emf.valueDomains.impl.ValuedomainsPackageImpl#getValueDomainEntry()
	 * @generated
	 */
	int VALUE_DOMAIN_ENTRY = 2;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.valueDomains.impl.PickListEntryImpl <em>Pick List Entry</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.valueDomains.impl.PickListEntryImpl
	 * @see org.LexGrid.emf.valueDomains.impl.ValuedomainsPackageImpl#getPickListEntry()
	 * @generated
	 */
	int PICK_LIST_ENTRY = 1;

	/**
	 * The feature id for the '<em><b>Pick Text</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PICK_LIST_ENTRY__PICK_TEXT = 0;

	/**
	 * The feature id for the '<em><b>Pick Context</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PICK_LIST_ENTRY__PICK_CONTEXT = 1;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PICK_LIST_ENTRY__ID = 2;

	/**
	 * The feature id for the '<em><b>Is Default</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PICK_LIST_ENTRY__IS_DEFAULT = 3;

	/**
	 * The feature id for the '<em><b>Language</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PICK_LIST_ENTRY__LANGUAGE = 4;

	/**
	 * The feature id for the '<em><b>Match If No Context</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PICK_LIST_ENTRY__MATCH_IF_NO_CONTEXT = 5;

	/**
	 * The number of structural features of the '<em>Pick List Entry</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PICK_LIST_ENTRY_FEATURE_COUNT = 6;

	/**
	 * The feature id for the '<em><b>Deprecated</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_ENTRY__DEPRECATED = CommontypesPackage.VERSIONABLE__DEPRECATED;

	/**
	 * The feature id for the '<em><b>First Release</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_ENTRY__FIRST_RELEASE = CommontypesPackage.VERSIONABLE__FIRST_RELEASE;

	/**
	 * The feature id for the '<em><b>Modified In Release</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_ENTRY__MODIFIED_IN_RELEASE = CommontypesPackage.VERSIONABLE__MODIFIED_IN_RELEASE;

	/**
	 * The feature id for the '<em><b>Pick List Entry</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_ENTRY__PICK_LIST_ENTRY = CommontypesPackage.VERSIONABLE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Includes Value Domain</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_ENTRY__INCLUDES_VALUE_DOMAIN = CommontypesPackage.VERSIONABLE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Property</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_ENTRY__PROPERTY = CommontypesPackage.VERSIONABLE_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Coding Scheme</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_ENTRY__CODING_SCHEME = CommontypesPackage.VERSIONABLE_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Concept Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_ENTRY__CONCEPT_CODE = CommontypesPackage.VERSIONABLE_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Entry Order</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_ENTRY__ENTRY_ORDER = CommontypesPackage.VERSIONABLE_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_ENTRY__ID = CommontypesPackage.VERSIONABLE_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Include Children</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_ENTRY__INCLUDE_CHILDREN = CommontypesPackage.VERSIONABLE_FEATURE_COUNT + 7;

	/**
	 * The feature id for the '<em><b>Is Selectable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_ENTRY__IS_SELECTABLE = CommontypesPackage.VERSIONABLE_FEATURE_COUNT + 8;

	/**
	 * The feature id for the '<em><b>Test Subsumption</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_ENTRY__TEST_SUBSUMPTION = CommontypesPackage.VERSIONABLE_FEATURE_COUNT + 9;

	/**
	 * The number of structural features of the '<em>Value Domain Entry</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_ENTRY_FEATURE_COUNT = CommontypesPackage.VERSIONABLE_FEATURE_COUNT + 10;

	/**
	 * The feature id for the '<em><b>Value Domain</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAINS__VALUE_DOMAIN = 0;

	/**
	 * The feature id for the '<em><b>Dc</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAINS__DC = 1;

	/**
	 * The number of structural features of the '<em>Value Domains</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAINS_FEATURE_COUNT = 2;

	/**
	 * The feature id for the '<em><b>Deprecated</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_TYPE__DEPRECATED = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE__DEPRECATED;

	/**
	 * The feature id for the '<em><b>First Release</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_TYPE__FIRST_RELEASE = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE__FIRST_RELEASE;

	/**
	 * The feature id for the '<em><b>Modified In Release</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_TYPE__MODIFIED_IN_RELEASE = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE__MODIFIED_IN_RELEASE;

	/**
	 * The feature id for the '<em><b>Entity Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_TYPE__ENTITY_DESCRIPTION = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE__ENTITY_DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Source</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_TYPE__SOURCE = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Mappings</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_TYPE__MAPPINGS = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Properties</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_TYPE__PROPERTIES = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Domain Concept</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_TYPE__DOMAIN_CONCEPT = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Versions</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_TYPE__VERSIONS = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Represents Realm Or Context</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_TYPE__REPRESENTS_REALM_OR_CONTEXT = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Default Coding Scheme</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_TYPE__DEFAULT_CODING_SCHEME = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Default Language</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_TYPE__DEFAULT_LANGUAGE = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 7;

	/**
	 * The feature id for the '<em><b>Registered Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_TYPE__REGISTERED_NAME = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 8;

	/**
	 * The feature id for the '<em><b>Represents Value Domain Version</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_TYPE__REPRESENTS_VALUE_DOMAIN_VERSION = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 9;

	/**
	 * The feature id for the '<em><b>Value Domain</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_TYPE__VALUE_DOMAIN = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 10;

	/**
	 * The number of structural features of the '<em>Value Domain Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_TYPE_FEATURE_COUNT = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 11;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.valueDomains.impl.ValueDomainVersionImpl <em>Value Domain Version</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.valueDomains.impl.ValueDomainVersionImpl
	 * @see org.LexGrid.emf.valueDomains.impl.ValuedomainsPackageImpl#getValueDomainVersion()
	 * @generated
	 */
	int VALUE_DOMAIN_VERSION = 5;

	/**
	 * The feature id for the '<em><b>Entity Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_VERSION__ENTITY_DESCRIPTION = VersionsPackage.ENTITY_VERSION__ENTITY_DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Change Documentation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_VERSION__CHANGE_DOCUMENTATION = VersionsPackage.ENTITY_VERSION__CHANGE_DOCUMENTATION;

	/**
	 * The feature id for the '<em><b>Change Instructions</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_VERSION__CHANGE_INSTRUCTIONS = VersionsPackage.ENTITY_VERSION__CHANGE_INSTRUCTIONS;

	/**
	 * The feature id for the '<em><b>Effective Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_VERSION__EFFECTIVE_DATE = VersionsPackage.ENTITY_VERSION__EFFECTIVE_DATE;

	/**
	 * The feature id for the '<em><b>Is Complete</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_VERSION__IS_COMPLETE = VersionsPackage.ENTITY_VERSION__IS_COMPLETE;

	/**
	 * The feature id for the '<em><b>Release URN</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_VERSION__RELEASE_URN = VersionsPackage.ENTITY_VERSION__RELEASE_URN;

	/**
	 * The feature id for the '<em><b>Version</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_VERSION__VERSION = VersionsPackage.ENTITY_VERSION__VERSION;

	/**
	 * The feature id for the '<em><b>Version Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_VERSION__VERSION_DATE = VersionsPackage.ENTITY_VERSION__VERSION_DATE;

	/**
	 * The feature id for the '<em><b>Version Order</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_VERSION__VERSION_ORDER = VersionsPackage.ENTITY_VERSION__VERSION_ORDER;

	/**
	 * The feature id for the '<em><b>Domain Concept</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_VERSION__DOMAIN_CONCEPT = VersionsPackage.ENTITY_VERSION_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Value Domain Version</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VALUE_DOMAIN_VERSION_FEATURE_COUNT = VersionsPackage.ENTITY_VERSION_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.valueDomains.impl.VdVersionsImpl <em>Vd Versions</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.valueDomains.impl.VdVersionsImpl
	 * @see org.LexGrid.emf.valueDomains.impl.ValuedomainsPackageImpl#getVdVersions()
	 * @generated
	 */
	int VD_VERSIONS = 6;

	/**
	 * The feature id for the '<em><b>Version</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VD_VERSIONS__VERSION = 0;

	/**
	 * The feature id for the '<em><b>Dc</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VD_VERSIONS__DC = 1;

	/**
	 * The number of structural features of the '<em>Vd Versions</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VD_VERSIONS_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.valueDomains.impl.DocumentRootImpl <em>Document Root</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.valueDomains.impl.DocumentRootImpl
	 * @see org.LexGrid.emf.valueDomains.impl.ValuedomainsPackageImpl#getDocumentRoot()
	 * @generated
	 */
	int DOCUMENT_ROOT = 7;

	/**
	 * The feature id for the '<em><b>Mixed</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__MIXED = 0;

	/**
	 * The feature id for the '<em><b>XMLNS Prefix Map</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__XMLNS_PREFIX_MAP = 1;

	/**
	 * The feature id for the '<em><b>XSI Schema Location</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = 2;

	/**
	 * The feature id for the '<em><b>Value Domain</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__VALUE_DOMAIN = 3;

	/**
	 * The feature id for the '<em><b>Value Domains</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__VALUE_DOMAINS = 4;

	/**
	 * The number of structural features of the '<em>Document Root</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT_FEATURE_COUNT = 5;

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.valueDomains.Mappings <em>Mappings</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Mappings</em>'.
	 * @see org.LexGrid.emf.valueDomains.Mappings
	 * @generated
	 */
	EClass getMappings();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.valueDomains.Mappings#getSupportedCodingScheme <em>Supported Coding Scheme</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Supported Coding Scheme</em>'.
	 * @see org.LexGrid.emf.valueDomains.Mappings#getSupportedCodingScheme()
	 * @see #getMappings()
	 * @generated
	 */
	EReference getMappings_SupportedCodingScheme();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.valueDomains.Mappings#getSupportedSource <em>Supported Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Supported Source</em>'.
	 * @see org.LexGrid.emf.valueDomains.Mappings#getSupportedSource()
	 * @see #getMappings()
	 * @generated
	 */
	EReference getMappings_SupportedSource();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.valueDomains.Mappings#getSupportedLanguage <em>Supported Language</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Supported Language</em>'.
	 * @see org.LexGrid.emf.valueDomains.Mappings#getSupportedLanguage()
	 * @see #getMappings()
	 * @generated
	 */
	EReference getMappings_SupportedLanguage();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.valueDomains.Mappings#getSupportedContext <em>Supported Context</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Supported Context</em>'.
	 * @see org.LexGrid.emf.valueDomains.Mappings#getSupportedContext()
	 * @see #getMappings()
	 * @generated
	 */
	EReference getMappings_SupportedContext();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.valueDomains.Mappings#getDc <em>Dc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Dc</em>'.
	 * @see org.LexGrid.emf.valueDomains.Mappings#getDc()
	 * @see #getMappings()
	 * @generated
	 */
	EAttribute getMappings_Dc();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.valueDomains.ValueDomains <em>Value Domains</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Value Domains</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomains
	 * @generated
	 */
	EClass getValueDomains();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.valueDomains.ValueDomainType <em>Value Domain Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Value Domain Type</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomainType
	 * @generated
	 */
	EClass getValueDomainType();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.valueDomains.ValueDomainType#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Source</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomainType#getSource()
	 * @see #getValueDomainType()
	 * @generated
	 */
	EReference getValueDomainType_Source();

	/**
	 * Returns the meta object for the containment reference '{@link org.LexGrid.emf.valueDomains.ValueDomainType#getMappings <em>Mappings</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Mappings</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomainType#getMappings()
	 * @see #getValueDomainType()
	 * @generated
	 */
	EReference getValueDomainType_Mappings();

	/**
	 * Returns the meta object for the containment reference '{@link org.LexGrid.emf.valueDomains.ValueDomainType#getProperties <em>Properties</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Properties</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomainType#getProperties()
	 * @see #getValueDomainType()
	 * @generated
	 */
	EReference getValueDomainType_Properties();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.valueDomains.ValueDomainType#getDomainConcept <em>Domain Concept</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Domain Concept</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomainType#getDomainConcept()
	 * @see #getValueDomainType()
	 * @generated
	 */
	EReference getValueDomainType_DomainConcept();

	/**
	 * Returns the meta object for the containment reference '{@link org.LexGrid.emf.valueDomains.ValueDomainType#getVersions <em>Versions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Versions</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomainType#getVersions()
	 * @see #getValueDomainType()
	 * @generated
	 */
	EReference getValueDomainType_Versions();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.valueDomains.ValueDomainType#getDefaultCodingScheme <em>Default Coding Scheme</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Default Coding Scheme</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomainType#getDefaultCodingScheme()
	 * @see #getValueDomainType()
	 * @generated
	 */
	EAttribute getValueDomainType_DefaultCodingScheme();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.valueDomains.ValueDomainType#getDefaultLanguage <em>Default Language</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Default Language</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomainType#getDefaultLanguage()
	 * @see #getValueDomainType()
	 * @generated
	 */
	EAttribute getValueDomainType_DefaultLanguage();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.valueDomains.ValueDomainType#getRegisteredName <em>Registered Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Registered Name</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomainType#getRegisteredName()
	 * @see #getValueDomainType()
	 * @generated
	 */
	EAttribute getValueDomainType_RegisteredName();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.valueDomains.ValueDomainType#getRepresentsValueDomainVersion <em>Represents Value Domain Version</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Represents Value Domain Version</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomainType#getRepresentsValueDomainVersion()
	 * @see #getValueDomainType()
	 * @generated
	 */
	EAttribute getValueDomainType_RepresentsValueDomainVersion();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.valueDomains.ValueDomainType#getValueDomain <em>Value Domain</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value Domain</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomainType#getValueDomain()
	 * @see #getValueDomainType()
	 * @generated
	 */
	EAttribute getValueDomainType_ValueDomain();

	/**
	 * Returns the meta object for the attribute list '{@link org.LexGrid.emf.valueDomains.ValueDomainType#getRepresentsRealmOrContext <em>Represents Realm Or Context</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Represents Realm Or Context</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomainType#getRepresentsRealmOrContext()
	 * @see #getValueDomainType()
	 * @generated
	 */
	EAttribute getValueDomainType_RepresentsRealmOrContext();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.valueDomains.ValueDomains#getDc <em>Dc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Dc</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomains#getDc()
	 * @see #getValueDomains()
	 * @generated
	 */
	EAttribute getValueDomains_Dc();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.valueDomains.ValueDomains#getValueDomain <em>Value Domain</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Value Domain</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomains#getValueDomain()
	 * @see #getValueDomains()
	 * @generated
	 */
	EReference getValueDomains_ValueDomain();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.valueDomains.ValueDomainEntry <em>Value Domain Entry</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Value Domain Entry</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomainEntry
	 * @generated
	 */
	EClass getValueDomainEntry();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomainEntry#getId()
	 * @see #getValueDomainEntry()
	 * @generated
	 */
	EAttribute getValueDomainEntry_Id();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#isIncludeChildren <em>Include Children</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Include Children</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomainEntry#isIncludeChildren()
	 * @see #getValueDomainEntry()
	 * @generated
	 */
	EAttribute getValueDomainEntry_IncludeChildren();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#getCodingScheme <em>Coding Scheme</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Coding Scheme</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomainEntry#getCodingScheme()
	 * @see #getValueDomainEntry()
	 * @generated
	 */
	EAttribute getValueDomainEntry_CodingScheme();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#getConceptCode <em>Concept Code</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Concept Code</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomainEntry#getConceptCode()
	 * @see #getValueDomainEntry()
	 * @generated
	 */
	EAttribute getValueDomainEntry_ConceptCode();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#getEntryOrder <em>Entry Order</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Entry Order</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomainEntry#getEntryOrder()
	 * @see #getValueDomainEntry()
	 * @generated
	 */
	EAttribute getValueDomainEntry_EntryOrder();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#getPickListEntry <em>Pick List Entry</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Pick List Entry</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomainEntry#getPickListEntry()
	 * @see #getValueDomainEntry()
	 * @generated
	 */
	EReference getValueDomainEntry_PickListEntry();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#isIsSelectable <em>Is Selectable</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Selectable</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomainEntry#isIsSelectable()
	 * @see #getValueDomainEntry()
	 * @generated
	 */
	EAttribute getValueDomainEntry_IsSelectable();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#isTestSubsumption <em>Test Subsumption</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Test Subsumption</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomainEntry#isTestSubsumption()
	 * @see #getValueDomainEntry()
	 * @generated
	 */
	EAttribute getValueDomainEntry_TestSubsumption();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#getProperty <em>Property</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Property</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomainEntry#getProperty()
	 * @see #getValueDomainEntry()
	 * @generated
	 */
	EReference getValueDomainEntry_Property();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.valueDomains.ValueDomainEntry#getIncludesValueDomain <em>Includes Value Domain</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Includes Value Domain</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomainEntry#getIncludesValueDomain()
	 * @see #getValueDomainEntry()
	 * @generated
	 */
	EAttribute getValueDomainEntry_IncludesValueDomain();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.valueDomains.PickListEntry <em>Pick List Entry</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Pick List Entry</em>'.
	 * @see org.LexGrid.emf.valueDomains.PickListEntry
	 * @generated
	 */
	EClass getPickListEntry();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.valueDomains.PickListEntry#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see org.LexGrid.emf.valueDomains.PickListEntry#getId()
	 * @see #getPickListEntry()
	 * @generated
	 */
	EAttribute getPickListEntry_Id();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.valueDomains.PickListEntry#getIsDefault <em>Is Default</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Default</em>'.
	 * @see org.LexGrid.emf.valueDomains.PickListEntry#getIsDefault()
	 * @see #getPickListEntry()
	 * @generated
	 */
	EAttribute getPickListEntry_IsDefault();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.valueDomains.PickListEntry#getMatchIfNoContext <em>Match If No Context</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Match If No Context</em>'.
	 * @see org.LexGrid.emf.valueDomains.PickListEntry#getMatchIfNoContext()
	 * @see #getPickListEntry()
	 * @generated
	 */
	EAttribute getPickListEntry_MatchIfNoContext();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.valueDomains.PickListEntry#getLanguage <em>Language</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Language</em>'.
	 * @see org.LexGrid.emf.valueDomains.PickListEntry#getLanguage()
	 * @see #getPickListEntry()
	 * @generated
	 */
	EAttribute getPickListEntry_Language();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.valueDomains.PickListEntry#getPickText <em>Pick Text</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Pick Text</em>'.
	 * @see org.LexGrid.emf.valueDomains.PickListEntry#getPickText()
	 * @see #getPickListEntry()
	 * @generated
	 */
	EAttribute getPickListEntry_PickText();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.valueDomains.PickListEntry#getPickContext <em>Pick Context</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Pick Context</em>'.
	 * @see org.LexGrid.emf.valueDomains.PickListEntry#getPickContext()
	 * @see #getPickListEntry()
	 * @generated
	 */
	EReference getPickListEntry_PickContext();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.valueDomains.ValueDomainVersion <em>Value Domain Version</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Value Domain Version</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomainVersion
	 * @generated
	 */
	EClass getValueDomainVersion();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.valueDomains.ValueDomainVersion#getDomainConcept <em>Domain Concept</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Domain Concept</em>'.
	 * @see org.LexGrid.emf.valueDomains.ValueDomainVersion#getDomainConcept()
	 * @see #getValueDomainVersion()
	 * @generated
	 */
	EReference getValueDomainVersion_DomainConcept();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.valueDomains.VdVersions <em>Vd Versions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Vd Versions</em>'.
	 * @see org.LexGrid.emf.valueDomains.VdVersions
	 * @generated
	 */
	EClass getVdVersions();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.valueDomains.VdVersions#getVersion <em>Version</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Version</em>'.
	 * @see org.LexGrid.emf.valueDomains.VdVersions#getVersion()
	 * @see #getVdVersions()
	 * @generated
	 */
	EReference getVdVersions_Version();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.valueDomains.VdVersions#getDc <em>Dc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Dc</em>'.
	 * @see org.LexGrid.emf.valueDomains.VdVersions#getDc()
	 * @see #getVdVersions()
	 * @generated
	 */
	EAttribute getVdVersions_Dc();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.valueDomains.DocumentRoot <em>Document Root</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Document Root</em>'.
	 * @see org.LexGrid.emf.valueDomains.DocumentRoot
	 * @generated
	 */
	EClass getDocumentRoot();

	/**
	 * Returns the meta object for the attribute list '{@link org.LexGrid.emf.valueDomains.DocumentRoot#getMixed <em>Mixed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Mixed</em>'.
	 * @see org.LexGrid.emf.valueDomains.DocumentRoot#getMixed()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EAttribute getDocumentRoot_Mixed();

	/**
	 * Returns the meta object for the map '{@link org.LexGrid.emf.valueDomains.DocumentRoot#getXMLNSPrefixMap <em>XMLNS Prefix Map</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>XMLNS Prefix Map</em>'.
	 * @see org.LexGrid.emf.valueDomains.DocumentRoot#getXMLNSPrefixMap()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_XMLNSPrefixMap();

	/**
	 * Returns the meta object for the map '{@link org.LexGrid.emf.valueDomains.DocumentRoot#getXSISchemaLocation <em>XSI Schema Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>XSI Schema Location</em>'.
	 * @see org.LexGrid.emf.valueDomains.DocumentRoot#getXSISchemaLocation()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_XSISchemaLocation();

	/**
	 * Returns the meta object for the containment reference '{@link org.LexGrid.emf.valueDomains.DocumentRoot#getValueDomain <em>Value Domain</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Value Domain</em>'.
	 * @see org.LexGrid.emf.valueDomains.DocumentRoot#getValueDomain()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_ValueDomain();

	/**
	 * Returns the meta object for the containment reference '{@link org.LexGrid.emf.valueDomains.DocumentRoot#getValueDomains <em>Value Domains</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Value Domains</em>'.
	 * @see org.LexGrid.emf.valueDomains.DocumentRoot#getValueDomains()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_ValueDomains();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	ValuedomainsFactory getValuedomainsFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.valueDomains.impl.MappingsImpl <em>Mappings</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.valueDomains.impl.MappingsImpl
		 * @see org.LexGrid.emf.valueDomains.impl.ValuedomainsPackageImpl#getMappings()
		 * @generated
		 */
		EClass MAPPINGS = eINSTANCE.getMappings();

		/**
		 * The meta object literal for the '<em><b>Supported Coding Scheme</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MAPPINGS__SUPPORTED_CODING_SCHEME = eINSTANCE.getMappings_SupportedCodingScheme();

		/**
		 * The meta object literal for the '<em><b>Supported Source</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MAPPINGS__SUPPORTED_SOURCE = eINSTANCE.getMappings_SupportedSource();

		/**
		 * The meta object literal for the '<em><b>Supported Language</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MAPPINGS__SUPPORTED_LANGUAGE = eINSTANCE.getMappings_SupportedLanguage();

		/**
		 * The meta object literal for the '<em><b>Supported Context</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MAPPINGS__SUPPORTED_CONTEXT = eINSTANCE.getMappings_SupportedContext();

		/**
		 * The meta object literal for the '<em><b>Dc</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MAPPINGS__DC = eINSTANCE.getMappings_Dc();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.valueDomains.impl.PickListEntryImpl <em>Pick List Entry</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.valueDomains.impl.PickListEntryImpl
		 * @see org.LexGrid.emf.valueDomains.impl.ValuedomainsPackageImpl#getPickListEntry()
		 * @generated
		 */
		EClass PICK_LIST_ENTRY = eINSTANCE.getPickListEntry();

		/**
		 * The meta object literal for the '<em><b>Pick Text</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PICK_LIST_ENTRY__PICK_TEXT = eINSTANCE.getPickListEntry_PickText();

		/**
		 * The meta object literal for the '<em><b>Pick Context</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PICK_LIST_ENTRY__PICK_CONTEXT = eINSTANCE.getPickListEntry_PickContext();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PICK_LIST_ENTRY__ID = eINSTANCE.getPickListEntry_Id();

		/**
		 * The meta object literal for the '<em><b>Is Default</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PICK_LIST_ENTRY__IS_DEFAULT = eINSTANCE.getPickListEntry_IsDefault();

		/**
		 * The meta object literal for the '<em><b>Language</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PICK_LIST_ENTRY__LANGUAGE = eINSTANCE.getPickListEntry_Language();

		/**
		 * The meta object literal for the '<em><b>Match If No Context</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PICK_LIST_ENTRY__MATCH_IF_NO_CONTEXT = eINSTANCE.getPickListEntry_MatchIfNoContext();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.valueDomains.impl.ValueDomainEntryImpl <em>Value Domain Entry</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.valueDomains.impl.ValueDomainEntryImpl
		 * @see org.LexGrid.emf.valueDomains.impl.ValuedomainsPackageImpl#getValueDomainEntry()
		 * @generated
		 */
		EClass VALUE_DOMAIN_ENTRY = eINSTANCE.getValueDomainEntry();

		/**
		 * The meta object literal for the '<em><b>Pick List Entry</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VALUE_DOMAIN_ENTRY__PICK_LIST_ENTRY = eINSTANCE.getValueDomainEntry_PickListEntry();

		/**
		 * The meta object literal for the '<em><b>Coding Scheme</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VALUE_DOMAIN_ENTRY__CODING_SCHEME = eINSTANCE.getValueDomainEntry_CodingScheme();

		/**
		 * The meta object literal for the '<em><b>Concept Code</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VALUE_DOMAIN_ENTRY__CONCEPT_CODE = eINSTANCE.getValueDomainEntry_ConceptCode();

		/**
		 * The meta object literal for the '<em><b>Entry Order</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VALUE_DOMAIN_ENTRY__ENTRY_ORDER = eINSTANCE.getValueDomainEntry_EntryOrder();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VALUE_DOMAIN_ENTRY__ID = eINSTANCE.getValueDomainEntry_Id();

		/**
		 * The meta object literal for the '<em><b>Include Children</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VALUE_DOMAIN_ENTRY__INCLUDE_CHILDREN = eINSTANCE.getValueDomainEntry_IncludeChildren();

		/**
		 * The meta object literal for the '<em><b>Is Selectable</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VALUE_DOMAIN_ENTRY__IS_SELECTABLE = eINSTANCE.getValueDomainEntry_IsSelectable();

		/**
		 * The meta object literal for the '<em><b>Test Subsumption</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VALUE_DOMAIN_ENTRY__TEST_SUBSUMPTION = eINSTANCE.getValueDomainEntry_TestSubsumption();

		/**
		 * The meta object literal for the '<em><b>Property</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VALUE_DOMAIN_ENTRY__PROPERTY = eINSTANCE.getValueDomainEntry_Property();

		/**
		 * The meta object literal for the '<em><b>Includes Value Domain</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VALUE_DOMAIN_ENTRY__INCLUDES_VALUE_DOMAIN = eINSTANCE.getValueDomainEntry_IncludesValueDomain();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.valueDomains.impl.ValueDomainsImpl <em>Value Domains</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.valueDomains.impl.ValueDomainsImpl
		 * @see org.LexGrid.emf.valueDomains.impl.ValuedomainsPackageImpl#getValueDomains()
		 * @generated
		 */
		EClass VALUE_DOMAINS = eINSTANCE.getValueDomains();

		/**
		 * The meta object literal for the '<em><b>Value Domain</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VALUE_DOMAINS__VALUE_DOMAIN = eINSTANCE.getValueDomains_ValueDomain();

		/**
		 * The meta object literal for the '<em><b>Dc</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VALUE_DOMAINS__DC = eINSTANCE.getValueDomains_Dc();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.valueDomains.impl.ValueDomainTypeImpl <em>Value Domain Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.valueDomains.impl.ValueDomainTypeImpl
		 * @see org.LexGrid.emf.valueDomains.impl.ValuedomainsPackageImpl#getValueDomainType()
		 * @generated
		 */
		EClass VALUE_DOMAIN_TYPE = eINSTANCE.getValueDomainType();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VALUE_DOMAIN_TYPE__SOURCE = eINSTANCE.getValueDomainType_Source();

		/**
		 * The meta object literal for the '<em><b>Mappings</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VALUE_DOMAIN_TYPE__MAPPINGS = eINSTANCE.getValueDomainType_Mappings();

		/**
		 * The meta object literal for the '<em><b>Properties</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VALUE_DOMAIN_TYPE__PROPERTIES = eINSTANCE.getValueDomainType_Properties();

		/**
		 * The meta object literal for the '<em><b>Domain Concept</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VALUE_DOMAIN_TYPE__DOMAIN_CONCEPT = eINSTANCE.getValueDomainType_DomainConcept();

		/**
		 * The meta object literal for the '<em><b>Versions</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VALUE_DOMAIN_TYPE__VERSIONS = eINSTANCE.getValueDomainType_Versions();

		/**
		 * The meta object literal for the '<em><b>Default Coding Scheme</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VALUE_DOMAIN_TYPE__DEFAULT_CODING_SCHEME = eINSTANCE.getValueDomainType_DefaultCodingScheme();

		/**
		 * The meta object literal for the '<em><b>Default Language</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VALUE_DOMAIN_TYPE__DEFAULT_LANGUAGE = eINSTANCE.getValueDomainType_DefaultLanguage();

		/**
		 * The meta object literal for the '<em><b>Registered Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VALUE_DOMAIN_TYPE__REGISTERED_NAME = eINSTANCE.getValueDomainType_RegisteredName();

		/**
		 * The meta object literal for the '<em><b>Represents Value Domain Version</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VALUE_DOMAIN_TYPE__REPRESENTS_VALUE_DOMAIN_VERSION = eINSTANCE
				.getValueDomainType_RepresentsValueDomainVersion();

		/**
		 * The meta object literal for the '<em><b>Value Domain</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VALUE_DOMAIN_TYPE__VALUE_DOMAIN = eINSTANCE.getValueDomainType_ValueDomain();

		/**
		 * The meta object literal for the '<em><b>Represents Realm Or Context</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VALUE_DOMAIN_TYPE__REPRESENTS_REALM_OR_CONTEXT = eINSTANCE
				.getValueDomainType_RepresentsRealmOrContext();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.valueDomains.impl.ValueDomainVersionImpl <em>Value Domain Version</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.valueDomains.impl.ValueDomainVersionImpl
		 * @see org.LexGrid.emf.valueDomains.impl.ValuedomainsPackageImpl#getValueDomainVersion()
		 * @generated
		 */
		EClass VALUE_DOMAIN_VERSION = eINSTANCE.getValueDomainVersion();

		/**
		 * The meta object literal for the '<em><b>Domain Concept</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VALUE_DOMAIN_VERSION__DOMAIN_CONCEPT = eINSTANCE.getValueDomainVersion_DomainConcept();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.valueDomains.impl.VdVersionsImpl <em>Vd Versions</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.valueDomains.impl.VdVersionsImpl
		 * @see org.LexGrid.emf.valueDomains.impl.ValuedomainsPackageImpl#getVdVersions()
		 * @generated
		 */
		EClass VD_VERSIONS = eINSTANCE.getVdVersions();

		/**
		 * The meta object literal for the '<em><b>Version</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VD_VERSIONS__VERSION = eINSTANCE.getVdVersions_Version();

		/**
		 * The meta object literal for the '<em><b>Dc</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VD_VERSIONS__DC = eINSTANCE.getVdVersions_Dc();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.valueDomains.impl.DocumentRootImpl <em>Document Root</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.valueDomains.impl.DocumentRootImpl
		 * @see org.LexGrid.emf.valueDomains.impl.ValuedomainsPackageImpl#getDocumentRoot()
		 * @generated
		 */
		EClass DOCUMENT_ROOT = eINSTANCE.getDocumentRoot();

		/**
		 * The meta object literal for the '<em><b>Mixed</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCUMENT_ROOT__MIXED = eINSTANCE.getDocumentRoot_Mixed();

		/**
		 * The meta object literal for the '<em><b>XMLNS Prefix Map</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__XMLNS_PREFIX_MAP = eINSTANCE.getDocumentRoot_XMLNSPrefixMap();

		/**
		 * The meta object literal for the '<em><b>XSI Schema Location</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = eINSTANCE.getDocumentRoot_XSISchemaLocation();

		/**
		 * The meta object literal for the '<em><b>Value Domain</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__VALUE_DOMAIN = eINSTANCE.getDocumentRoot_ValueDomain();

		/**
		 * The meta object literal for the '<em><b>Value Domains</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__VALUE_DOMAINS = eINSTANCE.getDocumentRoot_ValueDomains();

	}

} //ValuedomainsPackage