/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.versions;

import java.util.Date;

import org.LexGrid.emf.commonTypes.Describable;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Entity Version</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A static snapshot of the given entity.
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.LexGrid.emf.versions.EntityVersion#getChangeDocumentation <em>Change Documentation</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.EntityVersion#getChangeInstructions <em>Change Instructions</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.EntityVersion#getEffectiveDate <em>Effective Date</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.EntityVersion#isIsComplete <em>Is Complete</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.EntityVersion#getReleaseURN <em>Release URN</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.EntityVersion#getVersion <em>Version</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.EntityVersion#getVersionDate <em>Version Date</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.EntityVersion#getVersionOrder <em>Version Order</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.LexGrid.emf.versions.VersionsPackage#getEntityVersion()
 * @model extendedMetaData="name='entityVersion' kind='elementOnly'"
 * @generated
 */
public interface EntityVersion extends Describable {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Returns the value of the '<em><b>Change Documentation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * User documentation about this particular change. Format is coding scheme
	 *                                                         specific.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Change Documentation</em>' attribute.
	 * @see #setChangeDocumentation(String)
	 * @see org.LexGrid.emf.versions.VersionsPackage#getEntityVersion_ChangeDocumentation()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.TsCaseIgnoreDirectoryString"
	 *        extendedMetaData="kind='element' name='changeDocumentation' namespace='##targetNamespace'"
	 * @generated
	 */
	String getChangeDocumentation();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.versions.EntityVersion#getChangeDocumentation <em>Change Documentation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Change Documentation</em>' attribute.
	 * @see #getChangeDocumentation()
	 * @generated
	 */
	void setChangeDocumentation(String value);

	/**
	 * Returns the value of the '<em><b>Change Instructions</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Formal or semi-formal instructions on how to apply this change.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Change Instructions</em>' attribute.
	 * @see #setChangeInstructions(String)
	 * @see org.LexGrid.emf.versions.VersionsPackage#getEntityVersion_ChangeInstructions()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.TsCaseIgnoreDirectoryString"
	 *        extendedMetaData="kind='element' name='changeInstructions' namespace='##targetNamespace'"
	 * @generated
	 */
	String getChangeInstructions();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.versions.EntityVersion#getChangeInstructions <em>Change Instructions</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Change Instructions</em>' attribute.
	 * @see #getChangeInstructions()
	 * @generated
	 */
	void setChangeInstructions(String value);

	/**
	 * Returns the value of the '<em><b>Effective Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The start date for which this version is operative (considered active).
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Effective Date</em>' attribute.
	 * @see #setEffectiveDate(Date)
	 * @see org.LexGrid.emf.versions.VersionsPackage#getEntityVersion_EffectiveDate()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.TsTimestamp"
	 *        extendedMetaData="kind='attribute' name='effectiveDate'"
	 * @generated
	 */
	Date getEffectiveDate();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.versions.EntityVersion#getEffectiveDate <em>Effective Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Effective Date</em>' attribute.
	 * @see #getEffectiveDate()
	 * @generated
	 */
	void setEffectiveDate(Date value);

	/**
	 * Returns the value of the '<em><b>Is Complete</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * If true, this entity represents a complete copy of the particular release. If false, it only
	 *                                                         carries a delta.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Is Complete</em>' attribute.
	 * @see #isSetIsComplete()
	 * @see #unsetIsComplete()
	 * @see #setIsComplete(boolean)
	 * @see org.LexGrid.emf.versions.VersionsPackage#getEntityVersion_IsComplete()
	 * @model unique="false" unsettable="true" dataType="org.LexGrid.emf.builtins.TsBoolean" required="true"
	 *        extendedMetaData="kind='attribute' name='isComplete'"
	 * @generated
	 */
	boolean isIsComplete();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.versions.EntityVersion#isIsComplete <em>Is Complete</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Complete</em>' attribute.
	 * @see #isSetIsComplete()
	 * @see #unsetIsComplete()
	 * @see #isIsComplete()
	 * @generated
	 */
	void setIsComplete(boolean value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.versions.EntityVersion#isIsComplete <em>Is Complete</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsComplete()
	 * @see #isIsComplete()
	 * @see #setIsComplete(boolean)
	 * @generated
	 */
	void unsetIsComplete();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.versions.EntityVersion#isIsComplete <em>Is Complete</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Complete</em>' attribute is set.
	 * @see #unsetIsComplete()
	 * @see #isIsComplete()
	 * @see #setIsComplete(boolean)
	 * @generated
	 */
	boolean isSetIsComplete();

	/**
	 * Returns the value of the '<em><b>Version</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The unique version identifier.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Version</em>' attribute.
	 * @see #setVersion(String)
	 * @see org.LexGrid.emf.versions.VersionsPackage#getEntityVersion_Version()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.Version" required="true"
	 *        extendedMetaData="kind='attribute' name='version'"
	 * @generated
	 */
	String getVersion();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.versions.EntityVersion#getVersion <em>Version</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Version</em>' attribute.
	 * @see #getVersion()
	 * @generated
	 */
	void setVersion(String value);

	/**
	 * Returns the value of the '<em><b>Version Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The end date for which this version is operative (considered commited).
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Version Date</em>' attribute.
	 * @see #setVersionDate(Date)
	 * @see org.LexGrid.emf.versions.VersionsPackage#getEntityVersion_VersionDate()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.TsTimestamp"
	 *        extendedMetaData="kind='attribute' name='versionDate'"
	 * @generated
	 */
	Date getVersionDate();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.versions.EntityVersion#getVersionDate <em>Version Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Version Date</em>' attribute.
	 * @see #getVersionDate()
	 * @generated
	 */
	void setVersionDate(Date value);

	/**
	 * Returns the value of the '<em><b>Version Order</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The relative order of this version within the surrounding container.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Version Order</em>' attribute.
	 * @see #setVersionOrder(int)
	 * @see org.LexGrid.emf.versions.VersionsPackage#getEntityVersion_VersionOrder()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.EntryOrder" required="true"
	 *        extendedMetaData="kind='attribute' name='versionOrder'"
	 * @generated
	 */
	int getVersionOrder();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.versions.EntityVersion#getVersionOrder <em>Version Order</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Version Order</em>' attribute.
	 * @see #getVersionOrder()
	 * @generated
	 */
	void setVersionOrder(int value);

	/**
	 * Returns the value of the '<em><b>Release URN</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * URN of the release from which this version is drawn.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Release URN</em>' attribute.
	 * @see #setReleaseURN(String)
	 * @see org.LexGrid.emf.versions.VersionsPackage#getEntityVersion_ReleaseURN()
	 * @model unique="false" dataType="org.LexGrid.emf.naming.URN"
	 *        extendedMetaData="kind='attribute' name='releaseURN'"
	 * @generated
	 */
	String getReleaseURN();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.versions.EntityVersion#getReleaseURN <em>Release URN</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Release URN</em>' attribute.
	 * @see #getReleaseURN()
	 * @generated
	 */
	void setReleaseURN(String value);

} // EntityVersion