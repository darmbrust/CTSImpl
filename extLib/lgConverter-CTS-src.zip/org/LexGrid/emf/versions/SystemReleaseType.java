/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.versions;

import java.util.Date;

import org.LexGrid.emf.commonTypes.Describable;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>System Release</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.LexGrid.emf.versions.SystemReleaseType#getReleaseDefines <em>Release Defines</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.SystemReleaseType#getReleaseContains <em>Release Contains</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.SystemReleaseType#getReleaseReferences <em>Release References</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.SystemReleaseType#getBasedOnRelease <em>Based On Release</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.SystemReleaseType#getReleaseAgency <em>Release Agency</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.SystemReleaseType#getReleaseDate <em>Release Date</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.SystemReleaseType#getReleaseId <em>Release Id</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.SystemReleaseType#getReleaseURN <em>Release URN</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.LexGrid.emf.versions.VersionsPackage#getSystemReleaseType()
 * @model extendedMetaData="name='systemRelease_._type' kind='elementOnly'"
 * @generated
 */
public interface SystemReleaseType extends Describable {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Returns the value of the '<em><b>Release Defines</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The names, identifiers and versions of the code systems and value domains
	 *                                                                         defined by this release.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Release Defines</em>' containment reference.
	 * @see #setReleaseDefines(ReferenceSet)
	 * @see org.LexGrid.emf.versions.VersionsPackage#getSystemReleaseType_ReleaseDefines()
	 * @model containment="true" required="true"
	 *        extendedMetaData="kind='element' name='releaseDefines' namespace='##targetNamespace'"
	 * @generated
	 */
	ReferenceSet getReleaseDefines();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.versions.SystemReleaseType#getReleaseDefines <em>Release Defines</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Release Defines</em>' containment reference.
	 * @see #getReleaseDefines()
	 * @generated
	 */
	void setReleaseDefines(ReferenceSet value);

	/**
	 * Returns the value of the '<em><b>Release Contains</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The names, identifiers and versions of the code systems copied into but not
	 *                                                                         defined in this release.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Release Contains</em>' containment reference.
	 * @see #setReleaseContains(ReferenceSet)
	 * @see org.LexGrid.emf.versions.VersionsPackage#getSystemReleaseType_ReleaseContains()
	 * @model containment="true" required="true"
	 *        extendedMetaData="kind='element' name='releaseContains' namespace='##targetNamespace'"
	 * @generated
	 */
	ReferenceSet getReleaseContains();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.versions.SystemReleaseType#getReleaseContains <em>Release Contains</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Release Contains</em>' containment reference.
	 * @see #getReleaseContains()
	 * @generated
	 */
	void setReleaseContains(ReferenceSet value);

	/**
	 * Returns the value of the '<em><b>Release References</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The names, identifiers and versions of the code systems and value domains
	 *                                                                         referenced this release.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Release References</em>' containment reference.
	 * @see #setReleaseReferences(ReferenceSet)
	 * @see org.LexGrid.emf.versions.VersionsPackage#getSystemReleaseType_ReleaseReferences()
	 * @model containment="true" required="true"
	 *        extendedMetaData="kind='element' name='releaseReferences' namespace='##targetNamespace'"
	 * @generated
	 */
	ReferenceSet getReleaseReferences();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.versions.SystemReleaseType#getReleaseReferences <em>Release References</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Release References</em>' containment reference.
	 * @see #getReleaseReferences()
	 * @generated
	 */
	void setReleaseReferences(ReferenceSet value);

	/**
	 * Returns the value of the '<em><b>Based On Release</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Release to which this set of changes was applied to yield the containing release.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Based On Release</em>' attribute.
	 * @see #setBasedOnRelease(String)
	 * @see org.LexGrid.emf.versions.VersionsPackage#getSystemReleaseType_BasedOnRelease()
	 * @model unique="false" dataType="org.LexGrid.emf.naming.URN"
	 *        extendedMetaData="kind='attribute' name='basedOnRelease'"
	 * @generated
	 */
	String getBasedOnRelease();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.versions.SystemReleaseType#getBasedOnRelease <em>Based On Release</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Based On Release</em>' attribute.
	 * @see #getBasedOnRelease()
	 * @generated
	 */
	void setBasedOnRelease(String value);

	/**
	 * Returns the value of the '<em><b>Release Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The globally unique name of a system release.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Release Id</em>' attribute.
	 * @see #setReleaseId(String)
	 * @see org.LexGrid.emf.versions.VersionsPackage#getSystemReleaseType_ReleaseId()
	 * @model unique="false" dataType="org.LexGrid.emf.naming.URN" required="true"
	 *        extendedMetaData="kind='attribute' name='releaseId'"
	 * @generated
	 */
	String getReleaseId();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.versions.SystemReleaseType#getReleaseId <em>Release Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Release Id</em>' attribute.
	 * @see #getReleaseId()
	 * @generated
	 */
	void setReleaseId(String value);

	/**
	 * Returns the value of the '<em><b>Release Agency</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Agency responsible for a release.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Release Agency</em>' attribute.
	 * @see #setReleaseAgency(String)
	 * @see org.LexGrid.emf.versions.VersionsPackage#getSystemReleaseType_ReleaseAgency()
	 * @model unique="false" dataType="org.LexGrid.emf.naming.URN" required="true"
	 *        extendedMetaData="kind='attribute' name='releaseAgency'"
	 * @generated
	 */
	String getReleaseAgency();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.versions.SystemReleaseType#getReleaseAgency <em>Release Agency</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Release Agency</em>' attribute.
	 * @see #getReleaseAgency()
	 * @generated
	 */
	void setReleaseAgency(String value);

	/**
	 * Returns the value of the '<em><b>Release URN</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The URN of a system release.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Release URN</em>' attribute.
	 * @see #setReleaseURN(String)
	 * @see org.LexGrid.emf.versions.VersionsPackage#getSystemReleaseType_ReleaseURN()
	 * @model unique="false" dataType="org.LexGrid.emf.naming.URN" required="true"
	 *        extendedMetaData="kind='attribute' name='releaseURN'"
	 * @generated
	 */
	String getReleaseURN();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.versions.SystemReleaseType#getReleaseURN <em>Release URN</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Release URN</em>' attribute.
	 * @see #getReleaseURN()
	 * @generated
	 */
	void setReleaseURN(String value);

	/**
	 * Returns the value of the '<em><b>Release Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The date time of a release.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Release Date</em>' attribute.
	 * @see #setReleaseDate(Date)
	 * @see org.LexGrid.emf.versions.VersionsPackage#getSystemReleaseType_ReleaseDate()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.TsTimestamp" required="true"
	 *        extendedMetaData="kind='attribute' name='releaseDate'"
	 * @generated
	 */
	Date getReleaseDate();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.versions.SystemReleaseType#getReleaseDate <em>Release Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Release Date</em>' attribute.
	 * @see #getReleaseDate()
	 * @generated
	 */
	void setReleaseDate(Date value);

} // SystemReleaseType