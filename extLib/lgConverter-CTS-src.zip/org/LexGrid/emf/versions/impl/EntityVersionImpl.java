/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.versions.impl;

import java.util.Date;

import org.LexGrid.emf.commonTypes.impl.DescribableImpl;
import org.LexGrid.emf.versions.EntityVersion;
import org.LexGrid.emf.versions.VersionsPackage;
import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Entity Version</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.LexGrid.emf.versions.impl.EntityVersionImpl#getChangeDocumentation <em>Change Documentation</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.impl.EntityVersionImpl#getChangeInstructions <em>Change Instructions</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.impl.EntityVersionImpl#getEffectiveDate <em>Effective Date</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.impl.EntityVersionImpl#isIsComplete <em>Is Complete</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.impl.EntityVersionImpl#getReleaseURN <em>Release URN</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.impl.EntityVersionImpl#getVersion <em>Version</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.impl.EntityVersionImpl#getVersionDate <em>Version Date</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.impl.EntityVersionImpl#getVersionOrder <em>Version Order</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class EntityVersionImpl extends DescribableImpl implements EntityVersion {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EntityVersionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return VersionsPackage.Literals.ENTITY_VERSION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getChangeDocumentation() {
		return (String) eGet(VersionsPackage.Literals.ENTITY_VERSION__CHANGE_DOCUMENTATION, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setChangeDocumentation(String newChangeDocumentation) {
		eSet(VersionsPackage.Literals.ENTITY_VERSION__CHANGE_DOCUMENTATION, newChangeDocumentation);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getChangeInstructions() {
		return (String) eGet(VersionsPackage.Literals.ENTITY_VERSION__CHANGE_INSTRUCTIONS, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setChangeInstructions(String newChangeInstructions) {
		eSet(VersionsPackage.Literals.ENTITY_VERSION__CHANGE_INSTRUCTIONS, newChangeInstructions);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Date getEffectiveDate() {
		return (Date) eGet(VersionsPackage.Literals.ENTITY_VERSION__EFFECTIVE_DATE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEffectiveDate(Date newEffectiveDate) {
		eSet(VersionsPackage.Literals.ENTITY_VERSION__EFFECTIVE_DATE, newEffectiveDate);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isIsComplete() {
		return ((Boolean) eGet(VersionsPackage.Literals.ENTITY_VERSION__IS_COMPLETE, true)).booleanValue();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsComplete(boolean newIsComplete) {
		eSet(VersionsPackage.Literals.ENTITY_VERSION__IS_COMPLETE, new Boolean(newIsComplete));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetIsComplete() {
		eUnset(VersionsPackage.Literals.ENTITY_VERSION__IS_COMPLETE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetIsComplete() {
		return eIsSet(VersionsPackage.Literals.ENTITY_VERSION__IS_COMPLETE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getVersion() {
		return (String) eGet(VersionsPackage.Literals.ENTITY_VERSION__VERSION, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVersion(String newVersion) {
		eSet(VersionsPackage.Literals.ENTITY_VERSION__VERSION, newVersion);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Date getVersionDate() {
		return (Date) eGet(VersionsPackage.Literals.ENTITY_VERSION__VERSION_DATE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVersionDate(Date newVersionDate) {
		eSet(VersionsPackage.Literals.ENTITY_VERSION__VERSION_DATE, newVersionDate);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getVersionOrder() {
		return ((Integer) eGet(VersionsPackage.Literals.ENTITY_VERSION__VERSION_ORDER, true)).intValue();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVersionOrder(int newVersionOrder) {
		eSet(VersionsPackage.Literals.ENTITY_VERSION__VERSION_ORDER, new Integer(newVersionOrder));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getReleaseURN() {
		return (String) eGet(VersionsPackage.Literals.ENTITY_VERSION__RELEASE_URN, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReleaseURN(String newReleaseURN) {
		eSet(VersionsPackage.Literals.ENTITY_VERSION__RELEASE_URN, newReleaseURN);
	}

} //EntityVersionImpl