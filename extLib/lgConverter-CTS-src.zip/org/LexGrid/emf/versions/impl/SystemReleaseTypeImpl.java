/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.versions.impl;

import java.util.Date;

import org.LexGrid.emf.commonTypes.impl.DescribableImpl;
import org.LexGrid.emf.versions.ReferenceSet;
import org.LexGrid.emf.versions.SystemReleaseType;
import org.LexGrid.emf.versions.VersionsPackage;
import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>System Release Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.LexGrid.emf.versions.impl.SystemReleaseTypeImpl#getReleaseDefines <em>Release Defines</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.impl.SystemReleaseTypeImpl#getReleaseContains <em>Release Contains</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.impl.SystemReleaseTypeImpl#getReleaseReferences <em>Release References</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.impl.SystemReleaseTypeImpl#getBasedOnRelease <em>Based On Release</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.impl.SystemReleaseTypeImpl#getReleaseAgency <em>Release Agency</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.impl.SystemReleaseTypeImpl#getReleaseDate <em>Release Date</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.impl.SystemReleaseTypeImpl#getReleaseId <em>Release Id</em>}</li>
 *   <li>{@link org.LexGrid.emf.versions.impl.SystemReleaseTypeImpl#getReleaseURN <em>Release URN</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class SystemReleaseTypeImpl extends DescribableImpl implements SystemReleaseType {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SystemReleaseTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return VersionsPackage.Literals.SYSTEM_RELEASE_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ReferenceSet getReleaseDefines() {
		return (ReferenceSet) eGet(VersionsPackage.Literals.SYSTEM_RELEASE_TYPE__RELEASE_DEFINES, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReleaseDefines(ReferenceSet newReleaseDefines) {
		eSet(VersionsPackage.Literals.SYSTEM_RELEASE_TYPE__RELEASE_DEFINES, newReleaseDefines);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ReferenceSet getReleaseContains() {
		return (ReferenceSet) eGet(VersionsPackage.Literals.SYSTEM_RELEASE_TYPE__RELEASE_CONTAINS, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReleaseContains(ReferenceSet newReleaseContains) {
		eSet(VersionsPackage.Literals.SYSTEM_RELEASE_TYPE__RELEASE_CONTAINS, newReleaseContains);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ReferenceSet getReleaseReferences() {
		return (ReferenceSet) eGet(VersionsPackage.Literals.SYSTEM_RELEASE_TYPE__RELEASE_REFERENCES, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReleaseReferences(ReferenceSet newReleaseReferences) {
		eSet(VersionsPackage.Literals.SYSTEM_RELEASE_TYPE__RELEASE_REFERENCES, newReleaseReferences);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getBasedOnRelease() {
		return (String) eGet(VersionsPackage.Literals.SYSTEM_RELEASE_TYPE__BASED_ON_RELEASE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBasedOnRelease(String newBasedOnRelease) {
		eSet(VersionsPackage.Literals.SYSTEM_RELEASE_TYPE__BASED_ON_RELEASE, newBasedOnRelease);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getReleaseAgency() {
		return (String) eGet(VersionsPackage.Literals.SYSTEM_RELEASE_TYPE__RELEASE_AGENCY, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReleaseAgency(String newReleaseAgency) {
		eSet(VersionsPackage.Literals.SYSTEM_RELEASE_TYPE__RELEASE_AGENCY, newReleaseAgency);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Date getReleaseDate() {
		return (Date) eGet(VersionsPackage.Literals.SYSTEM_RELEASE_TYPE__RELEASE_DATE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReleaseDate(Date newReleaseDate) {
		eSet(VersionsPackage.Literals.SYSTEM_RELEASE_TYPE__RELEASE_DATE, newReleaseDate);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getReleaseId() {
		return (String) eGet(VersionsPackage.Literals.SYSTEM_RELEASE_TYPE__RELEASE_ID, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReleaseId(String newReleaseId) {
		eSet(VersionsPackage.Literals.SYSTEM_RELEASE_TYPE__RELEASE_ID, newReleaseId);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getReleaseURN() {
		return (String) eGet(VersionsPackage.Literals.SYSTEM_RELEASE_TYPE__RELEASE_URN, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReleaseURN(String newReleaseURN) {
		eSet(VersionsPackage.Literals.SYSTEM_RELEASE_TYPE__RELEASE_URN, newReleaseURN);
	}

} //SystemReleaseTypeImpl