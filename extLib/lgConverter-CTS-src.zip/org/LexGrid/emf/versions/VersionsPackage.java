/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.versions;

import org.LexGrid.emf.commonTypes.CommontypesPackage;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * <!-- begin-model-doc -->
 * 
 * 			<h2 xmlns="http://LexGrid.org/schema/2006/01/LexGrid/builtins">Core data types for the lexical grid.</h2>
 * 		
 * These types need to be mapped to the appropriate implementation specific data types. The mapping in this package represents the XML
 * 			Schema data types mapping
 * LDAP specific types for appinfo annotation
 * Basic builtin types
 * <!-- end-model-doc -->
 * @see org.LexGrid.emf.versions.VersionsFactory
 * @model kind="package"
 * @generated
 */
public interface VersionsPackage extends EPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "versions";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://LexGrid.org/schema/2006/01/LexGrid/versions";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "lgVer";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	VersionsPackage eINSTANCE = org.LexGrid.emf.versions.impl.VersionsPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.versions.impl.EntityVersionImpl <em>Entity Version</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.versions.impl.EntityVersionImpl
	 * @see org.LexGrid.emf.versions.impl.VersionsPackageImpl#getEntityVersion()
	 * @generated
	 */
	int ENTITY_VERSION = 0;

	/**
	 * The feature id for the '<em><b>Entity Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_VERSION__ENTITY_DESCRIPTION = CommontypesPackage.DESCRIBABLE__ENTITY_DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Change Documentation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_VERSION__CHANGE_DOCUMENTATION = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Change Instructions</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_VERSION__CHANGE_INSTRUCTIONS = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Effective Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_VERSION__EFFECTIVE_DATE = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Is Complete</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_VERSION__IS_COMPLETE = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Release URN</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_VERSION__RELEASE_URN = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Version</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_VERSION__VERSION = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Version Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_VERSION__VERSION_DATE = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Version Order</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_VERSION__VERSION_ORDER = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 7;

	/**
	 * The number of structural features of the '<em>Entity Version</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_VERSION_FEATURE_COUNT = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 8;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.versions.impl.DocumentRootImpl <em>Document Root</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.versions.impl.DocumentRootImpl
	 * @see org.LexGrid.emf.versions.impl.VersionsPackageImpl#getDocumentRoot()
	 * @generated
	 */
	int DOCUMENT_ROOT = 1;

	/**
	 * The feature id for the '<em><b>Mixed</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__MIXED = 0;

	/**
	 * The feature id for the '<em><b>XMLNS Prefix Map</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__XMLNS_PREFIX_MAP = 1;

	/**
	 * The feature id for the '<em><b>XSI Schema Location</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = 2;

	/**
	 * The feature id for the '<em><b>System Release</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__SYSTEM_RELEASE = 3;

	/**
	 * The number of structural features of the '<em>Document Root</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.versions.impl.HistoryImpl <em>History</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.versions.impl.HistoryImpl
	 * @see org.LexGrid.emf.versions.impl.VersionsPackageImpl#getHistory()
	 * @generated
	 */
	int HISTORY = 2;

	/**
	 * The feature id for the '<em><b>System Release</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HISTORY__SYSTEM_RELEASE = 0;

	/**
	 * The feature id for the '<em><b>Dc</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HISTORY__DC = 1;

	/**
	 * The number of structural features of the '<em>History</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HISTORY_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.versions.impl.ReferenceSetImpl <em>Reference Set</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.versions.impl.ReferenceSetImpl
	 * @see org.LexGrid.emf.versions.impl.VersionsPackageImpl#getReferenceSet()
	 * @generated
	 */
	int REFERENCE_SET = 3;

	/**
	 * The feature id for the '<em><b>Coding Scheme Reference</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCE_SET__CODING_SCHEME_REFERENCE = 0;

	/**
	 * The feature id for the '<em><b>Value Domain Reference</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCE_SET__VALUE_DOMAIN_REFERENCE = 1;

	/**
	 * The number of structural features of the '<em>Reference Set</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCE_SET_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.versions.impl.SystemReleaseTypeImpl <em>System Release Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.versions.impl.SystemReleaseTypeImpl
	 * @see org.LexGrid.emf.versions.impl.VersionsPackageImpl#getSystemReleaseType()
	 * @generated
	 */
	int SYSTEM_RELEASE_TYPE = 4;

	/**
	 * The feature id for the '<em><b>Entity Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM_RELEASE_TYPE__ENTITY_DESCRIPTION = CommontypesPackage.DESCRIBABLE__ENTITY_DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Release Defines</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM_RELEASE_TYPE__RELEASE_DEFINES = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Release Contains</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM_RELEASE_TYPE__RELEASE_CONTAINS = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Release References</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM_RELEASE_TYPE__RELEASE_REFERENCES = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Based On Release</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM_RELEASE_TYPE__BASED_ON_RELEASE = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Release Agency</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM_RELEASE_TYPE__RELEASE_AGENCY = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Release Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM_RELEASE_TYPE__RELEASE_DATE = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Release Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM_RELEASE_TYPE__RELEASE_ID = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Release URN</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM_RELEASE_TYPE__RELEASE_URN = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 7;

	/**
	 * The number of structural features of the '<em>System Release Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM_RELEASE_TYPE_FEATURE_COUNT = CommontypesPackage.DESCRIBABLE_FEATURE_COUNT + 8;

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.versions.EntityVersion <em>Entity Version</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Entity Version</em>'.
	 * @see org.LexGrid.emf.versions.EntityVersion
	 * @generated
	 */
	EClass getEntityVersion();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.versions.EntityVersion#getChangeDocumentation <em>Change Documentation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Change Documentation</em>'.
	 * @see org.LexGrid.emf.versions.EntityVersion#getChangeDocumentation()
	 * @see #getEntityVersion()
	 * @generated
	 */
	EAttribute getEntityVersion_ChangeDocumentation();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.versions.EntityVersion#getChangeInstructions <em>Change Instructions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Change Instructions</em>'.
	 * @see org.LexGrid.emf.versions.EntityVersion#getChangeInstructions()
	 * @see #getEntityVersion()
	 * @generated
	 */
	EAttribute getEntityVersion_ChangeInstructions();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.versions.EntityVersion#getEffectiveDate <em>Effective Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Effective Date</em>'.
	 * @see org.LexGrid.emf.versions.EntityVersion#getEffectiveDate()
	 * @see #getEntityVersion()
	 * @generated
	 */
	EAttribute getEntityVersion_EffectiveDate();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.versions.EntityVersion#isIsComplete <em>Is Complete</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Complete</em>'.
	 * @see org.LexGrid.emf.versions.EntityVersion#isIsComplete()
	 * @see #getEntityVersion()
	 * @generated
	 */
	EAttribute getEntityVersion_IsComplete();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.versions.EntityVersion#getVersion <em>Version</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Version</em>'.
	 * @see org.LexGrid.emf.versions.EntityVersion#getVersion()
	 * @see #getEntityVersion()
	 * @generated
	 */
	EAttribute getEntityVersion_Version();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.versions.EntityVersion#getVersionDate <em>Version Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Version Date</em>'.
	 * @see org.LexGrid.emf.versions.EntityVersion#getVersionDate()
	 * @see #getEntityVersion()
	 * @generated
	 */
	EAttribute getEntityVersion_VersionDate();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.versions.EntityVersion#getVersionOrder <em>Version Order</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Version Order</em>'.
	 * @see org.LexGrid.emf.versions.EntityVersion#getVersionOrder()
	 * @see #getEntityVersion()
	 * @generated
	 */
	EAttribute getEntityVersion_VersionOrder();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.versions.DocumentRoot <em>Document Root</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Document Root</em>'.
	 * @see org.LexGrid.emf.versions.DocumentRoot
	 * @generated
	 */
	EClass getDocumentRoot();

	/**
	 * Returns the meta object for the attribute list '{@link org.LexGrid.emf.versions.DocumentRoot#getMixed <em>Mixed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Mixed</em>'.
	 * @see org.LexGrid.emf.versions.DocumentRoot#getMixed()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EAttribute getDocumentRoot_Mixed();

	/**
	 * Returns the meta object for the map '{@link org.LexGrid.emf.versions.DocumentRoot#getXMLNSPrefixMap <em>XMLNS Prefix Map</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>XMLNS Prefix Map</em>'.
	 * @see org.LexGrid.emf.versions.DocumentRoot#getXMLNSPrefixMap()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_XMLNSPrefixMap();

	/**
	 * Returns the meta object for the map '{@link org.LexGrid.emf.versions.DocumentRoot#getXSISchemaLocation <em>XSI Schema Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>XSI Schema Location</em>'.
	 * @see org.LexGrid.emf.versions.DocumentRoot#getXSISchemaLocation()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_XSISchemaLocation();

	/**
	 * Returns the meta object for the containment reference '{@link org.LexGrid.emf.versions.DocumentRoot#getSystemRelease <em>System Release</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>System Release</em>'.
	 * @see org.LexGrid.emf.versions.DocumentRoot#getSystemRelease()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_SystemRelease();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.versions.EntityVersion#getReleaseURN <em>Release URN</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Release URN</em>'.
	 * @see org.LexGrid.emf.versions.EntityVersion#getReleaseURN()
	 * @see #getEntityVersion()
	 * @generated
	 */
	EAttribute getEntityVersion_ReleaseURN();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.versions.History <em>History</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>History</em>'.
	 * @see org.LexGrid.emf.versions.History
	 * @generated
	 */
	EClass getHistory();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.versions.SystemReleaseType <em>System Release Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>System Release Type</em>'.
	 * @see org.LexGrid.emf.versions.SystemReleaseType
	 * @generated
	 */
	EClass getSystemReleaseType();

	/**
	 * Returns the meta object for the containment reference '{@link org.LexGrid.emf.versions.SystemReleaseType#getReleaseDefines <em>Release Defines</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Release Defines</em>'.
	 * @see org.LexGrid.emf.versions.SystemReleaseType#getReleaseDefines()
	 * @see #getSystemReleaseType()
	 * @generated
	 */
	EReference getSystemReleaseType_ReleaseDefines();

	/**
	 * Returns the meta object for the containment reference '{@link org.LexGrid.emf.versions.SystemReleaseType#getReleaseContains <em>Release Contains</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Release Contains</em>'.
	 * @see org.LexGrid.emf.versions.SystemReleaseType#getReleaseContains()
	 * @see #getSystemReleaseType()
	 * @generated
	 */
	EReference getSystemReleaseType_ReleaseContains();

	/**
	 * Returns the meta object for the containment reference '{@link org.LexGrid.emf.versions.SystemReleaseType#getReleaseReferences <em>Release References</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Release References</em>'.
	 * @see org.LexGrid.emf.versions.SystemReleaseType#getReleaseReferences()
	 * @see #getSystemReleaseType()
	 * @generated
	 */
	EReference getSystemReleaseType_ReleaseReferences();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.versions.SystemReleaseType#getBasedOnRelease <em>Based On Release</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Based On Release</em>'.
	 * @see org.LexGrid.emf.versions.SystemReleaseType#getBasedOnRelease()
	 * @see #getSystemReleaseType()
	 * @generated
	 */
	EAttribute getSystemReleaseType_BasedOnRelease();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.versions.SystemReleaseType#getReleaseAgency <em>Release Agency</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Release Agency</em>'.
	 * @see org.LexGrid.emf.versions.SystemReleaseType#getReleaseAgency()
	 * @see #getSystemReleaseType()
	 * @generated
	 */
	EAttribute getSystemReleaseType_ReleaseAgency();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.versions.SystemReleaseType#getReleaseDate <em>Release Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Release Date</em>'.
	 * @see org.LexGrid.emf.versions.SystemReleaseType#getReleaseDate()
	 * @see #getSystemReleaseType()
	 * @generated
	 */
	EAttribute getSystemReleaseType_ReleaseDate();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.versions.SystemReleaseType#getReleaseId <em>Release Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Release Id</em>'.
	 * @see org.LexGrid.emf.versions.SystemReleaseType#getReleaseId()
	 * @see #getSystemReleaseType()
	 * @generated
	 */
	EAttribute getSystemReleaseType_ReleaseId();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.versions.SystemReleaseType#getReleaseURN <em>Release URN</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Release URN</em>'.
	 * @see org.LexGrid.emf.versions.SystemReleaseType#getReleaseURN()
	 * @see #getSystemReleaseType()
	 * @generated
	 */
	EAttribute getSystemReleaseType_ReleaseURN();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.versions.History#getDc <em>Dc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Dc</em>'.
	 * @see org.LexGrid.emf.versions.History#getDc()
	 * @see #getHistory()
	 * @generated
	 */
	EAttribute getHistory_Dc();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.versions.ReferenceSet <em>Reference Set</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Reference Set</em>'.
	 * @see org.LexGrid.emf.versions.ReferenceSet
	 * @generated
	 */
	EClass getReferenceSet();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.versions.ReferenceSet#getCodingSchemeReference <em>Coding Scheme Reference</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Coding Scheme Reference</em>'.
	 * @see org.LexGrid.emf.versions.ReferenceSet#getCodingSchemeReference()
	 * @see #getReferenceSet()
	 * @generated
	 */
	EReference getReferenceSet_CodingSchemeReference();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.versions.ReferenceSet#getValueDomainReference <em>Value Domain Reference</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Value Domain Reference</em>'.
	 * @see org.LexGrid.emf.versions.ReferenceSet#getValueDomainReference()
	 * @see #getReferenceSet()
	 * @generated
	 */
	EReference getReferenceSet_ValueDomainReference();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.versions.History#getSystemRelease <em>System Release</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>System Release</em>'.
	 * @see org.LexGrid.emf.versions.History#getSystemRelease()
	 * @see #getHistory()
	 * @generated
	 */
	EReference getHistory_SystemRelease();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	VersionsFactory getVersionsFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.versions.impl.EntityVersionImpl <em>Entity Version</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.versions.impl.EntityVersionImpl
		 * @see org.LexGrid.emf.versions.impl.VersionsPackageImpl#getEntityVersion()
		 * @generated
		 */
		EClass ENTITY_VERSION = eINSTANCE.getEntityVersion();

		/**
		 * The meta object literal for the '<em><b>Change Documentation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENTITY_VERSION__CHANGE_DOCUMENTATION = eINSTANCE.getEntityVersion_ChangeDocumentation();

		/**
		 * The meta object literal for the '<em><b>Change Instructions</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENTITY_VERSION__CHANGE_INSTRUCTIONS = eINSTANCE.getEntityVersion_ChangeInstructions();

		/**
		 * The meta object literal for the '<em><b>Effective Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENTITY_VERSION__EFFECTIVE_DATE = eINSTANCE.getEntityVersion_EffectiveDate();

		/**
		 * The meta object literal for the '<em><b>Is Complete</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENTITY_VERSION__IS_COMPLETE = eINSTANCE.getEntityVersion_IsComplete();

		/**
		 * The meta object literal for the '<em><b>Release URN</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENTITY_VERSION__RELEASE_URN = eINSTANCE.getEntityVersion_ReleaseURN();

		/**
		 * The meta object literal for the '<em><b>Version</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENTITY_VERSION__VERSION = eINSTANCE.getEntityVersion_Version();

		/**
		 * The meta object literal for the '<em><b>Version Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENTITY_VERSION__VERSION_DATE = eINSTANCE.getEntityVersion_VersionDate();

		/**
		 * The meta object literal for the '<em><b>Version Order</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENTITY_VERSION__VERSION_ORDER = eINSTANCE.getEntityVersion_VersionOrder();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.versions.impl.DocumentRootImpl <em>Document Root</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.versions.impl.DocumentRootImpl
		 * @see org.LexGrid.emf.versions.impl.VersionsPackageImpl#getDocumentRoot()
		 * @generated
		 */
		EClass DOCUMENT_ROOT = eINSTANCE.getDocumentRoot();

		/**
		 * The meta object literal for the '<em><b>Mixed</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCUMENT_ROOT__MIXED = eINSTANCE.getDocumentRoot_Mixed();

		/**
		 * The meta object literal for the '<em><b>XMLNS Prefix Map</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__XMLNS_PREFIX_MAP = eINSTANCE.getDocumentRoot_XMLNSPrefixMap();

		/**
		 * The meta object literal for the '<em><b>XSI Schema Location</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = eINSTANCE.getDocumentRoot_XSISchemaLocation();

		/**
		 * The meta object literal for the '<em><b>System Release</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__SYSTEM_RELEASE = eINSTANCE.getDocumentRoot_SystemRelease();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.versions.impl.HistoryImpl <em>History</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.versions.impl.HistoryImpl
		 * @see org.LexGrid.emf.versions.impl.VersionsPackageImpl#getHistory()
		 * @generated
		 */
		EClass HISTORY = eINSTANCE.getHistory();

		/**
		 * The meta object literal for the '<em><b>System Release</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HISTORY__SYSTEM_RELEASE = eINSTANCE.getHistory_SystemRelease();

		/**
		 * The meta object literal for the '<em><b>Dc</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HISTORY__DC = eINSTANCE.getHistory_Dc();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.versions.impl.ReferenceSetImpl <em>Reference Set</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.versions.impl.ReferenceSetImpl
		 * @see org.LexGrid.emf.versions.impl.VersionsPackageImpl#getReferenceSet()
		 * @generated
		 */
		EClass REFERENCE_SET = eINSTANCE.getReferenceSet();

		/**
		 * The meta object literal for the '<em><b>Coding Scheme Reference</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REFERENCE_SET__CODING_SCHEME_REFERENCE = eINSTANCE.getReferenceSet_CodingSchemeReference();

		/**
		 * The meta object literal for the '<em><b>Value Domain Reference</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REFERENCE_SET__VALUE_DOMAIN_REFERENCE = eINSTANCE.getReferenceSet_ValueDomainReference();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.versions.impl.SystemReleaseTypeImpl <em>System Release Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.versions.impl.SystemReleaseTypeImpl
		 * @see org.LexGrid.emf.versions.impl.VersionsPackageImpl#getSystemReleaseType()
		 * @generated
		 */
		EClass SYSTEM_RELEASE_TYPE = eINSTANCE.getSystemReleaseType();

		/**
		 * The meta object literal for the '<em><b>Release Defines</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SYSTEM_RELEASE_TYPE__RELEASE_DEFINES = eINSTANCE.getSystemReleaseType_ReleaseDefines();

		/**
		 * The meta object literal for the '<em><b>Release Contains</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SYSTEM_RELEASE_TYPE__RELEASE_CONTAINS = eINSTANCE.getSystemReleaseType_ReleaseContains();

		/**
		 * The meta object literal for the '<em><b>Release References</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SYSTEM_RELEASE_TYPE__RELEASE_REFERENCES = eINSTANCE.getSystemReleaseType_ReleaseReferences();

		/**
		 * The meta object literal for the '<em><b>Based On Release</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SYSTEM_RELEASE_TYPE__BASED_ON_RELEASE = eINSTANCE.getSystemReleaseType_BasedOnRelease();

		/**
		 * The meta object literal for the '<em><b>Release Agency</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SYSTEM_RELEASE_TYPE__RELEASE_AGENCY = eINSTANCE.getSystemReleaseType_ReleaseAgency();

		/**
		 * The meta object literal for the '<em><b>Release Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SYSTEM_RELEASE_TYPE__RELEASE_DATE = eINSTANCE.getSystemReleaseType_ReleaseDate();

		/**
		 * The meta object literal for the '<em><b>Release Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SYSTEM_RELEASE_TYPE__RELEASE_ID = eINSTANCE.getSystemReleaseType_ReleaseId();

		/**
		 * The meta object literal for the '<em><b>Release URN</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SYSTEM_RELEASE_TYPE__RELEASE_URN = eINSTANCE.getSystemReleaseType_ReleaseURN();

	}

} //VersionsPackage