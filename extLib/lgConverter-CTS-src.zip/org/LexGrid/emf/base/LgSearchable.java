/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.base;

import org.LexGrid.managedobj.ManagedObjIterator;
import org.LexGrid.managedobj.QueryException;

/**
 * Defines behavior for services providing support for common searches
 * performed against LexGrid containers.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public interface LgSearchable {

	/**
	 * Returns an iterator over encapsulated concepts (in all imbedded concept
	 * containers) that conform to the given constraints.
	 * <p>
	 * Note: Results may be paged on demand depending on the nature of the returned iterator.
	 * The iterator must be closed to guarantee that associated resources are freed.
	 * Closure is automatic once all elements are processed, but should be guaranteed in a
	 * try/catch block by the caller.
	 * 
	 * @param root The root of the object hierarchy to search, or null
	 * to search from the top-most available element.
	 * @param conceptConstraints Provides conditions to be satisfied
	 * by each concept returned (property-based constraints may also be
	 * specified); null to accept all concepts.
	 * @param limit The maximum number of items to resolve; 0 for no limit.
	 * @return An iterator over all concepts satisfying the given
	 * constraints (instances of CodedEntry).
	 * @throws QueryException
	 */
	ManagedObjIterator queryConcepts(
		LgModelObj root,
		LgConstraint[] constraints,
		int limit
		) throws QueryException;

	/**
	 * Returns an iterator over encapsulated relation instances (in all imbedded
	 * relation containers) for the given code.
	 * <p>
	 * Note: Results may be paged on demand depending on the nature of the returned iterator.
	 * The iterator must be closed to guarantee that associated resources are freed.
	 * Closure is automatic once all elements are processed, but should be guaranteed in a
	 * try/catch block by the caller.
	 * 
	 * @param root The root of the object hierarchy to search, or null
	 * to search from the top-most available element.
	 * @param code The concept code to match.
	 * @param limit The maximum number of items to resolve; 0 for no limit.
	 * @return An iterator over all matcing instances (instances of
	 * AssociationInstance).
	 * @throws QueryException
	 */
	ManagedObjIterator queryRelationSources(
		LgModelObj root,
		String code,
		int limit
		) throws QueryException;

	/**
	 * Returns an iterator over encapsulated relation targets (in all imbedded
	 * relation containers) for the given code.
	 * <p>
	 * Note: Results may be paged on demand depending on the nature of the returned iterator.
	 * The iterator must be closed to guarantee that associated resources are freed.
	 * Closure is automatic once all elements are processed, but should be guaranteed in a
	 * try/catch block by the caller.
	 * 
	 * @param root The root of the object hierarchy to search, or null
	 * to search from the top-most available element.
	 * @param targetContext The context name of the target coding scheme;
	 * null to match any context.
	 * @param targetCode The concept code to match.
	 * @param limit The maximum number of items to resolve; 0 for no limit.
	 * @return An iterator over all matching targets (instances of
	 * AssociationTarget).
	 * @throws QueryException
	 */
	ManagedObjIterator queryRelationTargets(
		LgModelObj root,
		String targetContext,
		String targetCode,
		int limit
		) throws QueryException;

}