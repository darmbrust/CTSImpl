/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.base.xml;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.LexGrid.emf.builtins.BuiltinsFactory;
import org.LexGrid.emf.builtins.BuiltinsPackage;
import org.LexGrid.emf.codingSchemes.CodingSchemeType;
import org.LexGrid.emf.codingSchemes.CodingschemesFactory;
import org.LexGrid.emf.codingSchemes.CodingschemesPackage;
import org.LexGrid.emf.codingSchemes.Mappings;
import org.LexGrid.emf.commonTypes.CommontypesFactory;
import org.LexGrid.emf.commonTypes.CommontypesPackage;
import org.LexGrid.emf.concepts.ConceptsFactory;
import org.LexGrid.emf.concepts.ConceptsPackage;
import org.LexGrid.emf.ldap.LdapFactory;
import org.LexGrid.emf.ldap.LdapPackage;
import org.LexGrid.emf.naming.NamingFactory;
import org.LexGrid.emf.naming.NamingPackage;
import org.LexGrid.emf.relations.RelationsFactory;
import org.LexGrid.emf.relations.RelationsPackage;
import org.LexGrid.emf.service.ServiceTypeFactory;
import org.LexGrid.emf.service.ServiceTypePackage;
import org.LexGrid.emf.valueDomains.ValuedomainsFactory;
import org.LexGrid.emf.valueDomains.ValuedomainsPackage;
import org.LexGrid.emf.versions.VersionsFactory;
import org.LexGrid.emf.versions.VersionsPackage;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EFactory;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.xmi.FeatureNotFoundException;
import org.eclipse.emf.ecore.xmi.IllegalValueException;
import org.eclipse.emf.ecore.xmi.XMIException;
import org.eclipse.emf.ecore.xmi.XMLHelper;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.impl.SAXXMLHandler;

/**
 * Extension to assist with conversion to/from the LexGrid canonical XML format.
 * 
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class LgXMLHandlerImpl extends SAXXMLHandler {
    protected final static Logger logger = Logger.getLogger("org.LexGrid.emf.base.xml.LgXMLHandlerImpl");

	// For special handling of concept property subtypes ...
	protected static final String TYPE_Comment = ConceptsPackage.eINSTANCE.getComment().getName();
	protected static final String TYPE_ConceptProperty = ConceptsPackage.eINSTANCE.getConceptProperty().getName();
	protected static final String TYPE_Definition = ConceptsPackage.eINSTANCE.getDefinition().getName();
	protected static final String TYPE_Instruction = ConceptsPackage.eINSTANCE.getInstruction().getName();
	protected static final String TYPE_Presentation = ConceptsPackage.eINSTANCE.getPresentation().getName();
	protected static final String TYPE_Property = ConceptsPackage.eINSTANCE.getConceptProperty().getName();
	protected static final List TYPES_Props = new ArrayList();

	// XML tag values that do not match the class name ...
	protected static final String TYPE_CodingScheme = "codingScheme";
	protected static final String TYPE_CodingSchemes = "codingSchemes";
	protected static final String TYPE_Release = "systemRelease";
	protected static final String TYPE_Service = "service";
	protected static final String ATTR_Copyright = "copyright";
	
	// Tracks features for mapped metadata references (supportedXXX) ...
	protected static final List EREF_CSMappings = new ArrayList();

	protected int inTextDepth = 0;
	
	public LgXMLHandlerImpl(XMLResource xmiResource, XMLHelper helper, Map options) {
		super(xmiResource, helper, options);
		prefixesToFactories.put(BuiltinsPackage.eNS_PREFIX, BuiltinsFactory.eINSTANCE);
		prefixesToFactories.put(CodingschemesPackage.eNS_PREFIX, CodingschemesFactory.eINSTANCE);
		prefixesToFactories.put(CommontypesPackage.eNS_PREFIX, CommontypesFactory.eINSTANCE);
		prefixesToFactories.put(ConceptsPackage.eNS_PREFIX, ConceptsFactory.eINSTANCE);
		prefixesToFactories.put(LdapPackage.eNS_PREFIX, LdapFactory.eINSTANCE);
		prefixesToFactories.put(NamingPackage.eNS_PREFIX, NamingFactory.eINSTANCE);
		prefixesToFactories.put(RelationsPackage.eNS_PREFIX, RelationsFactory.eINSTANCE);
		prefixesToFactories.put(ServiceTypePackage.eNS_PREFIX, ServiceTypeFactory.eINSTANCE);
		prefixesToFactories.put(ValuedomainsPackage.eNS_PREFIX, ValuedomainsFactory.eINSTANCE);
		prefixesToFactories.put(VersionsPackage.eNS_PREFIX, VersionsFactory.eINSTANCE);
		
		// Tolerate alternate LexGrid namespaces for limited compatibility with 2006 schema on load ...
		packageRegistry.put("http://LexGrid.org/schema/2005/01/LexGrid/builtins", BuiltinsPackage.eINSTANCE);
		packageRegistry.put("http://LexGrid.org/schema/2005/01/LexGrid/codingSchemes", CodingschemesPackage.eINSTANCE);
		packageRegistry.put("http://LexGrid.org/schema/2005/01/LexGrid/commonTypes", CommontypesPackage.eINSTANCE);
		packageRegistry.put("http://LexGrid.org/schema/2005/01/LexGrid/concepts", ConceptsPackage.eINSTANCE);
		packageRegistry.put("http://LexGrid.org/schema/2005/01/LexGrid/ldap", LdapPackage.eINSTANCE);
		packageRegistry.put("http://LexGrid.org/schema/2005/01/LexGrid/naming", NamingPackage.eINSTANCE);
		packageRegistry.put("http://LexGrid.org/schema/2005/01/LexGrid/relations", RelationsPackage.eINSTANCE);
		packageRegistry.put("http://LexGrid.org/schema/2005/01/LexGrid/service", ServiceTypePackage.eINSTANCE);
		packageRegistry.put("http://LexGrid.org/schema/2005/01/LexGrid/valueDomains", ValuedomainsPackage.eINSTANCE);
		packageRegistry.put("http://LexGrid.org/schema/2005/01/LexGrid/versions", VersionsPackage.eINSTANCE);
		
		// Get a list of coding scheme supportedXXX eReferences contained by the mappings container ...
		EREF_CSMappings.add(CodingschemesPackage.eINSTANCE.getMappings_SupportedAssociation());
		EREF_CSMappings.add(CodingschemesPackage.eINSTANCE.getMappings_SupportedAssociationQualifier());
		EREF_CSMappings.add(CodingschemesPackage.eINSTANCE.getMappings_SupportedCodingScheme());
		EREF_CSMappings.add(CodingschemesPackage.eINSTANCE.getMappings_SupportedConceptStatus());
		EREF_CSMappings.add(CodingschemesPackage.eINSTANCE.getMappings_SupportedContext());
		EREF_CSMappings.add(CodingschemesPackage.eINSTANCE.getMappings_SupportedDegreeOfFidelity());
		EREF_CSMappings.add(CodingschemesPackage.eINSTANCE.getMappings_SupportedFormat());
		EREF_CSMappings.add(CodingschemesPackage.eINSTANCE.getMappings_SupportedLanguage());
		EREF_CSMappings.add(CodingschemesPackage.eINSTANCE.getMappings_SupportedProperty());
		EREF_CSMappings.add(CodingschemesPackage.eINSTANCE.getMappings_SupportedPropertyLink());
		EREF_CSMappings.add(CodingschemesPackage.eINSTANCE.getMappings_SupportedPropertyQualifier());
		EREF_CSMappings.add(CodingschemesPackage.eINSTANCE.getMappings_SupportedRepresentationalForm());
		EREF_CSMappings.add(CodingschemesPackage.eINSTANCE.getMappings_SupportedSource());
		
		TYPES_Props.add(TYPE_Comment);
		TYPES_Props.add(TYPE_ConceptProperty);
		TYPES_Props.add(TYPE_Definition);
		TYPES_Props.add(TYPE_Instruction);
		TYPES_Props.add(TYPE_Presentation);
	}
	
	/* (non-Javadoc)
	 * @see org.eclipse.emf.ecore.xmi.impl.XMLHandler#createObjectFromFactory(org.eclipse.emf.ecore.EFactory, java.lang.String)
	 */
	protected EObject createObjectFromFactory(EFactory factory, String typeName) {
		String capName = StringUtils.capitalize(typeName);
		EObject o = null;

		// Handle property subclasses (includes backward compatibility to 2005 model) ...
		if (TYPE_Comment.equals(capName))
			o = ConceptsFactory.eINSTANCE.createComment();
		if (TYPE_ConceptProperty.equals(capName) || TYPE_Property.equals(capName))
			o = ConceptsFactory.eINSTANCE.createConceptProperty();
		if (TYPE_Definition.equals(capName))
			o = ConceptsFactory.eINSTANCE.createDefinition();
		if (TYPE_Instruction.equals(capName))
			o = ConceptsFactory.eINSTANCE.createInstruction();
		if (TYPE_Presentation.equals(capName))
			o = ConceptsFactory.eINSTANCE.createPresentation();

		// Handle items for which the xml tag does not match the generated class name ...
		if (TYPE_CodingScheme.equals(typeName))
			o = CodingschemesFactory.eINSTANCE.createCodingSchemeType();
		if (TYPE_CodingSchemes.equals(typeName))
			o = CodingschemesFactory.eINSTANCE.createCodingSchemesType();
		if (TYPE_Release.equals(typeName))
			o = VersionsFactory.eINSTANCE.createSystemReleaseType();
		if (TYPE_Service.equals(typeName))
			o = ServiceTypeFactory.eINSTANCE.createServiceType();

		if (o != null) {
			if (disableNotify)
				o.eSetDeliver(false);
			handleObjectAttribs(o);
			return o;
		}
		return super.createObjectFromFactory(factory, capName);
	}
	
	protected EObject createObjectFromFeatureType(EObject peekObject, EStructuralFeature feature) {
		if (peekObject != null && feature != null) {
			if (peekObject.eClass().equals(CodingschemesPackage.eINSTANCE.getCodingSchemeType())) {
				if (EREF_CSMappings.contains(feature)) {
					// Handle backward compatibility of supportedXXX metadata registered to
					// the coding scheme (with 2005 model).
					Mappings mappings = ((CodingSchemeType) peekObject).getMappings();
					if (mappings == null) {
						mappings = CodingschemesFactory.eINSTANCE.createMappings();
						((CodingSchemeType) peekObject).setMappings(mappings);
					}
					peekObject = mappings;
				}
			}
		}
		return super.createObjectFromFeatureType(peekObject, feature);
	}

	/**
	 * Invoked from modified handleFeature() method for LexGrid-specific processing,
	 * which includes proper handling of property subtypes.
	 * @param peekObject
	 * @param feature
	 * @param name
	 * @see handleFeature()
	 * @return org.eclipse.emf.ecore.EObject
	 */
	protected EObject createObjectFromFeatureType(EObject peekObject, EStructuralFeature feature, String name) {
		if (peekObject != null) {
			EClass eClass = peekObject.eClass();
			if (eClass.equals(ConceptsPackage.eINSTANCE.getCodedEntry())
				&& TYPES_Props.contains(name))
			{
				// Handle property subclasses (includes backward compatibility to 2005 model) ...
				EObject o = null;
				if (TYPE_Comment.equals(name))
					o = ConceptsFactory.eINSTANCE.createComment();
				if (TYPE_ConceptProperty.equals(name) || TYPE_Property.equals(name))
					o = ConceptsFactory.eINSTANCE.createConceptProperty();
				if (TYPE_Definition.equals(name))
					o = ConceptsFactory.eINSTANCE.createDefinition();
				if (TYPE_Instruction.equals(name))
					o = ConceptsFactory.eINSTANCE.createInstruction();
				if (TYPE_Presentation.equals(name))
					o = ConceptsFactory.eINSTANCE.createPresentation();
				if (o != null) {
					if (disableNotify)
						o.eSetDeliver(false);
					handleObjectAttribs(o);
					setFeatureValue(peekObject, feature, o);
					processObject(o);
					return o;
				}
			}
		}
		return createObjectFromFeatureType(peekObject, feature);
	}
	
	/* (non-Javadoc)
	 * @see org.eclipse.emf.ecore.xmi.impl.XMLHandler#getFeature(org.eclipse.emf.ecore.EObject, java.lang.String, java.lang.String, boolean)
	 */
	protected EStructuralFeature getFeature(EObject object, String prefix, String name, boolean isElement) {
		if (object != null && name != null) {
			EClass ec = object.eClass();
			if (ec.equals(CodingschemesPackage.eINSTANCE.getCodingSchemeType())) {
				
				// The 'copyright' attribute is designated for other use by EMF.
				// Import the 'copyright' XML attribute as the 'copyrightText' feature.
				if (name.equals(ATTR_Copyright))
					return CodingschemesPackage.eINSTANCE.getCodingSchemeType_CopyrightText();
				
				// Handle backward compatibility of supportedXXX metadata registered to
				// the coding scheme (with 2005 model).
				if (name.startsWith("supported")) {
					Mappings mappings = ((CodingSchemeType) object).getMappings();
					if (mappings == null) {
						mappings = CodingschemesFactory.eINSTANCE.createMappings();
						((CodingSchemeType) object).setMappings(mappings);
					}
					object = mappings;
				}
			}
			// Coded entry 'property' in 2005 model changed to 'conceptProperty' in 2006 model
			else if (ec.equals(ConceptsPackage.eINSTANCE.getCodedEntry()) && name.equals("property"))
				return super.getFeature(object, prefix, "conceptProperty", isElement);
		}
		return super.getFeature(object, prefix, name, isElement);
	}

	/* (non-Javadoc)
	 * Override to allow for handling of embedded XML in text features.
	 */
	public void startElement(String uri, String localName, String name) {
		// Handling embedded text?  If so, append without interpretation.
		if (inTextDepth > 0
				|| ((uri == null || uri.trim().length() == 0) && text != null)) {
			inTextDepth++;
			text.append('<'+name+'>');
		} else
			super.startElement(uri, localName, name);
	}

	/* (non-Javadoc)
	 * Override to allow for handling of embedded XML in text features.
	 */
	public void endElement(String uri, String localName, String name) {
		// Handling embedded text?  If so, append without interpretation.
		if (inTextDepth > 0) {
			inTextDepth--;
			text.append("</"+name+'>');
		} else
			super.endElement(uri, localName, name);
	}

	public void error(XMIException e) {
		// Flag illegal values, but attempt to continue ...
		if (e instanceof IllegalValueException) {
			warning(e);
			return;
		}
		logger.error("Error on XML load.", e);
		super.error(e);
	}

	public void fatalError(XMIException e) {
		logger.error("Fatal error on XML load.", e);
		super.fatalError(e);
	}

	public void warning(XMIException e) {
		logger.warn("Warning on XML load.");
		super.warning(e);
	}

	protected void reportUnknownFeature(String prefix, String name, boolean isElement, EObject peekObject, String value) {
		// Override superclass to avoid signalling exception.
		// Instead, issue warning and bypass the unknown feature.
		logger.warn("Warning on XML load.",
			new FeatureNotFoundException(name, peekObject, getLocation(), getLineNumber(), getColumnNumber()));
	}

}