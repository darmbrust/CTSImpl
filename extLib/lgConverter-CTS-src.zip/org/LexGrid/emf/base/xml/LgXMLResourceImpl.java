/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.base.xml;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.LexGrid.emf.base.LgModelObj;
import org.LexGrid.emf.base.LgPagedList;
import org.LexGrid.emf.base.impl.LgModelObjImpl;
import org.LexGrid.emf.base.util.LgModelUtil;
import org.apache.commons.collections.Unmodifiable;
import org.apache.log4j.Logger;
import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.xmi.XMLLoad;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.XMLSave;
import org.eclipse.emf.ecore.xmi.impl.XMLResourceImpl;

/**
 * Extension to assist with conversion to/from the LexGrid canonical XML format.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class LgXMLResourceImpl extends XMLResourceImpl {
	
    protected final static Logger logger = Logger.getLogger("org.LexGrid.emf.base.xml.LgXMLResourceImpl");

    public LgXMLResourceImpl(URI uri) {
		super(uri);
	}
    
    public LgXMLResourceImpl() {
        super();
    }
	
	/* (non-Javadoc)
	 * @see org.eclipse.emf.ecore.xmi.impl.XMLResourceImpl#createXMLLoad()
	 */
	protected XMLLoad createXMLLoad() {
		// Use the LexGrid-specific helper implementation
	    return new LgXMLLoadImpl(new LgXMLHelperImpl(this));
	}
	/* (non-Javadoc)
	 * @see org.eclipse.emf.ecore.xmi.impl.XMLResourceImpl#createXMLSave()
	 */
	protected XMLSave createXMLSave() {
		// Use the LexGrid-specific helper implementation
	    return new LgXMLSaveImpl(new LgXMLHelperImpl(this));
	}

	/* (non-Javadoc)
	 * @see org.eclipse.emf.ecore.resource.impl.ResourceImpl#doLoad()
	 */
	public void doLoad(InputStream inputStream, Map options) throws IOException {
		// Bypass notification during the load process of LexGrid documents
		// as specified in central utility class (controlled on per-thread basis).
		boolean notifyOn = LgModelUtil.isNotifyRequired();
		try {
			LgModelUtil.setNotifyRequired(false);
			super.doLoad(inputStream, options);
		} finally {
			LgModelUtil.setNotifyRequired(notifyOn);
		}
	}

	/* (non-Javadoc)
	 * @see org.eclipse.emf.ecore.resource.impl.ResourceImpl#doUnload()
	 */
	public void doUnload() {
		// Bypass notification during the load process of LexGrid documents
		// as specified in central utility class (controlled on per-thread basis).
		boolean notifyOn = LgModelUtil.isNotifyRequired();
		try {
			LgModelUtil.setNotifyRequired(false);
			unloadAll(getTopModel());
			getContents().clear();
			super.doUnload();
		} finally {
			LgModelUtil.setNotifyRequired(notifyOn);
			logger.info("Unloading Resource: "+getURI());
			modificationTrackingAdapter = null;
			basicSetResourceSet(null, null);
			if (eAdapters != null)
				eAdapters.clear();
		}
	}

	public Map getDefaultLoadOptions() {
		if (defaultLoadOptions == null) {
			defaultLoadOptions = new HashMap();
			defaultLoadOptions.put(XMLResource.OPTION_DISABLE_NOTIFY, Boolean.TRUE);
	        defaultLoadOptions.put(XMLResource.OPTION_ENCODING, "UTF-8");
	        defaultLoadOptions.put(XMLResource.OPTION_XML_MAP, LgXMLLoadMapImpl.INSTANCE);			
		}
		return defaultLoadOptions;
	}
	public Map getDefaultSaveOptions() {
		if (defaultSaveOptions == null) {
			defaultSaveOptions = new HashMap();
			defaultSaveOptions.put(XMLResource.OPTION_XML_MAP, LgXMLSaveMapImpl.INSTANCE);
			defaultSaveOptions.put(XMLResource.OPTION_ENCODING, "UTF-8");
			defaultSaveOptions.put(XMLResource.OPTION_FLUSH_THRESHOLD, new Integer(65535));
			defaultSaveOptions.put(XMLResource.OPTION_USE_FILE_BUFFER, Boolean.TRUE);
		}
		return defaultSaveOptions;
	}

	/**
	 * Return the root LexGrid model object, if available.
	 * @return LgModelObj
	 */
	protected LgModelObj getTopModel() {
		if (!getContents().isEmpty()) {
			Object o = getContents().get(0);
			if (o instanceof LgModelObj)
				return (LgModelObj) o;
		}
		return null;
	}

	public void load() throws IOException {
		load(getDefaultLoadOptions());
	}

	/* (non-Javadoc)
	 * @see org.eclipse.emf.ecore.resource.Resource#load(java.util.Map)
	 */
	public void load(Map options) throws IOException {
		try {
			// Force garbage collection to maximize VM resources available for load...
			System.runFinalization();
			System.gc();
			
			if (!(options instanceof Unmodifiable)) {
				// Force these options, overriding anything passed in ...
				options.put(XMLResource.OPTION_DISABLE_NOTIFY, Boolean.TRUE);
		        options.put(XMLResource.OPTION_ENCODING, "UTF-8");
		        options.put(XMLResource.OPTION_XML_MAP, LgXMLLoadMapImpl.INSTANCE);
			}
	 		super.load(options);
		} catch (IOException e) {
			logger.error("Error on load. Document: "+getURI(), e);
			throw e;
		}
	}

	/**
	 * Performs the save operation with default options.
	 * @throws IOException
	 */
	public void save() throws IOException {
		save(getDefaultSaveOptions());
	}

	/* (non-Javadoc)
	 * @see org.eclipse.emf.ecore.resource.Resource#save(java.util.Map)
	 */
	public void save(Map options) throws IOException {
		try {
			if (!(options instanceof Unmodifiable)) {
				// Force these options, overriding anything passed in ...
				options.put(XMLResource.OPTION_XML_MAP, LgXMLSaveMapImpl.INSTANCE);
				options.put(XMLResource.OPTION_ENCODING, "UTF-8");
			}
			super.save(options);
		} catch (IOException e) {
			logger.error("Error on save. Document: "+getURI(), e);
			throw e;
		}
	}

	/**
	 * Recursively detaches resources from the given object and
	 * all encapsulated objects.
	 * @param model
	 */
	protected void unloadAll(EObject o) {
		// Note: Turning the object into a proxy is expensive and
		// unnecessary in our world, so we bypass that step (performed by the
		// superclass impl) and clear the associated adapters.
		unloaded(o);
	}

	protected void unloaded(EObject o) {
		// Recurse to handle children.
		// Ignore content if it has not yet been paged in ...
		if (o != null
			&& (!(o instanceof LgModelObjImpl)
				|| !(((LgModelObjImpl) o).isContentPending())))
		{
			EList children = o.eContents();
			if (children instanceof LgPagedList)
				((LgPagedList) children).setPagingService(null);
			for (Iterator it = children.iterator(); it.hasNext(); )
				unloaded((EObject) it.next());
			if (children instanceof BasicEList)
				((BasicEList) children).setData(0, null);
		}
		// Process the item ...
		if (o instanceof InternalEObject) {
			EList adapters = o.eAdapters();
			if (adapters instanceof BasicEList) {
				for (Iterator items = adapters.iterator(); items.hasNext(); )
					((Adapter) items.next()).setTarget(null);
				((BasicEList) adapters).setData(0, null);
			} else
				adapters.clear();
		}
	}

}