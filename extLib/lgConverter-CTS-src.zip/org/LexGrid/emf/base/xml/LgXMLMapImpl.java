/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.base.xml;

import org.LexGrid.emf.codingSchemes.CodingschemesPackage;
import org.LexGrid.emf.commonTypes.CommontypesPackage;
import org.LexGrid.emf.concepts.ConceptsPackage;
import org.LexGrid.emf.history.NCIHistoryPackage;
import org.LexGrid.emf.naming.NamingPackage;
import org.LexGrid.emf.relations.RelationsPackage;
import org.LexGrid.emf.service.ServiceTypePackage;
import org.LexGrid.emf.valueDomains.ValuedomainsPackage;
import org.LexGrid.emf.versions.VersionsPackage;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.ENamedElement;
import org.eclipse.emf.ecore.ETypedElement;
import org.eclipse.emf.ecore.xmi.XMLResource.XMLInfo;
import org.eclipse.emf.ecore.xmi.impl.XMLInfoImpl;
import org.eclipse.emf.ecore.xmi.impl.XMLMapImpl;

/**
 * Extension to assist with conversion to/from the LexGrid canonical XML format.
 * 
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class LgXMLMapImpl extends XMLMapImpl {
	public static final LgXMLMapImpl INSTANCE =
		new LgXMLMapImpl();

	protected LgXMLMapImpl() {
		super();
		lgInit();
	}
	
	protected void lgInit() {
		setNoNamespacePackage(CodingschemesPackage.eINSTANCE);

		// CodingScheme
		// ************
		String nsURI = CodingschemesPackage.eNS_URI; 
		add(CodingschemesPackage.eINSTANCE.getCodingSchemeType(), new LgXMLInfoImpl("codingScheme", nsURI, XMLInfoImpl.ELEMENT));
		add(CodingschemesPackage.eINSTANCE.getCodingSchemeType_Source(), new LgXMLInfoImpl("source", nsURI, XMLInfoImpl.ELEMENT));
		add(CodingschemesPackage.eINSTANCE.getCodingSchemeType_CopyrightText(), new LgXMLInfoImpl("copyright", nsURI, XMLInfoImpl.ELEMENT));
		add(CodingschemesPackage.eINSTANCE.getCodingSchemesType(), new LgXMLInfoImpl("codingSchemes", nsURI, XMLInfoImpl.ELEMENT));
		add(CodingschemesPackage.eINSTANCE.getCodingSchemesType_CodingScheme(), new LgXMLInfoImpl("codingScheme", nsURI, XMLInfoImpl.ATTRIBUTE));
		add(CodingschemesPackage.eINSTANCE.getCodingSchemeVersion(), new LgXMLInfoImpl("codingSchemeVersion", nsURI, XMLInfoImpl.ELEMENT));
		add(CodingschemesPackage.eINSTANCE.getVersions(), new LgXMLInfoImpl("versions", nsURI, XMLInfoImpl.ELEMENT));
		add(CodingschemesPackage.eINSTANCE.getMappings(), new LgXMLInfoImpl("mappings", nsURI, XMLInfoImpl.ELEMENT));

		// CommonTypes
		// ***********
		nsURI = CommontypesPackage.eNS_URI;
		add(CommontypesPackage.eINSTANCE.getEntityDescription(), new LgXMLInfoImpl("entityDescription", nsURI, XMLInfoImpl.ELEMENT));
		add(CommontypesPackage.eINSTANCE.getProperty(), new LgXMLInfoImpl("property", null, XMLInfoImpl.ELEMENT));
		add(CommontypesPackage.eINSTANCE.getProperty_Source(), new LgXMLInfoImpl("source", nsURI, XMLInfoImpl.ELEMENT));
		add(CommontypesPackage.eINSTANCE.getProperty_Text(), new LgXMLInfoImpl("text", nsURI, XMLInfoImpl.ELEMENT));
		add(CommontypesPackage.eINSTANCE.getProperty_UsageContext(), new LgXMLInfoImpl("usageContext", null, XMLInfoImpl.ELEMENT));
		add(CommontypesPackage.eINSTANCE.getProperty_PropertyQualifier(), new LgXMLInfoImpl("propertyQualifier", null, XMLInfoImpl.ELEMENT));
		add(CommontypesPackage.eINSTANCE.getPropertyQualifier_Value(), new LgXMLInfoImpl(null, null, XMLInfoImpl.CONTENT));		
		add(CommontypesPackage.eINSTANCE.getSource_Value(), new LgXMLInfoImpl(null, null, XMLInfoImpl.CONTENT));
		add(CommontypesPackage.eINSTANCE.getVersionable_Deprecated(), new LgXMLInfoImpl("deprecated", null, XMLInfoImpl.ATTRIBUTE));
		add(CommontypesPackage.eINSTANCE.getVersionable_FirstRelease(), new LgXMLInfoImpl("firstRelease", null, XMLInfoImpl.ATTRIBUTE));
		add(CommontypesPackage.eINSTANCE.getVersionable_ModifiedInRelease(), new LgXMLInfoImpl("modifiedInRelease", null, XMLInfoImpl.ATTRIBUTE));
		
		// Concepts
		// ********
		nsURI = ConceptsPackage.eNS_URI;
		add(ConceptsPackage.eINSTANCE.getCodedEntry(), new LgXMLInfoImpl("concept", nsURI, XMLInfoImpl.ELEMENT));
		add(ConceptsPackage.eINSTANCE.getComment(), new LgXMLInfoImpl("comment", nsURI, XMLInfoImpl.ELEMENT));
		add(ConceptsPackage.eINSTANCE.getConceptProperty(), new LgXMLInfoImpl("conceptProperty", nsURI, XMLInfoImpl.ELEMENT));
		add(ConceptsPackage.eINSTANCE.getConcepts(), new LgXMLInfoImpl("concepts", null, XMLInfoImpl.ELEMENT));
		add(ConceptsPackage.eINSTANCE.getDefinition(), new LgXMLInfoImpl("definition", nsURI, XMLInfoImpl.ELEMENT));
		add(ConceptsPackage.eINSTANCE.getInstruction(), new LgXMLInfoImpl("instruction", nsURI, XMLInfoImpl.ELEMENT));
		add(ConceptsPackage.eINSTANCE.getPresentation(), new LgXMLInfoImpl("presentation", nsURI, XMLInfoImpl.ELEMENT));
		add(ConceptsPackage.eINSTANCE.getPropertyLink(), new LgXMLInfoImpl("propertyLink", nsURI, XMLInfoImpl.ELEMENT));

		// Naming
		// ******
		nsURI = NamingPackage.eNS_URI;
		add(NamingPackage.eINSTANCE.getURN(), new LgXMLInfoImpl("urn", null, XMLInfoImpl.ATTRIBUTE));
		add(NamingPackage.eINSTANCE.getURNMap(), new LgXMLInfoImpl("urnMap", null, XMLInfoImpl.ELEMENT));
		add(NamingPackage.eINSTANCE.getURNMap_Value(), new LgXMLInfoImpl(null, null, XMLInfoImpl.CONTENT));

		// NCIHistory
		// **********
		nsURI = NCIHistoryPackage.eNS_URI;
		add(NCIHistoryPackage.eINSTANCE.getNCIChangeEvent(), new LgXMLInfoImpl("NCIChangeEvent", nsURI, XMLInfoImpl.ELEMENT));

		// Relations
		// *********
		nsURI = RelationsPackage.eNS_URI;
		add(RelationsPackage.eINSTANCE.getAssociatableElement(), new LgXMLInfoImpl("associatableElement", nsURI, XMLInfoImpl.ELEMENT));
		add(RelationsPackage.eINSTANCE.getAssociation(), new LgXMLInfoImpl("association", nsURI, XMLInfoImpl.ELEMENT));
		add(RelationsPackage.eINSTANCE.getAssociationData(), new LgXMLInfoImpl("targetDataValue", nsURI, XMLInfoImpl.ELEMENT));
		add(RelationsPackage.eINSTANCE.getAssociationData_DataValue(), new LgXMLInfoImpl("dataValue", nsURI, XMLInfoImpl.ELEMENT));
		add(RelationsPackage.eINSTANCE.getAssociationInstance(), new LgXMLInfoImpl("sourceConcept", nsURI, XMLInfoImpl.ELEMENT));
		add(RelationsPackage.eINSTANCE.getAssociationQualification(), new LgXMLInfoImpl("associationQualification", nsURI, XMLInfoImpl.ELEMENT));
		add(RelationsPackage.eINSTANCE.getAssociationQualification_AssociationQualifierValue(), new LgXMLInfoImpl("associationQualifierValue", nsURI, XMLInfoImpl.CONTENT));
		add(RelationsPackage.eINSTANCE.getAssociationTarget(), new LgXMLInfoImpl("targetConcept", nsURI, XMLInfoImpl.ELEMENT));
		add(RelationsPackage.eINSTANCE.getRelations(), new LgXMLInfoImpl("relations", null, XMLInfoImpl.ELEMENT));
		add(RelationsPackage.eINSTANCE.getRelations_Source(), new LgXMLInfoImpl("source", nsURI, XMLInfoImpl.ELEMENT));
		
		// ServiceType
		// ***********
		nsURI = ServiceTypePackage.eNS_URI;
		add(ServiceTypePackage.eINSTANCE.getServiceType(), new LgXMLInfoImpl("service", nsURI, XMLInfoImpl.ELEMENT));

		// ValueDomains
		// ************
		nsURI = ValuedomainsPackage.eNS_URI;
		add(ValuedomainsPackage.eINSTANCE.getPickListEntry(), new LgXMLInfoImpl("pickListEntry", nsURI, XMLInfoImpl.ELEMENT));
		add(ValuedomainsPackage.eINSTANCE.getValueDomainType(), new LgXMLInfoImpl("valueDomain", nsURI, XMLInfoImpl.ELEMENT));
		add(ValuedomainsPackage.eINSTANCE.getValueDomainEntry(), new LgXMLInfoImpl("valueDomainEntry", nsURI, XMLInfoImpl.ELEMENT));
		add(ValuedomainsPackage.eINSTANCE.getValueDomains(), new LgXMLInfoImpl("valueDomains", nsURI, XMLInfoImpl.ELEMENT));
		add(ValuedomainsPackage.eINSTANCE.getValueDomainVersion(), new LgXMLInfoImpl("valueDomainVersion", nsURI, XMLInfoImpl.ELEMENT));
		add(ValuedomainsPackage.eINSTANCE.getVdVersions(), new LgXMLInfoImpl("valueDomainVersions", nsURI, XMLInfoImpl.ELEMENT));

		// Versions
		// ********
		nsURI = VersionsPackage.eNS_URI;
		add(VersionsPackage.eINSTANCE.getEntityVersion(), new LgXMLInfoImpl("entityVersion", nsURI, XMLInfoImpl.ELEMENT));
		add(VersionsPackage.eINSTANCE.getHistory(), new LgXMLInfoImpl("history", nsURI, XMLInfoImpl.ELEMENT));
		add(VersionsPackage.eINSTANCE.getReferenceSet(), new LgXMLInfoImpl("referenceSet", nsURI, XMLInfoImpl.ELEMENT));
		add(VersionsPackage.eINSTANCE.getSystemReleaseType(), new LgXMLInfoImpl("systemRelease", nsURI, XMLInfoImpl.ELEMENT));
	}

	/**
	 * Overide to allow lookup based on element type definition
	 * if element does not have a direct mapping.
	 * @param element ENamedElement
	 * @return XMLInfo
	 */
	public XMLInfo getInfo(ENamedElement element) {
		XMLInfo info = super.getInfo(element);
		if (info == null && element instanceof ETypedElement) {
			EClassifier type = ((ETypedElement) element).getEType();
			if (type != null)
				return super.getInfo(type);
		}
		return info;
	}

}