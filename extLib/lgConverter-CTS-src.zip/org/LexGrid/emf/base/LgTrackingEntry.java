/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.base;

import org.LexGrid.managedobj.ManagedObjIF;

/**
 * Defines common behavior for informational entries used to
 * track modified resources.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public interface LgTrackingEntry extends ManagedObjIF {
	public static final int EVENT_Unspecified = 0;
	public static final int EVENT_Add = 1;
	public static final int EVENT_Change = 2;
	public static final int EVENT_Change_Content = 3;
	public static final int EVENT_Change_Context = 4;
	public static final int EVENT_Change_Identity = 5;
	public static final int EVENT_Move = 6;
	public static final int EVENT_Remove = 7;
	public static final int EVENT_New = 8;

	/**
	 * Indicates whether the action represented by the entry
	 * has been persisted, and can no longer be undone.
	 * @return boolean
	 */
	boolean getCommitted();

	/**
	 * Returns a string identifying additional detail information relevant
	 * to the item being tracked, or null if not applicable.
	 * <p>
	 * Use of this field is application-specific. For example, if the object
	 * was renamed, this value might indicate the previous name.
	 * @return String
	 */
	String getDetail();
	
	/**
	 * Returns the event being tracked.
	 * <p>
	 * Well-known values are defined as constants on this interface.
	 * @return int
	 */
	int getEventType();

	/**
	 * Returns the identifier of the emf feature associated
	 * with the change; -1 if not applicable.
	 * @return int
	 */
	int getFeatureID();

	/**
	 * Returns a string representing context for the tracked item,
	 * or null if not applicable.
	 * @return String
	 */
	String getItemContext();
	
	/**
	 * Returns a string identifying the item being tracked,
	 * relative to its context.
	 * @return String
	 */
	String getItemID();
	
	/**
	 * Returns a string identifying the type of item being tracked.
	 * @return String
	 */
	String getItemType();
	
	/**
	 * Returns the time of record (measured in milliseconds, between
     * time of entry and midnight, January 1, 1970 UTC).
	 * @return long
	 */
	long getTimestamp();
	
	/**
	 * Indicates whether the action represented by the entry
	 * has been persisted, and can no longer be undone.
	 * @param isComitted boolean
	 */
	void setCommitted(boolean isCommitted);

	/**
	 * Sets a string identifying additional detail information relevant
	 * to the item being tracked, or null if not applicable.
	 * <p>
	 * Use of this field is application-specific. For example, if the object
	 * was renamed, this value might indicate the previous name.
	 * @param data String
	 */
	void setDetail(String data);
	
	/**
	 * Sets the event being tracked.
	 * @param val String
	 */
	void setEventType(int val);

	/**
	 * Sets the identifier of the emf feature associated
	 * with the change; -1 if not applicable.
	 * @param val int
	 */
	void setFeatureID(int val);

	/**
	 * Sets a string representing context for the tracked item,
	 * or null if not applicable.
	 * @param val String
	 */
	void setItemContext(String val);

	/**
	 * Sets a string identifying the item being tracked,
	 * relative to its context.
	 * @param val String
	 */
	void setItemID(String val);

	/**
	 * Sets a string identifying the type of item being tracked.
	 * @param val String
	 */
	void setItemType(String val);

	/**
	 * Sets the time of record (measured in milliseconds, between
     * time of entry and midnight, January 1, 1970 UTC).
	 * @param val long
	 */
	void setTimestamp(long val);
	
}