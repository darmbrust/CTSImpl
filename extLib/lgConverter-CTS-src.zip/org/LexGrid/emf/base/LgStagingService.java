/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.base;

import org.LexGrid.managedobj.ResolveException;
import org.eclipse.emf.ecore.EStructuralFeature;

/**
 * Defines behavior for services providing on-demand resolution
 * of LexGrid model object features.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 * @non-generated
 */
public interface LgStagingService {
	
	/**
	 * Requests resolution of a feature for the given object.
	 * <p>
	 * Note: The service may choose to resolve additional features.
	 * This allows performance optimization in cases where little or no
	 * incremental cost is associated with retrieving additional information.
	 * @param obj
	 * @param feature
	 * @throws ResolveException
	 */
	void stageFeature(LgStagedObj obj, EStructuralFeature feature) throws ResolveException;
	
	/**
	 * Indicates whether staged (on-demand) feature resolution is
	 * currently enabled for the service.
	 * @return b
	 */
	boolean isStagingEnabled();

}