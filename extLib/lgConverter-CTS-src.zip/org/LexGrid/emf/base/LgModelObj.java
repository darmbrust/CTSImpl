/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.base;

import java.util.Iterator;

import org.LexGrid.managedobj.ManagedObjIF;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

/**
 * Extension point to define common behavior for LexGrid EMF-based model objects.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 * @non-generated
 */
public interface LgModelObj extends Comparable, Cloneable, EObject, ManagedObjIF, LgTrackable {

	/**
	 * Adds a listener to those registered to be notified of changes to
	 * identity features; does nothing if the given object is already registered.
	 * @param listener
	 */
	void addIdentityListener(LgIdentityListener listener);

	/* (non-Javadoc)
	 * @see java.lang.Object#clone()
	 */
	Object clone() throws CloneNotSupportedException;

	/**
	 * Searches the containment hierarchy for this object for an item of
	 * the given class.
	 * @param containerClass The class of object to match.
	 * @param distance Maximum number of levels removed from the current item
	 * to be evaluated during the search (0 to check immediate container, 1 to check
	 * its container, etc); any value less than 0 searches the entire chain. 
	 * @return A matching container, or null if no match is found.
	 */
	EObject getContainer(Class containerClass, int distance);

	/**
	 * Provides iteration over all contained models of the given class.
	 * @param containerClass The class of object to match.
	 * @param distance Maximum number of levels removed from the current item
	 * to be evaluated during the search (0 to check immediate content, 1 to check
	 * its content, etc); any value less than 0 searches the entire chain. 
	 * @return A matching container, or null if no match is found.
	 * @return An iterator over items matching the given class; empty if no
	 * matches are found.
	 */
	Iterator getContent(Class contentClass, int distance);

	/**
	 * Returns a preferential name to display for the object.
	 * <p>
	 * Note: This text is provided as a hint or suggestion, and may be ignored by
	 * individual views. Additional representations can be introduced as necessary (and
	 * perhaps more appropriately), using adapters.
	 * @return String
	 */
	String getPreferredDisplayName();

	/**
	 * Returns a preferential description for the object.
	 * <p>
	 * Note: this is differentiated from the display name in that it does not
	 * necessarily include identifying information (e.g. concept code).
	 * This value is intended to provide a simple readable description; null if not available.
	 * @return String
	 */
	String getPreferredTextDescription();

	/**
	 * Removes a listener from those registered to be notified of changes
	 * to identity features; does nothing if the given object is not registered.
	 * @param listener
	 */
	void removeIdentityListener(LgIdentityListener listener);
	
	/**
	 * If the implementation utilizes lazy initialization, this method will
	 * force load of all internally managed information defining the object.
	 * <p>
	 * This does not include resolution of contained objects, if applicable.
	 */
	void resolveAllAttributes();

	/**
	 * Set the immediate container for the object.
	 * @param container The object containing this object.
	 * @param containerFeature Indicates the feature of the container that
	 * contains a reference back to this object.
	 * @param addToContainer Indicates whether this object should be added
	 * to the container for the given feature.  If false, only a local
	 * reference is maintained back to the container.
	 */
	void setContainer(EObject container, EStructuralFeature containerFeature, boolean addToContainer);

}