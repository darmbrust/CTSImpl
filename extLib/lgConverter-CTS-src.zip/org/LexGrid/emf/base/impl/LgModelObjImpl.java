/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.base.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.LexGrid.emf.base.LgIdentityListener;
import org.LexGrid.emf.base.LgModelObj;
import org.LexGrid.emf.base.LgStagedObj;
import org.LexGrid.emf.base.LgStagingService;
import org.LexGrid.emf.base.util.LgModelUtil;
import org.LexGrid.managedobj.ResolveException;
import org.LexGrid.managedobj.ServiceUnavailableException;
import org.LexGrid.managedobj.UnexpectedException;
import org.apache.commons.collections.IteratorUtils;
import org.apache.commons.collections.map.HashedMap;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.notify.impl.NotificationImpl;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
import org.eclipse.emf.ecore.resource.Resource;

/**
 * Extension point for LexGrid-specific implementation.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 * @non-generated
 */
public abstract class LgModelObjImpl
	extends EObjectImpl
	implements LgModelObj, LgStagedObj {
	
	private static Map EClass2IDFeatures = new HashedMap();

	private transient LgStagingService _stagingService = null; // handles staged feature resolution
	private transient LgIdentityListener _idListener = null; // optimize for one primary identity listener
	private transient List _idListeners = null; // additional identity listeners
	private transient int _rbits = 0x000; // tracks resolve state (assumes <= 32 features)
	private int _fbits = 0x000; // tracks feature state (assumes <= 32 features)

	public LgModelObjImpl() {
		super();
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.LgModelObj#addIdentityListener(org.LexGrid.emf.base.LgIdentityListener)
	 */
	public void addIdentityListener(LgIdentityListener listener) {
		// Note: in many cases there is 0 or 1 listener, so we
		// optimize to this case in order to avoid the overhead of
		// maintaining a list.
		if (_idListener == null)
			_idListener = listener;
		else if (_idListener != listener) {
			if (_idListeners == null)
				_idListeners = new ArrayList(1);
			if (!_idListeners.contains(listener))
				_idListeners.add(listener);
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#clone()
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	public int compareTo(Object o) {
		if (!(o instanceof LgModelObj))
			throw new ClassCastException("Object not comparable to LgModelObj: " + o);

		Object key1 = getPrimaryKey();
		Object key2 = ((LgModelObj) o).getPrimaryKey();
		
		return 
			key2 == null ? 1
				: key1 == null ? -1
					: key1.toString().compareTo(key2.toString());
	}

	/**
	 * Ensures the assigned container is cleared on removal.
	 * @param msgs org.eclipse.emf.common.notify.NotificationChain
	 * @return org.eclipse.emf.common.notify.NotificationChain 
	 */
	public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
		msgs = super.eBasicRemoveFromContainer(msgs);
		eBasicSetContainer(null, 0);
		return msgs;
	}
	
	/* (non-Javadoc)
	 * @see org.eclipse.emf.ecore.impl.BasicEObjectImpl#eDynamicBasicRemoveFromContainer(org.eclipse.emf.common.notify.NotificationChain)
	 */
	public NotificationChain eDynamicBasicRemoveFromContainer(NotificationChain msgs) {
		try {
			EReference inverseFeature = ((EReference)eClass().getEStructuralFeature(eContainerFeatureID())).getEOpposite();
			if (inverseFeature != null)
				return eInternalContainer().eInverseRemove(this, inverseFeature.getFeatureID(), inverseFeature.getContainerClass(), msgs);
		} catch (ClassCastException e) {
			// Inverse feature not recognized... ignore and continue.
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.emf.ecore.EObject#eGet(org.eclipse.emf.ecore.EStructuralFeature, boolean)
	 */
	public Object eGet(EStructuralFeature eFeature, boolean resolve) {
		// Perform re-resolution of features marked as dirty...
		if (resolve && internalIsDirty(eFeature))
			try {
				resolveFeature(eFeature);
			} catch (ResolveException e) {
				throw new UnexpectedException(e);
			}
		return super.eGet(eFeature, resolve);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.emf.ecore.EObject#eIsSet(org.eclipse.emf.ecore.EStructuralFeature)
	 */
	public boolean eIsSet(EStructuralFeature eFeature) {
		// Treat required attributes that have a default literal assigned
		// as 'set', so they are properly detected when the model is written
		// to XML, etc.
		if (eFeature.isRequired() && eFeature.getDefaultValueLiteral() != null)
			return true;
		return super.eIsSet(eFeature);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.emf.common.notify.impl.NotifierImpl#eNotificationRequired()
	 */
	public boolean eNotificationRequired() {
		return LgModelUtil.isNotifyRequired() && super.eNotificationRequired();
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object obj) {
		// Same instance?
		if (this == obj)
			return true;
		// Same class?
		if (!(obj instanceof LgModelObjImpl && getClass() == obj.getClass()))
			return false;

		// Check origin.
		Resource r1 = eResource();
		Resource r2 = ((LgModelObjImpl) obj).eResource();
		if (!(r1 == r2 || (r1 != null && r1.equals(r2))))
			return false;
		
		// Check identification and ancestry.
		// Note: By default, models under the same parent with null
		// primary keys are not considered equal (this can occur if
		// multiple new items are introduced under a parent without
		// being assigned identifying attributes/features.
		Object key1 = getPrimaryKey();
		Object key2 = ((LgModelObjImpl) obj).getPrimaryKey();
		if (key1 != null && key1.equals(key2)) {
			Object par1 = eContainer;
			Object par2 = ((LgModelObjImpl) obj).eContainer();
			if (par1 == par2 || (par1 != null && par1.equals(par2)))
				return true;
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.emf.ecore.EObject#eSet(org.eclipse.emf.ecore.EStructuralFeature, java.lang.Object)
	 */
	public void eSet(EStructuralFeature eFeature, Object newValue) {
		internalMarkClean(eFeature);
		if (getIdentityFeatures().contains(eFeature) && eNotificationRequired()) {
			Object old_pk = getPrimaryKey();
			super.eSet(eFeature, newValue);

			NotificationImpl msg = new ENotificationImpl(this, Notification.SET, eFeature.getFeatureID(), old_pk, getPrimaryKey());
			if (_idListener != null)
				_idListener.identityChanged(msg);
			if (_idListeners != null) {
				LgIdentityListener[] listeners =
					(LgIdentityListener[]) _idListeners.toArray(new LgIdentityListener[_idListeners.size()]);
				for (int i = 0; i < listeners.length; i++)
					listeners[i].identityChanged(msg);	
			}
			return;
		}
		
		// No-op on exact value match ...
		if (newValue == eGet(eFeature, false))
			return;
		super.eSet(eFeature, newValue);
	}

	/**
	 * Override to force storage of all feature values in eSettings store.
	 * @return int
	 */
	protected int eStaticFeatureCount() {
		return 0;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.emf.ecore.EObject#eUnset(org.eclipse.emf.ecore.EStructuralFeature)
	 */
	public void eUnset(EStructuralFeature eFeature) {
		super.eUnset(eFeature);
		internalMarkDirty(eFeature);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.LgModelObj#getContainer(java.lang.Class, int)
	 */
	public EObject getContainer(Class containerClass, int distance) {
		if (!(LgModelObj.class.isAssignableFrom(containerClass)))
			throw new IllegalArgumentException(containerClass + " not assignable from LgModelObj");
		
		EObject o = null;
		int level = 0;
		for (
			o = eContainer();
			(distance < 0 || level++ <= distance) && o != null && !(containerClass.isInstance(o));
			o = o.eContainer());
		return o;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.LgModelObj#getContent(java.lang.Class, int)
	 */
	public Iterator getContent(Class contentClass, int distance) {
		List contained = new ArrayList();
		for (Iterator content = eContents().iterator(); content.hasNext(); ) {
			Object o = content.next(); 
			if (contentClass.isInstance(o))
				contained.add(o);
			if (distance != 0 && o instanceof LgModelObj)
				contained.addAll(
					IteratorUtils.toList(
						(((LgModelObj) o).getContent(contentClass, distance - 1))));
		}
		return contained.iterator();
	}

	/**
	 * Return the list of EMF structural features that, when considered together,
	 * serve to uniquely identify instances of the class.
	 * 
	 * @return The list of features.
	 */
	protected final List getIdentityFeatures() {
		EClass ec = eClass();
		if (EClass2IDFeatures.containsKey(ec))
			return (List) EClass2IDFeatures.get(ec);
		
		// Identity features for this class of object have not yet
		// been resolved.  Find and cache now.
		List ids = new ArrayList();
		for (Iterator attrs = ec.getEAllAttributes().iterator(); attrs.hasNext(); ) {
			EAttribute attr = (EAttribute) attrs.next();
			if (attr.isID())
				ids.add(attr);
		}
		EClass2IDFeatures.put(ec, ids);
		return ids;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.LgModelObj#getPreferredDisplayName()
	 */
	public String getPreferredDisplayName() {
		Object key = getPrimaryKey();
		return key != null ? key.toString() : getPreferredDisplayNameDefault();
	}

	/**
	 * Returns a default name displayed for the object if no name
	 * can be derived from assigned properties; this would typically
	 * be used to represent new objects that have not yet been
	 * assigned identifying information.
	 * @return String
	 */
	protected String getPreferredDisplayNameDefault() {
		return "<new item>";
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.LgModelObj#getPreferredTextDescription()
	 */
	public String getPreferredTextDescription() {
		return null;
	}

	/**
	 * @see org.LexGrid.managedobj.ManagedObjIF#getPrimaryKey()
	 * <p>
	 * Used to reference the object in persistent storage.
	 * The primary key is formed by concatenating string representations
	 * of the object's identifying features.
	 * <p>
	 * Returns null if no feature IDs are defined.
	 */
	public final Object getPrimaryKey() {
		List idFeatures = getIdentityFeatures();
		if (idFeatures.size() > 0) {
			if (idFeatures.size() == 1) {
				Object o = eGet((EStructuralFeature) idFeatures.get(0));
				return o != null ? o.toString() : null;
			} else {
				StringBuffer sb = new StringBuffer(64);
				Object featureValue;
				for (Iterator features = getIdentityFeatures().iterator(); features.hasNext(); )
					if ((featureValue = eGet((EStructuralFeature) features.next())) != null) {
						if (sb.length() > 0)
							sb.append("::");
						sb.append(featureValue.toString());
					}
				return sb.length() > 0 ? sb.toString() : null;
			}
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.ManagedObjIF#getSecondaryKey()
	 */
	public Object getSecondaryKey() {
		return null;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.LgStagedObj#getStagingService()
	 */
	public LgStagingService getStagingService() {
		return _stagingService;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.LgTrackable#getTrackingContext()
	 */
	public String getTrackingContext() {
		String context = null;
		EObject parent = eContainer();
		if (parent != null) {
			List contextItems = new ArrayList();
			while (parent != null) {
				contextItems.add(parent);
				parent = parent.eContainer();
			}
			StringBuffer sb = new StringBuffer(256);
			for (int i = contextItems.size() - 1; i >= 0; i--) {
				sb.append('/');
				sb.append(((LgModelObj) contextItems.get(i)).getTrackingID());
			}
			context = sb.toString();		
		}
		return context;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.LgTrackable#getTrackingID()
	 */
	public String getTrackingID() {
		Object key = getPrimaryKey();
		return key != null ? key.toString() : null;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.LgTrackable#getTrackingIDQualified()
	 */
	public String getTrackingIDQualified() {
		String context = getTrackingContext();
		return (context == null)
			? getTrackingID()
			: new StringBuffer(256)
				.append(context)
				.append("/")
				.append(getTrackingID())
				.toString();
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.LgTrackable#getTrackingType()
	 */
	public String getTrackingType() {
		return getClass().getName();
	}

	/**
	 * Indicates if a feature has been tagged as 'dirty', implying that the
	 * current value may be inaccurate or out-of-sync.
	 * @param feature
	 * @return boolean
	 */
	protected boolean internalIsDirty(EStructuralFeature feature) {
		return ((_fbits >> eDerivedStructuralFeatureID(feature)) & 1) == 0;
	}

	/**
	 * Indicates if a feature is in the process of being resolved.
	 * @param feature
	 * @return boolean
	 */
	protected boolean internalIsResolving(EStructuralFeature feature) {
		return ((_rbits >> eDerivedStructuralFeatureID(feature)) & 1) != 0;
	}

	/**
	 * Maintains a status flag for the given feature.
	 * <p>
	 * If <code>true</code>, the feature is considered set and accurate.
	 * If <code>false</code>, the feature is treated as unset, inconsistent,
	 * or out-of-sync.
	 * <p>
	 * Note: All features initially start in a 'dirty' state, and are
	 * cleaned explicitly or as values are set (via <b>eSet()</b>).
	 * <p>
	 * These flags are typically used internally for two purposes. First,
	 * they are used to determine when linked objects must be re-synchronized;
	 * typically because some counterpart attribute has changed.
	 * <p>
	 * Second, they are used to determine whether or not attribute values
	 * have been retrieved when staging of features is enabled. Note that it
	 * is not sufficient to rely on the <i>eIsSet()</i> method, since
	 * that method will always report false in cases when a field matches
	 * the default value. So if a boolean field is set to false, and the
	 * default is false, it will always be considered unset. However,
	 * the value may have been staged in. We track status so that features
	 * are staged in once and only once.
	 * @param feature
	 * @param isClean
	 */
	protected void internalMark(EStructuralFeature feature, boolean isClean) {
		if (isClean) _fbits |= (1 << eDerivedStructuralFeatureID(feature));
			else _fbits &= (1 << eDerivedStructuralFeatureID(feature));
	}

	/**
	 * Clear any 'dirty' status for the feature, implying that the
	 * current value is accurate.
	 * @param feature
	 */
	protected void internalMarkClean(EStructuralFeature feature) {
		internalMark(feature, true);
	}

	/**
	 * Tags a feature as dirty, implying that the current value
	 * may be inaccurate or out-of-sync. A corresponding notification is issued to listeners.
	 * @param feature
	 */
	protected void internalMarkDirty(EStructuralFeature feature) {
		internalMarkDirty(feature, true);
	}

	/**
	 * Tags a feature as dirty, implying that the current value
	 * may be inaccurate or out-of-sync. If requested and the feature's status has
	 * changed, a corresponding notification is issued to listeners.
	 * @param feature
	 * @param notify
	 */
	protected void internalMarkDirty(EStructuralFeature feature, boolean notify) {
		if (!internalIsDirty(feature)) {
			internalMark(feature, false);
			if (notify) {
				Object oldVal = eGet(feature, false);
				if (eNotificationRequired())
					eNotify(new LgDirtyFeatureNotificationImpl(this, feature, oldVal));
			}
		}
	}

	/**
	 * Assigns a flag indicating whether a feature is in the process of being resolved.
	 * @param feature
	 * @param isResolving
	 */
	protected void internalResolving(EStructuralFeature feature, boolean isResolving) {
		if (isResolving) _rbits |= (1 << eDerivedStructuralFeatureID(feature));
			else _rbits &= (1 << eDerivedStructuralFeatureID(feature));
	}

	/**
	 * Indicates if content for the item is still awaiting retrieval.
	 * @return boolean
	 */
	public boolean isContentPending() {
		return eProperties().getEContents() == null;
	}

	/**
	 * Indicates whether the object is capable of resolving features on demand.
	 * @return boolean
	 */
	protected boolean isStagingEnabled() {
		return _stagingService != null && _stagingService.isStagingEnabled();
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.ManagedObjIF#isTransient()
	 */
	public boolean isTransient() {
		return false;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.LgModelObj#removeIdentityListener(org.LexGrid.emf.base.LgIdentityListener)
	 */
	public void removeIdentityListener(LgIdentityListener listener) {
		// Note: in many cases there 0 or 1 listener, so we
		// optimize to this case in order to avoid the overhead of
		// maintaining a list.
		if (_idListener == listener)
			_idListener = null;
		else if (_idListeners != null) {
			_idListeners.remove(listener);
			if (_idListeners.isEmpty())
				_idListeners = null;
		}
	}

	/**
	 * Indicates whether or not the given feature is eligible
	 * for resolution.
	 * <p>
	 * By default, features are considered ineligible if a resolve
	 * operation is already in progress.
	 * @param eFeature
	 */
	protected boolean resolvable(EStructuralFeature eFeature) {
		return (!internalIsResolving(eFeature));
	}
	
	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.LgModelObj#resolveAllAttributes()
	 */
	public void resolveAllAttributes() {
	   for (Iterator attributes = eClass().getEAttributes().iterator(); attributes.hasNext(); ) {
		   EStructuralFeature feature = (EStructuralFeature) attributes.next();
		   if (!eIsSet(feature))
			   eGet(feature, true);
	   }
	}

	/**
	 * Attempts to fill in information for the object related to the given
	 * feature. By default, resolution is delegated to the associated staging
	 * service, if available.  Note that automatic resolution of additional
	 * features may also occur, at the discretion of the staging service
	 * provider, to allow performance optimization.
	 * @param eFeature
	 * @throws ServiceUnavailableException
	 * @throws ResolveException
	 */
	protected void resolveFeature(EStructuralFeature eFeature) throws ServiceUnavailableException, ResolveException {
		if (resolvable(eFeature)) {
			LgStagingService service = getStagingService();
			if (service != null && service.isStagingEnabled()) {
				boolean notifyOn = LgModelUtil.isNotifyRequired();
				try {
					LgModelUtil.setNotifyRequired(false);
					internalResolving(eFeature, true);
					service.stageFeature(this, eFeature);
				} finally {
					internalResolving(eFeature, false);
					LgModelUtil.setNotifyRequired(notifyOn);
				}
			}
		}
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.LgStagedObj#setStagingService(org.LexGrid.emf.base.LgStagingService)
	 */
	public void setStagingService(LgStagingService service) {
		_stagingService = service;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.LgStagedObj#stageComplete(org.eclipse.emf.ecore.EStructuralFeature)
	 */
	public void stageComplete(EStructuralFeature feature) {
		internalMarkClean(feature);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.LgStagedObj#stageComplete(org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EStructuralFeature, boolean)
	 */
	public void setContainer(EObject container, EStructuralFeature containerFeature, boolean addToContainer) {
		if (container == null)
			return;
		if (containerFeature != null && addToContainer) {
			Object o = container.eGet(containerFeature);
			if (o instanceof Collection)
				((Collection) o).add(o);
			else
				container.eSet(containerFeature, this);
			return;
		}
		if (container instanceof InternalEObject && !(container.equals(eContainer)))
			eBasicSetContainer((InternalEObject) container, containerFeature != null ? containerFeature.getFeatureID() : 0);
	}

}