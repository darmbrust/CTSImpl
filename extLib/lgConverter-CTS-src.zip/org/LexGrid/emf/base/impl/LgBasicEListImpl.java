/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.base.impl;

import java.util.Collection;
import java.util.NoSuchElementException;

import org.LexGrid.emf.base.LgConstrainableList;
import org.LexGrid.emf.base.LgConstraint;
import org.LexGrid.emf.base.LgModelObj;
import org.LexGrid.emf.base.LgPagedList;
import org.LexGrid.emf.base.LgPagedListService;
import org.LexGrid.managedobj.ResolveException;
import org.LexGrid.managedobj.ServiceUnavailableException;
import org.eclipse.emf.common.util.BasicEList;

/**
 * An EList implementation that allows for simple paging and constraints
 * to control resolution of a homogeneous collection of LexGrid managed objects.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class LgBasicEListImpl extends BasicEList implements LgConstrainableList, LgPagedList {
	/**
	 * 
	 */
	private static final long serialVersionUID = 258251239336449199L;
	private LgConstraint[] _constraints;
	private LgModelObj _pageContext = null;
	private LgPagedListService _pageService = null;
	private Object _pageCookie = null;
	private int _pageSize = 0;

	public LgBasicEListImpl() {
		super();
	}
	public LgBasicEListImpl(Collection collection) {
		super(collection);
	}
	public LgBasicEListImpl(int initialCapacity) {
		super(initialCapacity);
	}
	public LgBasicEListImpl(int size, Object[] data) {
		super(size, data);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.collection.LgPagedList#disposePage()
	 */
	public void disposePage() {
		if (_pageService != null)
			_pageService.pagedListDisposed(this);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.collection.LgConstrainableList#getConstraints()
	 */
	public LgConstraint[] getConstraints() {
		return _constraints;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.collection.LgPagedList#getPageCookie()
	 */
	public Object getPageCookie() {
		return _pageCookie;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.collection.LgPagedList#getPageSize()
	 */
	public int getPageSize() {
		return _pageSize;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.collection.LgPagedList#getPagingContext()
	 */
	public LgModelObj getPagingContext() {
		return _pageContext;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.collection.LgPagedList#getPagingService()
	 */
	public LgPagedListService getPagingService() {
		return _pageService;
	}

	/**
	 * Grows the capacity of the list to ensure that no additional growth
	 * is needed until after an additional page of information is added.
	 */
	protected void growPage() {
		grow(size() + getPageSize());
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.collection.LgConstrainableList#isConstrained()
	 */
	public boolean isConstrained() {
		return _constraints != null && _constraints.length > 0;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.collection.LgPagedList#isComplete()
	 */
	public boolean isPagingComplete() {
		return getPagingService() == null || getPageCookie() == null;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.collection.LgPagedList#resolveAll()
	 */
	public void resolveAll() throws ResolveException {
		while (!isPagingComplete())
			resolvePage();
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.collection.LgPagedList#resolvePage()
	 */
	public void resolvePage() throws ResolveException {
		if (!isPagingComplete()) {
			LgPagedListService service = getPagingService();
			if (service != null) {
				growPage();
				service.resolveNextPage(this);
			} else
				throw new ResolveException(
					new ServiceUnavailableException());
		} else
			throw new ResolveException(
				new NoSuchElementException());
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.collection.LgPagedList#resolvePagesTo(int)
	 */
	public boolean resolvePagesTo(int index) throws ResolveException {
		while (index >= size && !isPagingComplete())
			resolvePage();
		return index < size;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.collection.LgConstrainableList#setConstraints(org.LexGrid.emf.base.collection.LgConstraint[])
	 */
	public void setConstraints(LgConstraint[] constraints) {
		_constraints = constraints;
	}

	/**
	 * Sets the model object providing context for resolved objects;
	 * null if not applicable.
	 * @param context
	 */
	public void setPageContext(LgModelObj context) {
		_pageContext = context;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.collection.LgPagedList#setPageCookie(java.lang.Object)
	 */
	public void setPageCookie(Object cookie) {
		_pageCookie = cookie;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.collection.LgPagedList#setPageSize(int)
	 */
	public void setPageSize(int size) {
		if (size < 0)
			throw new IllegalArgumentException("size");
		_pageSize = size;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.collection.LgPagedList#setPagingService(org.LexGrid.emf.base.collection.LgPagedListService)
	 */
	public void setPagingService(LgPagedListService service) {
		_pageService = service;
	}

}