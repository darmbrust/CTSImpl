/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.base.impl;

import org.LexGrid.emf.base.LgConstraint;
import org.eclipse.emf.ecore.EStructuralFeature;

/**
 * Provides a tuple combining a model feature, relationship type,
 * and comparison value used as criteria for constraint-based ELists.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class LgConstraintImpl implements LgConstraint {
	private EStructuralFeature _modelFeature = null;
	private int _relationType = RELATION_equals;
	private Object _compareValue = null;

	/**
	 * Default constructor.
	 */
	public LgConstraintImpl() {
		super();
	}

	/**
	 * Constructor allowing initialization of object properties.
	 */
	public LgConstraintImpl(
		EStructuralFeature feature,
		int type,
		Object compareValue) {
		super();
		setModelFeature(feature);
		setRelationType(type);
		setCompareValue(compareValue);
	}

	/**
	 * Returns the value used as reference when testing candidate
	 * objects for a match against the assigned feature/relation.
	 * @return Object
	 */
	public Object getCompareValue() {
		return _compareValue;
	}

	/**
	 * Returns the feature to compare for candidate objects.
	 * @return EStructuralFeature
	 */
	public EStructuralFeature getModelFeature() {
		return _modelFeature;
	}

	/**
	 * Returns the type of comparison performed when evaluating
	 * the model feature against the reference value.
	 * <p>
	 * Well-known types are defined as constants on this class.
	 * @return int
	 */
	public int getRelationType() {
		return _relationType;
	}

	/**
	 * Sets the value used as reference when testing candidate
	 * objects for a match against the assigned feature/relation.
	 * @param object
	 */
	public void setCompareValue(Object object) {
		_compareValue = object;
	}

	/**
	 * Sets the feature to compare for candidate objects.
	 * @param feature
	 */
	public void setModelFeature(EStructuralFeature feature) {
		_modelFeature = feature;
	}

	/**
	 * Sets the type of comparison performed when evaluating
	 * the model feature against the reference value.
	 * <p>
	 * Well-known types are defined as constants on this class.
	 * @param i
	 */
	public void setRelationType(int i) {
		_relationType = i;
	}

}