/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.base.impl;

import java.util.Comparator;
import java.util.SortedMap;
import java.util.TreeMap;

import org.LexGrid.emf.base.LgIdentityListener;
import org.LexGrid.emf.base.LgKeyedList;
import org.LexGrid.emf.base.LgModelObj;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;

/**
 * An EList implementation that provides direct resolution of contained
 * LexGrid Managed Objects (instances of LgModelObj) by primary key.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class LgKeyedEListImpl extends EObjectContainmentEList implements LgKeyedList, LgIdentityListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4814486687164274968L;
	protected static Comparator _keyComparator = new Comparator() {
		public int compare(Object o1, Object o2) {
			if (o1 instanceof Comparable && o2 instanceof Comparable)
				return ((Comparable) o1).compareTo(o2);
			int o1hash = o1 == null ? 0 : o1.hashCode();
			int o2hash = o2 == null ? 0 : o2.hashCode();
			return o1hash - o2hash;
		}
	};
	protected SortedMap _byKey = new TreeMap(_keyComparator);
	protected int _incCapacity = 1024;

	public LgKeyedEListImpl(Class dataClass, InternalEObject owner, int featureID) {
		this(dataClass, owner, featureID, -1, -1);
	}
	public LgKeyedEListImpl(Class dataClass, InternalEObject owner, int featureID, int initialCapacity, int incrementalCapacity) {
		super(dataClass, owner, featureID);
		if (initialCapacity > 0)
			setData(initialCapacity, newData(initialCapacity));
		setIncrementalCapacity(incrementalCapacity);
	}

	public void clear() {
		try {
			clearByKey();
		} finally {
			super.clear();
		}
	}

	/**
	 * Clears all keyed references maintained by this subclass. 
	 */
	protected void clearByKey() {
		Object[] vals = _byKey.values().toArray();
		LgModelObj model;
		for (int i = 0; i < vals.length; i++) {
			Object val = vals[i];
			if (val instanceof LgModelObj) {
				_byKey.remove(
					(model = (LgModelObj) val).getPrimaryKey());
				model.removeIdentityListener(this);
			}
		}
	}

	/* (non-Javadoc)
	 * @see java.util.Collection#contains(java.lang.Object)
	 */
	public boolean contains(Object object) {
		if (object instanceof LgModelObj) {
			Object key = ((LgModelObj) object).getPrimaryKey();
			if (key != null)
				return getByPrimaryKey(key) != null;
		}
		return super.contains(object);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.emf.common.util.BasicEList#didAdd(int, java.lang.Object)
	 */
	protected void didAdd(int i, Object o) {
		super.didAdd(i, o);
		if (o instanceof LgModelObj)
			keyAdd((LgModelObj) o);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.emf.common.util.BasicEList#didRemove(int, java.lang.Object)
	 */
	protected void didRemove(int i, Object o) {
		super.didRemove(i, o);
		if (o instanceof LgModelObj)
			keyRemove((LgModelObj) o);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.emf.common.util.BasicEList#didSet(int, java.lang.Object, java.lang.Object)
	 */
	protected void didSet(int i, Object o, Object old) {
		super.didSet(i, o, old);
		if (old instanceof LgModelObj)
			keyRemove((LgModelObj) old);
		if (o instanceof LgModelObj)
			keyAdd((LgModelObj) o);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#finalize()
	 */
	protected void finalize() throws Throwable {
		try {
			clearByKey();
		} finally {
			super.finalize();
		}
	}

	/**
	 * Returns the contained object with the given primary key;
	 * null if not available.
	 * @param key
	 * @return LgModelObj
	 */
	public LgModelObj getByPrimaryKey(Object key) {
		return (LgModelObj) _byKey.get(key);
	}

	/**
	 * @return The minimum expansion size when growing the array used to maintain list data.
	 */
	protected int getIncrementalCapacity() {
		return _incCapacity > 0 || data == null ? _incCapacity : data.length / 2;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.emf.common.util.BasicEList#grow(int)
	 */
	public void grow(int minimumCapacity) {
		super.modCount++;
		int oldCapacity = data != null ? data.length : 0;
		if (minimumCapacity > oldCapacity) {
			Object oldData[] = data;
			data = newData(Math.max(minimumCapacity, oldCapacity + getIncrementalCapacity()));
			if (oldData != null)
				System.arraycopy(oldData, 0, data, 0, oldCapacity);
		}
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.LgIdentityListener#identityChanged(org.eclipse.emf.common.notify.Notification)
	 */
	public void identityChanged(Notification msg) {
		Object notifier = msg.getNotifier();
		if (notifier instanceof LgModelObj)
			keyReplace((LgModelObj) notifier, msg.getOldValue());
	}

	/**
	 * Register the given object for lookup by primary key.
	 * @param o
	 */
	protected void keyAdd(LgModelObj o) {
		keyAdd(o, o.getPrimaryKey());
	}

	/**
	 * Register the given object for lookup by key.
	 * @param o
	 * @param key
	 */
	protected void keyAdd(LgModelObj o, Object key) {
		Object old;
		if (key != null) {
			old = _byKey.put(key, o);
			if (old != o) {
				o.addIdentityListener(this);
				if (old != null)
					((LgModelObj) old).removeIdentityListener(this);
			}
		} else
			o.addIdentityListener(this);	
	}

	/**
	 * Deregister the given object for lookup by primary key.
	 * @param o
	 */
	protected void keyRemove(LgModelObj o) {
		keyRemove(o, o.getPrimaryKey());
	}

	/**
	 * Deregister the given object for lookup by key.
	 * @param o
	 * @param key
	 */
	protected void keyRemove(LgModelObj o, Object key) {
		if (key != null) {
			Object old = _byKey.remove(key);
			if (old != null)
				((LgModelObj) old).removeIdentityListener(this);
			if (old != o)
				o.removeIdentityListener(this);
		}
	}

	/**
	 * Deregister the given object for lookup by key.
	 * @param o
	 * @param oldKey
	 */
	protected void keyReplace(LgModelObj o, Object oldKey) {
		keyRemove(o, oldKey);
		keyAdd(o, o.getPrimaryKey());
	}

	/**
	 * Deregister the given object for lookup by key.
	 * @param o
	 * @param oldKey
	 * @param newKey
	 */
	protected void keyReplace(LgModelObj o, Object oldKey, Object newKey) {
		keyRemove(o, oldKey);
		keyAdd(o, newKey);
	}

	public void setData(int size, Object[] data) {
		try {
			clearByKey();
		} finally {
			super.setData(size, data);
			if (data != null)
				for (int i = 0; i < data.length; i++)
					didAdd(i, data[i]);
		}
	}

	/**
	 * @param i The expansion size when growing the array used to maintain list data.
	 */
	protected void setIncrementalCapacity(int i) {
		_incCapacity = i;
	}

}