/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.base.impl;

import org.LexGrid.emf.base.LgTrackingEntry;
import org.LexGrid.managedobj.OIDBasedObj;

/**
 * Provides a concrete implementation of the tracking entry interface.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class LgTrackingEntryImpl extends OIDBasedObj implements LgTrackingEntry {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3803019501708776799L;
	boolean _committed = false;
	int _featureID = -1;
	int _event = 0;
	long _timeMs = 0;
	String _context = null;
	String _data = null;
	String _item = null;
	String _type = null;

	public LgTrackingEntryImpl() {
		super();
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntry#getCommitted()
	 */
	public boolean getCommitted() {
		return _committed;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntry#getDetail()
	 */
	public String getDetail() {
		return _data;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntry#getEventType()
	 */
	public int getEventType() {
		return _event;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntry#getFeatureID()
	 */
	public int getFeatureID() {
		return _featureID;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntry#getItemContext()
	 */
	public String getItemContext() {
		return _context;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntry#getItemID()
	 */
	public String getItemID() {
		return _item;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntry#getItemType()
	 */
	public String getItemType() {
		return _type;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntry#getTimestamp()
	 */
	public long getTimestamp() {
		return _timeMs;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntry#setCommitted(boolean)
	 */
	public void setCommitted(boolean isCommitted) {
		_committed = isCommitted;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntry#setDetail(java.lang.String)
	 */
	public void setDetail(String data) {
		_data = data;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntry#setEventType(int)
	 */
	public void setEventType(int event) {
		_event = event;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntry#setFeatureID(int)
	 */
	public void setFeatureID(int val) {
		_featureID = val;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntry#setItemContext(java.lang.String)
	 */
	public void setItemContext(String val) {
		_context = val;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntry#setItem(java.lang.String)
	 */
	public void setItemID(String val) {
		_item = val;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntry#setItemType(java.lang.String)
	 */
	public void setItemType(String val) {
		_type = val;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.emf.base.tracking.LgTrackingEntry#setTimestamp(long)
	 */
	public void setTimestamp(long val) {
		_timeMs = val;
	}

}