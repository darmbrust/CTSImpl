/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.base;

import java.util.List;

import org.LexGrid.managedobj.ResolveException;

/**
 * A List definition that provides on-demand resolution of
 * LexGrid model objects (instances of LgModelObj) in fixed-size chunks.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public interface LgPagedList extends List {
	
	/**
	 * Invoked when the given list is no longer in use to allow
	 * cleanup of associated resources.
	 */
	void disposePage();

	/**
	 * Returns an opaque object maintained by the paging service
	 * as a position reference for subsequent paging requests. 
	 * @return Object
	 */
	Object getPageCookie();

	/**
	 * Returns the maximum number of items retrieved in each virtual page;
	 * a value of zero indicates to retrieve all items
	 * as a single page.
	 * @return int
	 */
	int getPageSize();

	/**
	 * Returns the model object providing context for resolved objects;
	 * null if not applicable.
	 * @return LgModelObj
	 */
	LgModelObj getPagingContext();
	
	/**
	 * Returns the service used to resolve paged information on demand;
	 * null if not applicable.
	 * @return LgPagedListService
	 */
	LgPagedListService getPagingService();

	/**
	 * Indicates whether or not all available information has been resolved.
	 * @return boolean
	 */
	boolean isPagingComplete();

	/**
	 * Forces resolution of all available content.
	 * @throws ResolveException
	 */	
	void resolveAll() throws ResolveException;
	
	/**
	 * Resolves the next page of information, if available, growing the list
	 * as necessary. Upon completion, the <i>isPagingComplete()</i> method will
	 * indicate whether more information is available. 
	 * @throws ResolveException
	 */	
	void resolvePage() throws ResolveException;
	
	/**
	 * Instructs the receiver to page in information up to and including
	 * the item with the given index, if available. The list is grown as
	 * necessary to accomodate newly resolved items.
	 * @param index The index of the desired item.
	 * @return true if the resulting list is large enough to contain an
	 * item at the provided index; false otherwise. If false,
	 * the index of the last available item can be determined based on
	 * the updated list size. 
	 * @throws ResolveException
	 */
	boolean resolvePagesTo(int index) throws ResolveException;

	/**
	 * Sets an opaque object maintained by the paging service
	 * as a position reference for subsequent paging requests. 
	 * @param cookie Object
	 */
	void setPageCookie(Object cookie);

	/**
	 * Sets the maximum number of items retrieved in each virtual page;
	 * a value of zero indicates to retrieve all items
	 * as a single page.
	 * @param size int
	 */
	void setPageSize(int size);

	/**
	 * Sets the service used to resolve paged information on demand;
	 * null if not applicable.
	 * @param service LgPagedListService
	 */
	void setPagingService(LgPagedListService service);

}