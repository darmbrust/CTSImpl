/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.base;

import org.eclipse.emf.ecore.EStructuralFeature;

/**
 * Describes a tuple combining a model feature, relationship type,
 * and comparison value used as criteria for constraint-based ELists.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public interface LgConstraint {

	// Well-known relation types ...
	public static final int RELATION_equals = 0;
	public static final int RELATION_contains = 1;
	public static final int RELATION_beginsWith = 2;	  
	public static final int RELATION_endsWith = 3;	  
	public static final int RELATION_greaterThanOrEqualTo = 4;
	public static final int RELATION_lessThanOrEqualTo = 5;

	/**
	 * Returns the value used as reference when testing candidate
	 * objects for a match against the assigned feature/relation.
	 * @return Object
	 */
	Object getCompareValue();

	/**
	 * Returns the feature to compare for candidate objects.
	 * @return EStructuralFeature
	 */
	EStructuralFeature getModelFeature();

	/**
	 * Returns the type of comparison performed when evaluating
	 * the model feature against the reference value.
	 * <p>
	 * Well-known types are defined as constants on this class.
	 * @return int
	 */
	int getRelationType();

}