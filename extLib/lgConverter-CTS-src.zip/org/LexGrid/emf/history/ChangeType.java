/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.LexGrid.emf.history;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.AbstractEnumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Change Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * <!-- begin-model-doc -->
 * Atomic modification actions. To be populated from a combination of Concordia, SNOMED-CT list and NCI's action
 * 			list.
 * <!-- end-model-doc -->
 * @see org.LexGrid.emf.history.NCIHistoryPackage#getChangeType()
 * @model
 * @generated
 */
public final class ChangeType extends AbstractEnumerator {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * The '<em><b>Create</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Create a new concept.
	 * <!-- end-model-doc -->
	 * @see #CREATE_LITERAL
	 * @model name="create"
	 * @generated
	 * @ordered
	 */
	public static final int CREATE = 0;

	/**
	 * The '<em><b>Retire</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Retire a concept so that it can be referenced by identifier, but will not appear in searches for active
	 * 					concepts
	 * <!-- end-model-doc -->
	 * @see #RETIRE_LITERAL
	 * @model name="retire"
	 * @generated
	 * @ordered
	 */
	public static final int RETIRE = 1;

	/**
	 * The '<em><b>Merge</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Two or more concepts were combined.
	 * <!-- end-model-doc -->
	 * @see #MERGE_LITERAL
	 * @model name="merge"
	 * @generated
	 * @ordered
	 */
	public static final int MERGE = 2;

	/**
	 * The '<em><b>Split</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Concept was divided into two or more parts.
	 * <!-- end-model-doc -->
	 * @see #SPLIT_LITERAL
	 * @model name="split"
	 * @generated
	 * @ordered
	 */
	public static final int SPLIT = 3;

	/**
	 * The '<em><b>Modify</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * One or more associations were removed
	 * <!-- end-model-doc -->
	 * @see #MODIFY_LITERAL
	 * @model name="modify"
	 * @generated
	 * @ordered
	 */
	public static final int MODIFY = 4;

	/**
	 * The '<em><b>Create</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CREATE
	 * @generated
	 * @ordered
	 */
	public static final ChangeType CREATE_LITERAL = new ChangeType(CREATE, "create", "create");

	/**
	 * The '<em><b>Retire</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #RETIRE
	 * @generated
	 * @ordered
	 */
	public static final ChangeType RETIRE_LITERAL = new ChangeType(RETIRE, "retire", "retire");

	/**
	 * The '<em><b>Merge</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MERGE
	 * @generated
	 * @ordered
	 */
	public static final ChangeType MERGE_LITERAL = new ChangeType(MERGE, "merge", "merge");

	/**
	 * The '<em><b>Split</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SPLIT
	 * @generated
	 * @ordered
	 */
	public static final ChangeType SPLIT_LITERAL = new ChangeType(SPLIT, "split", "split");

	/**
	 * The '<em><b>Modify</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MODIFY
	 * @generated
	 * @ordered
	 */
	public static final ChangeType MODIFY_LITERAL = new ChangeType(MODIFY, "modify", "modify");

	/**
	 * An array of all the '<em><b>Change Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final ChangeType[] VALUES_ARRAY = new ChangeType[] { CREATE_LITERAL, RETIRE_LITERAL, MERGE_LITERAL,
			SPLIT_LITERAL, MODIFY_LITERAL, };

	/**
	 * A public read-only list of all the '<em><b>Change Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Change Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static ChangeType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			ChangeType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Change Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static ChangeType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			ChangeType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Change Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static ChangeType get(int value) {
		switch (value) {
		case CREATE:
			return CREATE_LITERAL;
		case RETIRE:
			return RETIRE_LITERAL;
		case MERGE:
			return MERGE_LITERAL;
		case SPLIT:
			return SPLIT_LITERAL;
		case MODIFY:
			return MODIFY_LITERAL;
		}
		return null;
	}

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private ChangeType(int value, String name, String literal) {
		super(value, name, literal);
	}

} //ChangeType
