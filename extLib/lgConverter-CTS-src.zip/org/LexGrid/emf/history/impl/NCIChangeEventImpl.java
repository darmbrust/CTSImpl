/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.LexGrid.emf.history.impl;

import org.LexGrid.emf.base.impl.LgModelObjImpl;
import org.LexGrid.emf.history.ChangeType;
import org.LexGrid.emf.history.NCIChangeEvent;
import org.LexGrid.emf.history.NCIHistoryPackage;
import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>NCI Change Event</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.LexGrid.emf.history.impl.NCIChangeEventImpl#getConceptcode <em>Conceptcode</em>}</li>
 *   <li>{@link org.LexGrid.emf.history.impl.NCIChangeEventImpl#getConceptName <em>Concept Name</em>}</li>
 *   <li>{@link org.LexGrid.emf.history.impl.NCIChangeEventImpl#getEditaction <em>Editaction</em>}</li>
 *   <li>{@link org.LexGrid.emf.history.impl.NCIChangeEventImpl#getReferencecode <em>Referencecode</em>}</li>
 *   <li>{@link org.LexGrid.emf.history.impl.NCIChangeEventImpl#getReferencename <em>Referencename</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class NCIChangeEventImpl extends LgModelObjImpl implements NCIChangeEvent {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NCIChangeEventImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return NCIHistoryPackage.Literals.NCI_CHANGE_EVENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getConceptcode() {
		return (String) eGet(NCIHistoryPackage.Literals.NCI_CHANGE_EVENT__CONCEPTCODE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setConceptcode(String newConceptcode) {
		eSet(NCIHistoryPackage.Literals.NCI_CHANGE_EVENT__CONCEPTCODE, newConceptcode);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getConceptName() {
		return (String) eGet(NCIHistoryPackage.Literals.NCI_CHANGE_EVENT__CONCEPT_NAME, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setConceptName(String newConceptName) {
		eSet(NCIHistoryPackage.Literals.NCI_CHANGE_EVENT__CONCEPT_NAME, newConceptName);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ChangeType getEditaction() {
		return (ChangeType) eGet(NCIHistoryPackage.Literals.NCI_CHANGE_EVENT__EDITACTION, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEditaction(ChangeType newEditaction) {
		eSet(NCIHistoryPackage.Literals.NCI_CHANGE_EVENT__EDITACTION, newEditaction);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetEditaction() {
		eUnset(NCIHistoryPackage.Literals.NCI_CHANGE_EVENT__EDITACTION);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetEditaction() {
		return eIsSet(NCIHistoryPackage.Literals.NCI_CHANGE_EVENT__EDITACTION);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getReferencecode() {
		return (String) eGet(NCIHistoryPackage.Literals.NCI_CHANGE_EVENT__REFERENCECODE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReferencecode(String newReferencecode) {
		eSet(NCIHistoryPackage.Literals.NCI_CHANGE_EVENT__REFERENCECODE, newReferencecode);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getReferencename() {
		return (String) eGet(NCIHistoryPackage.Literals.NCI_CHANGE_EVENT__REFERENCENAME, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReferencename(String newReferencename) {
		eSet(NCIHistoryPackage.Literals.NCI_CHANGE_EVENT__REFERENCENAME, newReferencename);
	}

} //NCIChangeEventImpl