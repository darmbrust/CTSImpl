/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.LexGrid.emf.history;

import org.LexGrid.emf.base.LgModelObj;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>NCI Change Event</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 *  A change event as documented in ftp://ftp1.nci.nih.gov/pub/cacore/EVS/ReadMe_history.txt. Note that date and time of the change
 * 				event is recorded in the containing version. All change events for the same/date and time a recorded in the same verison. 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.LexGrid.emf.history.NCIChangeEvent#getConceptcode <em>Conceptcode</em>}</li>
 *   <li>{@link org.LexGrid.emf.history.NCIChangeEvent#getConceptName <em>Concept Name</em>}</li>
 *   <li>{@link org.LexGrid.emf.history.NCIChangeEvent#getEditaction <em>Editaction</em>}</li>
 *   <li>{@link org.LexGrid.emf.history.NCIChangeEvent#getReferencecode <em>Referencecode</em>}</li>
 *   <li>{@link org.LexGrid.emf.history.NCIChangeEvent#getReferencename <em>Referencename</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.LexGrid.emf.history.NCIHistoryPackage#getNCIChangeEvent()
 * @model extendedMetaData="name='NCIChangeEvent' kind='empty'"
 * @extends LgModelObj
 * @generated
 */
public interface NCIChangeEvent extends LgModelObj {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Returns the value of the '<em><b>Conceptcode</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The unique, permanent, alphanumeric identifier of the concept
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Conceptcode</em>' attribute.
	 * @see #setConceptcode(String)
	 * @see org.LexGrid.emf.history.NCIHistoryPackage#getNCIChangeEvent_Conceptcode()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.ConceptCode" required="true"
	 *        extendedMetaData="kind='attribute' name='conceptcode'"
	 * @generated
	 */
	String getConceptcode();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.history.NCIChangeEvent#getConceptcode <em>Conceptcode</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Conceptcode</em>' attribute.
	 * @see #getConceptcode()
	 * @generated
	 */
	void setConceptcode(String value);

	/**
	 * Returns the value of the '<em><b>Concept Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The current text name of the concept. Typed as conceptCode because it serves that function.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Concept Name</em>' attribute.
	 * @see #setConceptName(String)
	 * @see org.LexGrid.emf.history.NCIHistoryPackage#getNCIChangeEvent_ConceptName()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.ConceptCode" required="true"
	 *        extendedMetaData="kind='attribute' name='conceptName'"
	 * @generated
	 */
	String getConceptName();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.history.NCIChangeEvent#getConceptName <em>Concept Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Concept Name</em>' attribute.
	 * @see #getConceptName()
	 * @generated
	 */
	void setConceptName(String value);

	/**
	 * Returns the value of the '<em><b>Editaction</b></em>' attribute.
	 * The default value is <code>"create"</code>.
	 * The literals are from the enumeration {@link org.LexGrid.emf.history.ChangeType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The activity being recorded (create, modify, split, merge, retire)
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Editaction</em>' attribute.
	 * @see org.LexGrid.emf.history.ChangeType
	 * @see #isSetEditaction()
	 * @see #unsetEditaction()
	 * @see #setEditaction(ChangeType)
	 * @see org.LexGrid.emf.history.NCIHistoryPackage#getNCIChangeEvent_Editaction()
	 * @model default="create" unique="false" unsettable="true" required="true"
	 *        extendedMetaData="kind='attribute' name='editaction'"
	 * @generated
	 */
	ChangeType getEditaction();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.history.NCIChangeEvent#getEditaction <em>Editaction</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Editaction</em>' attribute.
	 * @see org.LexGrid.emf.history.ChangeType
	 * @see #isSetEditaction()
	 * @see #unsetEditaction()
	 * @see #getEditaction()
	 * @generated
	 */
	void setEditaction(ChangeType value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.history.NCIChangeEvent#getEditaction <em>Editaction</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetEditaction()
	 * @see #getEditaction()
	 * @see #setEditaction(ChangeType)
	 * @generated
	 */
	void unsetEditaction();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.history.NCIChangeEvent#getEditaction <em>Editaction</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Editaction</em>' attribute is set.
	 * @see #unsetEditaction()
	 * @see #getEditaction()
	 * @see #setEditaction(ChangeType)
	 * @generated
	 */
	boolean isSetEditaction();

	/**
	 * Returns the value of the '<em><b>Referencecode</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The identifier for a concept affected by or influencing the action, as detailed below
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Referencecode</em>' attribute.
	 * @see #setReferencecode(String)
	 * @see org.LexGrid.emf.history.NCIHistoryPackage#getNCIChangeEvent_Referencecode()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.ConceptCode"
	 *        extendedMetaData="kind='attribute' name='referencecode'"
	 * @generated
	 */
	String getReferencecode();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.history.NCIChangeEvent#getReferencecode <em>Referencecode</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Referencecode</em>' attribute.
	 * @see #getReferencecode()
	 * @generated
	 */
	void setReferencecode(String value);

	/**
	 * Returns the value of the '<em><b>Referencename</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The current text name of the reference concept in all cases except concept name changes. For these, the referencename is the
	 * 					old name of the current concept. Reference codes are recorded in the following circumstances: Merges - In a merge, two concepts are merged
	 * 					into one. One of the two concepts survives and the other concept is retired. A merge history record is written for both of the concepts with
	 * 					a reference code of the surviving concept and a retire record is written for the concept that retires. In the case of A merging with B and A
	 * 					surviving, the history will appear as follows: C11111|A|merge|dd-mon-yy|C11111|A C22222|B|merge|dd-mon-yy|C11111|A
	 * 					C22222|B|retire|dd-mon-yy|(null)|(null) Splits - In a split, a single concept is split into two. The original concept survives and a new
	 * 					concept is generated. Two split records are written for the original concept with reference codes for the resulting concepts and a create
	 * 					history record is written for the new concept. In the case of A being split into A and B the history will appear as follows:
	 * 					C22222|B|create|dd-mon-yy|(null)|(null) C11111|A|split|dd-mon-yy|C22222|B C11111|A|split|dd-mon-yy|C11111|A Retires - In a retirement the
	 * 					concept is moved from it's old location in the tree hierarchy into the Retired_Kind. A retire record is written for the retiring concept
	 * 					with a reference code of the old superconcept. If a concept has multiple superconcepts, then a retire record is written for each reference.
	 * 					In the case of retiring concept A which has two superconcepts (B and C), the history will appear as follows:
	 * 					C11111|A|retire|dd-mon-yy|C22222|B C11111|A|retire|dd-mon-yy|C33333|C Concept Name Changes - When a history record is written, the current
	 * 					name of the concept is recorded in the history. We can match the conceptcode from the current Thesaurus against the conceptcodes in the
	 * 					history to determine if any conceptnames have changed. In the case of concept A having it's name changed to B, the history will appear as
	 * 					follows: C11111|B|modify|dd-mon-yy|(null)|A 
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Referencename</em>' attribute.
	 * @see #setReferencename(String)
	 * @see org.LexGrid.emf.history.NCIHistoryPackage#getNCIChangeEvent_Referencename()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.ConceptCode"
	 *        extendedMetaData="kind='attribute' name='referencename'"
	 * @generated
	 */
	String getReferencename();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.history.NCIChangeEvent#getReferencename <em>Referencename</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Referencename</em>' attribute.
	 * @see #getReferencename()
	 * @generated
	 */
	void setReferencename(String value);

} // NCIChangeEvent