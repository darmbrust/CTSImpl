/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.LexGrid.emf.history;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * <!-- begin-model-doc -->
 * 
 * 			<h2 xmlns="http://LexGrid.org/schema/2006/01/LexGrid/NCIHistory">Version change definition for NCI change model</h2>
 * 		
 * The change type below is designed to be referenced in the changeInstructions portion of a codingScheme version when the source of the
 * 			changes is NCI or equivalent. 
 * 
 * 			<h2 xmlns="http://LexGrid.org/schema/2006/01/LexGrid/builtins">Core data types for the lexical grid.</h2>
 * 		
 * These types need to be mapped to the appropriate implementation specific data types. The mapping in this package represents the XML
 * 			Schema data types mapping
 * LDAP specific types for appinfo annotation
 * Basic builtin types
 * <!-- end-model-doc -->
 * @see org.LexGrid.emf.history.NCIHistoryFactory
 * @model kind="package"
 * @generated
 */
public interface NCIHistoryPackage extends EPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "history";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://LexGrid.org/schema/2006/01/LexGrid/NCIHistory";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "NCIHistory";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	NCIHistoryPackage eINSTANCE = org.LexGrid.emf.history.impl.NCIHistoryPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.history.impl.NCIChangeEventImpl <em>NCI Change Event</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.history.impl.NCIChangeEventImpl
	 * @see org.LexGrid.emf.history.impl.NCIHistoryPackageImpl#getNCIChangeEvent()
	 * @generated
	 */
	int NCI_CHANGE_EVENT = 0;

	/**
	 * The feature id for the '<em><b>Conceptcode</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NCI_CHANGE_EVENT__CONCEPTCODE = 0;

	/**
	 * The feature id for the '<em><b>Concept Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NCI_CHANGE_EVENT__CONCEPT_NAME = 1;

	/**
	 * The feature id for the '<em><b>Editaction</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NCI_CHANGE_EVENT__EDITACTION = 2;

	/**
	 * The feature id for the '<em><b>Referencecode</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NCI_CHANGE_EVENT__REFERENCECODE = 3;

	/**
	 * The feature id for the '<em><b>Referencename</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NCI_CHANGE_EVENT__REFERENCENAME = 4;

	/**
	 * The number of structural features of the '<em>NCI Change Event</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NCI_CHANGE_EVENT_FEATURE_COUNT = 5;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.history.ChangeType <em>Change Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.history.ChangeType
	 * @see org.LexGrid.emf.history.impl.NCIHistoryPackageImpl#getChangeType()
	 * @generated
	 */
	int CHANGE_TYPE = 1;

	/**
	 * The meta object id for the '<em>Change Type Object</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.history.ChangeType
	 * @see org.LexGrid.emf.history.impl.NCIHistoryPackageImpl#getChangeTypeObject()
	 * @generated
	 */
	int CHANGE_TYPE_OBJECT = 2;

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.history.NCIChangeEvent <em>NCI Change Event</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>NCI Change Event</em>'.
	 * @see org.LexGrid.emf.history.NCIChangeEvent
	 * @generated
	 */
	EClass getNCIChangeEvent();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.history.NCIChangeEvent#getConceptcode <em>Conceptcode</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Conceptcode</em>'.
	 * @see org.LexGrid.emf.history.NCIChangeEvent#getConceptcode()
	 * @see #getNCIChangeEvent()
	 * @generated
	 */
	EAttribute getNCIChangeEvent_Conceptcode();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.history.NCIChangeEvent#getConceptName <em>Concept Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Concept Name</em>'.
	 * @see org.LexGrid.emf.history.NCIChangeEvent#getConceptName()
	 * @see #getNCIChangeEvent()
	 * @generated
	 */
	EAttribute getNCIChangeEvent_ConceptName();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.history.NCIChangeEvent#getEditaction <em>Editaction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Editaction</em>'.
	 * @see org.LexGrid.emf.history.NCIChangeEvent#getEditaction()
	 * @see #getNCIChangeEvent()
	 * @generated
	 */
	EAttribute getNCIChangeEvent_Editaction();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.history.NCIChangeEvent#getReferencecode <em>Referencecode</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Referencecode</em>'.
	 * @see org.LexGrid.emf.history.NCIChangeEvent#getReferencecode()
	 * @see #getNCIChangeEvent()
	 * @generated
	 */
	EAttribute getNCIChangeEvent_Referencecode();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.history.NCIChangeEvent#getReferencename <em>Referencename</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Referencename</em>'.
	 * @see org.LexGrid.emf.history.NCIChangeEvent#getReferencename()
	 * @see #getNCIChangeEvent()
	 * @generated
	 */
	EAttribute getNCIChangeEvent_Referencename();

	/**
	 * Returns the meta object for enum '{@link org.LexGrid.emf.history.ChangeType <em>Change Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Change Type</em>'.
	 * @see org.LexGrid.emf.history.ChangeType
	 * @generated
	 */
	EEnum getChangeType();

	/**
	 * Returns the meta object for data type '{@link org.LexGrid.emf.history.ChangeType <em>Change Type Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Change Type Object</em>'.
	 * @see org.LexGrid.emf.history.ChangeType
	 * @model instanceClass="org.LexGrid.emf.history.ChangeType"
	 *        extendedMetaData="name='changeType:Object' baseType='changeType'" 
	 * @generated
	 */
	EDataType getChangeTypeObject();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	NCIHistoryFactory getNCIHistoryFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.history.impl.NCIChangeEventImpl <em>NCI Change Event</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.history.impl.NCIChangeEventImpl
		 * @see org.LexGrid.emf.history.impl.NCIHistoryPackageImpl#getNCIChangeEvent()
		 * @generated
		 */
		EClass NCI_CHANGE_EVENT = eINSTANCE.getNCIChangeEvent();

		/**
		 * The meta object literal for the '<em><b>Conceptcode</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NCI_CHANGE_EVENT__CONCEPTCODE = eINSTANCE.getNCIChangeEvent_Conceptcode();

		/**
		 * The meta object literal for the '<em><b>Concept Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NCI_CHANGE_EVENT__CONCEPT_NAME = eINSTANCE.getNCIChangeEvent_ConceptName();

		/**
		 * The meta object literal for the '<em><b>Editaction</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NCI_CHANGE_EVENT__EDITACTION = eINSTANCE.getNCIChangeEvent_Editaction();

		/**
		 * The meta object literal for the '<em><b>Referencecode</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NCI_CHANGE_EVENT__REFERENCECODE = eINSTANCE.getNCIChangeEvent_Referencecode();

		/**
		 * The meta object literal for the '<em><b>Referencename</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NCI_CHANGE_EVENT__REFERENCENAME = eINSTANCE.getNCIChangeEvent_Referencename();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.history.ChangeType <em>Change Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.history.ChangeType
		 * @see org.LexGrid.emf.history.impl.NCIHistoryPackageImpl#getChangeType()
		 * @generated
		 */
		EEnum CHANGE_TYPE = eINSTANCE.getChangeType();

		/**
		 * The meta object literal for the '<em>Change Type Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.history.ChangeType
		 * @see org.LexGrid.emf.history.impl.NCIHistoryPackageImpl#getChangeTypeObject()
		 * @generated
		 */
		EDataType CHANGE_TYPE_OBJECT = eINSTANCE.getChangeTypeObject();

	}

} //NCIHistoryPackage
