/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.codingSchemes;

import java.util.List;

import org.LexGrid.emf.commonTypes.Properties;
import org.LexGrid.emf.commonTypes.VersionableAndDescribable;
import org.LexGrid.emf.concepts.Concepts;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Coding Scheme</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getLocalName <em>Local Name</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getSource <em>Source</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getCopyrightText <em>Copyright Text</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getMappings <em>Mappings</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getProperties <em>Properties</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getConcepts <em>Concepts</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getRelations <em>Relations</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getVersions <em>Versions</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getApproxNumConcepts <em>Approx Num Concepts</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getCodingScheme <em>Coding Scheme</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getDefaultLanguage <em>Default Language</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getFormalName <em>Formal Name</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getIsNative <em>Is Native</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getRegisteredName <em>Registered Name</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getRepresentsVersion <em>Represents Version</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getCodingSchemeType()
 * @model extendedMetaData="name='codingScheme_._type' kind='elementOnly'"
 * @generated
 */
public interface CodingSchemeType extends VersionableAndDescribable {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Returns the value of the '<em><b>Coding Scheme</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * A unique identifier for the coding scheme within a particular context; usually a mnemonic.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Coding Scheme</em>' attribute.
	 * @see #setCodingScheme(String)
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getCodingSchemeType_CodingScheme()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.LocalId" required="true"
	 *        extendedMetaData="kind='attribute' name='codingScheme'"
	 * @generated
	 */
	String getCodingScheme();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getCodingScheme <em>Coding Scheme</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Coding Scheme</em>' attribute.
	 * @see #getCodingScheme()
	 * @generated
	 */
	void setCodingScheme(String value);

	/**
	 * Returns the value of the '<em><b>Formal Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Official or published name of the coding scheme
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Formal Name</em>' attribute.
	 * @see #setFormalName(String)
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getCodingSchemeType_FormalName()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.TsCaseIgnoreIA5String" required="true"
	 *        extendedMetaData="kind='attribute' name='formalName'"
	 * @generated
	 */
	String getFormalName();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getFormalName <em>Formal Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Formal Name</em>' attribute.
	 * @see #getFormalName()
	 * @generated
	 */
	void setFormalName(String value);

	/**
	 * Returns the value of the '<em><b>Is Native</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * TRUE means that this is the "native" coding scheme for this service (optional -
	 *                                                                 default: FALSE)
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Is Native</em>' attribute.
	 * @see #isSetIsNative()
	 * @see #unsetIsNative()
	 * @see #setIsNative(Boolean)
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getCodingSchemeType_IsNative()
	 * @model unique="false" unsettable="true" dataType="org.LexGrid.emf.builtins.TsBooleanObject"
	 *        extendedMetaData="kind='attribute' name='isNative'"
	 * @generated
	 */
	Boolean getIsNative();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getIsNative <em>Is Native</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Native</em>' attribute.
	 * @see #isSetIsNative()
	 * @see #unsetIsNative()
	 * @see #getIsNative()
	 * @generated
	 */
	void setIsNative(Boolean value);

	/**
	 * Returns the value of the '<em><b>Registered Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The official coding scheme URN
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Registered Name</em>' attribute.
	 * @see #setRegisteredName(String)
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getCodingSchemeType_RegisteredName()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.RegisteredName" required="true"
	 *        extendedMetaData="kind='attribute' name='registeredName'"
	 * @generated
	 */
	String getRegisteredName();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getRegisteredName <em>Registered Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Registered Name</em>' attribute.
	 * @see #getRegisteredName()
	 * @generated
	 */
	void setRegisteredName(String value);

	/**
	 * Returns the value of the '<em><b>Default Language</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Local name of the language to use if not otherwise specified. Must be in
	 *                                                                 supportedLanguage
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Default Language</em>' attribute.
	 * @see #setDefaultLanguage(String)
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getCodingSchemeType_DefaultLanguage()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.DefaultLanguage" required="true"
	 *        extendedMetaData="kind='attribute' name='defaultLanguage'"
	 * @generated
	 */
	String getDefaultLanguage();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getDefaultLanguage <em>Default Language</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Default Language</em>' attribute.
	 * @see #getDefaultLanguage()
	 * @generated
	 */
	void setDefaultLanguage(String value);

	/**
	 * Returns the value of the '<em><b>Represents Version</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The coding scheme version currently represented by this entity
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Represents Version</em>' attribute.
	 * @see #setRepresentsVersion(String)
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getCodingSchemeType_RepresentsVersion()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.Version" required="true"
	 *        extendedMetaData="kind='attribute' name='representsVersion'"
	 * @generated
	 */
	String getRepresentsVersion();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getRepresentsVersion <em>Represents Version</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Represents Version</em>' attribute.
	 * @see #getRepresentsVersion()
	 * @generated
	 */
	void setRepresentsVersion(String value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getIsNative <em>Is Native</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsNative()
	 * @see #getIsNative()
	 * @see #setIsNative(Boolean)
	 * @generated
	 */
	void unsetIsNative();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getIsNative <em>Is Native</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Native</em>' attribute is set.
	 * @see #unsetIsNative()
	 * @see #getIsNative()
	 * @see #setIsNative(Boolean)
	 * @generated
	 */
	boolean isSetIsNative();

	/**
	 * Returns the value of the '<em><b>Approx Num Concepts</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Hint for the system about the approximate number of concepts in the scheme
	 *                                                         (optional)
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Approx Num Concepts</em>' attribute.
	 * @see #setApproxNumConcepts(int)
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getCodingSchemeType_ApproxNumConcepts()
	 * @model unique="false" dataType="org.LexGrid.emf.builtins.TsInteger"
	 *        extendedMetaData="kind='attribute' name='approxNumConcepts'"
	 * @generated
	 */
	int getApproxNumConcepts();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getApproxNumConcepts <em>Approx Num Concepts</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Approx Num Concepts</em>' attribute.
	 * @see #getApproxNumConcepts()
	 * @generated
	 */
	void setApproxNumConcepts(int value);

	/**
	 * Returns the value of the '<em><b>Local Name</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.String}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Name that can be used to reference the coding scheme within the context of the
	 *                                                                         service.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Local Name</em>' attribute list.
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getCodingSchemeType_LocalName()
	 * @model type="java.lang.String" unique="false" dataType="org.LexGrid.emf.builtins.TsCaseIgnoreIA5String" required="true"
	 *        extendedMetaData="kind='element' name='localName' namespace='##targetNamespace'"
	 * @generated
	 */
	List getLocalName();

	/**
	 * Returns the value of the '<em><b>Source</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.commonTypes.Source}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The source or orginator of the coding scheme.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Source</em>' containment reference list.
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getCodingSchemeType_Source()
	 * @model type="org.LexGrid.emf.commonTypes.Source" containment="true"
	 *        extendedMetaData="kind='element' name='source' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSource();

	/**
	 * Returns the value of the '<em><b>Copyright Text</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Copyright notice
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Copyright Text</em>' attribute.
	 * @see #setCopyrightText(String)
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getCodingSchemeType_CopyrightText()
	 * @model unique="false" dataType="org.LexGrid.emf.commonTypes.Text"
	 *        extendedMetaData="kind='element' name='copyright' namespace='##targetNamespace'"
	 * @generated
	 */
	String getCopyrightText();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getCopyrightText <em>Copyright Text</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Copyright Text</em>' attribute.
	 * @see #getCopyrightText()
	 * @generated
	 */
	void setCopyrightText(String value);

	/**
	 * Returns the value of the '<em><b>Mappings</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Mappings from local names to URN.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Mappings</em>' containment reference.
	 * @see #setMappings(Mappings)
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getCodingSchemeType_Mappings()
	 * @model containment="true" required="true"
	 *        extendedMetaData="kind='element' name='mappings' namespace='##targetNamespace'"
	 * @generated
	 */
	Mappings getMappings();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getMappings <em>Mappings</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Mappings</em>' containment reference.
	 * @see #getMappings()
	 * @generated
	 */
	void setMappings(Mappings value);

	/**
	 * Returns the value of the '<em><b>Properties</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Additional tags and associated values that further describe or identify the coding scheme.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Properties</em>' containment reference.
	 * @see #setProperties(Properties)
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getCodingSchemeType_Properties()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='properties' namespace='##targetNamespace'"
	 * @generated
	 */
	Properties getProperties();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getProperties <em>Properties</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Properties</em>' containment reference.
	 * @see #getProperties()
	 * @generated
	 */
	void setProperties(Properties value);

	/**
	 * Returns the value of the '<em><b>Concepts</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The set of coded concepts represented by the coding scheme.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Concepts</em>' containment reference.
	 * @see #setConcepts(Concepts)
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getCodingSchemeType_Concepts()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='concepts' namespace='##targetNamespace'"
	 * @generated
	 */
	Concepts getConcepts();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getConcepts <em>Concepts</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Concepts</em>' containment reference.
	 * @see #getConcepts()
	 * @generated
	 */
	void setConcepts(Concepts value);

	/**
	 * Returns the value of the '<em><b>Relations</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.relations.Relations}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The set of relations (collections of associations) represented by the coding scheme.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Relations</em>' containment reference list.
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getCodingSchemeType_Relations()
	 * @model type="org.LexGrid.emf.relations.Relations" containment="true"
	 *        extendedMetaData="kind='element' name='relations' namespace='##targetNamespace'"
	 * @generated
	 */
	List getRelations();

	/**
	 * Returns the value of the '<em><b>Versions</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Version information for the coding sheme.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Versions</em>' containment reference.
	 * @see #setVersions(Versions)
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getCodingSchemeType_Versions()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='versions' namespace='##targetNamespace'"
	 * @generated
	 */
	Versions getVersions();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getVersions <em>Versions</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Versions</em>' containment reference.
	 * @see #getVersions()
	 * @generated
	 */
	void setVersions(Versions value);

} // CodingSchemeType