/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.codingSchemes.impl;

import org.LexGrid.emf.base.impl.LgAttributeImpl;
import org.LexGrid.emf.base.impl.LgReferenceImpl;
import org.LexGrid.emf.builtins.BuiltinsPackage;
import org.LexGrid.emf.builtins.impl.BuiltinsPackageImpl;
import org.LexGrid.emf.codingSchemes.CodingSchemeType;
import org.LexGrid.emf.codingSchemes.CodingSchemeVersion;
import org.LexGrid.emf.codingSchemes.CodingSchemesType;
import org.LexGrid.emf.codingSchemes.CodingschemesFactory;
import org.LexGrid.emf.codingSchemes.CodingschemesPackage;
import org.LexGrid.emf.codingSchemes.DocumentRoot;
import org.LexGrid.emf.codingSchemes.Mappings;
import org.LexGrid.emf.codingSchemes.Versions;
import org.LexGrid.emf.commonTypes.CommontypesPackage;
import org.LexGrid.emf.commonTypes.impl.CommontypesPackageImpl;
import org.LexGrid.emf.concepts.ConceptsPackage;
import org.LexGrid.emf.concepts.impl.ConceptsPackageImpl;
import org.LexGrid.emf.history.NCIHistoryPackage;
import org.LexGrid.emf.history.impl.NCIHistoryPackageImpl;
import org.LexGrid.emf.ldap.LdapPackage;
import org.LexGrid.emf.ldap.impl.LdapPackageImpl;
import org.LexGrid.emf.naming.NamingPackage;
import org.LexGrid.emf.naming.impl.NamingPackageImpl;
import org.LexGrid.emf.relations.RelationsPackage;
import org.LexGrid.emf.relations.impl.RelationsPackageImpl;
import org.LexGrid.emf.service.ServiceTypePackage;
import org.LexGrid.emf.service.impl.ServiceTypePackageImpl;
import org.LexGrid.emf.valueDomains.ValuedomainsPackage;
import org.LexGrid.emf.valueDomains.impl.ValuedomainsPackageImpl;
import org.LexGrid.emf.versions.VersionsPackage;
import org.LexGrid.emf.versions.impl.VersionsPackageImpl;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class CodingschemesPackageImpl extends EPackageImpl implements CodingschemesPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass codingSchemesTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass codingSchemeTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass codingSchemeVersionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass documentRootEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass mappingsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass versionsEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private CodingschemesPackageImpl() {
		super(eNS_URI, CodingschemesFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this
	 * model, and for any others upon which it depends.  Simple
	 * dependencies are satisfied by calling this method on all
	 * dependent packages before doing anything else.  This method drives
	 * initialization for interdependent packages directly, in parallel
	 * with this package, itself.
	 * <p>Of this package and its interdependencies, all packages which
	 * have not yet been registered by their URI values are first created
	 * and registered.  The packages are then initialized in two steps:
	 * meta-model objects for all of the packages are created before any
	 * are initialized, since one package's meta-model objects may refer to
	 * those of another.
	 * <p>Invocation of this method will not affect any packages that have
	 * already been initialized.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static CodingschemesPackage init() {
		if (isInited)
			return (CodingschemesPackage) EPackage.Registry.INSTANCE.getEPackage(CodingschemesPackage.eNS_URI);

		// Obtain or create and register package
		CodingschemesPackageImpl theCodingschemesPackage = (CodingschemesPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(eNS_URI) instanceof CodingschemesPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(eNS_URI) : new CodingschemesPackageImpl());

		isInited = true;

		// Obtain or create and register interdependencies
		ConceptsPackageImpl theConceptsPackage = (ConceptsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(ConceptsPackage.eNS_URI) instanceof ConceptsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(ConceptsPackage.eNS_URI) : ConceptsPackage.eINSTANCE);
		RelationsPackageImpl theRelationsPackage = (RelationsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(RelationsPackage.eNS_URI) instanceof RelationsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(RelationsPackage.eNS_URI) : RelationsPackage.eINSTANCE);
		NCIHistoryPackageImpl theNCIHistoryPackage = (NCIHistoryPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(NCIHistoryPackage.eNS_URI) instanceof NCIHistoryPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(NCIHistoryPackage.eNS_URI) : NCIHistoryPackage.eINSTANCE);
		VersionsPackageImpl theVersionsPackage = (VersionsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(VersionsPackage.eNS_URI) instanceof VersionsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(VersionsPackage.eNS_URI) : VersionsPackage.eINSTANCE);
		LdapPackageImpl theLdapPackage = (LdapPackageImpl) (EPackage.Registry.INSTANCE.getEPackage(LdapPackage.eNS_URI) instanceof LdapPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(LdapPackage.eNS_URI)
				: LdapPackage.eINSTANCE);
		BuiltinsPackageImpl theBuiltinsPackage = (BuiltinsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(BuiltinsPackage.eNS_URI) instanceof BuiltinsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(BuiltinsPackage.eNS_URI) : BuiltinsPackage.eINSTANCE);
		ValuedomainsPackageImpl theValuedomainsPackage = (ValuedomainsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(ValuedomainsPackage.eNS_URI) instanceof ValuedomainsPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(ValuedomainsPackage.eNS_URI)
				: ValuedomainsPackage.eINSTANCE);
		CommontypesPackageImpl theCommontypesPackage = (CommontypesPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(CommontypesPackage.eNS_URI) instanceof CommontypesPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(CommontypesPackage.eNS_URI) : CommontypesPackage.eINSTANCE);
		ServiceTypePackageImpl theServiceTypePackage = (ServiceTypePackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(ServiceTypePackage.eNS_URI) instanceof ServiceTypePackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(ServiceTypePackage.eNS_URI) : ServiceTypePackage.eINSTANCE);
		NamingPackageImpl theNamingPackage = (NamingPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(NamingPackage.eNS_URI) instanceof NamingPackageImpl ? EPackage.Registry.INSTANCE
				.getEPackage(NamingPackage.eNS_URI) : NamingPackage.eINSTANCE);

		// Create package meta-data objects
		theCodingschemesPackage.createPackageContents();
		theConceptsPackage.createPackageContents();
		theRelationsPackage.createPackageContents();
		theNCIHistoryPackage.createPackageContents();
		theVersionsPackage.createPackageContents();
		theLdapPackage.createPackageContents();
		theBuiltinsPackage.createPackageContents();
		theValuedomainsPackage.createPackageContents();
		theCommontypesPackage.createPackageContents();
		theServiceTypePackage.createPackageContents();
		theNamingPackage.createPackageContents();

		// Initialize created meta-data
		theCodingschemesPackage.initializePackageContents();
		theConceptsPackage.initializePackageContents();
		theRelationsPackage.initializePackageContents();
		theNCIHistoryPackage.initializePackageContents();
		theVersionsPackage.initializePackageContents();
		theLdapPackage.initializePackageContents();
		theBuiltinsPackage.initializePackageContents();
		theValuedomainsPackage.initializePackageContents();
		theCommontypesPackage.initializePackageContents();
		theServiceTypePackage.initializePackageContents();
		theNamingPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theCodingschemesPackage.freeze();

		return theCodingschemesPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCodingSchemesType() {
		return codingSchemesTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCodingSchemesType_CodingScheme() {
		return (EReference) codingSchemesTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCodingSchemesType_Dc() {
		return (EAttribute) codingSchemesTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCodingSchemeType() {
		return codingSchemeTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCodingSchemeType_LocalName() {
		return (EAttribute) codingSchemeTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCodingSchemeType_Source() {
		return (EReference) codingSchemeTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCodingSchemeType_CopyrightText() {
		return (EAttribute) codingSchemeTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCodingSchemeType_Mappings() {
		return (EReference) codingSchemeTypeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCodingSchemeType_Properties() {
		return (EReference) codingSchemeTypeEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCodingSchemeType_Concepts() {
		return (EReference) codingSchemeTypeEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCodingSchemeType_Relations() {
		return (EReference) codingSchemeTypeEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCodingSchemeType_Versions() {
		return (EReference) codingSchemeTypeEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCodingSchemeType_ApproxNumConcepts() {
		return (EAttribute) codingSchemeTypeEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCodingSchemeType_CodingScheme() {
		return (EAttribute) codingSchemeTypeEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCodingSchemeType_DefaultLanguage() {
		return (EAttribute) codingSchemeTypeEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCodingSchemeType_FormalName() {
		return (EAttribute) codingSchemeTypeEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCodingSchemeType_IsNative() {
		return (EAttribute) codingSchemeTypeEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCodingSchemeType_RegisteredName() {
		return (EAttribute) codingSchemeTypeEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCodingSchemeType_RepresentsVersion() {
		return (EAttribute) codingSchemeTypeEClass.getEStructuralFeatures().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCodingSchemeVersion() {
		return codingSchemeVersionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCodingSchemeVersion_Concepts() {
		return (EReference) codingSchemeVersionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCodingSchemeVersion_Relations() {
		return (EReference) codingSchemeVersionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDocumentRoot() {
		return documentRootEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDocumentRoot_Mixed() {
		return (EAttribute) documentRootEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_XMLNSPrefixMap() {
		return (EReference) documentRootEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_XSISchemaLocation() {
		return (EReference) documentRootEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_CodingScheme() {
		return (EReference) documentRootEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_CodingSchemes() {
		return (EReference) documentRootEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMappings() {
		return mappingsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMappings_SupportedLanguage() {
		return (EReference) mappingsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMappings_SupportedFormat() {
		return (EReference) mappingsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMappings_SupportedProperty() {
		return (EReference) mappingsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMappings_SupportedCodingScheme() {
		return (EReference) mappingsEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMappings_SupportedSource() {
		return (EReference) mappingsEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMappings_SupportedAssociation() {
		return (EReference) mappingsEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMappings_SupportedContext() {
		return (EReference) mappingsEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMappings_SupportedAssociationQualifier() {
		return (EReference) mappingsEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMappings_SupportedConceptStatus() {
		return (EReference) mappingsEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMappings_SupportedRepresentationalForm() {
		return (EReference) mappingsEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMappings_SupportedPropertyLink() {
		return (EReference) mappingsEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMappings_SupportedDegreeOfFidelity() {
		return (EReference) mappingsEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMappings_SupportedPropertyQualifier() {
		return (EReference) mappingsEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMappings_Dc() {
		return (EAttribute) mappingsEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getVersions() {
		return versionsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVersions_Version() {
		return (EReference) versionsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVersions_Dc() {
		return (EAttribute) versionsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CodingschemesFactory getCodingschemesFactory() {
		return (CodingschemesFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		codingSchemesTypeEClass = createEClass(CODING_SCHEMES_TYPE);
		createEReference(codingSchemesTypeEClass, CODING_SCHEMES_TYPE__CODING_SCHEME);
		createEAttribute(codingSchemesTypeEClass, CODING_SCHEMES_TYPE__DC);

		codingSchemeTypeEClass = createEClass(CODING_SCHEME_TYPE);
		createEAttribute(codingSchemeTypeEClass, CODING_SCHEME_TYPE__LOCAL_NAME);
		createEReference(codingSchemeTypeEClass, CODING_SCHEME_TYPE__SOURCE);
		createEAttribute(codingSchemeTypeEClass, CODING_SCHEME_TYPE__COPYRIGHT_TEXT);
		createEReference(codingSchemeTypeEClass, CODING_SCHEME_TYPE__MAPPINGS);
		createEReference(codingSchemeTypeEClass, CODING_SCHEME_TYPE__PROPERTIES);
		createEReference(codingSchemeTypeEClass, CODING_SCHEME_TYPE__CONCEPTS);
		createEReference(codingSchemeTypeEClass, CODING_SCHEME_TYPE__RELATIONS);
		createEReference(codingSchemeTypeEClass, CODING_SCHEME_TYPE__VERSIONS);
		createEAttribute(codingSchemeTypeEClass, CODING_SCHEME_TYPE__APPROX_NUM_CONCEPTS);
		createEAttribute(codingSchemeTypeEClass, CODING_SCHEME_TYPE__CODING_SCHEME);
		createEAttribute(codingSchemeTypeEClass, CODING_SCHEME_TYPE__DEFAULT_LANGUAGE);
		createEAttribute(codingSchemeTypeEClass, CODING_SCHEME_TYPE__FORMAL_NAME);
		createEAttribute(codingSchemeTypeEClass, CODING_SCHEME_TYPE__IS_NATIVE);
		createEAttribute(codingSchemeTypeEClass, CODING_SCHEME_TYPE__REGISTERED_NAME);
		createEAttribute(codingSchemeTypeEClass, CODING_SCHEME_TYPE__REPRESENTS_VERSION);

		codingSchemeVersionEClass = createEClass(CODING_SCHEME_VERSION);
		createEReference(codingSchemeVersionEClass, CODING_SCHEME_VERSION__CONCEPTS);
		createEReference(codingSchemeVersionEClass, CODING_SCHEME_VERSION__RELATIONS);

		documentRootEClass = createEClass(DOCUMENT_ROOT);
		createEAttribute(documentRootEClass, DOCUMENT_ROOT__MIXED);
		createEReference(documentRootEClass, DOCUMENT_ROOT__XMLNS_PREFIX_MAP);
		createEReference(documentRootEClass, DOCUMENT_ROOT__XSI_SCHEMA_LOCATION);
		createEReference(documentRootEClass, DOCUMENT_ROOT__CODING_SCHEME);
		createEReference(documentRootEClass, DOCUMENT_ROOT__CODING_SCHEMES);

		mappingsEClass = createEClass(MAPPINGS);
		createEReference(mappingsEClass, MAPPINGS__SUPPORTED_LANGUAGE);
		createEReference(mappingsEClass, MAPPINGS__SUPPORTED_FORMAT);
		createEReference(mappingsEClass, MAPPINGS__SUPPORTED_PROPERTY);
		createEReference(mappingsEClass, MAPPINGS__SUPPORTED_CODING_SCHEME);
		createEReference(mappingsEClass, MAPPINGS__SUPPORTED_SOURCE);
		createEReference(mappingsEClass, MAPPINGS__SUPPORTED_ASSOCIATION);
		createEReference(mappingsEClass, MAPPINGS__SUPPORTED_CONTEXT);
		createEReference(mappingsEClass, MAPPINGS__SUPPORTED_ASSOCIATION_QUALIFIER);
		createEReference(mappingsEClass, MAPPINGS__SUPPORTED_CONCEPT_STATUS);
		createEReference(mappingsEClass, MAPPINGS__SUPPORTED_REPRESENTATIONAL_FORM);
		createEReference(mappingsEClass, MAPPINGS__SUPPORTED_PROPERTY_LINK);
		createEReference(mappingsEClass, MAPPINGS__SUPPORTED_DEGREE_OF_FIDELITY);
		createEReference(mappingsEClass, MAPPINGS__SUPPORTED_PROPERTY_QUALIFIER);
		createEAttribute(mappingsEClass, MAPPINGS__DC);

		versionsEClass = createEClass(VERSIONS);
		createEReference(versionsEClass, VERSIONS__VERSION);
		createEAttribute(versionsEClass, VERSIONS__DC);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContentsGen() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		CommontypesPackage theCommontypesPackage = (CommontypesPackage) EPackage.Registry.INSTANCE
				.getEPackage(CommontypesPackage.eNS_URI);
		BuiltinsPackage theBuiltinsPackage = (BuiltinsPackage) EPackage.Registry.INSTANCE
				.getEPackage(BuiltinsPackage.eNS_URI);
		ConceptsPackage theConceptsPackage = (ConceptsPackage) EPackage.Registry.INSTANCE
				.getEPackage(ConceptsPackage.eNS_URI);
		RelationsPackage theRelationsPackage = (RelationsPackage) EPackage.Registry.INSTANCE
				.getEPackage(RelationsPackage.eNS_URI);
		VersionsPackage theVersionsPackage = (VersionsPackage) EPackage.Registry.INSTANCE
				.getEPackage(VersionsPackage.eNS_URI);
		NamingPackage theNamingPackage = (NamingPackage) EPackage.Registry.INSTANCE.getEPackage(NamingPackage.eNS_URI);

		// Add supertypes to classes
		codingSchemeTypeEClass.getESuperTypes().add(theCommontypesPackage.getVersionableAndDescribable());
		codingSchemeVersionEClass.getESuperTypes().add(theVersionsPackage.getEntityVersion());

		// Initialize classes and features; add operations and parameters
		initEClass(codingSchemesTypeEClass, CodingSchemesType.class, "CodingSchemesType", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCodingSchemesType_CodingScheme(), this.getCodingSchemeType(), null, "codingScheme", null, 1,
				-1, CodingSchemesType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCodingSchemesType_Dc(), theCommontypesPackage.getDc(), "dc", "codingSchemes", 1, 1,
				CodingSchemesType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(codingSchemeTypeEClass, CodingSchemeType.class, "CodingSchemeType", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCodingSchemeType_LocalName(), theBuiltinsPackage.getTsCaseIgnoreIA5String(), "localName",
				null, 1, -1, CodingSchemeType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE,
				!IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCodingSchemeType_Source(), theCommontypesPackage.getSource(), null, "source", null, 0, -1,
				CodingSchemeType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCodingSchemeType_CopyrightText(), theCommontypesPackage.getText(), "copyrightText", null, 0,
				1, CodingSchemeType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				!IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCodingSchemeType_Mappings(), this.getMappings(), null, "mappings", null, 1, 1,
				CodingSchemeType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCodingSchemeType_Properties(), theCommontypesPackage.getProperties(), null, "properties",
				null, 0, 1, CodingSchemeType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCodingSchemeType_Concepts(), theConceptsPackage.getConcepts(), null, "concepts", null, 0, 1,
				CodingSchemeType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCodingSchemeType_Relations(), theRelationsPackage.getRelations(), null, "relations", null, 0,
				-1, CodingSchemeType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCodingSchemeType_Versions(), this.getVersions(), null, "versions", null, 0, 1,
				CodingSchemeType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCodingSchemeType_ApproxNumConcepts(), theBuiltinsPackage.getTsInteger(), "approxNumConcepts",
				null, 0, 1, CodingSchemeType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				!IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCodingSchemeType_CodingScheme(), theBuiltinsPackage.getLocalId(), "codingScheme", null, 1, 1,
				CodingSchemeType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getCodingSchemeType_DefaultLanguage(), theCommontypesPackage.getDefaultLanguage(),
				"defaultLanguage", null, 1, 1, CodingSchemeType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCodingSchemeType_FormalName(), theBuiltinsPackage.getTsCaseIgnoreIA5String(), "formalName",
				null, 1, 1, CodingSchemeType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				!IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCodingSchemeType_IsNative(), theBuiltinsPackage.getTsBooleanObject(), "isNative", null, 0, 1,
				CodingSchemeType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getCodingSchemeType_RegisteredName(), theCommontypesPackage.getRegisteredName(),
				"registeredName", null, 1, 1, CodingSchemeType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCodingSchemeType_RepresentsVersion(), theCommontypesPackage.getVersion(),
				"representsVersion", null, 1, 1, CodingSchemeType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(codingSchemeVersionEClass, CodingSchemeVersion.class, "CodingSchemeVersion", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCodingSchemeVersion_Concepts(), theConceptsPackage.getConcepts(), null, "concepts", null, 0,
				1, CodingSchemeVersion.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCodingSchemeVersion_Relations(), theRelationsPackage.getRelations(), null, "relations", null,
				0, -1, CodingSchemeVersion.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(documentRootEClass, DocumentRoot.class, "DocumentRoot", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDocumentRoot_Mixed(), ecorePackage.getEFeatureMapEntry(), "mixed", null, 0, -1, null,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_XMLNSPrefixMap(), ecorePackage.getEStringToStringMapEntry(), null,
				"xMLNSPrefixMap", null, 0, -1, null, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_XSISchemaLocation(), ecorePackage.getEStringToStringMapEntry(), null,
				"xSISchemaLocation", null, 0, -1, null, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_CodingScheme(), this.getCodingSchemeType(), null, "codingScheme", null, 0, -2,
				null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_CodingSchemes(), this.getCodingSchemesType(), null, "codingSchemes", null, 0,
				-2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, IS_DERIVED, IS_ORDERED);

		initEClass(mappingsEClass, Mappings.class, "Mappings", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getMappings_SupportedLanguage(), theNamingPackage.getSupportedLanguage(), null,
				"supportedLanguage", null, 0, -1, Mappings.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMappings_SupportedFormat(), theNamingPackage.getSupportedFormat(), null, "supportedFormat",
				null, 0, -1, Mappings.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMappings_SupportedProperty(), theNamingPackage.getSupportedProperty(), null,
				"supportedProperty", null, 0, -1, Mappings.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMappings_SupportedCodingScheme(), theNamingPackage.getSupportedCodingScheme(), null,
				"supportedCodingScheme", null, 0, -1, Mappings.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMappings_SupportedSource(), theNamingPackage.getSupportedSource(), null, "supportedSource",
				null, 0, -1, Mappings.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMappings_SupportedAssociation(), theNamingPackage.getSupportedAssociation(), null,
				"supportedAssociation", null, 0, -1, Mappings.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMappings_SupportedContext(), theNamingPackage.getSupportedContext(), null,
				"supportedContext", null, 0, -1, Mappings.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMappings_SupportedAssociationQualifier(),
				theNamingPackage.getSupportedAssociationQualifier(), null, "supportedAssociationQualifier", null, 0,
				-1, Mappings.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMappings_SupportedConceptStatus(), theNamingPackage.getSupportedConceptStatus(), null,
				"supportedConceptStatus", null, 0, -1, Mappings.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMappings_SupportedRepresentationalForm(),
				theNamingPackage.getSupportedRepresentationalForm(), null, "supportedRepresentationalForm", null, 0,
				-1, Mappings.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMappings_SupportedPropertyLink(), theNamingPackage.getSupportedPropertyLink(), null,
				"supportedPropertyLink", null, 0, -1, Mappings.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMappings_SupportedDegreeOfFidelity(), theNamingPackage.getSupportedDegreeOfFidelity(), null,
				"supportedDegreeOfFidelity", null, 0, -1, Mappings.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMappings_SupportedPropertyQualifier(), theNamingPackage.getSupportedPropertyQualifier(),
				null, "supportedPropertyQualifier", null, 0, -1, Mappings.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMappings_Dc(), theCommontypesPackage.getDc(), "dc", "mappings", 1, 1, Mappings.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(versionsEClass, Versions.class, "Versions", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getVersions_Version(), this.getCodingSchemeVersion(), null, "version", null, 1, -1,
				Versions.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVersions_Dc(), theCommontypesPackage.getDc(), "dc", "versions", 1, 1, Versions.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http:///org/eclipse/emf/ecore/util/ExtendedMetaData
		createExtendedMetaDataAnnotations();
		// null
		createNullAnnotations();
	}

	/**
	 * Initializes the annotations for <b>http:///org/eclipse/emf/ecore/util/ExtendedMetaData</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createExtendedMetaDataAnnotations() {
		String source = "http:///org/eclipse/emf/ecore/util/ExtendedMetaData";
		addAnnotation(codingSchemesTypeEClass, source, new String[] { "name", "codingSchemes_._type", "kind",
				"elementOnly" });
		addAnnotation(getCodingSchemesType_CodingScheme(), source, new String[] { "kind", "element", "name",
				"codingScheme", "namespace", "##targetNamespace" });
		addAnnotation(getCodingSchemesType_Dc(), source, new String[] { "kind", "attribute", "name", "dc" });
		addAnnotation(codingSchemeTypeEClass, source, new String[] { "name", "codingScheme_._type", "kind",
				"elementOnly" });
		addAnnotation(getCodingSchemeType_LocalName(), source, new String[] { "kind", "element", "name", "localName",
				"namespace", "##targetNamespace" });
		addAnnotation(getCodingSchemeType_Source(), source, new String[] { "kind", "element", "name", "source",
				"namespace", "##targetNamespace" });
		addAnnotation(getCodingSchemeType_CopyrightText(), source, new String[] { "kind", "element", "name",
				"copyright", "namespace", "##targetNamespace" });
		addAnnotation(getCodingSchemeType_Mappings(), source, new String[] { "kind", "element", "name", "mappings",
				"namespace", "##targetNamespace" });
		addAnnotation(getCodingSchemeType_Properties(), source, new String[] { "kind", "element", "name", "properties",
				"namespace", "##targetNamespace" });
		addAnnotation(getCodingSchemeType_Concepts(), source, new String[] { "kind", "element", "name", "concepts",
				"namespace", "##targetNamespace" });
		addAnnotation(getCodingSchemeType_Relations(), source, new String[] { "kind", "element", "name", "relations",
				"namespace", "##targetNamespace" });
		addAnnotation(getCodingSchemeType_Versions(), source, new String[] { "kind", "element", "name", "versions",
				"namespace", "##targetNamespace" });
		addAnnotation(getCodingSchemeType_ApproxNumConcepts(), source, new String[] { "kind", "attribute", "name",
				"approxNumConcepts" });
		addAnnotation(getCodingSchemeType_CodingScheme(), source, new String[] { "kind", "attribute", "name",
				"codingScheme" });
		addAnnotation(getCodingSchemeType_DefaultLanguage(), source, new String[] { "kind", "attribute", "name",
				"defaultLanguage" });
		addAnnotation(getCodingSchemeType_FormalName(), source, new String[] { "kind", "attribute", "name",
				"formalName" });
		addAnnotation(getCodingSchemeType_IsNative(), source, new String[] { "kind", "attribute", "name", "isNative" });
		addAnnotation(getCodingSchemeType_RegisteredName(), source, new String[] { "kind", "attribute", "name",
				"registeredName" });
		addAnnotation(getCodingSchemeType_RepresentsVersion(), source, new String[] { "kind", "attribute", "name",
				"representsVersion" });
		addAnnotation(codingSchemeVersionEClass, source, new String[] { "name", "codingSchemeVersion", "kind",
				"elementOnly" });
		addAnnotation(getCodingSchemeVersion_Concepts(), source, new String[] { "kind", "element", "name", "concepts",
				"namespace", "##targetNamespace" });
		addAnnotation(getCodingSchemeVersion_Relations(), source, new String[] { "kind", "element", "name",
				"relations", "namespace", "##targetNamespace" });
		addAnnotation(documentRootEClass, source, new String[] { "name", "", "kind", "mixed" });
		addAnnotation(getDocumentRoot_Mixed(), source, new String[] { "kind", "elementWildcard", "name", ":mixed" });
		addAnnotation(getDocumentRoot_XMLNSPrefixMap(), source, new String[] { "kind", "attribute", "name",
				"xmlns:prefix" });
		addAnnotation(getDocumentRoot_XSISchemaLocation(), source, new String[] { "kind", "attribute", "name",
				"xsi:schemaLocation" });
		addAnnotation(getDocumentRoot_CodingScheme(), source, new String[] { "kind", "element", "name", "codingScheme",
				"namespace", "##targetNamespace" });
		addAnnotation(getDocumentRoot_CodingSchemes(), source, new String[] { "kind", "element", "name",
				"codingSchemes", "namespace", "##targetNamespace" });
		addAnnotation(mappingsEClass, source, new String[] { "name", "mappings", "kind", "elementOnly" });
		addAnnotation(getMappings_SupportedLanguage(), source, new String[] { "kind", "element", "name",
				"supportedLanguage", "namespace", "##targetNamespace" });
		addAnnotation(getMappings_SupportedFormat(), source, new String[] { "kind", "element", "name",
				"supportedFormat", "namespace", "##targetNamespace" });
		addAnnotation(getMappings_SupportedProperty(), source, new String[] { "kind", "element", "name",
				"supportedProperty", "namespace", "##targetNamespace" });
		addAnnotation(getMappings_SupportedCodingScheme(), source, new String[] { "kind", "element", "name",
				"supportedCodingScheme", "namespace", "##targetNamespace" });
		addAnnotation(getMappings_SupportedSource(), source, new String[] { "kind", "element", "name",
				"supportedSource", "namespace", "##targetNamespace" });
		addAnnotation(getMappings_SupportedAssociation(), source, new String[] { "kind", "element", "name",
				"supportedAssociation", "namespace", "##targetNamespace" });
		addAnnotation(getMappings_SupportedContext(), source, new String[] { "kind", "element", "name",
				"supportedContext", "namespace", "##targetNamespace" });
		addAnnotation(getMappings_SupportedAssociationQualifier(), source, new String[] { "kind", "element", "name",
				"supportedAssociationQualifier", "namespace", "##targetNamespace" });
		addAnnotation(getMappings_SupportedConceptStatus(), source, new String[] { "kind", "element", "name",
				"supportedConceptStatus", "namespace", "##targetNamespace" });
		addAnnotation(getMappings_SupportedRepresentationalForm(), source, new String[] { "kind", "element", "name",
				"supportedRepresentationalForm", "namespace", "##targetNamespace" });
		addAnnotation(getMappings_SupportedPropertyLink(), source, new String[] { "kind", "element", "name",
				"supportedPropertyLink", "namespace", "##targetNamespace" });
		addAnnotation(getMappings_SupportedDegreeOfFidelity(), source, new String[] { "kind", "element", "name",
				"supportedDegreeOfFidelity", "namespace", "##targetNamespace" });
		addAnnotation(getMappings_SupportedPropertyQualifier(), source, new String[] { "kind", "element", "name",
				"supportedPropertyQualifier", "namespace", "##targetNamespace" });
		addAnnotation(getMappings_Dc(), source, new String[] { "kind", "attribute", "name", "dc" });
		addAnnotation(versionsEClass, source, new String[] { "name", "versions", "kind", "elementOnly" });
		addAnnotation(getVersions_Version(), source, new String[] { "kind", "element", "name", "version", "namespace",
				"##targetNamespace" });
		addAnnotation(getVersions_Dc(), source, new String[] { "kind", "attribute", "name", "dc" });
	}

	/**
	 * Initializes the annotations for <b>null</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createNullAnnotations() {
		String source = null;
		addAnnotation(
				getCodingSchemesType_CodingScheme(),
				source,
				new String[] {
						"appinfo",
						"\r\n                                <ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.7.2</ldap:oid>\r\n                                <ldap:rdn xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">codingScheme</ldap:rdn>\r\n                        " });
		addAnnotation(
				codingSchemeVersionEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n                                <ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.7.3</ldap:oid>\r\n                                <ldap:rdn xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">versionId</ldap:rdn>\r\n                        " });
		addAnnotation(
				getDocumentRoot_CodingScheme(),
				source,
				new String[] {
						"appinfo",
						"\r\n                                <ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.7.2</ldap:oid>\r\n                                <ldap:rdn xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">codingScheme</ldap:rdn>\r\n                        " });
		addAnnotation(
				getDocumentRoot_CodingSchemes(),
				source,
				new String[] {
						"appinfo",
						"\r\n                                <ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.7.81</ldap:oid>\r\n                                <ldap:rdn xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">dc</ldap:rdn>\r\n                        " });
		addAnnotation(
				versionsEClass,
				source,
				new String[] {
						"appinfo",
						"\r\n                                <ldap:oid xmlns:ldap=\"http://LexGrid.org/schema/2006/01/LexGrid/ldap\">1.3.6.1.4.1.2114.108.1.7.84</ldap:oid>\r\n                        " });
	}

	////////////////////////////////////////////////////////////
	// ************** BEGIN NON-GENERATED CODE ************** //
	//                                                        //
	// ****************************************************** //
	////////////////////////////////////////////////////////////
	/**
	 * Override superclass to create a LexGrid-aware attribute.
	 * @non-generated
	 */
	protected void createEAttribute(EClass owner, int id) {
		LgAttributeImpl eAttribute = new LgAttributeImpl();
		eAttribute.setFeatureID(id);
		owner.getEStructuralFeatures().add(eAttribute);
	}

	/**
	 * Override superclass to create a LexGrid-aware reference.
	 * @non-generated
	 */
	protected void createEReference(EClass owner, int id) {
		LgReferenceImpl eReference = new LgReferenceImpl();
		eReference.setFeatureID(id);
		owner.getEStructuralFeatures().add(eReference);
	}

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * @non-generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		initializePackageContentsGen();

		((LgAttributeImpl) getCodingSchemeType_CodingScheme()).setID(true);
		((LgAttributeImpl) getCodingSchemesType_Dc()).setID(true);
		((LgAttributeImpl) getCodingSchemesType_Dc()).setDefaultValueLiteral("codingSchemes");
		((LgAttributeImpl) getMappings_Dc()).setID(true);
		((LgAttributeImpl) getMappings_Dc()).setDefaultValueLiteral("mappings");
		((LgAttributeImpl) getVersions_Dc()).setID(true);
		((LgAttributeImpl) getVersions_Dc()).setDefaultValueLiteral("versions");

		((LgAttributeImpl) getCodingSchemeType_CopyrightText()).setValueMaxLength(2048);
		((LgAttributeImpl) getCodingSchemeType_CopyrightText()).setMultiLine(true);

		// Ensures order of output in XML ...
		String source = "http:///org/eclipse/emf/mapping/xsd2ecore/XSD2Ecore";
		addAnnotation(codingSchemeTypeEClass, source, new String[] { "feature-order",
				"localName source copyrightText mappings properties concepts relations versions" });
		addAnnotation(codingSchemeVersionEClass, source, new String[] { "feature-order",
				"concepts relations" });
		addAnnotation(mappingsEClass, source, new String[] { "feature-order",
				"supportedLanguage supportedFormat supportedProperty supportedCodingScheme supportedSource supportedAssociation supportedContext supportedAssociationQualifier supportedConceptStatus supportedRepresentationalForm supportedPropertyLink supportedDegreeOfFidelity supportedPropertyQualifier" });
	}
	////////////////////////////////////////////////////////////
	// *************** END NON-GENERATED CODE *************** //
	////////////////////////////////////////////////////////////

} //CodingschemesPackageImpl