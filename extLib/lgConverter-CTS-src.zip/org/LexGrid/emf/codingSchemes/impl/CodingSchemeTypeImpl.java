/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.codingSchemes.impl;

import java.util.List;

import org.LexGrid.emf.codingSchemes.CodingSchemeType;
import org.LexGrid.emf.codingSchemes.CodingschemesPackage;
import org.LexGrid.emf.codingSchemes.Mappings;
import org.LexGrid.emf.codingSchemes.Versions;
import org.LexGrid.emf.commonTypes.Properties;
import org.LexGrid.emf.commonTypes.impl.VersionableAndDescribableImpl;
import org.LexGrid.emf.concepts.Concepts;
import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Coding Scheme Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.CodingSchemeTypeImpl#getLocalName <em>Local Name</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.CodingSchemeTypeImpl#getSource <em>Source</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.CodingSchemeTypeImpl#getCopyrightText <em>Copyright Text</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.CodingSchemeTypeImpl#getMappings <em>Mappings</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.CodingSchemeTypeImpl#getProperties <em>Properties</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.CodingSchemeTypeImpl#getConcepts <em>Concepts</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.CodingSchemeTypeImpl#getRelations <em>Relations</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.CodingSchemeTypeImpl#getVersions <em>Versions</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.CodingSchemeTypeImpl#getApproxNumConcepts <em>Approx Num Concepts</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.CodingSchemeTypeImpl#getCodingScheme <em>Coding Scheme</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.CodingSchemeTypeImpl#getDefaultLanguage <em>Default Language</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.CodingSchemeTypeImpl#getFormalName <em>Formal Name</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.CodingSchemeTypeImpl#getIsNative <em>Is Native</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.CodingSchemeTypeImpl#getRegisteredName <em>Registered Name</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.CodingSchemeTypeImpl#getRepresentsVersion <em>Represents Version</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class CodingSchemeTypeImpl extends VersionableAndDescribableImpl implements CodingSchemeType {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CodingSchemeTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return CodingschemesPackage.Literals.CODING_SCHEME_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getLocalName() {
		return (List) eGet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__LOCAL_NAME, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getSource() {
		return (List) eGet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__SOURCE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCopyrightText() {
		return (String) eGet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__COPYRIGHT_TEXT, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCopyrightText(String newCopyrightText) {
		eSet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__COPYRIGHT_TEXT, newCopyrightText);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Mappings getMappings() {
		return (Mappings) eGet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__MAPPINGS, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMappings(Mappings newMappings) {
		eSet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__MAPPINGS, newMappings);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Properties getProperties() {
		return (Properties) eGet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__PROPERTIES, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProperties(Properties newProperties) {
		eSet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__PROPERTIES, newProperties);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Concepts getConcepts() {
		return (Concepts) eGet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__CONCEPTS, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setConcepts(Concepts newConcepts) {
		eSet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__CONCEPTS, newConcepts);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getRelations() {
		return (List) eGet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__RELATIONS, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Versions getVersions() {
		return (Versions) eGet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__VERSIONS, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVersions(Versions newVersions) {
		eSet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__VERSIONS, newVersions);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getApproxNumConcepts() {
		return ((Integer) eGet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__APPROX_NUM_CONCEPTS, true)).intValue();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setApproxNumConcepts(int newApproxNumConcepts) {
		eSet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__APPROX_NUM_CONCEPTS, new Integer(newApproxNumConcepts));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCodingScheme() {
		return (String) eGet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__CODING_SCHEME, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCodingScheme(String newCodingScheme) {
		eSet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__CODING_SCHEME, newCodingScheme);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDefaultLanguage() {
		return (String) eGet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__DEFAULT_LANGUAGE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDefaultLanguage(String newDefaultLanguage) {
		eSet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__DEFAULT_LANGUAGE, newDefaultLanguage);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getFormalName() {
		return (String) eGet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__FORMAL_NAME, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFormalName(String newFormalName) {
		eSet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__FORMAL_NAME, newFormalName);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean getIsNative() {
		return (Boolean) eGet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__IS_NATIVE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsNative(Boolean newIsNative) {
		eSet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__IS_NATIVE, newIsNative);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetIsNative() {
		eUnset(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__IS_NATIVE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetIsNative() {
		return eIsSet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__IS_NATIVE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getRegisteredName() {
		return (String) eGet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__REGISTERED_NAME, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRegisteredName(String newRegisteredName) {
		eSet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__REGISTERED_NAME, newRegisteredName);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getRepresentsVersion() {
		return (String) eGet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__REPRESENTS_VERSION, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRepresentsVersion(String newRepresentsVersion) {
		eSet(CodingschemesPackage.Literals.CODING_SCHEME_TYPE__REPRESENTS_VERSION, newRepresentsVersion);
	}

} //CodingSchemeTypeImpl