/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.LexGrid.emf.codingSchemes.impl;

import java.util.List;

import org.LexGrid.emf.base.impl.LgModelObjImpl;
import org.LexGrid.emf.codingSchemes.CodingschemesPackage;
import org.LexGrid.emf.codingSchemes.Mappings;
import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Mappings</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.MappingsImpl#getSupportedLanguage <em>Supported Language</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.MappingsImpl#getSupportedFormat <em>Supported Format</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.MappingsImpl#getSupportedProperty <em>Supported Property</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.MappingsImpl#getSupportedCodingScheme <em>Supported Coding Scheme</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.MappingsImpl#getSupportedSource <em>Supported Source</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.MappingsImpl#getSupportedAssociation <em>Supported Association</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.MappingsImpl#getSupportedContext <em>Supported Context</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.MappingsImpl#getSupportedAssociationQualifier <em>Supported Association Qualifier</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.MappingsImpl#getSupportedConceptStatus <em>Supported Concept Status</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.MappingsImpl#getSupportedRepresentationalForm <em>Supported Representational Form</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.MappingsImpl#getSupportedPropertyLink <em>Supported Property Link</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.MappingsImpl#getSupportedDegreeOfFidelity <em>Supported Degree Of Fidelity</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.MappingsImpl#getSupportedPropertyQualifier <em>Supported Property Qualifier</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.impl.MappingsImpl#getDc <em>Dc</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class MappingsImpl extends LgModelObjImpl implements Mappings {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MappingsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return CodingschemesPackage.Literals.MAPPINGS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getSupportedLanguage() {
		return (List) eGet(CodingschemesPackage.Literals.MAPPINGS__SUPPORTED_LANGUAGE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getSupportedFormat() {
		return (List) eGet(CodingschemesPackage.Literals.MAPPINGS__SUPPORTED_FORMAT, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getSupportedProperty() {
		return (List) eGet(CodingschemesPackage.Literals.MAPPINGS__SUPPORTED_PROPERTY, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getSupportedCodingScheme() {
		return (List) eGet(CodingschemesPackage.Literals.MAPPINGS__SUPPORTED_CODING_SCHEME, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getSupportedSource() {
		return (List) eGet(CodingschemesPackage.Literals.MAPPINGS__SUPPORTED_SOURCE, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getSupportedAssociation() {
		return (List) eGet(CodingschemesPackage.Literals.MAPPINGS__SUPPORTED_ASSOCIATION, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getSupportedContext() {
		return (List) eGet(CodingschemesPackage.Literals.MAPPINGS__SUPPORTED_CONTEXT, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getSupportedAssociationQualifier() {
		return (List) eGet(CodingschemesPackage.Literals.MAPPINGS__SUPPORTED_ASSOCIATION_QUALIFIER, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getSupportedConceptStatus() {
		return (List) eGet(CodingschemesPackage.Literals.MAPPINGS__SUPPORTED_CONCEPT_STATUS, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getSupportedRepresentationalForm() {
		return (List) eGet(CodingschemesPackage.Literals.MAPPINGS__SUPPORTED_REPRESENTATIONAL_FORM, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getSupportedPropertyLink() {
		return (List) eGet(CodingschemesPackage.Literals.MAPPINGS__SUPPORTED_PROPERTY_LINK, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getSupportedDegreeOfFidelity() {
		return (List) eGet(CodingschemesPackage.Literals.MAPPINGS__SUPPORTED_DEGREE_OF_FIDELITY, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getSupportedPropertyQualifier() {
		return (List) eGet(CodingschemesPackage.Literals.MAPPINGS__SUPPORTED_PROPERTY_QUALIFIER, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDc() {
		return (String) eGet(CodingschemesPackage.Literals.MAPPINGS__DC, true);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDc(String newDc) {
		eSet(CodingschemesPackage.Literals.MAPPINGS__DC, newDc);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetDc() {
		eUnset(CodingschemesPackage.Literals.MAPPINGS__DC);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetDc() {
		return eIsSet(CodingschemesPackage.Literals.MAPPINGS__DC);
	}

} //MappingsImpl