/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.codingSchemes;

import java.util.List;

import org.LexGrid.emf.concepts.Concepts;
import org.LexGrid.emf.versions.EntityVersion;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Coding Scheme Version</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A static snapshot of a coding scheme at a point in time. May be either a complete
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.LexGrid.emf.codingSchemes.CodingSchemeVersion#getConcepts <em>Concepts</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.CodingSchemeVersion#getRelations <em>Relations</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getCodingSchemeVersion()
 * @model extendedMetaData="name='codingSchemeVersion' kind='elementOnly'"
 * @generated
 */
public interface CodingSchemeVersion extends EntityVersion {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Returns the value of the '<em><b>Concepts</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Set of concepts in this version (or changed concepts if delta)
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Concepts</em>' containment reference.
	 * @see #setConcepts(Concepts)
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getCodingSchemeVersion_Concepts()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='concepts' namespace='##targetNamespace'"
	 * @generated
	 */
	Concepts getConcepts();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.codingSchemes.CodingSchemeVersion#getConcepts <em>Concepts</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Concepts</em>' containment reference.
	 * @see #getConcepts()
	 * @generated
	 */
	void setConcepts(Concepts value);

	/**
	 * Returns the value of the '<em><b>Relations</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.relations.Relations}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Set of relations in this version (or changed relations if delta)
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Relations</em>' containment reference list.
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getCodingSchemeVersion_Relations()
	 * @model type="org.LexGrid.emf.relations.Relations" containment="true"
	 *        extendedMetaData="kind='element' name='relations' namespace='##targetNamespace'"
	 * @generated
	 */
	List getRelations();

} // CodingSchemeVersion