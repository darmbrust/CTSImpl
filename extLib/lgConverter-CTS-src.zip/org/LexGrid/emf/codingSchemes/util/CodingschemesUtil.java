/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.codingSchemes.util;

import java.util.Iterator;

import org.LexGrid.emf.base.LgModelObj;
import org.LexGrid.emf.codingSchemes.CodingSchemeType;
import org.LexGrid.emf.codingSchemes.CodingSchemesType;

/**
 * Common utility class to support coding schemes and related model objects.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 * @non-generated
 */
public class CodingschemesUtil {
	private CodingschemesUtil() {
		super();
	}
	
	/**
	 * Returns the CodingSchemeType object matching the given scheme name; null if not found.
	 * <p>
	 * Schemes are resolved from ancestors assigned to the given model.
	 * @param model
	 * @param schemeName
	 * @return CodingSchemeType
	 */
	public static CodingSchemeType resolveCodingScheme(LgModelObj model, String schemeName) {
		// Match for the scheme containing the model?
		CodingSchemeType scheme = (CodingSchemeType) model.getContainer(CodingSchemeType.class, -1);
		if (scheme != null) {
			if (schemeName.equals(scheme.getCodingScheme()))
				return scheme;
			
			// Match for another scheme that we can directly navigate to?
			CodingSchemesType schemes = (CodingSchemesType) scheme.getContainer(CodingSchemesType.class, 0);
			if (schemes != null) {
				for (Iterator it = schemes.getCodingScheme().iterator(); it.hasNext(); ) {
					scheme = (CodingSchemeType) it.next();
					if (schemeName.equals(scheme.getCodingScheme()))
						return scheme;
				}
			}
		}
		return null;
	}
}