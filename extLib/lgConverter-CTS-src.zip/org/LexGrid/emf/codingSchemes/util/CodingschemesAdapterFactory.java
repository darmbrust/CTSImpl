/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.codingSchemes.util;

import org.LexGrid.emf.codingSchemes.CodingSchemeType;
import org.LexGrid.emf.codingSchemes.CodingSchemeVersion;
import org.LexGrid.emf.codingSchemes.CodingSchemesType;
import org.LexGrid.emf.codingSchemes.CodingschemesPackage;
import org.LexGrid.emf.codingSchemes.DocumentRoot;
import org.LexGrid.emf.codingSchemes.Mappings;
import org.LexGrid.emf.codingSchemes.Versions;
import org.LexGrid.emf.commonTypes.Describable;
import org.LexGrid.emf.commonTypes.Versionable;
import org.LexGrid.emf.commonTypes.VersionableAndDescribable;
import org.LexGrid.emf.versions.EntityVersion;
import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;
import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage
 * @generated
 */
public class CodingschemesAdapterFactory extends AdapterFactoryImpl {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static CodingschemesPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CodingschemesAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = CodingschemesPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch the delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CodingschemesSwitch modelSwitch = new CodingschemesSwitch() {
		public Object caseCodingSchemesType(CodingSchemesType object) {
			return createCodingSchemesTypeAdapter();
		}

		public Object caseCodingSchemeType(CodingSchemeType object) {
			return createCodingSchemeTypeAdapter();
		}

		public Object caseCodingSchemeVersion(CodingSchemeVersion object) {
			return createCodingSchemeVersionAdapter();
		}

		public Object caseDocumentRoot(DocumentRoot object) {
			return createDocumentRootAdapter();
		}

		public Object caseMappings(Mappings object) {
			return createMappingsAdapter();
		}

		public Object caseVersions(Versions object) {
			return createVersionsAdapter();
		}

		public Object caseVersionable(Versionable object) {
			return createVersionableAdapter();
		}

		public Object caseVersionableAndDescribable(VersionableAndDescribable object) {
			return createVersionableAndDescribableAdapter();
		}

		public Object caseDescribable(Describable object) {
			return createDescribableAdapter();
		}

		public Object caseEntityVersion(EntityVersion object) {
			return createEntityVersionAdapter();
		}

		public Object defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	public Adapter createAdapter(Notifier target) {
		return (Adapter) modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.LexGrid.emf.codingSchemes.CodingSchemesType <em>Coding Schemes Type</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.LexGrid.emf.codingSchemes.CodingSchemesType
	 * @generated
	 */
	public Adapter createCodingSchemesTypeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType <em>Coding Scheme Type</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.LexGrid.emf.codingSchemes.CodingSchemeType
	 * @generated
	 */
	public Adapter createCodingSchemeTypeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.LexGrid.emf.codingSchemes.Versions <em>Versions</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.LexGrid.emf.codingSchemes.Versions
	 * @generated
	 */
	public Adapter createVersionsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.LexGrid.emf.commonTypes.Versionable <em>Versionable</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.LexGrid.emf.commonTypes.Versionable
	 * @generated
	 */
	public Adapter createVersionableAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.LexGrid.emf.commonTypes.VersionableAndDescribable <em>Versionable And Describable</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.LexGrid.emf.commonTypes.VersionableAndDescribable
	 * @generated
	 */
	public Adapter createVersionableAndDescribableAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.LexGrid.emf.codingSchemes.CodingSchemeVersion <em>Coding Scheme Version</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.LexGrid.emf.codingSchemes.CodingSchemeVersion
	 * @generated
	 */
	public Adapter createCodingSchemeVersionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.LexGrid.emf.codingSchemes.DocumentRoot <em>Document Root</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.LexGrid.emf.codingSchemes.DocumentRoot
	 * @generated
	 */
	public Adapter createDocumentRootAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.LexGrid.emf.codingSchemes.Mappings <em>Mappings</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.LexGrid.emf.codingSchemes.Mappings
	 * @generated
	 */
	public Adapter createMappingsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.LexGrid.emf.commonTypes.Describable <em>Describable</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.LexGrid.emf.commonTypes.Describable
	 * @generated
	 */
	public Adapter createDescribableAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.LexGrid.emf.versions.EntityVersion <em>Entity Version</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.LexGrid.emf.versions.EntityVersion
	 * @generated
	 */
	public Adapter createEntityVersionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //CodingschemesAdapterFactory