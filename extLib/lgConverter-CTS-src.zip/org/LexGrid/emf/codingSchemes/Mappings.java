/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.LexGrid.emf.codingSchemes;

import java.util.List;

import org.LexGrid.emf.base.LgModelObj;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Mappings</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A collection of mappings
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedLanguage <em>Supported Language</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedFormat <em>Supported Format</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedProperty <em>Supported Property</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedCodingScheme <em>Supported Coding Scheme</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedSource <em>Supported Source</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedAssociation <em>Supported Association</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedContext <em>Supported Context</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedAssociationQualifier <em>Supported Association Qualifier</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedConceptStatus <em>Supported Concept Status</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedRepresentationalForm <em>Supported Representational Form</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedPropertyLink <em>Supported Property Link</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedDegreeOfFidelity <em>Supported Degree Of Fidelity</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedPropertyQualifier <em>Supported Property Qualifier</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.Mappings#getDc <em>Dc</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getMappings()
 * @model extendedMetaData="name='mappings' kind='elementOnly'"
 * @extends LgModelObj
 * @generated
 */
public interface Mappings extends LgModelObj {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Returns the value of the '<em><b>Supported Language</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.naming.SupportedLanguage}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The URN and local name of a language supported by the coding scheme
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Supported Language</em>' containment reference list.
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getMappings_SupportedLanguage()
	 * @model type="org.LexGrid.emf.naming.SupportedLanguage" containment="true"
	 *        extendedMetaData="kind='element' name='supportedLanguage' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSupportedLanguage();

	/**
	 * Returns the value of the '<em><b>Supported Format</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.naming.SupportedFormat}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * A format (MIME code) supported by the coding scheme
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Supported Format</em>' containment reference list.
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getMappings_SupportedFormat()
	 * @model type="org.LexGrid.emf.naming.SupportedFormat" containment="true"
	 *        extendedMetaData="kind='element' name='supportedFormat' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSupportedFormat();

	/**
	 * Returns the value of the '<em><b>Supported Property</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.naming.SupportedProperty}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * A property supported by the coding scheme
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Supported Property</em>' containment reference list.
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getMappings_SupportedProperty()
	 * @model type="org.LexGrid.emf.naming.SupportedProperty" containment="true"
	 *        extendedMetaData="kind='element' name='supportedProperty' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSupportedProperty();

	/**
	 * Returns the value of the '<em><b>Supported Coding Scheme</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.naming.SupportedCodingScheme}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Any coding scheme that is referenced in the contents, inclulding the containing scheme itself. Rule:
	 *                                                 There must be a supportedCodingScheme entry for each local name in in the codingScheme object, with the URN set
	 *                                                 to the coding scheme registered name. 
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Supported Coding Scheme</em>' containment reference list.
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getMappings_SupportedCodingScheme()
	 * @model type="org.LexGrid.emf.naming.SupportedCodingScheme" containment="true"
	 *        extendedMetaData="kind='element' name='supportedCodingScheme' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSupportedCodingScheme();

	/**
	 * Returns the value of the '<em><b>Supported Source</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.naming.SupportedSource}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Information sources in the scheme
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Supported Source</em>' containment reference list.
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getMappings_SupportedSource()
	 * @model type="org.LexGrid.emf.naming.SupportedSource" containment="true"
	 *        extendedMetaData="kind='element' name='supportedSource' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSupportedSource();

	/**
	 * Returns the value of the '<em><b>Supported Association</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.naming.SupportedAssociation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * An association(relation) supported by the coding scheme
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Supported Association</em>' containment reference list.
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getMappings_SupportedAssociation()
	 * @model type="org.LexGrid.emf.naming.SupportedAssociation" containment="true"
	 *        extendedMetaData="kind='element' name='supportedAssociation' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSupportedAssociation();

	/**
	 * Returns the value of the '<em><b>Supported Context</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.naming.SupportedContext}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * A list of contexts used within the coding scheme
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Supported Context</em>' containment reference list.
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getMappings_SupportedContext()
	 * @model type="org.LexGrid.emf.naming.SupportedContext" containment="true"
	 *        extendedMetaData="kind='element' name='supportedContext' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSupportedContext();

	/**
	 * Returns the value of the '<em><b>Supported Association Qualifier</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.naming.SupportedAssociationQualifier}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * an association qualifier supported by the coding scheme
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Supported Association Qualifier</em>' containment reference list.
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getMappings_SupportedAssociationQualifier()
	 * @model type="org.LexGrid.emf.naming.SupportedAssociationQualifier" containment="true"
	 *        extendedMetaData="kind='element' name='supportedAssociationQualifier' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSupportedAssociationQualifier();

	/**
	 * Returns the value of the '<em><b>Supported Concept Status</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.naming.SupportedConceptStatus}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * A concept status value supported by the coding scheme
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Supported Concept Status</em>' containment reference list.
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getMappings_SupportedConceptStatus()
	 * @model type="org.LexGrid.emf.naming.SupportedConceptStatus" containment="true"
	 *        extendedMetaData="kind='element' name='supportedConceptStatus' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSupportedConceptStatus();

	/**
	 * Returns the value of the '<em><b>Supported Representational Form</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.naming.SupportedRepresentationalForm}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Representational form (e.g noun, adjective, eponym) used in the coding scheme
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Supported Representational Form</em>' containment reference list.
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getMappings_SupportedRepresentationalForm()
	 * @model type="org.LexGrid.emf.naming.SupportedRepresentationalForm" containment="true"
	 *        extendedMetaData="kind='element' name='supportedRepresentationalForm' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSupportedRepresentationalForm();

	/**
	 * Returns the value of the '<em><b>Supported Property Link</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.naming.SupportedPropertyLink}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Link between two properties (e.g. acronymFor, abbreviationFor, spellingVariantOf
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Supported Property Link</em>' containment reference list.
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getMappings_SupportedPropertyLink()
	 * @model type="org.LexGrid.emf.naming.SupportedPropertyLink" containment="true"
	 *        extendedMetaData="kind='element' name='supportedPropertyLink' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSupportedPropertyLink();

	/**
	 * Returns the value of the '<em><b>Supported Degree Of Fidelity</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.naming.SupportedDegreeOfFidelity}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Identifier for fidelity qualifier.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Supported Degree Of Fidelity</em>' containment reference list.
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getMappings_SupportedDegreeOfFidelity()
	 * @model type="org.LexGrid.emf.naming.SupportedDegreeOfFidelity" containment="true"
	 *        extendedMetaData="kind='element' name='supportedDegreeOfFidelity' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSupportedDegreeOfFidelity();

	/**
	 * Returns the value of the '<em><b>Supported Property Qualifier</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.naming.SupportedPropertyQualifier}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Identifier for generic property qualifier.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Supported Property Qualifier</em>' containment reference list.
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getMappings_SupportedPropertyQualifier()
	 * @model type="org.LexGrid.emf.naming.SupportedPropertyQualifier" containment="true"
	 *        extendedMetaData="kind='element' name='supportedPropertyQualifier' namespace='##targetNamespace'"
	 * @generated
	 */
	List getSupportedPropertyQualifier();

	/**
	 * Returns the value of the '<em><b>Dc</b></em>' attribute.
	 * The default value is <code>"mappings"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Node identifier
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Dc</em>' attribute.
	 * @see #isSetDc()
	 * @see #unsetDc()
	 * @see #setDc(String)
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getMappings_Dc()
	 * @model default="mappings" unique="false" unsettable="true" dataType="org.LexGrid.emf.commonTypes.Dc" required="true"
	 *        extendedMetaData="kind='attribute' name='dc'"
	 * @generated
	 */
	String getDc();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.codingSchemes.Mappings#getDc <em>Dc</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Dc</em>' attribute.
	 * @see #isSetDc()
	 * @see #unsetDc()
	 * @see #getDc()
	 * @generated
	 */
	void setDc(String value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.codingSchemes.Mappings#getDc <em>Dc</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetDc()
	 * @see #getDc()
	 * @see #setDc(String)
	 * @generated
	 */
	void unsetDc();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.codingSchemes.Mappings#getDc <em>Dc</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Dc</em>' attribute is set.
	 * @see #unsetDc()
	 * @see #getDc()
	 * @see #setDc(String)
	 * @generated
	 */
	boolean isSetDc();

} // Mappings