/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.codingSchemes;

import org.LexGrid.emf.commonTypes.CommontypesPackage;
import org.LexGrid.emf.versions.VersionsPackage;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * <!-- begin-model-doc -->
 * 
 * 			<h2 xmlns="http://LexGrid.org/schema/2006/01/LexGrid/builtins">Core data types for the lexical grid.</h2>
 * 		
 * These types need to be mapped to the appropriate implementation specific data types. The mapping in this package represents the XML
 * 			Schema data types mapping
 * LDAP specific types for appinfo annotation
 * Basic builtin types
 * <!-- end-model-doc -->
 * @see org.LexGrid.emf.codingSchemes.CodingschemesFactory
 * @model kind="package"
 * @generated
 */
public interface CodingschemesPackage extends EPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "codingSchemes";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://LexGrid.org/schema/2006/01/LexGrid/codingSchemes";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "lgCS";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	CodingschemesPackage eINSTANCE = org.LexGrid.emf.codingSchemes.impl.CodingschemesPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.codingSchemes.impl.CodingSchemesTypeImpl <em>Coding Schemes Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.codingSchemes.impl.CodingSchemesTypeImpl
	 * @see org.LexGrid.emf.codingSchemes.impl.CodingschemesPackageImpl#getCodingSchemesType()
	 * @generated
	 */
	int CODING_SCHEMES_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Coding Scheme</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEMES_TYPE__CODING_SCHEME = 0;

	/**
	 * The feature id for the '<em><b>Dc</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEMES_TYPE__DC = 1;

	/**
	 * The number of structural features of the '<em>Coding Schemes Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEMES_TYPE_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.codingSchemes.impl.CodingSchemeTypeImpl <em>Coding Scheme Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.codingSchemes.impl.CodingSchemeTypeImpl
	 * @see org.LexGrid.emf.codingSchemes.impl.CodingschemesPackageImpl#getCodingSchemeType()
	 * @generated
	 */
	int CODING_SCHEME_TYPE = 1;

	/**
	 * The feature id for the '<em><b>Deprecated</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_TYPE__DEPRECATED = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE__DEPRECATED;

	/**
	 * The feature id for the '<em><b>First Release</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_TYPE__FIRST_RELEASE = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE__FIRST_RELEASE;

	/**
	 * The feature id for the '<em><b>Modified In Release</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_TYPE__MODIFIED_IN_RELEASE = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE__MODIFIED_IN_RELEASE;

	/**
	 * The feature id for the '<em><b>Entity Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_TYPE__ENTITY_DESCRIPTION = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE__ENTITY_DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Local Name</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_TYPE__LOCAL_NAME = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Source</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_TYPE__SOURCE = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Copyright Text</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_TYPE__COPYRIGHT_TEXT = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Mappings</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_TYPE__MAPPINGS = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Properties</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_TYPE__PROPERTIES = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Concepts</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_TYPE__CONCEPTS = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Relations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_TYPE__RELATIONS = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Versions</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_TYPE__VERSIONS = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 7;

	/**
	 * The feature id for the '<em><b>Approx Num Concepts</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_TYPE__APPROX_NUM_CONCEPTS = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 8;

	/**
	 * The feature id for the '<em><b>Coding Scheme</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_TYPE__CODING_SCHEME = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 9;

	/**
	 * The feature id for the '<em><b>Default Language</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_TYPE__DEFAULT_LANGUAGE = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 10;

	/**
	 * The feature id for the '<em><b>Formal Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_TYPE__FORMAL_NAME = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 11;

	/**
	 * The feature id for the '<em><b>Is Native</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_TYPE__IS_NATIVE = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 12;

	/**
	 * The feature id for the '<em><b>Registered Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_TYPE__REGISTERED_NAME = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 13;

	/**
	 * The feature id for the '<em><b>Represents Version</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_TYPE__REPRESENTS_VERSION = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 14;

	/**
	 * The number of structural features of the '<em>Coding Scheme Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_TYPE_FEATURE_COUNT = CommontypesPackage.VERSIONABLE_AND_DESCRIBABLE_FEATURE_COUNT + 15;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.codingSchemes.impl.CodingSchemeVersionImpl <em>Coding Scheme Version</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.codingSchemes.impl.CodingSchemeVersionImpl
	 * @see org.LexGrid.emf.codingSchemes.impl.CodingschemesPackageImpl#getCodingSchemeVersion()
	 * @generated
	 */
	int CODING_SCHEME_VERSION = 2;

	/**
	 * The feature id for the '<em><b>Entity Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_VERSION__ENTITY_DESCRIPTION = VersionsPackage.ENTITY_VERSION__ENTITY_DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Change Documentation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_VERSION__CHANGE_DOCUMENTATION = VersionsPackage.ENTITY_VERSION__CHANGE_DOCUMENTATION;

	/**
	 * The feature id for the '<em><b>Change Instructions</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_VERSION__CHANGE_INSTRUCTIONS = VersionsPackage.ENTITY_VERSION__CHANGE_INSTRUCTIONS;

	/**
	 * The feature id for the '<em><b>Effective Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_VERSION__EFFECTIVE_DATE = VersionsPackage.ENTITY_VERSION__EFFECTIVE_DATE;

	/**
	 * The feature id for the '<em><b>Is Complete</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_VERSION__IS_COMPLETE = VersionsPackage.ENTITY_VERSION__IS_COMPLETE;

	/**
	 * The feature id for the '<em><b>Release URN</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_VERSION__RELEASE_URN = VersionsPackage.ENTITY_VERSION__RELEASE_URN;

	/**
	 * The feature id for the '<em><b>Version</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_VERSION__VERSION = VersionsPackage.ENTITY_VERSION__VERSION;

	/**
	 * The feature id for the '<em><b>Version Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_VERSION__VERSION_DATE = VersionsPackage.ENTITY_VERSION__VERSION_DATE;

	/**
	 * The feature id for the '<em><b>Version Order</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_VERSION__VERSION_ORDER = VersionsPackage.ENTITY_VERSION__VERSION_ORDER;

	/**
	 * The feature id for the '<em><b>Concepts</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_VERSION__CONCEPTS = VersionsPackage.ENTITY_VERSION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Relations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_VERSION__RELATIONS = VersionsPackage.ENTITY_VERSION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Coding Scheme Version</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CODING_SCHEME_VERSION_FEATURE_COUNT = VersionsPackage.ENTITY_VERSION_FEATURE_COUNT + 2;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.codingSchemes.impl.DocumentRootImpl <em>Document Root</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.codingSchemes.impl.DocumentRootImpl
	 * @see org.LexGrid.emf.codingSchemes.impl.CodingschemesPackageImpl#getDocumentRoot()
	 * @generated
	 */
	int DOCUMENT_ROOT = 3;

	/**
	 * The feature id for the '<em><b>Mixed</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__MIXED = 0;

	/**
	 * The feature id for the '<em><b>XMLNS Prefix Map</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__XMLNS_PREFIX_MAP = 1;

	/**
	 * The feature id for the '<em><b>XSI Schema Location</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = 2;

	/**
	 * The feature id for the '<em><b>Coding Scheme</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__CODING_SCHEME = 3;

	/**
	 * The feature id for the '<em><b>Coding Schemes</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__CODING_SCHEMES = 4;

	/**
	 * The number of structural features of the '<em>Document Root</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT_FEATURE_COUNT = 5;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.codingSchemes.impl.MappingsImpl <em>Mappings</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.codingSchemes.impl.MappingsImpl
	 * @see org.LexGrid.emf.codingSchemes.impl.CodingschemesPackageImpl#getMappings()
	 * @generated
	 */
	int MAPPINGS = 4;

	/**
	 * The feature id for the '<em><b>Supported Language</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAPPINGS__SUPPORTED_LANGUAGE = 0;

	/**
	 * The feature id for the '<em><b>Supported Format</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAPPINGS__SUPPORTED_FORMAT = 1;

	/**
	 * The feature id for the '<em><b>Supported Property</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAPPINGS__SUPPORTED_PROPERTY = 2;

	/**
	 * The feature id for the '<em><b>Supported Coding Scheme</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAPPINGS__SUPPORTED_CODING_SCHEME = 3;

	/**
	 * The feature id for the '<em><b>Supported Source</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAPPINGS__SUPPORTED_SOURCE = 4;

	/**
	 * The feature id for the '<em><b>Supported Association</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAPPINGS__SUPPORTED_ASSOCIATION = 5;

	/**
	 * The feature id for the '<em><b>Supported Context</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAPPINGS__SUPPORTED_CONTEXT = 6;

	/**
	 * The feature id for the '<em><b>Supported Association Qualifier</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAPPINGS__SUPPORTED_ASSOCIATION_QUALIFIER = 7;

	/**
	 * The feature id for the '<em><b>Supported Concept Status</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAPPINGS__SUPPORTED_CONCEPT_STATUS = 8;

	/**
	 * The feature id for the '<em><b>Supported Representational Form</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAPPINGS__SUPPORTED_REPRESENTATIONAL_FORM = 9;

	/**
	 * The feature id for the '<em><b>Supported Property Link</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAPPINGS__SUPPORTED_PROPERTY_LINK = 10;

	/**
	 * The feature id for the '<em><b>Supported Degree Of Fidelity</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAPPINGS__SUPPORTED_DEGREE_OF_FIDELITY = 11;

	/**
	 * The feature id for the '<em><b>Supported Property Qualifier</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAPPINGS__SUPPORTED_PROPERTY_QUALIFIER = 12;

	/**
	 * The feature id for the '<em><b>Dc</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAPPINGS__DC = 13;

	/**
	 * The number of structural features of the '<em>Mappings</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAPPINGS_FEATURE_COUNT = 14;

	/**
	 * The meta object id for the '{@link org.LexGrid.emf.codingSchemes.impl.VersionsImpl <em>Versions</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.LexGrid.emf.codingSchemes.impl.VersionsImpl
	 * @see org.LexGrid.emf.codingSchemes.impl.CodingschemesPackageImpl#getVersions()
	 * @generated
	 */
	int VERSIONS = 5;

	/**
	 * The feature id for the '<em><b>Version</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VERSIONS__VERSION = 0;

	/**
	 * The feature id for the '<em><b>Dc</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VERSIONS__DC = 1;

	/**
	 * The number of structural features of the '<em>Versions</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VERSIONS_FEATURE_COUNT = 2;

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.codingSchemes.CodingSchemesType <em>Coding Schemes Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Coding Schemes Type</em>'.
	 * @see org.LexGrid.emf.codingSchemes.CodingSchemesType
	 * @generated
	 */
	EClass getCodingSchemesType();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.codingSchemes.CodingSchemesType#getCodingScheme <em>Coding Scheme</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Coding Scheme</em>'.
	 * @see org.LexGrid.emf.codingSchemes.CodingSchemesType#getCodingScheme()
	 * @see #getCodingSchemesType()
	 * @generated
	 */
	EReference getCodingSchemesType_CodingScheme();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.codingSchemes.CodingSchemesType#getDc <em>Dc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Dc</em>'.
	 * @see org.LexGrid.emf.codingSchemes.CodingSchemesType#getDc()
	 * @see #getCodingSchemesType()
	 * @generated
	 */
	EAttribute getCodingSchemesType_Dc();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType <em>Coding Scheme Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Coding Scheme Type</em>'.
	 * @see org.LexGrid.emf.codingSchemes.CodingSchemeType
	 * @generated
	 */
	EClass getCodingSchemeType();

	/**
	 * Returns the meta object for the attribute list '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getLocalName <em>Local Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Local Name</em>'.
	 * @see org.LexGrid.emf.codingSchemes.CodingSchemeType#getLocalName()
	 * @see #getCodingSchemeType()
	 * @generated
	 */
	EAttribute getCodingSchemeType_LocalName();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Source</em>'.
	 * @see org.LexGrid.emf.codingSchemes.CodingSchemeType#getSource()
	 * @see #getCodingSchemeType()
	 * @generated
	 */
	EReference getCodingSchemeType_Source();

	/**
	 * Returns the meta object for the containment reference '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getConcepts <em>Concepts</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Concepts</em>'.
	 * @see org.LexGrid.emf.codingSchemes.CodingSchemeType#getConcepts()
	 * @see #getCodingSchemeType()
	 * @generated
	 */
	EReference getCodingSchemeType_Concepts();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getRelations <em>Relations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Relations</em>'.
	 * @see org.LexGrid.emf.codingSchemes.CodingSchemeType#getRelations()
	 * @see #getCodingSchemeType()
	 * @generated
	 */
	EReference getCodingSchemeType_Relations();

	/**
	 * Returns the meta object for the containment reference '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getVersions <em>Versions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Versions</em>'.
	 * @see org.LexGrid.emf.codingSchemes.CodingSchemeType#getVersions()
	 * @see #getCodingSchemeType()
	 * @generated
	 */
	EReference getCodingSchemeType_Versions();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getApproxNumConcepts <em>Approx Num Concepts</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Approx Num Concepts</em>'.
	 * @see org.LexGrid.emf.codingSchemes.CodingSchemeType#getApproxNumConcepts()
	 * @see #getCodingSchemeType()
	 * @generated
	 */
	EAttribute getCodingSchemeType_ApproxNumConcepts();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getCodingScheme <em>Coding Scheme</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Coding Scheme</em>'.
	 * @see org.LexGrid.emf.codingSchemes.CodingSchemeType#getCodingScheme()
	 * @see #getCodingSchemeType()
	 * @generated
	 */
	EAttribute getCodingSchemeType_CodingScheme();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getDefaultLanguage <em>Default Language</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Default Language</em>'.
	 * @see org.LexGrid.emf.codingSchemes.CodingSchemeType#getDefaultLanguage()
	 * @see #getCodingSchemeType()
	 * @generated
	 */
	EAttribute getCodingSchemeType_DefaultLanguage();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getFormalName <em>Formal Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Formal Name</em>'.
	 * @see org.LexGrid.emf.codingSchemes.CodingSchemeType#getFormalName()
	 * @see #getCodingSchemeType()
	 * @generated
	 */
	EAttribute getCodingSchemeType_FormalName();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getIsNative <em>Is Native</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Native</em>'.
	 * @see org.LexGrid.emf.codingSchemes.CodingSchemeType#getIsNative()
	 * @see #getCodingSchemeType()
	 * @generated
	 */
	EAttribute getCodingSchemeType_IsNative();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getRegisteredName <em>Registered Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Registered Name</em>'.
	 * @see org.LexGrid.emf.codingSchemes.CodingSchemeType#getRegisteredName()
	 * @see #getCodingSchemeType()
	 * @generated
	 */
	EAttribute getCodingSchemeType_RegisteredName();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getRepresentsVersion <em>Represents Version</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Represents Version</em>'.
	 * @see org.LexGrid.emf.codingSchemes.CodingSchemeType#getRepresentsVersion()
	 * @see #getCodingSchemeType()
	 * @generated
	 */
	EAttribute getCodingSchemeType_RepresentsVersion();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getCopyrightText <em>Copyright Text</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Copyright Text</em>'.
	 * @see org.LexGrid.emf.codingSchemes.CodingSchemeType#getCopyrightText()
	 * @see #getCodingSchemeType()
	 * @generated
	 */
	EAttribute getCodingSchemeType_CopyrightText();

	/**
	 * Returns the meta object for the containment reference '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getMappings <em>Mappings</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Mappings</em>'.
	 * @see org.LexGrid.emf.codingSchemes.CodingSchemeType#getMappings()
	 * @see #getCodingSchemeType()
	 * @generated
	 */
	EReference getCodingSchemeType_Mappings();

	/**
	 * Returns the meta object for the containment reference '{@link org.LexGrid.emf.codingSchemes.CodingSchemeType#getProperties <em>Properties</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Properties</em>'.
	 * @see org.LexGrid.emf.codingSchemes.CodingSchemeType#getProperties()
	 * @see #getCodingSchemeType()
	 * @generated
	 */
	EReference getCodingSchemeType_Properties();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.codingSchemes.CodingSchemeVersion <em>Coding Scheme Version</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Coding Scheme Version</em>'.
	 * @see org.LexGrid.emf.codingSchemes.CodingSchemeVersion
	 * @generated
	 */
	EClass getCodingSchemeVersion();

	/**
	 * Returns the meta object for the containment reference '{@link org.LexGrid.emf.codingSchemes.CodingSchemeVersion#getConcepts <em>Concepts</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Concepts</em>'.
	 * @see org.LexGrid.emf.codingSchemes.CodingSchemeVersion#getConcepts()
	 * @see #getCodingSchemeVersion()
	 * @generated
	 */
	EReference getCodingSchemeVersion_Concepts();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.codingSchemes.CodingSchemeVersion#getRelations <em>Relations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Relations</em>'.
	 * @see org.LexGrid.emf.codingSchemes.CodingSchemeVersion#getRelations()
	 * @see #getCodingSchemeVersion()
	 * @generated
	 */
	EReference getCodingSchemeVersion_Relations();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.codingSchemes.DocumentRoot <em>Document Root</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Document Root</em>'.
	 * @see org.LexGrid.emf.codingSchemes.DocumentRoot
	 * @generated
	 */
	EClass getDocumentRoot();

	/**
	 * Returns the meta object for the attribute list '{@link org.LexGrid.emf.codingSchemes.DocumentRoot#getMixed <em>Mixed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Mixed</em>'.
	 * @see org.LexGrid.emf.codingSchemes.DocumentRoot#getMixed()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EAttribute getDocumentRoot_Mixed();

	/**
	 * Returns the meta object for the map '{@link org.LexGrid.emf.codingSchemes.DocumentRoot#getXMLNSPrefixMap <em>XMLNS Prefix Map</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>XMLNS Prefix Map</em>'.
	 * @see org.LexGrid.emf.codingSchemes.DocumentRoot#getXMLNSPrefixMap()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_XMLNSPrefixMap();

	/**
	 * Returns the meta object for the map '{@link org.LexGrid.emf.codingSchemes.DocumentRoot#getXSISchemaLocation <em>XSI Schema Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>XSI Schema Location</em>'.
	 * @see org.LexGrid.emf.codingSchemes.DocumentRoot#getXSISchemaLocation()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_XSISchemaLocation();

	/**
	 * Returns the meta object for the containment reference '{@link org.LexGrid.emf.codingSchemes.DocumentRoot#getCodingScheme <em>Coding Scheme</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Coding Scheme</em>'.
	 * @see org.LexGrid.emf.codingSchemes.DocumentRoot#getCodingScheme()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_CodingScheme();

	/**
	 * Returns the meta object for the containment reference '{@link org.LexGrid.emf.codingSchemes.DocumentRoot#getCodingSchemes <em>Coding Schemes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Coding Schemes</em>'.
	 * @see org.LexGrid.emf.codingSchemes.DocumentRoot#getCodingSchemes()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_CodingSchemes();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.codingSchemes.Mappings <em>Mappings</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Mappings</em>'.
	 * @see org.LexGrid.emf.codingSchemes.Mappings
	 * @generated
	 */
	EClass getMappings();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedLanguage <em>Supported Language</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Supported Language</em>'.
	 * @see org.LexGrid.emf.codingSchemes.Mappings#getSupportedLanguage()
	 * @see #getMappings()
	 * @generated
	 */
	EReference getMappings_SupportedLanguage();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedFormat <em>Supported Format</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Supported Format</em>'.
	 * @see org.LexGrid.emf.codingSchemes.Mappings#getSupportedFormat()
	 * @see #getMappings()
	 * @generated
	 */
	EReference getMappings_SupportedFormat();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedProperty <em>Supported Property</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Supported Property</em>'.
	 * @see org.LexGrid.emf.codingSchemes.Mappings#getSupportedProperty()
	 * @see #getMappings()
	 * @generated
	 */
	EReference getMappings_SupportedProperty();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedCodingScheme <em>Supported Coding Scheme</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Supported Coding Scheme</em>'.
	 * @see org.LexGrid.emf.codingSchemes.Mappings#getSupportedCodingScheme()
	 * @see #getMappings()
	 * @generated
	 */
	EReference getMappings_SupportedCodingScheme();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedSource <em>Supported Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Supported Source</em>'.
	 * @see org.LexGrid.emf.codingSchemes.Mappings#getSupportedSource()
	 * @see #getMappings()
	 * @generated
	 */
	EReference getMappings_SupportedSource();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedAssociation <em>Supported Association</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Supported Association</em>'.
	 * @see org.LexGrid.emf.codingSchemes.Mappings#getSupportedAssociation()
	 * @see #getMappings()
	 * @generated
	 */
	EReference getMappings_SupportedAssociation();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedContext <em>Supported Context</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Supported Context</em>'.
	 * @see org.LexGrid.emf.codingSchemes.Mappings#getSupportedContext()
	 * @see #getMappings()
	 * @generated
	 */
	EReference getMappings_SupportedContext();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedAssociationQualifier <em>Supported Association Qualifier</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Supported Association Qualifier</em>'.
	 * @see org.LexGrid.emf.codingSchemes.Mappings#getSupportedAssociationQualifier()
	 * @see #getMappings()
	 * @generated
	 */
	EReference getMappings_SupportedAssociationQualifier();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedConceptStatus <em>Supported Concept Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Supported Concept Status</em>'.
	 * @see org.LexGrid.emf.codingSchemes.Mappings#getSupportedConceptStatus()
	 * @see #getMappings()
	 * @generated
	 */
	EReference getMappings_SupportedConceptStatus();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedRepresentationalForm <em>Supported Representational Form</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Supported Representational Form</em>'.
	 * @see org.LexGrid.emf.codingSchemes.Mappings#getSupportedRepresentationalForm()
	 * @see #getMappings()
	 * @generated
	 */
	EReference getMappings_SupportedRepresentationalForm();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedPropertyLink <em>Supported Property Link</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Supported Property Link</em>'.
	 * @see org.LexGrid.emf.codingSchemes.Mappings#getSupportedPropertyLink()
	 * @see #getMappings()
	 * @generated
	 */
	EReference getMappings_SupportedPropertyLink();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedDegreeOfFidelity <em>Supported Degree Of Fidelity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Supported Degree Of Fidelity</em>'.
	 * @see org.LexGrid.emf.codingSchemes.Mappings#getSupportedDegreeOfFidelity()
	 * @see #getMappings()
	 * @generated
	 */
	EReference getMappings_SupportedDegreeOfFidelity();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.codingSchemes.Mappings#getSupportedPropertyQualifier <em>Supported Property Qualifier</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Supported Property Qualifier</em>'.
	 * @see org.LexGrid.emf.codingSchemes.Mappings#getSupportedPropertyQualifier()
	 * @see #getMappings()
	 * @generated
	 */
	EReference getMappings_SupportedPropertyQualifier();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.codingSchemes.Mappings#getDc <em>Dc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Dc</em>'.
	 * @see org.LexGrid.emf.codingSchemes.Mappings#getDc()
	 * @see #getMappings()
	 * @generated
	 */
	EAttribute getMappings_Dc();

	/**
	 * Returns the meta object for class '{@link org.LexGrid.emf.codingSchemes.Versions <em>Versions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Versions</em>'.
	 * @see org.LexGrid.emf.codingSchemes.Versions
	 * @generated
	 */
	EClass getVersions();

	/**
	 * Returns the meta object for the containment reference list '{@link org.LexGrid.emf.codingSchemes.Versions#getVersion <em>Version</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Version</em>'.
	 * @see org.LexGrid.emf.codingSchemes.Versions#getVersion()
	 * @see #getVersions()
	 * @generated
	 */
	EReference getVersions_Version();

	/**
	 * Returns the meta object for the attribute '{@link org.LexGrid.emf.codingSchemes.Versions#getDc <em>Dc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Dc</em>'.
	 * @see org.LexGrid.emf.codingSchemes.Versions#getDc()
	 * @see #getVersions()
	 * @generated
	 */
	EAttribute getVersions_Dc();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	CodingschemesFactory getCodingschemesFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.codingSchemes.impl.CodingSchemesTypeImpl <em>Coding Schemes Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.codingSchemes.impl.CodingSchemesTypeImpl
		 * @see org.LexGrid.emf.codingSchemes.impl.CodingschemesPackageImpl#getCodingSchemesType()
		 * @generated
		 */
		EClass CODING_SCHEMES_TYPE = eINSTANCE.getCodingSchemesType();

		/**
		 * The meta object literal for the '<em><b>Coding Scheme</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CODING_SCHEMES_TYPE__CODING_SCHEME = eINSTANCE.getCodingSchemesType_CodingScheme();

		/**
		 * The meta object literal for the '<em><b>Dc</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CODING_SCHEMES_TYPE__DC = eINSTANCE.getCodingSchemesType_Dc();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.codingSchemes.impl.CodingSchemeTypeImpl <em>Coding Scheme Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.codingSchemes.impl.CodingSchemeTypeImpl
		 * @see org.LexGrid.emf.codingSchemes.impl.CodingschemesPackageImpl#getCodingSchemeType()
		 * @generated
		 */
		EClass CODING_SCHEME_TYPE = eINSTANCE.getCodingSchemeType();

		/**
		 * The meta object literal for the '<em><b>Local Name</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CODING_SCHEME_TYPE__LOCAL_NAME = eINSTANCE.getCodingSchemeType_LocalName();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CODING_SCHEME_TYPE__SOURCE = eINSTANCE.getCodingSchemeType_Source();

		/**
		 * The meta object literal for the '<em><b>Copyright Text</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CODING_SCHEME_TYPE__COPYRIGHT_TEXT = eINSTANCE.getCodingSchemeType_CopyrightText();

		/**
		 * The meta object literal for the '<em><b>Mappings</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CODING_SCHEME_TYPE__MAPPINGS = eINSTANCE.getCodingSchemeType_Mappings();

		/**
		 * The meta object literal for the '<em><b>Properties</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CODING_SCHEME_TYPE__PROPERTIES = eINSTANCE.getCodingSchemeType_Properties();

		/**
		 * The meta object literal for the '<em><b>Concepts</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CODING_SCHEME_TYPE__CONCEPTS = eINSTANCE.getCodingSchemeType_Concepts();

		/**
		 * The meta object literal for the '<em><b>Relations</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CODING_SCHEME_TYPE__RELATIONS = eINSTANCE.getCodingSchemeType_Relations();

		/**
		 * The meta object literal for the '<em><b>Versions</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CODING_SCHEME_TYPE__VERSIONS = eINSTANCE.getCodingSchemeType_Versions();

		/**
		 * The meta object literal for the '<em><b>Approx Num Concepts</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CODING_SCHEME_TYPE__APPROX_NUM_CONCEPTS = eINSTANCE.getCodingSchemeType_ApproxNumConcepts();

		/**
		 * The meta object literal for the '<em><b>Coding Scheme</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CODING_SCHEME_TYPE__CODING_SCHEME = eINSTANCE.getCodingSchemeType_CodingScheme();

		/**
		 * The meta object literal for the '<em><b>Default Language</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CODING_SCHEME_TYPE__DEFAULT_LANGUAGE = eINSTANCE.getCodingSchemeType_DefaultLanguage();

		/**
		 * The meta object literal for the '<em><b>Formal Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CODING_SCHEME_TYPE__FORMAL_NAME = eINSTANCE.getCodingSchemeType_FormalName();

		/**
		 * The meta object literal for the '<em><b>Is Native</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CODING_SCHEME_TYPE__IS_NATIVE = eINSTANCE.getCodingSchemeType_IsNative();

		/**
		 * The meta object literal for the '<em><b>Registered Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CODING_SCHEME_TYPE__REGISTERED_NAME = eINSTANCE.getCodingSchemeType_RegisteredName();

		/**
		 * The meta object literal for the '<em><b>Represents Version</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CODING_SCHEME_TYPE__REPRESENTS_VERSION = eINSTANCE.getCodingSchemeType_RepresentsVersion();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.codingSchemes.impl.CodingSchemeVersionImpl <em>Coding Scheme Version</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.codingSchemes.impl.CodingSchemeVersionImpl
		 * @see org.LexGrid.emf.codingSchemes.impl.CodingschemesPackageImpl#getCodingSchemeVersion()
		 * @generated
		 */
		EClass CODING_SCHEME_VERSION = eINSTANCE.getCodingSchemeVersion();

		/**
		 * The meta object literal for the '<em><b>Concepts</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CODING_SCHEME_VERSION__CONCEPTS = eINSTANCE.getCodingSchemeVersion_Concepts();

		/**
		 * The meta object literal for the '<em><b>Relations</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CODING_SCHEME_VERSION__RELATIONS = eINSTANCE.getCodingSchemeVersion_Relations();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.codingSchemes.impl.DocumentRootImpl <em>Document Root</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.codingSchemes.impl.DocumentRootImpl
		 * @see org.LexGrid.emf.codingSchemes.impl.CodingschemesPackageImpl#getDocumentRoot()
		 * @generated
		 */
		EClass DOCUMENT_ROOT = eINSTANCE.getDocumentRoot();

		/**
		 * The meta object literal for the '<em><b>Mixed</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCUMENT_ROOT__MIXED = eINSTANCE.getDocumentRoot_Mixed();

		/**
		 * The meta object literal for the '<em><b>XMLNS Prefix Map</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__XMLNS_PREFIX_MAP = eINSTANCE.getDocumentRoot_XMLNSPrefixMap();

		/**
		 * The meta object literal for the '<em><b>XSI Schema Location</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = eINSTANCE.getDocumentRoot_XSISchemaLocation();

		/**
		 * The meta object literal for the '<em><b>Coding Scheme</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__CODING_SCHEME = eINSTANCE.getDocumentRoot_CodingScheme();

		/**
		 * The meta object literal for the '<em><b>Coding Schemes</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__CODING_SCHEMES = eINSTANCE.getDocumentRoot_CodingSchemes();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.codingSchemes.impl.MappingsImpl <em>Mappings</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.codingSchemes.impl.MappingsImpl
		 * @see org.LexGrid.emf.codingSchemes.impl.CodingschemesPackageImpl#getMappings()
		 * @generated
		 */
		EClass MAPPINGS = eINSTANCE.getMappings();

		/**
		 * The meta object literal for the '<em><b>Supported Language</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MAPPINGS__SUPPORTED_LANGUAGE = eINSTANCE.getMappings_SupportedLanguage();

		/**
		 * The meta object literal for the '<em><b>Supported Format</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MAPPINGS__SUPPORTED_FORMAT = eINSTANCE.getMappings_SupportedFormat();

		/**
		 * The meta object literal for the '<em><b>Supported Property</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MAPPINGS__SUPPORTED_PROPERTY = eINSTANCE.getMappings_SupportedProperty();

		/**
		 * The meta object literal for the '<em><b>Supported Coding Scheme</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MAPPINGS__SUPPORTED_CODING_SCHEME = eINSTANCE.getMappings_SupportedCodingScheme();

		/**
		 * The meta object literal for the '<em><b>Supported Source</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MAPPINGS__SUPPORTED_SOURCE = eINSTANCE.getMappings_SupportedSource();

		/**
		 * The meta object literal for the '<em><b>Supported Association</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MAPPINGS__SUPPORTED_ASSOCIATION = eINSTANCE.getMappings_SupportedAssociation();

		/**
		 * The meta object literal for the '<em><b>Supported Context</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MAPPINGS__SUPPORTED_CONTEXT = eINSTANCE.getMappings_SupportedContext();

		/**
		 * The meta object literal for the '<em><b>Supported Association Qualifier</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MAPPINGS__SUPPORTED_ASSOCIATION_QUALIFIER = eINSTANCE.getMappings_SupportedAssociationQualifier();

		/**
		 * The meta object literal for the '<em><b>Supported Concept Status</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MAPPINGS__SUPPORTED_CONCEPT_STATUS = eINSTANCE.getMappings_SupportedConceptStatus();

		/**
		 * The meta object literal for the '<em><b>Supported Representational Form</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MAPPINGS__SUPPORTED_REPRESENTATIONAL_FORM = eINSTANCE.getMappings_SupportedRepresentationalForm();

		/**
		 * The meta object literal for the '<em><b>Supported Property Link</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MAPPINGS__SUPPORTED_PROPERTY_LINK = eINSTANCE.getMappings_SupportedPropertyLink();

		/**
		 * The meta object literal for the '<em><b>Supported Degree Of Fidelity</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MAPPINGS__SUPPORTED_DEGREE_OF_FIDELITY = eINSTANCE.getMappings_SupportedDegreeOfFidelity();

		/**
		 * The meta object literal for the '<em><b>Supported Property Qualifier</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MAPPINGS__SUPPORTED_PROPERTY_QUALIFIER = eINSTANCE.getMappings_SupportedPropertyQualifier();

		/**
		 * The meta object literal for the '<em><b>Dc</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MAPPINGS__DC = eINSTANCE.getMappings_Dc();

		/**
		 * The meta object literal for the '{@link org.LexGrid.emf.codingSchemes.impl.VersionsImpl <em>Versions</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.LexGrid.emf.codingSchemes.impl.VersionsImpl
		 * @see org.LexGrid.emf.codingSchemes.impl.CodingschemesPackageImpl#getVersions()
		 * @generated
		 */
		EClass VERSIONS = eINSTANCE.getVersions();

		/**
		 * The meta object literal for the '<em><b>Version</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VERSIONS__VERSION = eINSTANCE.getVersions_Version();

		/**
		 * The meta object literal for the '<em><b>Dc</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VERSIONS__DC = eINSTANCE.getVersions_Dc();

	}

} //CodingschemesPackage