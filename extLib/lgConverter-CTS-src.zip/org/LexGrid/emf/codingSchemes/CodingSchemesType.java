/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.emf.codingSchemes;

import java.util.List;

import org.LexGrid.emf.base.LgModelObj;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Coding Schemes</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.LexGrid.emf.codingSchemes.CodingSchemesType#getCodingScheme <em>Coding Scheme</em>}</li>
 *   <li>{@link org.LexGrid.emf.codingSchemes.CodingSchemesType#getDc <em>Dc</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getCodingSchemesType()
 * @model extendedMetaData="name='codingSchemes_._type' kind='elementOnly'"
 * @extends LgModelObj
 * @generated
 */
public interface CodingSchemesType extends LgModelObj {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the triple-shield Mayo logo are trademarks and service marks of MFMER. Except as contained in the copyright notice above, the trade names, trademarks, service marks, or product names of the copyright holder shall not be used in advertising, promotion or otherwise in connection with this Software without prior written authorization of the copyright holder.  Licensed under the Eclipse Public License, Version 1.0 (the \"License\"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.eclipse.org/legal/epl-v10.html. Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.";

	/**
	 * Returns the value of the '<em><b>Dc</b></em>' attribute.
	 * The default value is <code>"codingSchemes"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The context identifier for this directory.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Dc</em>' attribute.
	 * @see #isSetDc()
	 * @see #unsetDc()
	 * @see #setDc(String)
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getCodingSchemesType_Dc()
	 * @model default="codingSchemes" unique="false" unsettable="true" dataType="org.LexGrid.emf.commonTypes.Dc" required="true"
	 *        extendedMetaData="kind='attribute' name='dc'"
	 * @generated
	 */
	String getDc();

	/**
	 * Sets the value of the '{@link org.LexGrid.emf.codingSchemes.CodingSchemesType#getDc <em>Dc</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Dc</em>' attribute.
	 * @see #isSetDc()
	 * @see #unsetDc()
	 * @see #getDc()
	 * @generated
	 */
	void setDc(String value);

	/**
	 * Unsets the value of the '{@link org.LexGrid.emf.codingSchemes.CodingSchemesType#getDc <em>Dc</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetDc()
	 * @see #getDc()
	 * @see #setDc(String)
	 * @generated
	 */
	void unsetDc();

	/**
	 * Returns whether the value of the '{@link org.LexGrid.emf.codingSchemes.CodingSchemesType#getDc <em>Dc</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Dc</em>' attribute is set.
	 * @see #unsetDc()
	 * @see #getDc()
	 * @see #setDc(String)
	 * @generated
	 */
	boolean isSetDc();

	/**
	 * Returns the value of the '<em><b>Coding Scheme</b></em>' containment reference list.
	 * The list contents are of type {@link org.LexGrid.emf.codingSchemes.CodingSchemeType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * A list of individual coding schemes.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Coding Scheme</em>' containment reference list.
	 * @see org.LexGrid.emf.codingSchemes.CodingschemesPackage#getCodingSchemesType_CodingScheme()
	 * @model type="org.LexGrid.emf.codingSchemes.CodingSchemeType" containment="true" required="true"
	 *        extendedMetaData="kind='element' name='codingScheme' namespace='##targetNamespace'"
	 * @generated
	 */
	List getCodingScheme();

} // CodingSchemesType