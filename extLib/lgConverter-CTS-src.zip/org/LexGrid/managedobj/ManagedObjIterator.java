/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.managedobj;

import java.util.Iterator;

import org.apache.commons.collections.IteratorUtils;

/**
 * Describes common method for iterators over persisted objects.
 * <p>
 * Note: This interface allows for consistent cleanup of connections and other
 * resources that may be used during iteration. The standard contract expected
 * of implementers is to automatically cleanup any resources when iteration
 * is exhausted (<i>hasNext()</i> returns <b>false</b>). However, there may be
 * cases when this does not happen (i.e. it is undesirable for the application
 * to do so, or an error occurs). <b>In such cases, the <i>close()</i> method
 * must be used to ensure the proper release of resources.</b>
 *
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public interface ManagedObjIterator extends Iterator {
	public static ManagedObjIterator EMPTY_ITERATOR = new ManagedObjIteratorWrapper(IteratorUtils.EMPTY_ITERATOR);

	/**
	 * Closes iteration and forces the release of any associated resources,
	 * such as open connections, used during iteration.
	 * <p>
	 * Subsequent calls to <i>hasNext()</i> will return false.
	 */
	public void close();
}