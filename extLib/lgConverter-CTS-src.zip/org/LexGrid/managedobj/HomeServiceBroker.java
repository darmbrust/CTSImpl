/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.managedobj;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Provides a mechanism to dynamically associate a home context with a
 * specific implementation of required services.
 * <p>
 * Note: Currently a restriction is enforced to allow only one service to be
 * registered per home context class per broker.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public final class HomeServiceBroker {
	private static HomeServiceBroker _current = null;
	private Map _homeMap = null;
	private Map _serviceMap = null;

	/**
	 * Constructor for HomeServiceBroker.
	 */
	public HomeServiceBroker() {
		super();
	}

	/**
	 * Invokes close() method on all associated homes and services.
	 */
	public void close() {
		if (_homeMap != null) {
			Iterator homes = _homeMap.values().iterator();
			while (homes.hasNext()) {
				Home h = (Home) homes.next();
				try {
					h.close();
				} catch (Exception e) {
					System.err.println("Error closing home: " + h + " >>> " + e);
				}
			}
		}
		
		if (_serviceMap != null) {
			Iterator services = _serviceMap.values().iterator();
			while (services.hasNext()) {
				HomeServiceIF s = (HomeServiceIF) services.next();
				try {
					s.close();
				} catch (Exception e) {
					System.err.println("Error closing service: " + s + " >>> " + e);
				}
			}
		}
	}

	/**
	 * Removes the service registered fulfill requests for the given home context.
	 * @param home HomeIF
	 * @return The previously registered service, or null if no service was registered.
	 */
	public HomeServiceIF deregister(HomeIF home) {
		if (home == null)
			throw new IllegalArgumentException("home");
		getHomeMap().remove(home.getClass());
		return (HomeServiceIF) getServiceMap().remove(home.getClass());
	}

	/**
	 * Returns the current instance.
	 * @return HomeServiceBroker
	 */
	public static HomeServiceBroker getCurrent() {
		if (_current == null)
			_current = new HomeServiceBroker();
		return _current;
	}

	/**
	 * Returns the home context registered against this broker for the given class;
	 * null if not available.
	 * @return HomeIF
	 */
	public HomeIF getHome(Class homeType) {
		return (HomeIF) getHomeMap().get(homeType);
	}

	/**
	 * Returns the object used to map a particular class of home object to
	 * its registered instance.
	 * @return Map
	 */
	protected Map getHomeMap() {
		if (_homeMap == null)
			_homeMap = new HashMap();
		return _homeMap;
	}

	/**
	 * Returns a collection of registered home contexts.
	 * @return Collection
	 */
	public Collection getHomes() {
		return getServiceMap().keySet();
	}

	/**
	 * Returns a service to fulfill requests against the given home context.
	 * @param home The home context whose service is coordinated by the broker.
	 * @return HomeServiceIF
	 * @throws ServiceUnavailableException
	 */
	public HomeServiceIF getService(HomeIF home) {
		return getService(home.getClass());
	}

	/**
	 * Returns a service to fulfill requests against the given home context type.
	 * @param homeType The class of home context whose service is coordinated by the broker.
	 * @return HomeServiceIF
	 * @throws ServiceUnavailableException
	 */
	public HomeServiceIF getService(Class homeType)
		throws ServiceUnavailableException {
		HomeServiceIF service = (HomeServiceIF) getServiceMap().get(homeType);
		if (service == null)
			throw new ServiceUnavailableException();
		return service;
	}

	/**
	 * Returns a collection of registered services.
	 * @return Collection
	 */
	public Collection getServices() {
		return getServiceMap().values();
	}

	/**
	 * Returns the object used to map a particular class of home object to
	 * its underlying service layer.
	 * @return Map
	 */
	protected Map getServiceMap() {
		if (_serviceMap == null)
			_serviceMap = new HashMap();
		return _serviceMap;
	}

	/**
	 * Registers a service to fulfill requests against the given home context.
	 * @param home HomeIF
	 * @param service HomeServiceIF
	 */
	public void registerService(HomeIF home, HomeServiceIF service) {
		if (home == null)
			throw new IllegalArgumentException("home");
		if (service == null)
			throw new IllegalArgumentException("service");
		if (getHomeMap().containsKey(home.getClass()))
			throw new ServiceAlreadyRegisteredException();
		getHomeMap().put(home.getClass(), home);
		getServiceMap().put(home.getClass(), service);
	}

}