/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.managedobj;

/**
 * Generic superclass for exceptions used in the creation and maintenence
 * of managed objects.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class ManagedObjException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2038603752601845471L;
	private Throwable _cause = null;

	/**
	 * Constructor for ManagedObjException.
	 */
	public ManagedObjException() {
		super();
	}

	/**
	 * Constructor for ManagedObjException.
	 * @param s detail text
	 */
	public ManagedObjException(String s) {
		super(s);
	}

	/**
	 * Constructor for ManagedObjException.
	 * @param s detail text
	 * @param t wrapped throwable
	 */
	public ManagedObjException(String s, Throwable t) {
		this(s);
		setCause(t);
	}

	/**
	 * Constructor for ManagedObjException.
	 * @param t wrapped throwable
	 */
	public ManagedObjException(Throwable t) {
		this();
		setCause(t);
	}

	/**
	 * Returns a throwable that further describes the cause of the exception;
	 * null if not available.
	 * @return Throwable
	 */
	public Throwable getCause() {
		return _cause;
	}

	/**
	 * Sets a throwable that further describes the cause of the exception.
	 * @param t Throwable
	 */
	public void setCause(Throwable t) {
		_cause = t;
	}

	/**
	 * @see java.lang.Throwable#getMessage()
	 */
	public String getMessage() {
		return super.getMessage();
	}

	/**
	 * Returns the bottom-most encapsulated cause (i.e. if this exception
	 * has a cause, its cause is checked, and so on), or the exception itself if no
	 * cause is defined.
	 * @return
	 */
	public Throwable getRootCause() {
		Throwable rootCause = this;
		Throwable nextCause = getCause();
		while (nextCause != null) {
			rootCause = nextCause;
			nextCause = nextCause.getCause();
		}
		return rootCause;
	}
	
	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		StringBuffer sb = new StringBuffer(super.toString());
		if (getCause() != null)
			sb.append("\n[ Cause: ").append(getCause().toString()).append(']');
		return sb.toString();
	}

}