/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.managedobj;

import java.util.ArrayList;
import java.util.List;

/**
 * Abstract superclass providing a home context for managed objects.
 * The home has the overall responsibility of managing the persistence and
 * lifecycle of managed instances.
 * <p>
 * The home encapsulates all services required to fulfill
 * the above responsibilities. However, actual implementation is delegated
 * to a specific service provider. This allows for alternative implementations
 * and persistence mechanisms (i.e. LDAP vs JDBC) to be substituted
 * without affecting callers.
  * <p>
 * The intent is for each managed object to be self encapsulated and,
 * to the extent possible, unconcerned with how it is managed or stored.
 * This provides for a lightweight implementation, facilitates
 * network portability, etc.
  * <p>
 * Note: It is anticipated that parameter values will be verified centrally by the
 * object home, when possible, prior to respective calls to the service layer.
 * 
 * @see ManagedObj
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public abstract class Home implements HomeIF {
	private HomeServiceBroker _broker = null;
	private List _lcListeners = null;

	/**
	 * Constructs a new instance which will consult the given
	 * broker for its underlying service provider.
	 * @param broker
	 */
	public Home(HomeServiceBroker broker) {
		super();
		setBroker(broker);
	}

	/**
	 * @see org.LexGrid.managedobj.HomeIF#addLifeCycleEventListener(org.LexGrid.managedobj.LifeCycleEventListener)
	 */
	public void addLifeCycleEventListener(LifeCycleEventListener listener) {
		List listeners = getLcListeners();
		if (listeners == null)
			setLcListeners(listeners = new ArrayList());
		listeners.add(listener);
	}

	/**
	 * Notifies the receiver that it is being shutdown, and is to release
	 * associated resources, etc.
	 * <p>
	 * NOTE: Superclass only clears life cycle event listeners;
	 * subclasses should override as appropriate.
	 */
	public void close() {
		if (_lcListeners != null)
			_lcListeners.clear();
	}

	/**
	 * @see org.LexGrid.managedobj.HomeIF#findByPrimaryKey(java.lang.Object)
	 */
	public ManagedObjIF findByPrimaryKey(Object key) throws FindException {
		return getService().findByPrimaryKey(key);
	}

	/**
	 * @see org.LexGrid.managedobj.HomeIF#findBySecondaryKey(java.lang.Object)
	 */
	public ManagedObjIF findBySecondaryKey(Object key) throws FindException {
		return getService().findBySecondaryKey(key);
	}

	/**
	 * Returns the broker providing related services.
	 * @return HomeServiceBroker
	 */
	protected HomeServiceBroker getBroker() {
		return _broker;
	}

	/**
	 * Returns the list of objects registered to be notified of lifecycle events;
	 * null if no listeners have been assigned to the object.
	 * @return EventListenerList
	 */
	protected List getLcListeners() {
		return _lcListeners;
	}

	/**
	 * Returns the object providing a concrete implementation of required services.
	 * @return HomeServiceIF
	 */
	protected HomeServiceIF getService() {
		return getBroker().getService(this);
	}

	/**
	 * @see org.LexGrid.managedobj.HomeIF#insert(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public void insert(ManagedObjIF obj)
		throws InsertException, ObjectAlreadyExistsException {
		signalPreInsert(obj);
		getService().insert(obj);
		signalPostInsert(obj);
	}

	/**
	 * @see org.LexGrid.managedobj.HomeIF#newInstance()
	 */
	public ManagedObjIF newInstance() {
		ManagedObjIF obj = getService().newInstance();
		signalPostNew(obj);
		return obj;
	}

	/**
	 * @see org.LexGrid.managedobj.HomeIF#remove(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public void remove(ManagedObjIF obj)
		throws RemoveException, ObjectNotFoundException {
		signalPreRemove(obj);
		getService().remove(obj);
		signalPostRemove(obj);
	}

	/**
	 * @see org.LexGrid.managedobj.HomeIF#removeLifeCycleEventListener(org.LexGrid.managedobj.LifeCycleEventListener)
	 */
	public void removeLifeCycleEventListener(LifeCycleEventListener listener) {
		List listeners = getLcListeners();
		if (listeners != null)
			listeners.remove(listener);
	}

	/**
	 * Sets the broker providing related services.
	 * @param broker HomeServiceBroker
	 */
	protected void setBroker(HomeServiceBroker broker) {
		_broker = broker;
	}

	/**
	 * Sets the list of objects registered to be notified of lifecycle events.
	 * @param lcListeners List
	 */
	protected void setLcListeners(List lcListeners) {
		_lcListeners = lcListeners;
	}

	/**
	 * Signals a life cycle event for the given object.
	 * @param obj The associated object
	 */
	protected void signalPostInsert(ManagedObjIF obj) {
		List listeners = getLcListeners();
		if (listeners != null) {
			LifeCycleEventListener[] toNotify =
				(LifeCycleEventListener[]) listeners.toArray(new LifeCycleEventListener[listeners.size()]);
			for (int i = 0; i < toNotify.length; i++)
				toNotify[i].lcPostInsert(new LifeCycleEvent(obj));
		}
	}

	/**
	 * Signals a life cycle event for the given object.
	 * @param obj The associated object
	 */
	protected void signalPostNew(ManagedObjIF obj) {
		List listeners = getLcListeners();
		if (listeners != null) {
			LifeCycleEventListener[] toNotify =
				(LifeCycleEventListener[]) listeners.toArray(new LifeCycleEventListener[listeners.size()]);
			for (int i = 0; i < toNotify.length; i++)
				toNotify[i].lcPostNew(new LifeCycleEvent(obj));
		}
	}

	/**
	 * Signals a life cycle event for the given object.
	 * @param obj The associated object
	 */
	protected void signalPostRemove(ManagedObjIF obj) {
		List listeners = getLcListeners();
		if (listeners != null) {
			LifeCycleEventListener[] toNotify =
				(LifeCycleEventListener[]) listeners.toArray(new LifeCycleEventListener[listeners.size()]);
			for (int i = 0; i < toNotify.length; i++)
				toNotify[i].lcPostRemove(new LifeCycleEvent(obj));
		}
	}

	/**
	 * Signals a life cycle event for the given object.
	 * @param obj The associated object
	 */
	protected void signalPostUpdate(ManagedObjIF obj) {
		List listeners = getLcListeners();
		if (listeners != null) {
			LifeCycleEventListener[] toNotify =
				(LifeCycleEventListener[]) listeners.toArray(new LifeCycleEventListener[listeners.size()]);
			for (int i = 0; i < toNotify.length; i++)
				toNotify[i].lcPostUpdate(new LifeCycleEvent(obj));
		}
	}

	/**
	 * Signals a life cycle event for the given object.
	 * @param obj The associated object
	 */
	protected void signalPreInsert(ManagedObjIF obj) {
		List listeners = getLcListeners();
		if (listeners != null) {
			LifeCycleEventListener[] toNotify =
				(LifeCycleEventListener[]) listeners.toArray(new LifeCycleEventListener[listeners.size()]);
			for (int i = 0; i < toNotify.length; i++)
				toNotify[i].lcPreInsert(new LifeCycleEvent(obj));
		}
	}

	/**
	* Signals a life cycle event for the given object.
	* @param obj The associated object
	*/
	protected void signalPreRemove(ManagedObjIF obj) {
		List listeners = getLcListeners();
		if (listeners != null) {
			LifeCycleEventListener[] toNotify =
				(LifeCycleEventListener[]) listeners.toArray(new LifeCycleEventListener[listeners.size()]);
			for (int i = 0; i < toNotify.length; i++)
				toNotify[i].lcPreRemove(new LifeCycleEvent(obj));
		}
	}

	/**
	 * Signals a life cycle event for the given object.
	 * @param obj The associated object
	 */
	protected void signalPreUpdate(ManagedObjIF obj) {
		List listeners = getLcListeners();
		if (listeners != null) {
			LifeCycleEventListener[] toNotify =
				(LifeCycleEventListener[]) listeners.toArray(new LifeCycleEventListener[listeners.size()]);
			for (int i = 0; i < toNotify.length; i++)
				toNotify[i].lcPreUpdate(new LifeCycleEvent(obj));
		}
	}

	/**
	 * @see org.LexGrid.managedobj.HomeIF#update(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public void update(ManagedObjIF obj)
		throws UpdateException, ObjectNotFoundException {
		signalPreUpdate(obj);
		getService().update(obj);
		signalPostUpdate(obj);
	}

}