/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.managedobj.jndi;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.ldap.LdapContext;


/**
 * Iterates over the contents of an LDAP search result, returning corresponding
 * managed objects. The prepared statement used to generate the result set is
 * automatically checked in when iteration completes.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class LdapManagedObjIterator extends JndiDirSearchIterator {

	/**
	 * Constructs a new iterator over the given naming enumeration and context.
	 * @param helper
	 * @param ne
	 * @param ctx
	 * @throws NamingException
	 */
	public LdapManagedObjIterator(
		LdapManagedObjIteratorHelper helper,
		NamingEnumeration ne,
		LdapContext ctx)
		throws NamingException {
		super(helper, ne, ctx);
	}
}