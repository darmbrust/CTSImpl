/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.managedobj.jndi;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.commons.pool.BasePoolableObjectFactory;

/**
 * Handles lifecycle events for pooled JNDI context objects.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class JndiContextFactory extends BasePoolableObjectFactory {
	protected final String[] pingAttr = new String[] { "objectClass" };

	// JNDI environment info
	JndiContextDescriptor _ctxDesc = null;

	/**
	 * Constructor for JndiContextFactory.
	 */
	public JndiContextFactory(JndiContextDescriptor desc) {
		super();
		_ctxDesc = desc;
	}

	/**
	 * @see org.apache.commons.pool.PoolableObjectFactory#activateObject(java.lang.Object)
	 */
	public void activateObject(Object arg0) throws Exception {
		// No action required
	}

	/**
	 * @see org.apache.commons.pool.PoolableObjectFactory#destroyObject(java.lang.Object)
	 */
	public void destroyObject(Object arg0) throws Exception {
		Context ctx = (Context) arg0;
		ctx.close();
	}

	/**
	 * Returns the description used to initialize new instances.
	 * @return JndiContextDescriptor
	 */
	protected JndiContextDescriptor getContextDescriptor() {
		if (_ctxDesc == null)
			_ctxDesc = getContextDescriptorPrim();
		return _ctxDesc;
	}

	/**
	 * Primitive to create and return the description used to initialize new
	 * instances; invoked once during service initialization, then cached.
	 * @return JndiContextDescriptor
	 */
	protected JndiContextDescriptor getContextDescriptorPrim() {
		return new JndiContextDescriptor();
	}

	/**
	 * @see org.apache.commons.pool.PoolableObjectFactory#makeObject()
	 */
	public Object makeObject() throws Exception {
		return new JndiContextWrapper(
			new InitialContext(getContextDescriptor().getEnvironment()));
	}

	/**
	 * @see org.apache.commons.pool.PoolableObjectFactory#passivateObject(java.lang.Object)
	 */
	public void passivateObject(Object arg0) throws Exception {
		// No action required
	}

	/**
	 * Sets the description used to initialize new instances.
	 * @param desc JndiContextDescriptor
	 */
	protected void setContextDescriptor(JndiContextDescriptor desc) {
		_ctxDesc = desc;
	}

	/**
	 * @see org.apache.commons.pool.PoolableObjectFactory#validateObject(java.lang.Object)
	 */
	public boolean validateObject(Object arg0) {
		Context ctx = (Context) arg0;
		try {
			ctx.lookup("");
			return true;
		} catch (NamingException e) {
		}
		return false;
	}

}