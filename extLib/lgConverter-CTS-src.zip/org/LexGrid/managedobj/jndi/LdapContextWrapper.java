/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.managedobj.jndi;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import javax.naming.CommunicationException;
import javax.naming.NamingException;
import javax.naming.ldap.Control;
import javax.naming.ldap.ExtendedRequest;
import javax.naming.ldap.ExtendedResponse;
import javax.naming.ldap.LdapContext;

import org.LexGrid.managedobj.UnexpectedException;

/**
 * Wraps a standard LdapContext and provides additional functionality
 * to attempt selective recovery from failed connections, etc.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class LdapContextWrapper
	extends JndiDirContextWrapper
	implements LdapContext {

	// Initialize references to wrapped methods ...
	private static Method METHOD_extendedOperation;
	private static Method METHOD_getConnectControls;
	private static Method METHOD_getRequestControls;
	private static Method METHOD_getResponseControls;
	private static Method METHOD_newInstance;
	private static Method METHOD_reconnect;
	private static Method METHOD_setControls;
	static  {
		try {
			METHOD_extendedOperation = LdapContext.class.getMethod("extendedOperation", new Class[] { ExtendedRequest.class });
			METHOD_getConnectControls = LdapContext.class.getMethod("getConnectControls", null);
			METHOD_getRequestControls = LdapContext.class.getMethod("getRequestControls", null);
			METHOD_getResponseControls = LdapContext.class.getMethod("getResponseControls", null);
			METHOD_newInstance = LdapContext.class.getMethod("newInstance", new Class[] { Control[].class });
			METHOD_reconnect = LdapContext.class.getMethod("reconnect", new Class[] { Control[].class });
			METHOD_setControls = LdapContext.class.getMethod("setRequestControls", new Class[] { Control[].class });
		} catch (Exception e) {
			throw new UnexpectedException(e);
		}
	}

	/**
	 * Constructs a new wrapper for the given context.
	 * @param ctx
	 */
	public LdapContextWrapper(LdapContext ctx) {
		super(ctx);
	}

	/**
	 * Executes the given method on the wrapped context; retrying up to
	 * the designated maximum with intermittent pauses if communications errors
	 * occur.
	 * @param m
	 * @param args
	 * @return Object
	 */
	protected Object executeWithRetry(Method m, Object[] args)
		throws NamingException {
		Object o = null;
		boolean success = false;
		int i = 0;
		LdapContext ctx = (LdapContext) getContext();
		while (!success && i < RETRY_MAX_ATTEMPTS) {
			try {
				if (i++ > 0) {
					ctx.reconnect(ctx.getConnectControls());
				}
				o = m.invoke(ctx, args);
				success = true;
			} catch (IllegalAccessException iae) {
				throw new UnexpectedException(iae);
			} catch (InvocationTargetException ite) {
				Throwable cause = ite.getTargetException();
				if (!(cause instanceof CommunicationException)
					|| i == RETRY_MAX_ATTEMPTS)
					if (cause instanceof NamingException)
						throw (NamingException) cause;
					else
						throw new UnexpectedException(cause);
			}
			if (!success)
				try {
					Thread.currentThread().wait(RETRY_WAIT_TIME_MS);
				} catch (Exception e) {
				}
		}
		return o;
	}

	/* (non-Javadoc)
	 * @see javax.naming.ldap.LdapContext#extendedOperation(javax.naming.ldap.ExtendedRequest)
	 */
	public ExtendedResponse extendedOperation(ExtendedRequest request)
		throws NamingException {
		return (ExtendedResponse) executeWithRetry(METHOD_extendedOperation, new Object[] { request });
	}

	/* (non-Javadoc)
	 * @see javax.naming.ldap.LdapContext#getConnectControls()
	 */
	public Control[] getConnectControls() throws NamingException {
		return (Control[]) executeWithRetry(METHOD_getConnectControls, null);
	}

	/* (non-Javadoc)
	 * @see javax.naming.ldap.LdapContext#getRequestControls()
	 */
	public Control[] getRequestControls() throws NamingException {
		return (Control[]) executeWithRetry(METHOD_getRequestControls, null);
	}

	/* (non-Javadoc)
	 * @see javax.naming.ldap.LdapContext#getResponseControls()
	 */
	public Control[] getResponseControls() throws NamingException {
		return (Control[]) executeWithRetry(METHOD_getResponseControls, null);
	}

	/* (non-Javadoc)
	 * @see javax.naming.ldap.LdapContext#newInstance(javax.naming.ldap.Control[])
	 */
	public LdapContext newInstance(Control[] requestControls)
		throws NamingException {
		return (LdapContext) executeWithRetry(METHOD_newInstance, new Object[] { requestControls });
	}

	/* (non-Javadoc)
	 * @see javax.naming.ldap.LdapContext#reconnect(javax.naming.ldap.Control[])
	 */
	public void reconnect(Control[] connCtls) throws NamingException {
		executeWithRetry(METHOD_reconnect, new Object[] { connCtls });
	}

	/* (non-Javadoc)
	 * @see javax.naming.ldap.LdapContext#setRequestControls(javax.naming.ldap.Control[])
	 */
	public void setRequestControls(Control[] requestControls)
		throws NamingException {
		executeWithRetry(METHOD_setControls, new Object[] { requestControls });
	}

}