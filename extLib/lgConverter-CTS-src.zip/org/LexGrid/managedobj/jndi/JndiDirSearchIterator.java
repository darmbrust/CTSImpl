/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.managedobj.jndi;

import java.util.NoSuchElementException;

import javax.naming.InvalidNameException;
import javax.naming.NameNotFoundException;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchResult;

import org.LexGrid.managedobj.ManagedObjIterator;
import org.LexGrid.managedobj.UnexpectedException;

/**
 * Iterates over the contents of a JNDI DirContext search, returning
 * corresponding managed objects. The prepared statement used to generate the
 * result set is automatically checked in when iteration completes.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class JndiDirSearchIterator implements ManagedObjIterator {
	private JndiDirSearchIteratorHelper _helper = null;
	private DirContext _ctx = null;
	private NamingEnumeration _enum = null;
	private Object _next = null;

	/**
	 * Constructs a new iterator over the given naming enumeration and context.
	 * @param helper
	 * @param ne
	 * @param ctx
	 * @throws NamingException
	 */
	public JndiDirSearchIterator(
		JndiDirSearchIteratorHelper helper,
		NamingEnumeration ne,
		DirContext ctx)
		throws NamingException {
		_helper = helper;
		_enum = ne;
		_ctx = ctx;
		_next = nextPrim();
	}

	/**
	 * Release encapsulated resources.
	 */
	public void close() {
		if (_ctx != null) {
			_helper.checkInContext(_ctx);
			_ctx = null;
			_next = null;
		}
	}

	/**
	 * @see java.lang.Object#finalize()
	 */
	protected void finalize() throws Throwable {
		close();
		super.finalize();
	}

	/**
	 * @see java.util.Iterator#hasNext()
	 */
	public boolean hasNext() {
		return _next != null;
	}

	/**
	 * @see java.util.Iterator#next()
	 */
	public Object next() {
		if (_next == null)
			throw new NoSuchElementException();
		Object o = _next;
		_next = nextPrim();
		return o;
	}

	/**
	 * Returns the next object as derived from information in the wrapped
	 * enumeration; null if not available.
	 * @return Object
	 */
	protected Object nextPrim() {
		Object next = null;
		boolean cont = true; // continue flag
		try {
			while (cont) {
				try {
					if (_enum.hasMoreElements())
						next = _helper.result2obj((SearchResult) _enum.next());
					cont = false;
				} catch (NameNotFoundException e) {
					// Ignore entries no longer on the system...
				} catch (InvalidNameException e) {
					// Ignore invalid entries...
				}
			}
		} catch (NamingException e) {
			close();
			throw new UnexpectedException(e);
		} finally {
			if (next == null)
				close();
		}
		return next;
	}

	/**
	 * @see java.util.Iterator#remove()
	 */
	public void remove() {
		throw new UnsupportedOperationException("remove");
	}
}