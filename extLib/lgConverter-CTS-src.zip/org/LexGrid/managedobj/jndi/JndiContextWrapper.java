/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.managedobj.jndi;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Hashtable;

import javax.naming.CommunicationException;
import javax.naming.Context;
import javax.naming.Name;
import javax.naming.NameParser;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;

import org.LexGrid.managedobj.UnexpectedException;

/**
 * Wraps a standard Context and provides additional functionality to
 * attempt selective recovery from failed connections, etc.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class JndiContextWrapper implements Context {

	// Initialize references to wrapped methods ...
	private static final Method METHOD_addToEnvironment;
	private static final Method METHOD_bind1;
	private static final Method METHOD_bind2;
	private static final Method METHOD_composeName1;
	private static final Method METHOD_composeName2;
	private static final Method METHOD_createSubcontext1;
	private static final Method METHOD_createSubcontext2;
	private static final Method METHOD_destroySubcontext1;
	private static final Method METHOD_destroySubcontext2;
	private static final Method METHOD_getEnvironment;
	private static final Method METHOD_getNameInNamespace;
	private static final Method METHOD_getNameParser1;
	private static final Method METHOD_getNameParser2;
	private static final Method METHOD_list1;
	private static final Method METHOD_list2;
	private static final Method METHOD_listBindings1;
	private static final Method METHOD_listBindings2;
	private static final Method METHOD_lookup1;
	private static final Method METHOD_lookup2;
	private static final Method METHOD_lookupLink1;
	private static final Method METHOD_lookupLink2;
	private static final Method METHOD_rebind1;
	private static final Method METHOD_rebind2;
	private static final Method METHOD_removeFromEnvironment;
	private static final Method METHOD_rename1;
	private static final Method METHOD_rename2;
	private static final Method METHOD_unbind1;
	private static final Method METHOD_unbind2;
	static {
		try {
			METHOD_addToEnvironment = DirContext.class.getMethod("addToEnvironment", new Class[] { String.class, Object.class });
			METHOD_bind1 = DirContext.class.getMethod("bind", new Class[] { Name.class, Object.class });
			METHOD_bind2 = DirContext.class.getMethod("bind", new Class[] { String.class, Object.class }); 
			METHOD_composeName1 = DirContext.class.getMethod("composeName", new Class[] { Name.class, Name.class });
			METHOD_composeName2 = DirContext.class.getMethod("composeName", new Class[] { String.class, String.class });
			METHOD_createSubcontext1 = DirContext.class.getMethod("createSubcontext", new Class[] { Name.class });
			METHOD_createSubcontext2 = DirContext.class.getMethod("createSubcontext", new Class[] { String.class });
			METHOD_destroySubcontext1 = DirContext.class.getMethod("destroySubcontext", new Class[] { Name.class });
			METHOD_destroySubcontext2 = DirContext.class.getMethod("destroySubcontext", new Class[] { String.class });
			METHOD_getEnvironment = DirContext.class.getMethod("getEnvironment", null);
			METHOD_getNameInNamespace = DirContext.class.getMethod("getNameInNamespace", null);
			METHOD_getNameParser1 = DirContext.class.getMethod("getNameParser", new Class[] { Name.class });;
			METHOD_getNameParser2 = DirContext.class.getMethod("getNameParser", new Class[] { String.class });
			METHOD_list1 = DirContext.class.getMethod("list", new Class[] { Name.class });
			METHOD_list2 = DirContext.class.getMethod("list", new Class[] { String.class });
			METHOD_listBindings1 = DirContext.class.getMethod("listBindings", new Class[] { Name.class });
			METHOD_listBindings2 = DirContext.class.getMethod("listBindings", new Class[] { String.class });
			METHOD_lookup1 = DirContext.class.getMethod("lookup", new Class[] { Name.class });
			METHOD_lookup2 = DirContext.class.getMethod("lookup", new Class[] { String.class });
			METHOD_lookupLink1 = DirContext.class.getMethod("lookupLink", new Class[] { Name.class });
			METHOD_lookupLink2 = DirContext.class.getMethod("lookupLink", new Class[] { String.class });
			METHOD_rebind1 = DirContext.class.getMethod("rebind", new Class[] { Name.class, Object.class });
			METHOD_rebind2 = DirContext.class.getMethod("rebind", new Class[] { String.class, Object.class });
			METHOD_removeFromEnvironment = DirContext.class.getMethod("removeFromEnvironment", new Class[] { String.class });
			METHOD_rename1 = DirContext.class.getMethod("rename", new Class[] { Name.class, Name.class });
			METHOD_rename2 = DirContext.class.getMethod("rename", new Class[] { String.class, String.class });
			METHOD_unbind1 = DirContext.class.getMethod("unbind", new Class[] { Name.class });
			METHOD_unbind2 = DirContext.class.getMethod("unbind", new Class[] { String.class });
		} catch (Exception e) {
			throw new UnexpectedException(e);
		}
	}

	protected static final int RETRY_MAX_ATTEMPTS = 5;
	protected static final int RETRY_WAIT_TIME_MS = 5000;
	
	private Context _ctx = null;

	/**
	 * Constructs a new wrapper for the given context.
	 * @param ctx
	 */
	public JndiContextWrapper(Context ctx) {
		super();
		_ctx = ctx;
	}

	/**
	 * Executes the given method on the wrapped context; retrying up to
	 * the designated maximum with intermittent pauses if communications errors
	 * occur.
	 * @param m
	 * @param args
	 * @return Object
	 */
	protected Object executeWithRetry(Method m, Object[] args)
		throws NamingException {
		Object o = null;
		boolean success = false;
		int i = 0;
		Context ctx = getContext();
		while (!success && i < RETRY_MAX_ATTEMPTS) {
			try {
				o = m.invoke(ctx, args);
				success = true;
			} catch (IllegalAccessException iae) {
				throw new UnexpectedException(iae);
			} catch (InvocationTargetException ite) {
				Throwable cause = ite.getTargetException();
				if (!(cause instanceof CommunicationException)
					|| i == RETRY_MAX_ATTEMPTS)
					if (cause instanceof NamingException)
						throw (NamingException) cause;
					else
						throw new UnexpectedException(cause);
			}
			if (!success)
				try {
					Thread.currentThread().wait(RETRY_WAIT_TIME_MS);
				} catch (InterruptedException ie) {
				}
		}
		return o;
	}

	/**
	 * Returns the wrapped context.
	 * @return Context
	 */
	protected Context getContext() {
		return _ctx;
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#addToEnvironment(java.lang.String, java.lang.Object)
	 */
	public Object addToEnvironment(String propName, Object propVal)
		throws NamingException {
		return executeWithRetry(METHOD_addToEnvironment, new Object[] { propName, propVal });
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#bind(javax.naming.Name, java.lang.Object)
	 */
	public void bind(Name name, Object obj) throws NamingException {
		executeWithRetry(METHOD_bind1, new Object[] { name, obj });
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#bind(java.lang.String, java.lang.Object)
	 */
	public void bind(String name, Object obj) throws NamingException {
		executeWithRetry(METHOD_bind2, new Object[] { name, obj });
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#close()
	 */
	public void close() throws NamingException {
		getContext().close();
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#composeName(javax.naming.Name, javax.naming.Name)
	 */
	public Name composeName(Name name, Name prefix) throws NamingException {
		return (Name) executeWithRetry(METHOD_composeName1, new Object[] { name, prefix });
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#composeName(java.lang.String, java.lang.String)
	 */
	public String composeName(String name, String prefix)
		throws NamingException {
		return (String) executeWithRetry(METHOD_composeName2, new Object[] { name, prefix });
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#createSubcontext(javax.naming.Name)
	 */
	public Context createSubcontext(Name name) throws NamingException {
		return (Context) executeWithRetry(METHOD_createSubcontext1, new Object[] { name });
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#createSubcontext(java.lang.String)
	 */
	public Context createSubcontext(String name) throws NamingException {
		return (Context) executeWithRetry(METHOD_createSubcontext2, new Object[] { name });
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#destroySubcontext(javax.naming.Name)
	 */
	public void destroySubcontext(Name name) throws NamingException {
		executeWithRetry(METHOD_destroySubcontext1, new Object[] { name });
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#destroySubcontext(java.lang.String)
	 */
	public void destroySubcontext(String name) throws NamingException {
		executeWithRetry(METHOD_destroySubcontext2, new Object[] { name });
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#getEnvironment()
	 */
	public Hashtable getEnvironment() throws NamingException {
		return (Hashtable) executeWithRetry(METHOD_getEnvironment, null);
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#getNameInNamespace()
	 */
	public String getNameInNamespace() throws NamingException {
		return (String) executeWithRetry(METHOD_getNameInNamespace, null);
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#getNameParser(javax.naming.Name)
	 */
	public NameParser getNameParser(Name name) throws NamingException {
		return (NameParser) executeWithRetry(METHOD_getNameParser1, new Object[] { name });
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#getNameParser(java.lang.String)
	 */
	public NameParser getNameParser(String name) throws NamingException {
		return (NameParser) executeWithRetry(METHOD_getNameParser2, new Object[] { name });
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#list(javax.naming.Name)
	 */
	public NamingEnumeration list(Name name) throws NamingException {
		return (NamingEnumeration) executeWithRetry(METHOD_list1, new Object[] { name });
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#list(java.lang.String)
	 */
	public NamingEnumeration list(String name) throws NamingException {
		return (NamingEnumeration) executeWithRetry(METHOD_list2, new Object[] { name });
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#listBindings(javax.naming.Name)
	 */
	public NamingEnumeration listBindings(Name name) throws NamingException {
		return (NamingEnumeration) executeWithRetry(METHOD_listBindings1, new Object[] { name });
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#listBindings(java.lang.String)
	 */
	public NamingEnumeration listBindings(String name) throws NamingException {
		return (NamingEnumeration) executeWithRetry(METHOD_listBindings2, new Object[] { name });
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#lookup(javax.naming.Name)
	 */
	public Object lookup(Name name) throws NamingException {
		return executeWithRetry(METHOD_lookup1, new Object[] { name });
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#lookup(java.lang.String)
	 */
	public Object lookup(String name) throws NamingException {
		return executeWithRetry(METHOD_lookup2, new Object[] { name });
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#lookupLink(javax.naming.Name)
	 */
	public Object lookupLink(Name name) throws NamingException {
		return executeWithRetry(METHOD_lookupLink1, new Object[] { name });
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#lookupLink(java.lang.String)
	 */
	public Object lookupLink(String name) throws NamingException {
		return executeWithRetry(METHOD_lookupLink2, new Object[] { name });
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#rebind(javax.naming.Name, java.lang.Object)
	 */
	public void rebind(Name name, Object obj) throws NamingException {
		executeWithRetry(METHOD_rebind1, new Object[] { name, obj });
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#rebind(java.lang.String, java.lang.Object)
	 */
	public void rebind(String name, Object obj) throws NamingException {
		executeWithRetry(METHOD_rebind2, new Object[] { name, obj });
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#removeFromEnvironment(java.lang.String)
	 */
	public Object removeFromEnvironment(String propName)
		throws NamingException {
		return executeWithRetry(METHOD_removeFromEnvironment, new Object[] { propName });
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#rename(javax.naming.Name, javax.naming.Name)
	 */
	public void rename(Name oldName, Name newName) throws NamingException {
		executeWithRetry(METHOD_rename1, new Object[] { oldName, newName });
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#rename(java.lang.String, java.lang.String)
	 */
	public void rename(String oldName, String newName) throws NamingException {
		executeWithRetry(METHOD_rename2, new Object[] { oldName, newName });
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#unbind(javax.naming.Name)
	 */
	public void unbind(Name name) throws NamingException {
		executeWithRetry(METHOD_unbind1, new Object[] { name });
	}

	/* (non-Javadoc)
	 * @see javax.naming.Context#unbind(java.lang.String)
	 */
	public void unbind(String name) throws NamingException {
		executeWithRetry(METHOD_unbind2, new Object[] { name });
	}

}