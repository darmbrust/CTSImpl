/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.managedobj.jndi;

import java.util.Arrays;

import javax.naming.Context;
import javax.naming.NameClassPair;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.SearchResult;

import org.LexGrid.managedobj.CachedService;
import org.LexGrid.managedobj.HomeServiceBroker;
import org.LexGrid.managedobj.ManagedObjIF;
import org.LexGrid.managedobj.ServiceInitException;
import org.LexGrid.managedobj.ServiceUnavailableException;
import org.LexGrid.managedobj.UnexpectedException;

/**
 * Abstract superclass for all JNDI services.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public abstract class JndiBaseService extends CachedService {
	// Characters requiring escape in domain names ...
	private static final char[] ESCAPE_CHARS =
		new char[] { '"', '+', ',', '/', ';', '<', '>', '\\' };

	// Context & pooling (Jakarta Commons Pool)
	private JndiContextDescriptor _ctxDesc;
	private JndiContextPool _ctxPool = null;
	private JndiContextPoolPolicy _ctxPolicy = null;

	// Name of the directory entry serving as starting point for persistence
	// operations, relative to the associated context descriptor.
	private ThreadLocal _ctxRdn = null;

	// Statistics...
	// For now just simple running counts to provide a
	// sanity check on checked-in/checked-out statements.
	// Note: This should be extended to a more full-featured
	// approach that includes statement execution time,
	// averages, etc.
	private int _statCheckOutsAll = 0;
	private int _statCheckOutsNow = 0;

	/**
	 * Constructor for JndiBaseService.
	 */
	protected JndiBaseService() {
		super();
	}

	/**
	 * Constructor for JndiBaseService.
	 * @param anchorService
	 * @throws ServiceInitException
	 */
	public JndiBaseService(JndiBaseService anchorService)
		throws ServiceInitException {
		this();
		setBroker(anchorService.getBroker());
		anchorService.internalRegisterNestedService(this);
		setAnchorService(anchorService);
		setContextDescriptor(anchorService.getContextDescriptor());
		setContextPool(anchorService.getContextPool());
		setContextPoolPolicy(anchorService.getContextPoolPolicy());
		init();
	}

	/**
	 * Constructor for JndiBaseService.
	 * @param broker
	 * @throws ServiceInitException
	 */
	public JndiBaseService(HomeServiceBroker broker)
		throws ServiceInitException {
		super(broker);
	}

	/**
	 * Returns a context to the pool.
	 * @param ctx Context
	 */
	public void checkInContext(Context ctx) {
		_statCheckOutsNow--;
		try {
			if (ctx != null)
				getContextPool().returnObject(ctx);
		} catch (Exception e) {
			throw new UnexpectedException(e);
		}
	}

	/**
	 * Borrows a context from the pool.
	 * @return Context
	 * @throws NamingException
	 */
	public Context checkOutContext() throws NamingException {
		try {
			_statCheckOutsAll++;
			_statCheckOutsNow++;
			return (Context) getContextPool().borrowObject();
		} catch (NamingException e) {
			throw e;
		} catch (Exception e) {
			throw new NamingException(e.toString());
		}
	}

	/**
	 * @see org.LexGrid.managedobj.HomeServiceIF#closePrim()
	 */
	public void closePrim() {
		try {
			super.closePrim();
		} finally {
			try {
				// If this is a top level service,
				// release resources and close the JNDI context pool.
				if (getAnchorService() == null && _ctxPool != null)
					_ctxPool.close();
			} catch (Exception e) {
				throw new UnexpectedException(e);
			} finally {
				// Perform cleanup and write JNDI-related diagnostics ...
				_ctxDesc = null;
				_ctxPolicy = null;
				_ctxPool = null;
				_ctxRdn = null;
//				if (_statCheckOutsAll > 0 || _statCheckOutsNow > 0) {
//					System.out.println(">>> " + this.getClass().getName());
//					System.out.println(">>> Total # contexts checked out: " + _statCheckOutsAll);
//					System.out.println(">>>\tContexts not returned: " + _statCheckOutsNow);
//				}
				_statCheckOutsAll = 0;
				_statCheckOutsNow = 0;
			}
		}
	}

	/**
	 * Creates a new entry relative to the configured context.
	 * @param rdn Relative distinguished name of the target entry.
	 * @throws NamingException
	 */
	public void dcCreateEntry(String rdn) throws NamingException {
		dcCreateEntryAbsolute(qualifyRdn(rdn));
	}

	/**
	 * Creates a new entry relative to the configured context.
	 * @param dn Distinguished name of the target entry.
	 * @throws NamingException
	 */
	public void dcCreateEntryAbsolute(String dn) throws NamingException {
		Context ctx = checkOutContext();
		try {
			ctx.createSubcontext(dn);
		} finally {
			checkInContext(ctx);
		}
	}

	/**
	 * Removes an entry relative to the configured context.
	 * @param rdn Relative distinguished name of the target entry.
	 * @throws NamingException
	 */
	public void dcRemoveEntry(String rdn) throws NamingException {
		Context ctx = checkOutContext();
		try {
			ctx.destroySubcontext(qualifyRdn(rdn));
		} finally {
			checkInContext(ctx);
		}
	}

	/**
	 * Removes an entry relative to the configured context, and all children.
	 * @param rdn Relative distinguished name of the target entry.
	 * @throws NamingException
	 */
	public void dcRemoveTree(String rdn) throws NamingException {
		Context ctx = checkOutContext();
		try {
			// Recursively delete children...
			String qdn = qualifyRdn(rdn);
			NamingEnumeration ne = ctx.list(qdn);
			while (ne.hasMore())
				dcRemoveTree(((NameClassPair) ne.next()).getName() + ',' + rdn);
			// Delete the parent entry
			dcRemoveEntry(rdn);
		} finally {
			checkInContext(ctx);
		}
	}

	/**
	 * Returns a counterpart to the given text with escape characters inserted
	 * as required to conform to directory entry naming policy.
	 * @param rdn
	 * @return String
	 */
	protected String escapeRdn(String rdn) {
		StringBuffer sb = new StringBuffer(rdn.length() + 32);
		char ch;
		int last = rdn.length() - 1;
		for (int i = 0; i <= last; i++) {
			ch = rdn.charAt(i);
			if ((i == 0 && (ch == ' ' || ch == '#'))
				|| (i == last && ch == ' ')
				|| (Arrays.binarySearch(ESCAPE_CHARS, ch) >= 0))
				sb.append('\\');
			sb.append(ch);
		}
		return sb.toString();
	}

	/**
	 * Returns an object defining JNDI context objects. 
	 * @return JndiContextDescriptor
	 */
	public final JndiContextDescriptor getContextDescriptor() {
		if (_ctxDesc == null)
			_ctxDesc = newContextDescriptor();
		return _ctxDesc;
	}

	/**
	 * Returns the name of the entry acting as starting point for the service,
	 * relative to the provider URL defined by the context descriptor.
	 * <p>
	 * Note: This value is maintained in thread-local storage; callers can
	 * assume that the value will not be altered by other threads simultaneously
	 * accessing the service.
	 * @return String
	 */
	public String getContextEntryPoint() {
		return (String) getContextRdn().get();
	}

	/**
	 * Returns an object pool used to manage JNDI contexts.
	 * @return JndiContextPool
	 */
	public final JndiContextPool getContextPool() {
		if (_ctxPool == null)
			_ctxPool = newContextPool();
		return _ctxPool;
	}

	/**
	 * Returns the policy used to manage the context pool.
	 * @return JndiContextPoolPolicy
	 */
	public final JndiContextPoolPolicy getContextPoolPolicy() {
		if (_ctxPolicy == null)
			_ctxPolicy = newContextPoolPolicy();
		return _ctxPolicy;
	}

	/**
	 * Returns the thread-localized entry point.
	 * @return ThreadLocal
	 */
	private ThreadLocal getContextRdn() {
		if (_ctxRdn == null || _ctxRdn.get() == null)
			initContextRdn();
		return _ctxRdn;
	}

	/**
	 * Returns a service registered to handle instances of the given class that
	 * are nested under the given object; null if not available.
	 * @param clazz
	 * @param obj
	 * @return JndiBaseService
	 */
	protected JndiBaseService getNestedService(Class clazz, ManagedObjIF obj) {
		JndiBaseService service = (JndiBaseService) getNestedService(clazz);
		if (service != null)
			service.setContextEntryPoint(qualifyRdn(obj2rdn(obj)));
		return service;
	}

	/**
	 * Initializes the thread localized entry point.
	 * <p>
	 * Note: Separated into separate sync method (instead of lazy init in
	 * getter) due to concerns over integrity of approaches using double-checked
	 * locking.
	 */
	private synchronized void initContextRdn() {
		if (_ctxRdn == null)
			_ctxRdn = new ThreadLocal();
		_ctxRdn.set("");
	}

	/**
	 * Returns a new/default JNDI context definition.
	 * @return JndiContextDescriptor
	 */
	protected JndiContextDescriptor newContextDescriptor() {
		return new JndiContextDescriptor();
	}

	/**
	 * Returns a new pool to manage JNDI context objects.
	 * @return JndiContextPool
	 */
	protected JndiContextPool newContextPool() {
		return new JndiContextPool(
			new JndiContextFactory(getContextDescriptor()),
			getContextPoolPolicy());
	}

	/**
	 * Returns a new policy to manage the context pool.
	 * @return JndiContextPoolPolicy
	 */
	protected JndiContextPoolPolicy newContextPoolPolicy() {
		return new JndiContextPoolPolicy();
	}

	/**
	 * Returns a relative distinguished name based on the given object.
	 * @param obj
	 * @return String
	 */
	public String obj2rdn(ManagedObjIF obj) {
		return primaryKey2rdn(obj.getPrimaryKey());
	}

	/**
	 * Returns the relative distinguished name based on the given key.
	 * @param key
	 * @return String
	 */
	public abstract String primaryKey2rdn(Object key);

	/**
	 * Qualifies the given rdn by context entry point.
	 * @param rdn
	 * @return String
	 */
	public String qualifyRdn(String rdn) {
		String ep = getContextEntryPoint();
		return (ep.length() > 0)
			? (rdn.length() > 0
				? new StringBuffer(rdn.length() + 128)
					.append(escapeRdn(rdn))
					.append(',')
					.append(ep)
					.toString()
				: ep)
			: rdn;
	}

	/**
	 * Returns the relative distinguished name based on the given key.
	 * <p>
	 * Classes for which supporting the notion of secondary 
	 * @param key
	 * @return String
	 */
	public String secondaryKey2rdn(Object key) {
		throw new ServiceUnavailableException("secondaryKey2rdn");
	}

	/**
	 * Sets the object defining the JNDI context. 
	 * @param desc JndiContextDescriptor
	 */
	public void setContextDescriptor(JndiContextDescriptor desc) {
		_ctxDesc = desc;
	}

	/**
	 * Sets the name of the entry acting as starting point for the service,
	 * relative to the provider URL defined by the context descriptor.
	 * <p>
	 * Note: This value is maintained in thread-local storage; callers can
	 * assume that the value will not be altered by other threads simultaneously
	 * accessing the service.
	 * @param rdn String
	 */
	public void setContextEntryPoint(String rdn) {
		getContextRdn().set(rdn);
	}

	/**
	 * Sets an object pool used to manage JNDI contexts.
	 * @param pool JndiContextPool
	 */
	protected void setContextPool(JndiContextPool pool) {
		_ctxPool = pool;
	}

	/**
	 * Sets the policy used to manage the context pool.
	 * @param policy JndiContextPoolPolicy
	 */
	protected void setContextPoolPolicy(JndiContextPoolPolicy policy) {
		_ctxPolicy = policy;
	}

	/**
	 * Returns the name from the given search result.
	 * If the given rdn is wrapped in initial and trailing double-quotes,
	 * this method will extract and unescape the enclosed text.
	 * @param rdn
	 * @return String
	 */
	protected String unwrapName(SearchResult sr) {
		String name = sr.getName();
		if (name != null) {
			StringBuffer sb = new StringBuffer(name.length());
			boolean quoted = name.length() >= 2 && name.charAt(0) == '"' && name.charAt(name.length() - 1) == '"';
			int first = quoted ? 1 : 0;
			int last = quoted ? name.length() - 1 : name.length();
			char ch, next;
			int i = first;
			while (i < last) {
				ch = name.charAt(i);
				if (i + 1 < last) {
					next = name.charAt(i + 1);
					if (ch == '\\'
						&& ((Arrays.binarySearch(ESCAPE_CHARS, next) >= 0)
							|| ((i == first) && (next == ' ' || next == '#'))
							|| ((i == last-1) && (next == ' '))))
					{
						sb.append(next);
						i++;
					}
					else
						sb.append(ch);
				} else
					sb.append(ch);
				i++;
			}
			name = sb.toString();
		}
		return name;
	}

}