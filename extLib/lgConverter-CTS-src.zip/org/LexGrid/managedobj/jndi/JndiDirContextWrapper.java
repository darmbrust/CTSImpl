/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.managedobj.jndi;

import java.lang.reflect.Method;

import javax.naming.Name;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;

import org.LexGrid.managedobj.UnexpectedException;

/**
 * Wraps a standard DirContext and provides additional functionality to attempt
 * selective recovery from failed connections, etc.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class JndiDirContextWrapper
	extends JndiContextWrapper
	implements DirContext {

	// Initialize references to wrapped methods ...
	private static final Method METHOD_bind1;
	private static final Method METHOD_bind2;
	private static final Method METHOD_createSubcontext1;
	private static final Method METHOD_createSubcontext2;
	private static final Method METHOD_getAttributes1;
	private static final Method METHOD_getAttributes2;
	private static final Method METHOD_getAttributes3;
	private static final Method METHOD_getAttributes4;
	private static final Method METHOD_getSchema1;
	private static final Method METHOD_getSchema2;
	private static final Method METHOD_getSchemaClassDefinition1;
	private static final Method METHOD_getSchemaClassDefinition2;
	private static final Method METHOD_modifyAttributes1;
	private static final Method METHOD_modifyAttributes2;
	private static final Method METHOD_modifyAttributes3;
	private static final Method METHOD_modifyAttributes4;
	private static final Method METHOD_rebind1;
	private static final Method METHOD_rebind2;
	private static final Method METHOD_search1;
	private static final Method METHOD_search2;
	private static final Method METHOD_search3;
	private static final Method METHOD_search4;
	private static final Method METHOD_search5;
	private static final Method METHOD_search6;
	private static final Method METHOD_search7;
	private static final Method METHOD_search8;
	static {
		try {
			METHOD_bind1 = DirContext.class.getMethod("bind", new Class[] { Name.class, Object.class, Attributes.class });
			METHOD_bind2 = DirContext.class.getMethod("bind", new Class[] { String.class, Object.class, Attributes.class });
			METHOD_createSubcontext1 = DirContext.class.getMethod("createSubcontext", new Class[] { Name.class, Attributes.class });
			METHOD_createSubcontext2 = DirContext.class.getMethod("createSubcontext", new Class[] { String.class, Attributes.class });
			METHOD_getAttributes1 = DirContext.class.getMethod("getAttributes", new Class[] { Name.class });
			METHOD_getAttributes2 = DirContext.class.getMethod("getAttributes", new Class[] { Name.class, String[].class });
			METHOD_getAttributes3 = DirContext.class.getMethod("getAttributes", new Class[] { String.class });;
			METHOD_getAttributes4 = DirContext.class.getMethod("getAttributes", new Class[] { String.class, String[].class });
			METHOD_getSchema1 = DirContext.class.getMethod("getSchema", new Class[] { Name.class });
			METHOD_getSchema2 = DirContext.class.getMethod("getSchema", new Class[] { String.class });
			METHOD_getSchemaClassDefinition1 = DirContext.class.getMethod("getSchemaClassDefinition", new Class[] { Name.class });
			METHOD_getSchemaClassDefinition2 = DirContext.class.getMethod("getSchemaClassDefinition", new Class[] { String.class });
			METHOD_modifyAttributes1 = DirContext.class.getMethod("modifyAttributes", new Class[] { Name.class, int.class, Attributes.class });
			METHOD_modifyAttributes2 = DirContext.class.getMethod("modifyAttributes", new Class[] { Name.class, ModificationItem[].class });
			METHOD_modifyAttributes3 = DirContext.class.getMethod("modifyAttributes", new Class[] { String.class, int.class, Attributes.class });
			METHOD_modifyAttributes4 = DirContext.class.getMethod("modifyAttributes", new Class[] { String.class, ModificationItem[].class });
			METHOD_rebind1 = DirContext.class.getMethod("rebind", new Class[] { Name.class, Object.class, Attributes.class });
			METHOD_rebind2 = DirContext.class.getMethod("rebind", new Class[] { String.class, Object.class, Attributes.class });
			METHOD_search1 = DirContext.class.getMethod("search", new Class[] { Name.class, Attributes.class });
			METHOD_search2 = DirContext.class.getMethod("search", new Class[] { Name.class, Attributes.class, String[].class });
			METHOD_search3 = DirContext.class.getMethod("search", new Class[] { Name.class, String.class, Object[].class, SearchControls.class });
			METHOD_search4 = DirContext.class.getMethod("search", new Class[] { Name.class, String.class, SearchControls.class });
			METHOD_search5 = DirContext.class.getMethod("search", new Class[] { String.class, Attributes.class });
			METHOD_search6 = DirContext.class.getMethod("search", new Class[] { String.class, Attributes.class, String[].class });
			METHOD_search7 = DirContext.class.getMethod("search", new Class[] { String.class, String.class, Object[].class, SearchControls.class });
			METHOD_search8 = DirContext.class.getMethod("search", new Class[] { String.class, String.class, SearchControls.class });
		} catch (Exception e) {
			throw new UnexpectedException(e);
		}
	}
	
	/**
	 * Constructs a new wrapper for the given context.
	 * @param ctx
	 */
	public JndiDirContextWrapper(DirContext ctx) {
		super(ctx);
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#bind(javax.naming.Name, java.lang.Object, javax.naming.directory.Attributes)
	 */
	public void bind(Name name, Object obj, Attributes attrs)
		throws NamingException {
		executeWithRetry(METHOD_bind1, new Object[] { name, obj, attrs });
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#bind(java.lang.String, java.lang.Object, javax.naming.directory.Attributes)
	 */
	public void bind(String name, Object obj, Attributes attrs)
		throws NamingException {
		executeWithRetry(METHOD_bind2, new Object[] { name, obj, attrs });
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#createSubcontext(javax.naming.Name, javax.naming.directory.Attributes)
	 */
	public DirContext createSubcontext(Name name, Attributes attrs)
		throws NamingException {
		return (DirContext) executeWithRetry(METHOD_createSubcontext1, new Object[] { name, attrs });
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#createSubcontext(java.lang.String, javax.naming.directory.Attributes)
	 */
	public DirContext createSubcontext(String name, Attributes attrs)
		throws NamingException {
		return (DirContext) executeWithRetry(METHOD_createSubcontext2, new Object[] { name, attrs });
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#getAttributes(javax.naming.Name)
	 */
	public Attributes getAttributes(Name name) throws NamingException {
		return (Attributes) executeWithRetry(METHOD_getAttributes1, new Object[] { name });
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#getAttributes(javax.naming.Name, java.lang.String[])
	 */
	public Attributes getAttributes(Name name, String[] attrIds)
		throws NamingException {
		return (Attributes) executeWithRetry(METHOD_getAttributes2, new Object[] { name, attrIds });
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#getAttributes(java.lang.String)
	 */
	public Attributes getAttributes(String name) throws NamingException {
		return (Attributes) executeWithRetry(METHOD_getAttributes3, new Object[] { name });
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#getAttributes(java.lang.String, java.lang.String[])
	 */
	public Attributes getAttributes(String name, String[] attrIds)
		throws NamingException {
		return (Attributes) executeWithRetry(METHOD_getAttributes4, new Object[] { name, attrIds });
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#getSchema(javax.naming.Name)
	 */
	public DirContext getSchema(Name name) throws NamingException {
		return (DirContext) executeWithRetry(METHOD_getSchema1, new Object[] { name });
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#getSchema(java.lang.String)
	 */
	public DirContext getSchema(String name) throws NamingException {
		return (DirContext) executeWithRetry(METHOD_getSchema2, new Object[] { name });
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#getSchemaClassDefinition(javax.naming.Name)
	 */
	public DirContext getSchemaClassDefinition(Name name)
		throws NamingException {
		return (DirContext) executeWithRetry(METHOD_getSchemaClassDefinition1, new Object[] { name });
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#getSchemaClassDefinition(java.lang.String)
	 */
	public DirContext getSchemaClassDefinition(String name)
		throws NamingException {
		return (DirContext) executeWithRetry(METHOD_getSchemaClassDefinition2, new Object[] { name });
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#modifyAttributes(javax.naming.Name, int, javax.naming.directory.Attributes)
	 */
	public void modifyAttributes(Name name, int mod_op, Attributes attrs)
		throws NamingException {
		executeWithRetry(METHOD_modifyAttributes1, 	new Object[] { name, new Integer(mod_op), attrs });
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#modifyAttributes(javax.naming.Name, javax.naming.directory.ModificationItem[])
	 */
	public void modifyAttributes(Name name, ModificationItem[] mods)
		throws NamingException {
		executeWithRetry(METHOD_modifyAttributes2, new Object[] { name, mods });
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#modifyAttributes(java.lang.String, int, javax.naming.directory.Attributes)
	 */
	public void modifyAttributes(String name, int mod_op, Attributes attrs)
		throws NamingException {
		executeWithRetry(METHOD_modifyAttributes3, 	new Object[] { name, new Integer(mod_op), attrs });
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#modifyAttributes(java.lang.String, javax.naming.directory.ModificationItem[])
	 */
	public void modifyAttributes(String name, ModificationItem[] mods)
		throws NamingException {
		executeWithRetry(METHOD_modifyAttributes4, new Object[] { name, mods });
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#rebind(javax.naming.Name, java.lang.Object, javax.naming.directory.Attributes)
	 */
	public void rebind(Name name, Object obj, Attributes attrs)
		throws NamingException {
		executeWithRetry(METHOD_rebind1, new Object[] { name, obj, attrs });
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#rebind(java.lang.String, java.lang.Object, javax.naming.directory.Attributes)
	 */
	public void rebind(String name, Object obj, Attributes attrs)
		throws NamingException {
		executeWithRetry(METHOD_rebind2, new Object[] { name, obj, attrs });
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#search(javax.naming.Name, javax.naming.directory.Attributes)
	 */
	public NamingEnumeration search(Name name, Attributes matchingAttributes)
		throws NamingException {
		return (NamingEnumeration) executeWithRetry(METHOD_search1, new Object[] { name, matchingAttributes });
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#search(javax.naming.Name, javax.naming.directory.Attributes, java.lang.String[])
	 */
	public NamingEnumeration search(
		Name name,
		Attributes matchingAttributes,
		String[] attributesToReturn)
		throws NamingException {
		return (NamingEnumeration) executeWithRetry(METHOD_search2, new Object[] { name, matchingAttributes, attributesToReturn });
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#search(javax.naming.Name, java.lang.String, java.lang.Object[], javax.naming.directory.SearchControls)
	 */
	public NamingEnumeration search(
		Name name,
		String filterExpr,
		Object[] filterArgs,
		SearchControls cons)
		throws NamingException {
		return (NamingEnumeration) executeWithRetry(METHOD_search3, new Object[] { name, filterExpr, filterArgs, cons });
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#search(javax.naming.Name, java.lang.String, javax.naming.directory.SearchControls)
	 */
	public NamingEnumeration search(
		Name name,
		String filter,
		SearchControls cons)
		throws NamingException {
		return (NamingEnumeration) executeWithRetry(METHOD_search4, new Object[] { name, filter, cons });
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#search(java.lang.String, javax.naming.directory.Attributes)
	 */
	public NamingEnumeration search(String name, Attributes matchingAttributes)
		throws NamingException {
		return (NamingEnumeration) executeWithRetry(METHOD_search5, new Object[] { name, matchingAttributes });
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#search(java.lang.String, javax.naming.directory.Attributes, java.lang.String[])
	 */
	public NamingEnumeration search(
		String name,
		Attributes matchingAttributes,
		String[] attributesToReturn)
		throws NamingException {
		return (NamingEnumeration) executeWithRetry(METHOD_search6, new Object[] { name, matchingAttributes, attributesToReturn });
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#search(java.lang.String, java.lang.String, java.lang.Object[], javax.naming.directory.SearchControls)
	 */
	public NamingEnumeration search(
		String name,
		String filterExpr,
		Object[] filterArgs,
		SearchControls cons)
		throws NamingException {
		return (NamingEnumeration) executeWithRetry(METHOD_search7, new Object[] { name, filterExpr, filterArgs, cons });
	}

	/* (non-Javadoc)
	 * @see javax.naming.directory.DirContext#search(java.lang.String, java.lang.String, javax.naming.directory.SearchControls)
	 */
	public NamingEnumeration search(
		String name,
		String filter,
		SearchControls cons)
		throws NamingException {
		return (NamingEnumeration) executeWithRetry(METHOD_search8, new Object[] { name, filter, cons });
	}

}