/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.managedobj.jndi;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.SearchControls;
import javax.naming.ldap.LdapContext;

import org.LexGrid.managedobj.HomeServiceBroker;
import org.LexGrid.managedobj.ManagedObjIF;
import org.LexGrid.managedobj.ManagedObjIterator;
import org.LexGrid.managedobj.ServiceInitException;
import org.apache.commons.collections.CollectionUtils;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;

/**
 * Abstract superclass for all LDAP services.
 * <p>
 * The intent of these services is to allow decoupling of a neutral information
 * model from ldap-specific data representation and the ability to map between
 * the two forms.
 * 
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public abstract class LdapBaseService
	extends JndiDirService
	implements LdapManagedObjIteratorHelper {

	// Configuration
	protected static final String DEFAULT_CONFIG_FILE = "ldap.xml";
	protected static final String DEFAULT_FACTORY = "com.sun.jndi.ldap.LdapCtxFactory";
	protected File _configFile = null;

	// Attributes and ldap-defined classes required by the service
	// when resolving managed instances.
	private String[] _rAttrs = null;
	private String[] _rClass = null;

	/**
	 * Constructor for LdapBaseService.
	 */
	protected LdapBaseService() {
		super();
	}

	/**
	 * Constructs a new instance that connects to the server defined by the default
	 * config file (ldap.xml) using the default context pooling policy.
	 * @param broker
	 * @throws ServiceInitException
	 */
	public LdapBaseService(HomeServiceBroker broker) throws ServiceInitException {
		this(broker, new File(DEFAULT_CONFIG_FILE));
	}

	/**
	 * Constructs a new instance that connects to the repository defined by the
	 * given config file using the default connection pooling policy.
	 * @param broker
	 * @param xmlFile
	 * @throws ServiceInitException
	 */
	public LdapBaseService(HomeServiceBroker broker, File xmlFile)
		throws ServiceInitException {
		this();
		setBroker(broker);
		setConfigFile(xmlFile);
		init();
	}

	/**
	 * Constructs a new instance that connects to the repository using a
	 * specific context descriptor and connection pooling policy.
	 * <p>
	 * Note: If duplicated, file settings will override those in the given
	 * descriptor or policy.
	 * @param broker
	 * @param xmlFile
	 * @param ctxDescriptor
	 * @param ctxPoolPolicy
	 * @throws ServiceInitException
	 */
	public LdapBaseService(
		HomeServiceBroker broker,
		File xmlFile,
		LdapContextDescriptor ctxDescriptor,
		LdapContextPoolPolicy ctxPoolPolicy)
		throws ServiceInitException {
		this();
		setBroker(broker);
		setConfigFile(xmlFile);
		setContextDescriptor(ctxDescriptor);
		setContextPoolPolicy(ctxPoolPolicy);
		init();
	}

	/**
	 * Constructor for LdapBaseService.
	 * @param anchorService
	 * @throws ServiceInitException
	 */
	public LdapBaseService(LdapBaseService anchorService) throws ServiceInitException {
		super(anchorService);
	}

	/**
	 * @see org.LexGrid.managedobj.jndiJndiDirService#attrs2obj(Attributes)
	 */
	public ManagedObjIF attrs2obj(Attributes attrs) throws NamingException {
		Attribute classAttr = attrs.get(SchemaDef.ATTR_objectClass);
		ManagedObjIF obj =
			(classAttr != null)
				? newInstance((String[]) attr2list(classAttr).toArray(new String[0]))
				: newInstance();
		attrs2obj(obj, attrs);
		return obj;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.jndiJndiBaseService#checkInContext(javax.naming.Context)
	 */
	public void checkInContext(Context ctx) {
		try {
			if (ctx instanceof LdapContext)
				((LdapContext) ctx).setRequestControls(null);
		} catch (NamingException e) {
			try {
				getContextPool().invalidateObject(ctx);
			} catch (Exception e1) {
			}
		}
		super.checkInContext(ctx);
	}

	/**
	 * Borrows a context from the pool, cast as a LdapContext.
	 * @return LdapContext
	 * @throws NamingException
	 */
	public LdapContext checkOutLdapContext() throws NamingException {
		return (LdapContext) checkOutContext();
	}

	/* (non-Javadoc)
	 * @see org.org.LexGrid.commons.managedobj.service.BaseService#closePrim()
	 */
	public void closePrim() {
		try {
			super.closePrim();
		} finally {
			_configFile = null;
		}
	}

	/**
	 * @see org.LexGrid.managedobj.jndiJndiDirService#dcResolveAll(String,
	 * Attributes)
	 */
	public ManagedObjIterator dcResolveAll(String rdn, Attributes matchingAttrs) throws NamingException {
		ManagedObjIterator it = null;

		// Define search criteria ...
		Attributes crit =
			matchingAttrs == null ? new BasicAttributes() : (Attributes) matchingAttrs.clone();
		crit.put(newMultiValAttr(SchemaDef.ATTR_objectClass, getResolveClasses()));

		// Perform the search...
		LdapContext ctx = checkOutLdapContext();
		try {
			it =
				new LdapManagedObjIterator(
					this,
					ctx.search(qualifyRdn(rdn), crit, getResolveAttrs()),
					ctx);
		} finally {
			// Note: If instantiated successfully, context check-in is 
			// handled by the iterator...
			if (it == null)
				checkInContext(ctx);
		}
		return it;
	}

	/**
	 * @see org.LexGrid.managedobj.jndiJndiDirService#dcResolveAll(String,
	 * String, Object[], SearchControls)
	 */
	public ManagedObjIterator dcResolveAll(
		String rdn,
		String filterExpr,
		Object[] filterArgs,
		SearchControls sc)
		throws NamingException {
		ManagedObjIterator it = null;

		// Return only entries comprising objects managed by this service...
		StringBuffer sb = new StringBuffer(256);
		sb.append("(|(");
		String[] classes = getResolveClasses();
		for (int i = 0; i < classes.length; i++)
			sb.append("(objectClass=").append(classes[i]).append(')');
		sb.append("))");

		// Add the specified filter (if provided) ...
		String searchExpr =
			filterExpr == null ? sb.toString() : "(&(" + sb.toString() + '(' + filterExpr + ")))";

		// Perform the search...
		LdapContext ctx = checkOutLdapContext();
		try {
			it =
				new LdapManagedObjIterator(
					this,
					ctx.search(qualifyRdn(rdn), searchExpr, filterArgs, sc),
					ctx);
		} finally {
			// Note: If instantiated successfully, context check-in is 
			// handled by the iterator...
			if (it == null)
				checkInContext(ctx);
		}
		return it;
	}

	/**
	 * Returns the file defining the service configuration.
	 * @return File
	 */
	protected File getConfigFile() {
		return _configFile;
	}

	/**
	 * @see org.LexGrid.managedobj.jndiJndiDirService#getManagedAttrs()
	 */
	public List getManagedAttrs() {
		List attrs = super.getManagedAttrs();
		attrs.add(SchemaDef.ATTR_objectClass);
		return attrs;
	}

	/**
	 * @see org.LexGrid.managedobj.jndiJndiDirService#getResolveAttrs()
	 */
	public String[] getResolveAttrs() {
		if (_rAttrs == null) {
			// Start with immediately managed attributes...
			Set attrs = new HashSet();
			attrs.addAll(getManagedAttrs());

			// Add those required by nested services handling
			// subclass resolution...
			List mClass = getManagedClasses();
			Iterator nested = getNestedServices().iterator();
			LdapBaseService ls;
			while (nested.hasNext()) {
				ls = (LdapBaseService) nested.next();
				if (ls.getManagedClasses().containsAll(mClass)) {
					String[] subAttrs = ls.getResolveAttrs();
					CollectionUtils.addAll(attrs,
						subAttrs != null ? subAttrs
							: ls.getManagedAttrs().toArray());
				}
			}
			if (!attrs.isEmpty())
				Arrays.sort(_rAttrs = (String[]) attrs.toArray(new String[attrs.size()]));
		}
		return _rAttrs;
	}

	/**
	 * Returns an unordered list of LDAP object classes used to represent
	 * managed instances; without concern for nested services.
	 * @return List
	 */
	public List getManagedClasses() {
		return new ArrayList();
	}

	/**
	 * Returns the minimum sorted array of LDAP classes that an entry must be
	 * assigned to be recognized by this service.
	 * <p> 
	 * Subclasses should typically not override this method, but rather override
	 * the getManagedClasses() method to affect the value. This method sorts and
	 * caches the value for consumption.
	 * @return String[]
	 */
	public String[] getResolveClasses() {
		if (_rClass == null)
			Arrays.sort(_rClass = (String[]) getManagedClasses().toArray(new String[0]));
		return _rClass;
	}

	/**
	 * Initializes the service.
	 * @throws ServiceInitException
	 */
	protected void init() throws ServiceInitException {
		// Alter based on settings in the xml file
		File configFile = getConfigFile();
		if (configFile != null)
			try {
				// Open and parse the config file...
				SAXBuilder builder = new SAXBuilder();
				Document doc = builder.build(getConfigFile());
				Element ldapConfig =
					doc.getRootElement().getChild("ldap-connection-descriptor");
				// Define environment properties for pooled contexts
				Hashtable env = getContextDescriptor().getEnvironment();
				// Allow other providers, but assume a default if not specified
				String factory = ldapConfig.getAttributeValue("factory");
				env.put(
					Context.INITIAL_CONTEXT_FACTORY,
					(factory != null && factory.length() > 0) ? factory : DEFAULT_FACTORY);
				// Set the provider URL
				env.put(Context.PROVIDER_URL, ldapConfig.getAttributeValue("url"));
				// Set authentication info; default to anonymous if not provided
				String uid = ldapConfig.getAttributeValue("username");
				env.put(Context.SECURITY_PRINCIPAL, uid != null ? uid : "");
				String pwd = ldapConfig.getAttributeValue("password");
				env.put(Context.SECURITY_CREDENTIALS, pwd != null ? pwd : "");
				// Note: Above settings are well-known; we allow for simplified
				// XML notation as a convenience (no need to know qualified env name).
				// However, there are many other potential settings recognized by
				// JNDI of a specific provider. To accomodate, we allow for
				// generic property settings using qualified name/value pairs.
				Element envProps = ldapConfig.getChild("environment-properties");
				if (envProps != null) {
					Iterator props = envProps.getChildren().iterator();
					Element prop;
					while (props.hasNext()) {
						prop = (Element) props.next();
						env.put(
							prop.getAttributeValue("name"),
							prop.getAttributeValue("value"));
					}
				}
				// Override pool policy with any settings
				// provided in the external config file ...
				Element cp = ldapConfig.getChild("connection-pool");
				if (cp != null) {
					JndiContextPoolPolicy pol = getContextPoolPolicy();
					String val;
					if ((val = cp.getAttributeValue("maxActive")) != null)
						try {
							pol.maxActive = Integer.parseInt(val);
						} catch (RuntimeException e1) {
							e1.printStackTrace();
						}
					if ((val = cp.getAttributeValue("maxIdle")) != null)
						try {
							pol.maxIdle = Integer.parseInt(val);
						} catch (RuntimeException e1) {
							e1.printStackTrace();
						}
					if ((val = cp.getAttributeValue("maxWait")) != null)
						try {
							pol.maxWait = Integer.parseInt(val);
						} catch (RuntimeException e1) {
							e1.printStackTrace();
						}
					if ((val = cp.getAttributeValue("minEvictableIdleTimeMillis")) != null)
						try {
							pol.minEvictableIdleTimeMillis = Integer.parseInt(val);
						} catch (RuntimeException e1) {
							e1.printStackTrace();
						}
					if ((val = cp.getAttributeValue("numTestsPerEvictionRun")) != null)
						try {
							pol.numTestsPerEvictionRun = Integer.parseInt(val);
						} catch (RuntimeException e1) {
							e1.printStackTrace();
						}
					if ((val = cp.getAttributeValue("testOnBorrow")) != null)
						try {
							pol.testOnBorrow = val.equalsIgnoreCase("true");
						} catch (RuntimeException e1) {
							e1.printStackTrace();
						}
					if ((val = cp.getAttributeValue("testOnReturn")) != null)
						try {
							pol.testOnReturn = val.equalsIgnoreCase("true");
						} catch (RuntimeException e1) {
							e1.printStackTrace();
						}
					if ((val = cp.getAttributeValue("testWhileIdle")) != null)
						try {
							pol.testWhileIdle = val.equalsIgnoreCase("true");
						} catch (RuntimeException e1) {
							e1.printStackTrace();
						}
					if ((val = cp.getAttributeValue("timeBetweenEvictionRunsMillis")) != null)
						try {
							pol.timeBetweenEvictionRunsMillis = Integer.parseInt(val);
						} catch (RuntimeException e1) {
							e1.printStackTrace();
						}
					if ((val = cp.getAttributeValue("whenExhaustedAction")) != null)
						try {
							pol.whenExhaustedAction = Byte.parseByte(val);
						} catch (RuntimeException e1) {
							e1.printStackTrace();
						}
				}
			} catch (Exception e) {
				throw new ServiceInitException(e);
			}
		// Pick up any global init...
		super.init();
	}

	/**
	 * Returns a new/default JNDI context definition.
	 * @return JndiContextDescriptor
	 */
	protected JndiContextDescriptor newContextDescriptor() {
		return new LdapContextDescriptor();
	}

	/**
	 * Returns a new pool to manage JNDI context objects.
	 * @return JndiContextPool
	 */
	protected JndiContextPool newContextPool() {
		return new LdapContextPool(
			new LdapContextFactory(getContextDescriptor()),
			getContextPoolPolicy());
	}

	/**
	 * Returns a new policy to manage the context pool.
	 * @return JndiContextPoolPolicy
	 */
	protected JndiContextPoolPolicy newContextPoolPolicy() {
		return new LdapContextPoolPolicy();
	}

	/**
	 * Returns a new instance, allowing fine-grained typing based on the
	 * given array of LDAP-defined object classes.
	 * <p>
	 * The superclass will default to the generic newInstance() method, which
	 * will return a new instance based on the primary instance class.
	 * @param ldapClass String[]
	 * @return ManagedObjIF
	 */
	protected ManagedObjIF newInstance(String[] ldapClass) {
		// Use a finer-grain service, if registered & applicable...
		return serviceFor(ldapClass).newInstance();
	}

	/**
	 * Returns LDAP attributes applicable to the given object.
	 * @param obj
	 * @return Attributes
	 */
	public Attributes obj2attrs(ManagedObjIF obj) {
		Attributes attrs = new BasicAttributes();
		attrs.put(newMultiValAttr(SchemaDef.ATTR_objectClass, obj2classes(obj)));
		return attrs;
	}
	
	/**
	 * Returns the array of strings representing ldap classes
	 * associated with the given object. 
	 * <p>
	 * By default, fall back to the minimum set of classes resolved
	 * by this service.  Subclasses can override as appropriate to
	 * tune the objectClass attribute written by the obj2attrs method.
	 * @param obj
	 * @return String[]
	 */
	protected String[] obj2classes(ManagedObjIF obj) {
		return getResolveClasses();
	}

	/**
	 * Returns the service best suited to resolve objects based on class
	 * information in the given Attributes object.
	 * <p>
	 * If the immediate service is not an exact match, nested services are
	 * checked. If an exact match is found, that service is returned. Otherwise,
	 * the immediate service is returned.
	 * @param attrs Attributes
	 * @return JndiDirService
	 * @throws NamingException
	 */
	protected JndiDirService serviceFor(Attributes attrs) throws NamingException {
		// Use a finer-grain service, if registered & applicable...
		Attribute classAttr = attrs.get(SchemaDef.ATTR_objectClass);
		if (classAttr != null) {
			List classList = new ArrayList();
			CollectionUtils.addAll(classList, classAttr.getAll());
			return serviceFor((String[]) classList.toArray(new String[classList.size()]));
		}
		return this;
	}

	/**
	 * Returns the service best suited to resolve objects assigned to
	 * the given LDAP-defined classes.
	 * <p>
	 * If the immediate service is not an exact match, all registered
	 * services (nested and top-level) are checked. If an exact match is found,
	 * that service is returned. Otherwise, the immediate service is returned.
	 * @param ldapClass String[]
	 * @return LdapBaseService
	 */
	protected LdapBaseService serviceFor(String[] ldapClass) {
		LdapBaseService service = null;

		Arrays.sort(ldapClass);
		if (!Arrays.equals(ldapClass, getResolveClasses()))
			if ((service = serviceFor(ldapClass, getNestedServices())) == null)
				service = serviceFor(ldapClass, getBroker().getServices());
		return service == null ? this : service;
	}
	
	private LdapBaseService serviceFor(String[] ldapClass, Collection candidates) {
		for (Iterator it = candidates.iterator(); it.hasNext(); ) {
			LdapBaseService bs = (LdapBaseService) it.next();
			if (Arrays.equals(ldapClass, bs.getResolveClasses())) {
				(bs).setContextEntryPoint(getContextEntryPoint());
				return bs;
			}
		}
		return null;
	}

	/**
	 * Sets the file defining the service configuration.
	 * <p>
	 * Note: Must be set prior to initialization in order to be
	 * recognized by the service.
	 * @return File
	 */
	protected void setConfigFile(File f) {
		_configFile = f;
	}

}