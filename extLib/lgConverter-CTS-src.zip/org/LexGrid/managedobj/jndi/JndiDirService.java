/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.managedobj.jndi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.naming.ContextNotEmptyException;
import javax.naming.NameAlreadyBoundException;
import javax.naming.NameClassPair;
import javax.naming.NameNotFoundException;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.LexGrid.managedobj.FindException;
import org.LexGrid.managedobj.HomeServiceBroker;
import org.LexGrid.managedobj.InsertException;
import org.LexGrid.managedobj.ManagedObjIF;
import org.LexGrid.managedobj.ManagedObjIterator;
import org.LexGrid.managedobj.ObjectAlreadyExistsException;
import org.LexGrid.managedobj.ObjectNotFoundException;
import org.LexGrid.managedobj.QueryException;
import org.LexGrid.managedobj.RemoveException;
import org.LexGrid.managedobj.ServiceInitException;
import org.LexGrid.managedobj.UnexpectedException;
import org.LexGrid.managedobj.UpdateException;
import org.apache.commons.collections.IteratorUtils;

/**
 * Abstract superclass for directory-based JNDI services.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public abstract class JndiDirService
	extends JndiBaseService
	implements JndiDirSearchIteratorHelper {

	// Attributes required by the service when resolving managed instances
	private String[] _rAttrs = null;

	/**
	 * Constructor for JndiDirService.
	 */
	protected JndiDirService() {
		super();
	}

	/**
	 * Constructor for JndiDirService.
	 * @param broker
	 * @throws ServiceInitException
	 */
	public JndiDirService(HomeServiceBroker broker)
		throws ServiceInitException {
		super(broker);
	}

	/**
	 * Constructor for JndiDirService.
	 * @param anchorService
	 * @throws ServiceInitException
	 */
	public JndiDirService(JndiBaseService anchorService)
		throws ServiceInitException {
		super(anchorService);
	}

	/**
	 * Converts the values in an Attribute object to a list.
	 * @param attr
	 * @return List
	 * @throws NamingException
	 */
	protected List attr2list(Attribute attr) throws NamingException {
		List l = new ArrayList();
		NamingEnumeration ne = attr.getAll();
		while (ne.hasMore())
			l.add(ne.next());
		return l;
	}

	/**
	 * Returns a new instance based on the given attributes.
	 * <p>
	 * Superclass implementation just instantiates a new instance and passes
	 * it to the <i>attrs2obj(ManagedObjIF, Attributes)</i> method to populate it.
	 * It is the responsibility of each subclass to override one or both of
	 * the <i>attrs2obj</i> methods to populate known attributes.
	 * @param attrs Attributes
	 * @return ManagedObjIF
	 * @throws NamingException
	 */
	public ManagedObjIF attrs2obj(Attributes attrs) throws NamingException {
		ManagedObjIF obj = newInstance();
		attrs2obj(obj, attrs);
		return obj;
	}

	/**
	 * Populates a new instance based on the given attributes.
	 * <p>
	 * Invoked by the default implementation of the <i>attrs2obj(Attributes)</i> method.
	 * The superclass implementation does nothing; subclasses should override as appropriate.
	 * @param obj ManagedObjIF
	 * @param attrs Attributes
	 * @throws NamingException
	 */
	protected void attrs2obj(ManagedObjIF obj, Attributes attrs) throws NamingException {
	}

	/**
	 * Converts a boolean (primitive) value to a String counterpart
	 * suitable for use in attribute values.
	 * @param b
	 * @return String
	 */
	protected String bool2str(boolean b) {
		return b ? "TRUE" : "FALSE";
	}

	/**
	 * Converts a Boolean (object) value to a String counterpart
	 * suitable for use in attribute values.
	 * @param b
	 * @return String
	 */
	protected String bool2str(Boolean b) {
		if (b == null)
		{
			return null;
		}
		else
		{
			return bool2str(b.booleanValue());
		}
	}

	/**
	 * Borrows a context from the pool, cast as a DirContext.
	 * @return DirContext
	 * @throws NamingException
	 */
	public DirContext checkOutDirContext() throws NamingException {
		return (DirContext) checkOutContext();
	}

	/**
	 * Locates an entry relative to the configured context and adds
	 * the given attributes.
	 * @param rdn Relative distinguished name of the target entry.
	 * @param attrs
	 * @throws NamingException
	 */
	public void dcAddAttributes(String rdn, Attributes attrs)
		throws NamingException {
		DirContext ctx = checkOutDirContext();
		try {
			ctx.modifyAttributes(
				qualifyRdn(rdn),
				DirContext.ADD_ATTRIBUTE,
				attrs);
		} finally {
			checkInContext(ctx);
		}
	}

	/**
	 * Creates a new entry relative to the configured context.
	 * @param rdn Relative distinguished name of the target entry.
	 * @param attrs Attributes to assign; null to create only the target entry.
	 * @throws NamingException
	 */
	public void dcCreateEntry(String rdn, Attributes attrs)
		throws NamingException {
		dcCreateEntryAbsolute(qualifyRdn(rdn), attrs);
	}

	/**
	 * Creates a new entry for the given location.
	 * @param dn Distinguished name of the target entry.
	 * @param attrs Attributes to assign; null to create only the target entry.
	 * @throws NamingException
	 */
	public void dcCreateEntryAbsolute(String dn, Attributes attrs)
		throws NamingException {
		DirContext ctx = checkOutDirContext();
		try {
			if (attrs == null)
				dcCreateEntryAbsolute(dn);
			else
				ctx.createSubcontext(dn, attrs);
		} finally {
			checkInContext(ctx);
		}
	}

	/**
	 * Locates an entry relative to the configured context and returns
	 * the requested attributes.
	 * @param rdn Relative distinguished name of the target entry.
	 * @param attrNames Attributes to return; null to return all attributes.
	 * @return Attributes
	 * @throws NamingException
	 */
	public Attributes dcGetAttributes(String rdn, String[] attrNames)
		throws NamingException {
		Attributes attrs = null;
		DirContext ctx = checkOutDirContext();
		try {
			// Fetch the attributes in JNDI format ...
			if (attrNames == null)
				attrs = ctx.getAttributes(qualifyRdn(rdn));
			else
				attrs = ctx.getAttributes(qualifyRdn(rdn), attrNames);
		} finally {
			checkInContext(ctx);
		}
		return attrs;
	}

	/**
	 * Locates an entry relative to the configured context and removes
	 * the given attributes.
	 * @param rdn Relative distinguished name of the target entry.
	 * @param attrs
	 * @throws NamingException
	 */
	public void dcRemoveAttributes(String rdn, Attributes attrs)
		throws NamingException {
		DirContext ctx = checkOutDirContext();
		try {
			ctx.modifyAttributes(
				qualifyRdn(rdn),
				DirContext.REMOVE_ATTRIBUTE,
				attrs);
		} finally {
			checkInContext(ctx);
		}
	}

	/**
	 * Removes an entry relative to the configured context, and all children.
	 * @param rdn Relative distinguished name of the root entry.
	 * @throws NamingException
	 */
	public void dcRemoveTree(String rdn) throws NamingException {
		DirContext ctx = checkOutDirContext();
		try {
			dcRemoveTreePrim(rdn, ctx);
		} finally {
			checkInContext(ctx);
		}
	}

	/**
	 * Primitive method to perform recursive delete of an entry.
	 * @param rdn Relative distinguished name of the root entry.
	 * @param ctx The directory context to use.
	 * @throws NamingException
	 */
	protected void dcRemoveTreePrim(String rdn, DirContext ctx) throws NamingException {
		String rootQdn = qualifyRdn(rdn);
		NamingEnumeration ne = ctx.list(rootQdn);
		while (ne.hasMore()) {
			String subQdn = new StringBuffer(128)
				.append(((NameClassPair) ne.next()).getName()).append(',').append(rdn)
				.toString();
			// Delete child, recurse if necessary ...
			try {
				ctx.destroySubcontext(subQdn);
			} catch (ContextNotEmptyException e) {
				dcRemoveTreePrim(subQdn, ctx);
			}
		}
		// Delete the root entry
		ctx.destroySubcontext(rootQdn);
	}

	/**
	 * Locates an entry relative to the configured context and replaces
	 * the given attributes.
	 * @param rdn Relative distinguished name of the target entry.
	 * @param attrs
	 * @throws NamingException
	 */
	public void dcReplaceAttributes(String rdn, Attributes attrs)
		throws NamingException {
		DirContext ctx = checkOutDirContext();
		try {
			ctx.modifyAttributes(
				qualifyRdn(rdn),
				DirContext.REPLACE_ATTRIBUTE,
				attrs);
		} finally {
			checkInContext(ctx);
		}
	}

	/**
	 * Returns an object restored from information in an entry
	 * relative to the configured context.
	 * @param rdn Relative distinguished name of the target entry.
	 * @return ManagedObjIF
	 * @throws NamingException
	 */
	public ManagedObjIF dcResolve(String rdn) throws NamingException {
		// Use a finer-grain service, if registered & applicable...
		Attributes attrs = dcGetAttributes(rdn, getResolveAttrs());
		JndiDirService handler = serviceFor(attrs);
		ManagedObjIF obj = handler.attrs2obj(attrs);
		handler.postResolve(obj);
		return obj;
	}

	/**
	 * Returns an iterator over managed objects immediately contained as children
	 * of the given relative entry. If specified, returned objects must also meet
	 * requirements set forth by the provided attributes.
	 * @param rdn Relative distinguished name of the parent entry to search.
	 * @param matchingAttrs Additional attributes that must be matched
	 * in order for an object to be included in the returned list;
	 * null if not applicable.
	 * @return ManagedObjIterator
	 * @throws NamingException
	 */
	public ManagedObjIterator dcResolveAll(String rdn, Attributes matchingAttrs)
		throws NamingException {
		ManagedObjIterator it = null;

		// Define search criteria ...
		Attributes crit =
			matchingAttrs == null
				? new BasicAttributes()
				: (Attributes) matchingAttrs.clone();

		// Perform the search...
		DirContext ctx = checkOutDirContext();
		try {
			it =
				new JndiDirSearchIterator(
					this,
					ctx.search(qualifyRdn(rdn), crit, getResolveAttrs()),
					ctx);
		} catch (Exception e) {
			if (e instanceof NamingException)
				throw (NamingException) e;
			throw new UnexpectedException(e);
		} finally {
			// Note: If instantiated successfully, context check-in is 
			// handled by the iterator...
			if (it == null)
				checkInContext(ctx);
		}
		return it;
	}

	/**
	 * Returns an iterator over managed objects. If specified, returned objects
	 * must also meet requirements set forth by the filter criteria.
	 * @param rdn Relative distinguished name of the parent entry to search
	 * @param filterExpr The filter expression
	 * @param filterArgs Optional arguments substituted for {n} in the expression
	 * @return ManagedObjIterator
	 * @throws NamingException
	 */
	public ManagedObjIterator dcResolveAll(
		String rdn,
		String filterExpr,
		Object[] filterArgs)
		throws NamingException {

		// Default search controls ...
		SearchControls sc = new SearchControls();
		sc.setDerefLinkFlag(false);
		sc.setReturningObjFlag(false);
		sc.setReturningAttributes(getResolveAttrs());
		sc.setSearchScope(SearchControls.ONELEVEL_SCOPE);
		
		return dcResolveAll(rdn, filterExpr, filterArgs, sc);
	}

	/**
	 * Returns an iterator over managed objects. If specified, returned objects
	 * must also meet requirements set forth by the filter criteria.
	 * @param rdn Relative distinguished name of the parent entry to search
	 * @param filterExpr The filter expression
	 * @param filterArgs Optional arguments substituted for {n} in the expression
	 * @param sc Search controls
	 * @return ManagedObjIterator
	 * @throws NamingException
	 */
	public ManagedObjIterator dcResolveAll(
		String rdn,
		String filterExpr,
		Object[] filterArgs,
		SearchControls sc)
		throws NamingException {
		ManagedObjIterator it = null;

		// Perform the search...
		DirContext ctx = checkOutDirContext();
		try {
			it =
				new JndiDirSearchIterator(
					this,
					ctx.search(qualifyRdn(rdn), filterExpr, filterArgs, sc),
					ctx);
		} finally {
			// Note: If instantiated successfully, context check-in is 
			// handled by the iterator...
			if (it == null)
				checkInContext(ctx);
		}
		return it;
	}

	/**
	 * Returns a list of managed objects immediately contained as children
	 * of the given relative entry. If specified, returned objects must also meet
	 * requirements set forth by the provided attributes.
	 * @param rdn Relative distinguished name of the parent entry to search.
	 * @param matchingAttrs Additional attributes that must be matched
	 * in order for an object to be included in the returned list;
	 * null if not applicable.
	 * @return List
	 * @throws NamingException
	 */
	public List dcResolveAllToList(String rdn, Attributes matchingAttrs) throws NamingException {
		List items = null;
		ManagedObjIterator it = null;
		try {
			it = dcResolveAll(rdn, matchingAttrs);
			items = IteratorUtils.toList(it);
		} finally {
			if (it != null)
				it.close();
		}
		return items;
	}
	
	/**
	 * Returns a list of managed objects. If specified, returned objects
	 * must also meet requirements set forth by the filter criteria.
	 * @param rdn Relative distinguished name of the parent entry to search
	 * @param filterExpr The filter expression
	 * @param filterArgs Optional arguments substituted for {n} in the expression
	 * @return List
	 * @throws NamingException
	 */
	public List dcResolveAllToList(
		String rdn,
		String filterExpr,
		Object[] filterArgs)
		throws NamingException {
		List items = null;
		ManagedObjIterator it = null;
		try {
			it = dcResolveAll(rdn, filterExpr, filterArgs);
			items = IteratorUtils.toList(it);
		} finally {
			if (it != null)
				it.close();
		}
		return items;
	}
	
	/**
	 * Returns a list of managed objects. If specified, returned objects
	 * must also meet requirements set forth by the filter criteria.
	 * @param rdn Relative distinguished name of the parent entry to search
	 * @param filterExpr The filter expression
	 * @param filterArgs Optional arguments substituted for {n} in the expression
	 * @param sc Search controls
	 * @return List
	 * @throws NamingException
	 */
	public List dcResolveAllToList(
		String rdn,
		String filterExpr,
		Object[] filterArgs,
		SearchControls sc)
		throws NamingException {
		List items = null;
		ManagedObjIterator it = null;
		try {
			it = dcResolveAll(rdn, filterExpr, filterArgs, sc);
			items = IteratorUtils.toList(it);
		} finally {
			if (it != null)
				it.close();
		}
		return items;
	}
		
	/**
	 * Returns the first contained item to be resolved based on the current
	 * service configuration; null if not available.
	 * @return ManagedObjIF
	 * @throws NamingException
	 */
	public ManagedObjIF dcResolveFirst() throws NamingException {
		ManagedObjIF obj = null;
		Iterator it = null;
		try {
			if ((it = dcResolveAll("", null)).hasNext())
				obj = (ManagedObjIF) it.next();
		} finally {
			if (it instanceof ManagedObjIterator)
				 ((ManagedObjIterator) it).close();
		}
		return obj;
	}

	/**
	 * Returns the object with the given primary key without concern for the
	 * locally maintained cache.
	 * <p>
	 * This method is invoked when the object is not found in the local cache.
	 * @param key
	 * @return ManagedObjIF
	 * @throws FindException
	 */
	protected ManagedObjIF findByPrimaryKeyPrim(Object key)
		throws FindException {
		ManagedObjIF obj = null;
		try {
			obj = dcResolve(primaryKey2rdn(key));
		} catch (NameNotFoundException e) {
			throw new ObjectNotFoundException(e);
		} catch (NamingException e) {
			throw new FindException(e);
		}
		return obj;
	}

	/**
	 * Returns the object with the given secondary key without concern for the
	 * locally maintained cache.
	 * <p>
	 * This method is invoked when the object is not found in the local cache.
	 * <p>
	 * Since queries based on the secondary key are specific to the object
	 * being found, the default superclass implementation throws a
	 * ServiceUnavailableException.
	 * @param key
	 * @return ManagedObjIF
	 * @throws FindException
	 */
	protected ManagedObjIF findBySecondaryKeyPrim(Object key)
		throws FindException {
		ManagedObjIF obj = null;
		try {
			obj = dcResolve(secondaryKey2rdn(key));
		} catch (NameNotFoundException e) {
			throw new ObjectNotFoundException(e);
		} catch (NamingException e) {
			throw new FindException(e);
		}
		return obj;
	}

	/**
	 * Returns an unordered list of JNDI attribute names used to represent
	 * managed instances, without concern for nested services.
	 * @return List
	 */
	public List getManagedAttrs() {
		return new ArrayList();
	}

	/**
	 * Returns a sorted array of JNDI attribute names required to initialize
	 * managed instances, with concern for nested services.
	 * <p>
	 * Subclasses should not typically need to override this method, but rather
	 * override the <i>getManagedAttrs()</i> method to affect the value. This method
	 * sorts, combines, and caches the value for consumption.
	 * @return The array of attribute names; null to indicate that all
	 * attributes should be retrieved for purposes of object resolution.
	 */
	public String[] getResolveAttrs() {
		if (_rAttrs == null) {
			Set attrs = new HashSet();
			attrs.addAll(getManagedAttrs());
			if (!attrs.isEmpty())
				Arrays.sort(
					_rAttrs =
						(String[]) attrs.toArray(new String[attrs.size()]));
		}
		return _rAttrs;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.HomeServiceIF#insert(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public final void insert(ManagedObjIF obj)
		throws InsertException, ObjectAlreadyExistsException {
		// Delegate to a finer-grain service, if registered & applicable...
		JndiDirService jds = (JndiDirService) serviceFor(obj.getClass());
		if (jds != this)
			jds.setContextEntryPoint(getContextEntryPoint());
		jds.insertPrim(obj);
		// Cache it here (at level where action took place) ...
		addToCache(obj);
	}

	/**
	 * Primitive method to perform the insert operation.
	 * @param obj
	 * @throws InsertException
	 * @throws ObjectAlreadyExistsException
	 */
	protected void insertPrim(ManagedObjIF obj)
		throws InsertException, ObjectAlreadyExistsException {
		try {
			dcCreateEntry(obj2rdn(obj), primeAttrs(obj));
		} catch (NameAlreadyBoundException e) {
			throw new ObjectAlreadyExistsException(e);
		} catch (NamingException e) {
			throw new InsertException(e);
		}
	}

	/**
	 * Returns a new pool to manage JNDI context objects.
	 * @return JndiContextPool
	 */
	protected JndiContextPool newContextPool() {
		return new JndiContextPool(
			new JndiDirContextFactory(getContextDescriptor()),
			getContextPoolPolicy());
	}

	/**
	 * Returns a new multi-valued attribute created from the given ID
	 * and list of values. The toString() form of each value is added
	 * to the attribute values.
	 * @param id
	 * @param vals
	 * @return Attribute
	 */
	protected Attribute newMultiValAttr(String id, List vals) {
		Attribute attr = new BasicAttribute(id);
		if (!vals.isEmpty())
			for (Iterator it = vals.iterator(); it.hasNext(); )
				attr.add(it.next().toString());
		return attr;
	}

	/**
	 * Returns a new multi-valued attribute created from the given ID
	 * and array of values. The toString() form of each value is added to the
	 * attribute values.
	 * @param id
	 * @param vals
	 * @return Attribute
	 */
	protected Attribute newMultiValAttr(String id, Object[] vals) {
		Attribute attr = new BasicAttribute(id);
		if (vals.length > 0)
			for (int i = 0; i < vals.length; i++)
				attr.add(vals[i].toString());
		return attr;
	}

	/**
	 * Returns JNDI attributes applicable to the given object.
	 * @param obj
	 * @return Attributes
	 */
	public Attributes obj2attrs(ManagedObjIF obj) {
		return new BasicAttributes();
	}

	/**
	 * Extension point for subclasses to take action immediately after
	 * the given object is recreated from persistent attributes.
	 * @param obj
	 * @throws NamingException
	 */
	public void postResolve(ManagedObjIF obj)
		throws NamingException { // Do nothing in superclass
	}

	/**
	 * Returns attribute definitions for insertion of the given
	 * object (i.e. drop empty attributes).
	 * @param ManagedObjIF obj
	 * @return Attributes
	 * @throws NamingException
	 */
	protected Attributes primeAttrs(ManagedObjIF obj) throws NamingException {
		Attributes attrs = obj2attrs(obj);
		Attributes pAttrs = new BasicAttributes();
		if (attrs != null)
			for (NamingEnumeration ne = attrs.getAll(); ne.hasMore(); ) {
				Attribute attr = (Attribute) ne.next();
				Attribute pAttr = new BasicAttribute(attr.getID());
				if (attr.size() > 0) {
					for (NamingEnumeration vals = attr.getAll(); vals.hasMore(); ) {
						Object val = vals.next();
						if (val != null && val.toString().length() != 0)
							pAttr.add(val);
					}
				}
				if (pAttr.size() > 0)
					pAttrs.put(pAttr);
			}
		return pAttrs;
	}

	/**
	 * Return an iterator overall all objects administered by
	 * the service (object scope).
	 * @return ManagedObjIterator
	 * @throws QueryException
	 */
	public ManagedObjIterator query() throws QueryException {
		ManagedObjIterator it = null;
		try {
			it = dcResolveAll("", null);
		} catch (NamingException e) {
			throw new QueryException(e);
		}
		return it;
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.HomeServiceIF#remove(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public final void remove(ManagedObjIF obj)
		throws RemoveException, ObjectNotFoundException {
		// Remove from the cache (at level where action took place) ...
		removeFromCache(obj);
		// Delegate to a finer-grain service, if registered & applicable...
		JndiDirService jds = (JndiDirService) serviceFor(obj.getClass());
		if (jds != this)
			jds.setContextEntryPoint(getContextEntryPoint());
		jds.removePrim(obj);
	}

	/**
	 * Primitive method to perform the remove operation.
	 * @param obj
	 * @throws RemoveException
	 * @throws ObjectNotFoundException
	 */
	protected void removePrim(ManagedObjIF obj)
		throws RemoveException, ObjectNotFoundException {
		try {
			dcRemoveTree(obj2rdn(obj));
		} catch (NameNotFoundException e) {
			throw new ObjectNotFoundException(e);
		} catch (NamingException e) {
			throw new RemoveException(e);
		}
	}

	/**
	 * Removes all objects administered by the service.
	 * @throws RemoveException
	 */
	public void removeAll() throws RemoveException {
		ManagedObjIterator it = null;
		try {
			for (it = query(); it.hasNext(); )
				try { remove((ManagedObjIF) it.next()); }
					catch(ObjectNotFoundException onfe) { }
		} catch (QueryException e) {
			throw new RemoveException(e);
		} finally {
			if (it != null)
				it.close();
		}
	}

	/**
	 * @see org.LexGrid.managedobj.jndiJndiDirSearchIteratorHelper#result2obj(SearchResult)
	 */
	public ManagedObjIF result2obj(SearchResult sr) throws NamingException {
		// Use a finer-grain service, if registered & applicable...
		Attributes attrs = sr.getAttributes();
		JndiDirService handler = serviceFor(attrs);
		ManagedObjIF obj = handler.attrs2obj(attrs);
		handler.postResolve(obj);
		addToCache(obj);
		return obj;
	}

	/**
	 * Returns the service best suited to resolve objects based on class
	 * information in the given Attributes object.
	 * <p>
	 * Note: The superclass just returns the receiver. Subclasses may
	 * override as necessary to return an alternate or nested service
	 * as necessary.
	 * @param attrs Attributes
	 * @return JndiDirService
	 * @throws NamingException
	 */
	protected JndiDirService serviceFor(Attributes attrs)
		throws NamingException {
		return this;
	}

	/**
	 * Converts a string value to its boolean (primitive) counterpart.
	 * @param s
	 * @return boolean
	 */
	protected boolean str2bool(String s) {
		return str2Bool(s).booleanValue();
	}

	/**
	 * Converts a string value to its Boolean (object) counterpart.
	 * @param s
	 * @return boolean
	 */
	protected Boolean str2Bool(String s) {
		return Boolean.valueOf(s);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.HomeServiceIF#update(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public final void update(ManagedObjIF obj)
		throws UpdateException, ObjectNotFoundException {
		// Delegate to a finer-grain service, if registered & applicable...
		JndiDirService jds = (JndiDirService) serviceFor(obj.getClass());
		if (jds != this)
			jds.setContextEntryPoint(getContextEntryPoint());
		jds.updatePrim(obj);
	}

	/**
	 * Primitive method to perform the update operation.
	 * @param obj
	 * @throws UpdateException
	 * @throws ObjectNotFoundException
	 */
	protected void updatePrim(ManagedObjIF obj)
		throws UpdateException, ObjectNotFoundException {
			try {
				// Retrieve currently assigned attributes ...
				String rdn = obj2rdn(obj);
				Attributes oldAttrs = dcGetAttributes(rdn, null);

				// Determine base attributes for the object ...
				Attributes newAttrs = primeAttrs(obj);
				
				// Determine attributes to remove, add, and replace ...
				Attributes toRemove = new BasicAttributes();
				Attributes toAdd = new BasicAttributes();
				Attributes toReplace = new BasicAttributes();
				for (NamingEnumeration ne = oldAttrs.getAll(); ne.hasMore(); ) {
					Attribute oldAttr = (Attribute) ne.next();
					String oldID = oldAttr.getID();
					if (newAttrs.get(oldID) == null)
						toRemove.put(oldAttr);
				}
				for (NamingEnumeration ne = newAttrs.getAll(); ne.hasMore(); ) {
					Attribute newAttr = (Attribute) ne.next();
					String newID = newAttr.getID();
					Attribute oldAttr = oldAttrs.get(newID);
					if (oldAttr == null)
						toAdd.put(newAttr);
					else {
						boolean isEqual = oldAttr.size() == newAttr.size();
						for (int i = 0; isEqual && i < oldAttr.size(); i++)
							isEqual = oldAttr.get(i).equals(newAttr.get(i));
						if (!isEqual)
							toReplace.put(newAttr);
					}
				}
				
				// Perform the operations ...
				if (toRemove.size() > 0)
					dcRemoveAttributes(rdn, toRemove);
				if (toAdd.size() > 0)
					dcAddAttributes(rdn, toAdd);
				if (toReplace.size() > 0)
					dcReplaceAttributes(rdn, toReplace);
				
			} catch (NameNotFoundException e) {
				throw new ObjectNotFoundException(e);
			} catch (NamingException e) {
				throw new UpdateException(e);
			}
	}

}