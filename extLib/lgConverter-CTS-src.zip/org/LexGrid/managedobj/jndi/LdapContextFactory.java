/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.managedobj.jndi;

import javax.naming.NamingException;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;


/**
 * Handles lifecycle events for pooled LDAP context objects.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class LdapContextFactory extends JndiDirContextFactory {
	/**
	 * Constructor for LdapContextFactory.
	 */
	public LdapContextFactory(JndiContextDescriptor desc) {
		super(desc);
	}

	/**
	 * @see org.LexGrid.managedobj.jndiJndiContextFactory#getContextDescriptorPrim()
	 */
	protected JndiContextDescriptor getContextDescriptorPrim() {
		return new LdapContextDescriptor();
	}

	/**
	 * @see org.apache.commons.pool.PoolableObjectFactory#makeObject()
	 */
	public Object makeObject() throws Exception {
		LdapContextDescriptor desc =
			(LdapContextDescriptor) getContextDescriptor();
		LdapContext ctx =
			new LdapContextWrapper(
				new InitialLdapContext(
					desc.getEnvironment(),
					desc.getControls()));
		return ctx;
	}

	/**
	 * @see org.apache.commons.pool.PoolableObjectFactory#validateObject(java.lang.Object)
	 */
	public boolean validateObject(Object arg0) {
		LdapContext ctx = (LdapContext) arg0;
		try {
			ctx.getAttributes("", pingAttr);
			return true;
		} catch (NamingException e) {
			try {
				ctx.reconnect(
					((LdapContextDescriptor) getContextDescriptor())
						.getControls());
				return true;
			} catch (NamingException ne) {
			}
		}
		return false;
	}

}