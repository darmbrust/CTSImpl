/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.managedobj;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.beans.PropertyVetoException;
import java.beans.VetoableChangeListener;
import java.beans.VetoableChangeSupport;
import java.io.Serializable;

/**
 * Abstract superclass for objects whose lifecycle is managed via a
 * separate home context. The objects themselves are intended to be
 * lightweight and eliminate direct dependencies on services used
 * to persist and maintain the object (i.e. JDBC, etc).
 * <p>
 * The intent is for each managed object to be self standing and
 * in general unconcerned with how it is managed or stored. This
 * provides for a lightweight implementation, facilitates
 * network portability, etc.
 * 
 * @see Home
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public abstract class ManagedObj
	implements ManagedObjIF, ManagedObjListeneeIF, Serializable, Cloneable {

	// Transient flag
	private boolean _transient = false;
	// List of property change event bean listeners.
	private transient PropertyChangeSupport _propertyChangeListeners = null;
	// List of vetoable change event bean listeners.
	private transient VetoableChangeSupport _vetoableChangeListeners = null;

	/* (non-Javadoc)
	 * @see edu.mayo.mir.base.obj.ManagedObjIF#addPropertyChangeListener(java.beans.PropertyChangeListener)
	 */
	public void addPropertyChangeListener(PropertyChangeListener listener) {
		if (_propertyChangeListeners == null)
			_propertyChangeListeners = new PropertyChangeSupport(this);
		_propertyChangeListeners.addPropertyChangeListener(listener);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.ManagedObjListeneeIF#addPropertyChangeListener(java.beans.PropertyChangeListener, java.lang.String)
	 */
	public void addPropertyChangeListener(
		PropertyChangeListener listener,
		String propertyName) {
		if (_propertyChangeListeners == null)
			_propertyChangeListeners = new PropertyChangeSupport(this);
		_propertyChangeListeners.addPropertyChangeListener(propertyName, listener);
	}

	/* (non-Javadoc)
	 * @see edu.mayo.mir.base.obj.ManagedObjIF#addVetoableChangeListener(java.beans.VetoableChangeListener)
	 */
	public void addVetoableChangeListener(VetoableChangeListener listener) {
		if (_vetoableChangeListeners == null)
			_vetoableChangeListeners = new VetoableChangeSupport(this);
		_vetoableChangeListeners.addVetoableChangeListener(listener);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.ManagedObjListeneeIF#addVetoableChangeListener(java.beans.VetoableChangeListener, java.lang.String)
	 */
	public void addVetoableChangeListener(
		VetoableChangeListener listener,
		String propertyName) {
		if (_vetoableChangeListeners == null)
			_vetoableChangeListeners = new VetoableChangeSupport(this);
		_vetoableChangeListeners.addVetoableChangeListener(propertyName, listener);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#clone()
	 */
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object obj) {
		return obj != null
			&& getClass().equals(obj.getClass())
			&& getPrimaryKey().equals(((ManagedObj) obj).getPrimaryKey());
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.ManagedObjIF#getSecondaryKey()
	 */
	public Object getSecondaryKey() {
		return null;
	}

	/**
	 * Fires the given change event to any listeners.
	 * @param event
	 */
	protected void firePropertyChange(PropertyChangeEvent event) {
		if (_propertyChangeListeners != null)
			_propertyChangeListeners.firePropertyChange(event);
	}

	/**
	 * Fires the given change event to any listeners.
	 * @param propertyName
	 * @param oldVal
	 * @param newVal
	 */
	protected void firePropertyChange(String propertyName, boolean oldVal, boolean newVal) {
		if (_propertyChangeListeners != null)
			_propertyChangeListeners.firePropertyChange(propertyName, oldVal, newVal);
	}

	/**
	 * Fires the given change event to any listeners.
	 * @param propertyName
	 * @param oldVal
	 * @param newVal
	 */
	protected void firePropertyChange(String propertyName, int oldVal, int newVal) {
		if (_propertyChangeListeners != null)
			_propertyChangeListeners.firePropertyChange(propertyName, oldVal, newVal);
	}

	/**
	 * Fires the given change event to any listeners.
	 * @param propertyName
	 * @param oldVal
	 * @param newVal
	 */
	protected void firePropertyChange(String propertyName, Object oldVal, Object newVal) {
		if (_propertyChangeListeners != null)
			_propertyChangeListeners.firePropertyChange(propertyName, oldVal, newVal);
	}

	/**
	 * Fires the given vetoable event to any listeners.
	 * @param event
	 * @throws PropertyVetoException
	 */
	protected void fireVetoableChange(PropertyChangeEvent event) throws PropertyVetoException {
		if (_vetoableChangeListeners != null)
			_vetoableChangeListeners.fireVetoableChange(event);
	}

	/**
	 * Fires the given vetoable event to any listeners.
	 * @param propertyName
	 * @param oldVal
	 * @param newVal
	 * @throws PropertyVetoException
	 */
	protected void fireVetoableChange(String propertyName, boolean oldVal, boolean newVal)
		throws PropertyVetoException {
		if (_vetoableChangeListeners != null)
			_vetoableChangeListeners.fireVetoableChange(propertyName, oldVal, newVal);
	}

	/**
	 * Fires the given vetoable event to any listeners.
	 * @param propertyName
	 * @param oldVal
	 * @param newVal
	 * @throws PropertyVetoException
	 */
	protected void fireVetoableChange(String propertyName, int oldVal, int newVal)
		throws PropertyVetoException {
		if (_vetoableChangeListeners != null)
			_vetoableChangeListeners.fireVetoableChange(propertyName, oldVal, newVal);
	}

	/**
	 * Fires the given vetoable event to any listeners.
	 * @param propertyName
	 * @param oldVal
	 * @param newVal
	 * @throws PropertyVetoException
	 */
	protected void fireVetoableChange(String propertyName, Object oldVal, Object newVal)
		throws PropertyVetoException {
		if (_vetoableChangeListeners != null)
			_vetoableChangeListeners.fireVetoableChange(propertyName, oldVal, newVal);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.ManagedObjIF#isTransient()
	 */
	public boolean isTransient() {
		return _transient;
	}

	/* (non-Javadoc)
	 * @see edu.mayo.mir.base.obj.ManagedObjIF#removePropertyChangeListener(java.beans.PropertyChangeListener)
	 */
	public void removePropertyChangeListener(PropertyChangeListener listener) {
		if (_propertyChangeListeners != null)
			_propertyChangeListeners.removePropertyChangeListener(listener);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.ManagedObjListeneeIF#removePropertyChangeListener(java.beans.PropertyChangeListener, java.lang.String)
	 */
	public void removePropertyChangeListener(
		PropertyChangeListener listener,
		String propertyName) {
		if (_propertyChangeListeners != null)
			_propertyChangeListeners.removePropertyChangeListener(propertyName, listener);
	}

	/* (non-Javadoc)
	 * @see edu.mayo.mir.base.obj.ManagedObjIF#removeVetoableChangeListener(java.beans.VetoableChangeListener)
	 */
	public void removeVetoableChangeListener(VetoableChangeListener listener) {
		if (_vetoableChangeListeners != null)
			_vetoableChangeListeners.removeVetoableChangeListener(listener);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.ManagedObjListeneeIF#removeVetoableChangeListener(java.beans.VetoableChangeListener, java.lang.String)
	 */
	public void removeVetoableChangeListener(
		VetoableChangeListener listener,
		String propertyName) {
		if (_vetoableChangeListeners != null)
			_vetoableChangeListeners.removeVetoableChangeListener(propertyName, listener);
	}

	/**
	 * Sets a flag indicating if the object is capable of being inserted or
	 * updated in persistent storage.
	 * @param isTransient boolean
	 */
	public void setTransient(boolean isTransient) {
		_transient = isTransient;
	}

}