/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.managedobj;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.collections.map.LRUMap;

/**
 * Abstract superclass for services that allows caching of objects indexed by
 * primary and secondary key.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public abstract class CachedService extends BaseService {

	// Locally maintained mappings
	protected Map _key1Index = null;
	protected Map _key2Index = null;

	// Default maximum size of primary/secondary caches
	protected static final int DEFAULT_MAX_CACHE_SIZE = 0;

	/**
	 * Constructor for CachedService.
	 */
	protected CachedService() {
		super();
	}

	/**
	 * Constructor for CachedService.
	 * @param broker
	 * @throws ServiceInitException
	 */
	public CachedService(HomeServiceBroker broker) throws ServiceInitException {
		super(broker);
	}

	/**
	 * Constructor for CachedService.
	 * @param anchorService
	 * @throws ServiceInitException
	 */
	public CachedService(BaseService anchorService) throws ServiceInitException {
		super(anchorService);
	}

	/**
	 * Register cached entries for all objects in the collection
	 * based on key values.
	 * @param c
	 */
	protected void addAllToCache(Collection c) {
		Iterator it = c.iterator();
		while (it.hasNext())
			addToCache((ManagedObjIF) it.next());
	}

	/**
	 * Register cached entries for the object based on key values.
	 * @param obj
	 */
	protected void addToCache(ManagedObjIF obj) {
		addToPrimaryCache(obj);
		addToSecondaryCache(obj);
	}

	/**
	 * Register a locally cached entry for the object based on its primary key.
	 * @param obj
	 */
	protected void addToPrimaryCache(ManagedObjIF obj) {
		if (getPrimaryCacheMaxSize() > 0)
			getPrimaryCache().put(obj.getPrimaryKey(), obj);
	}

	/**
	 * If supported, register a locally cached entry for the object based on its
	 * secondary key.
	 * <p>
	 * Note: Use the hashcode of the secondary key as the key in the index to
	 * avoid storage overhead associated with using the full key (secondary keys
	 * tend to be more complex, as opposed to primary keys which are typically
	 * something like a simple OID). This will have the potential for some
	 * objects to 'fall through' the cache, but retrieved values will always be
	 * ensured accurate by the find method.
	 * @param obj
	 */
	protected void addToSecondaryCache(ManagedObjIF obj) {
		if (getSecondaryCacheMaxSize() > 0) {
			Object key = obj.getSecondaryKey();
			if (key != null)
				getSecondaryCache().put(new Integer(key.hashCode()), obj);
		}
	}

	/**
	 * @see org.LexGrid.managedobj.HomeServiceIF#closePrim()
	 */
	public void closePrim() {
		try {
			super.closePrim();
		} finally {
			getPrimaryCache().clear();
			getSecondaryCache().clear();
		}
	}

	/**
	 * @see org.LexGrid.managedobj.HomeServiceIF#findByPrimaryKey(java.lang.Object)
	 */
	public ManagedObjIF findByPrimaryKey(Object key) throws FindException {
		// Check the primary index being maintained over cached objects...
		ManagedObjIF obj = (ManagedObjIF) getPrimaryCache().get(key);

		// If not cached, check for the correct object from persistent storage.
		// If found, replace the currently maintained object in the cache.
		if (obj != null)
			return obj;

		obj = findByPrimaryKeyPrim(key);
		addToPrimaryCache(obj);
		return obj;
	}

	/**
	 * Returns the object with the given primary key without concern for the
	 * locally maintained cache.
	 * <p>
	 * This method is invoked when the object is not found in the local
	 * cache, and must be implemented by all subclasses.
	 * @param key
	 * @return ManagedObjIF
	 * @throws FindException
	 */
	protected abstract ManagedObjIF findByPrimaryKeyPrim(Object key) throws FindException;

	/**
	 * @see org.LexGrid.managedobj.HomeServiceIF#findBySecondaryKey(java.lang.Object)
	 */
	public ManagedObjIF findBySecondaryKey(Object key) throws FindException {
		// Check the secondary index being maintained over cached objects...
		ManagedObjIF obj = (ManagedObjIF) getSecondaryCache().get(new Integer(key.hashCode()));

		// If cached, ensure that the indexed value is an exact match for the
		// requested key. If not, 'fall through' the cache and check for the correct
		// object from persistent storage. If found, replace the currently
		// maintained object in the cache.
		if (obj != null && obj.getSecondaryKey().equals(key))
			return obj;

		obj = findBySecondaryKeyPrim(key);
		addToSecondaryCache(obj);
		return obj;
	}

	/**
	 * Returns the object with the given secondary key without concern for the
	 * locally maintained cache.
	 * <p>
	 * This method is invoked when the object is not found in the local
	 * cache, and must be implemented by all subclasses supporting
	 * objects with secondary keys.
	 * <p>
	 * Since queries based on the secondary key are specific to the object
	 * being found, the default superclass implementation throws a
	 * ServiceUnavailableException.
	 * @param key
	 * @return ManagedObjIF
	 * @throws FindException
	 */
	protected ManagedObjIF findBySecondaryKeyPrim(Object key) throws FindException {
		throw new ServiceUnavailableException();
	}

	/**
	 * Returns a map used to maintain an index (in memory) over objects
	 * by primary key.
	 * <p>
	 * Note: For simplicitly, the cache is currently implemented as a
	 * simple map that maintains a maximum size and, as the maximum is
	 * reached, evicts entries using a least recent used algorithm.
	 * @return Map
	 */
	protected Map getPrimaryCache() {
		if (_key1Index == null) {
			int size = getPrimaryCacheMaxSize();
			_key1Index = size > 0 ? new LRUMap(size)
				: Collections.EMPTY_MAP;
		}
		return _key1Index;
	}

	/**
	 * Returns the maximum number of items to maintain at any given time in the
	 * primary index.
	 * @return Map
	 */
	protected int getPrimaryCacheMaxSize() {
		return DEFAULT_MAX_CACHE_SIZE;
	}

	/**
	 * Returns a map used to maintain a secondary index (in memory) over
	 * objects supporting the concept of an alternate key.
	 * <p>
	 * Note: For simplicitly, the cache is currently implemented as a
	 * simple map that maintains a maximum size and, as the maximum is
	 * reached, evicts entries using a least recent used algorithm.
	 * @return Map
	 */
	protected Map getSecondaryCache() {
		if (_key2Index == null) {
			int size = getSecondaryCacheMaxSize();
			_key2Index = size > 0 ? new LRUMap(size)
				: Collections.EMPTY_MAP;
		}
		return _key2Index;
	}

	/**
	 * Returns the maximum number of items to maintain at any given time in the
	 * secondary index.
	 * @return Map
	 */
	protected int getSecondaryCacheMaxSize() {
		return DEFAULT_MAX_CACHE_SIZE;
	}

	/**
	 * Deregisters any cached entries for all objects in the collection.
	 * @param c
	 */
	protected void removeAllFromCache(Collection c) {
		Iterator it = c.iterator();
		while (it.hasNext())
			removeFromCache((ManagedObjIF) it.next());
	}

	/**
	 * Deregisters any cached entries for the object.
	 * @param obj
	 */
	protected void removeFromCache(ManagedObjIF obj) {
		removeFromPrimaryCache(obj);
		removeFromSecondaryCache(obj);
	}

	/**
	 * Deregisters any cached entry for the given object by primary key.
	 * @param obj
	 */
	protected void removeFromPrimaryCache(ManagedObjIF obj) {
		getSecondaryCache().remove(obj.getPrimaryKey());
	}

	/**
	 * Deregisters any cached entry for the given object by secondary key.
	 * @param obj
	 */
	protected void removeFromSecondaryCache(ManagedObjIF obj) {
		Object key = obj.getSecondaryKey();
		if (key != null)
			getSecondaryCache().remove(new Integer(key.hashCode()));
	}
}