/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.managedobj.jdbc;

import java.io.File;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.LexGrid.managedobj.FindException;
import org.LexGrid.managedobj.HomeServiceBroker;
import org.LexGrid.managedobj.ManagedObjIF;
import org.LexGrid.managedobj.OIDBasedObj;
import org.LexGrid.managedobj.OIDBasedObjServiceIF;
import org.LexGrid.managedobj.OIDKey;
import org.LexGrid.managedobj.ObjectNotFoundException;
import org.LexGrid.managedobj.RemoveException;
import org.LexGrid.managedobj.ServiceInitException;

import com.crossdb.sql.DeleteQuery;
import com.crossdb.sql.SelectQuery;
import com.crossdb.sql.WhereCondition;

/**
 * Abstract superclass for services handling objects 
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public abstract class OIDBasedObjService
	extends JDBCBaseService
	implements OIDBasedObjServiceIF {

	/**
	 * Constructor for OIDBasedObjService.
	 * @throws ServiceInitException
	 */
	public OIDBasedObjService() throws ServiceInitException {
		super();
	}

	/**
	 * Constructor for OIDBasedObjService.
	 * @param anchorService
	 * @throws ServiceInitException
	 */
	public OIDBasedObjService(JDBCBaseService anchorService) throws ServiceInitException {
		super(anchorService);
	}

	/**
	 * Constructor for OIDBasedObjService.
	 * @param broker
	 * @throws ServiceInitException
	 */
	public OIDBasedObjService(HomeServiceBroker broker) throws ServiceInitException {
		super(broker);
	}

	/**
	 * Constructor for OIDBasedObjService.
	 * @param broker
	 * @param xmlFile
	 * @throws ServiceInitException
	 */
	public OIDBasedObjService(HomeServiceBroker broker, File xmlFile)
		throws ServiceInitException {
		super(broker, xmlFile);
	}

	/**
	 * Constructor for OIDBasedObjService.
	 * @param broker
	 * @param xmlFile
	 * @param connDescriptor
	 * @param connPoolPolicy
	 * @throws ServiceInitException
	 */
	public OIDBasedObjService(
		HomeServiceBroker broker,
		File xmlFile,
		JDBCConnectionDescriptor connDescriptor,
		JDBCConnectionPoolPolicy connPoolPolicy)
		throws ServiceInitException {
		super(broker, xmlFile, connDescriptor, connPoolPolicy);
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.managedobj.OIDBasedObjServiceIF#assignNextOID(org.LexGrid.managedobj.OIDBasedObj)
	 */
	public void assignNextOID(OIDBasedObj o) {
		o.setOid(nextOid());
	}

	/**
	 * @see org.LexGrid.managedobj.jdbc.JDBCBaseService#findByPrimaryKeyPrim(java.lang.Object)
	 */
	protected ManagedObjIF findByPrimaryKeyPrim(Object key) throws FindException {
		ManagedObjIF obj = null;
		PreparedStatement ps = null;
		try {
			ps = checkOutRegisteredStatement(PS_FIND_PRIMARY_KEY);
			OIDKey idKey = (OIDKey) key;
			ps.setInt(1, idKey.getOid());
			ResultSet rs = ps.executeQuery();
			if (rs.next())
				obj = rs2Obj(rs);
			else
				throw new ObjectNotFoundException(key.toString());
		} catch (SQLException e) {
			throw new FindException(e);
		} finally {
			checkInPreparedStatement(ps);
		}
		return obj;
	}

	/**
	 * Returns the name of the database field used to store the OID.
	 * @return String
	 */
	protected String getOIDFieldName() {
		return "LG_OID";
	}

	/**
	 * @see org.LexGrid.managedobj.jdbc.JDBCBaseService#initRegisteredSQL()
	 */
	protected void initRegisteredSQL() {
		super.initRegisteredSQL();

		// Delete
		DeleteQuery dq = getSQLFactory().getDeleteQuery();
		dq.setTable(getDbTableName());
		dq.addWhereCondition(getOIDFieldName(), WhereCondition.EQUAL_TO, "?");
		registerSQL(PS_DELETE, dq.toString());

		// Find by primary key
		SelectQuery sq = getSQLFactory().getSelectQuery();
		sq.addTable(getDbTableName());
		sq.addWhereCondition(getOIDFieldName(), WhereCondition.EQUAL_TO, "?");
		registerSQL(PS_FIND_PRIMARY_KEY, sq.toString());
	}

	/**
	 * Return the next available OID for assignment to a new instance.
	 * @return int
	 */
	protected abstract int nextOid();

	/**
	 * @see org.LexGrid.managedobj.HomeServiceIF#remove(org.LexGrid.ma	nagedobj.ManagedObjIF)
	 */
	public void remove(ManagedObjIF obj) throws RemoveException, ObjectNotFoundException {
		OIDBasedObj o = null;
		PreparedStatement ps = null;
		try {
			o = (OIDBasedObj) obj;
			ps = checkOutRegisteredStatement(PS_DELETE);
			ps.setInt(1, o.getOid());
			ps.executeUpdate();
			removeFromCache(o);
		} catch (SQLException sqle) {
			try {
				handleSQLException(sqle);
			} catch (ObjectNotFoundException onfe) {
				throw onfe;
			} catch (RemoveException re) {
				throw re;
			} catch (Exception e) {
				throw new RemoveException(e);
			}
		} finally {
			checkInPreparedStatement(ps);
			if (o != null)
				removeFromCache(o);
		}
	}

	/**
	 * @see org.LexGrid.managedobj.jdbc.JDBCResultSetIteratorHelper#row2ManagedObj(java.sql.ResultSet)
	 */
	public ManagedObjIF row2ManagedObj(ResultSet rs) throws SQLException {
		// Note: When available, return the locally cached item
		// so that all processes work against the same instance.
		int oid = rs.getInt(1);
		ManagedObjIF o =
			(ManagedObjIF) getPrimaryCache()
				.get(new OIDKey(oid));
		if (o == null) {
			o = rs2Obj(rs, oid);
			addToCache(o);
		}
		return o;
	}

	/**
	 * Create and return a new instance based on converted values in the current
	 * row of the result set.
	 * @param rs
	 * @return ManagedObjIF
	 * @throws SQLException
	 */
	public ManagedObjIF rs2Obj(ResultSet rs) throws SQLException {
		return rs2Obj(rs, rs.getInt(1));
	}

	/**
	 * Create and return a new instance based on converted values in the current
	 * row of the result set and pre-determined object id.
	 * @param rs
	 * @param oid
	 * @return ManagedObjIF
	 * @throws SQLException
	 */
	protected abstract ManagedObjIF rs2Obj(ResultSet rs, int oid) throws SQLException;

	/* (non-Javadoc)
	 * @see org.org.LexGrid.commons.managedobj.service.CachedService#getPrimaryCacheMaxSize()
	 */
	protected int getPrimaryCacheMaxSize() {
		return 8192;
	}

	/* (non-Javadoc)
	 * @see org.org.LexGrid.commons.managedobj.service.CachedService#getSecondaryCacheMaxSize()
	 */
	protected int getSecondaryCacheMaxSize() {
		return 8192;
	}

}