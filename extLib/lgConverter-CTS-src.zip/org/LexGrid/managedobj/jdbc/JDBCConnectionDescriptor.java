/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.managedobj.jdbc;

import java.sql.Connection;

import org.LexGrid.util.sql.sqlReconnect.WrappedConnection;

/**
 * Describes database settings to be used for JDBC connections.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class JDBCConnectionDescriptor {
	// JDBC connection info
	private String _dbDriver = null;
	private String _dbUid = null;
	private String _dbPwd = null;
	private String _dbUrl = null;
	private String _dbPlatform = null;
	private Boolean _isOdbc = null;
	private boolean _autoCommit = true;
    private boolean _useUTF8 = false;
	private int _isoLevel = Connection.TRANSACTION_READ_UNCOMMITTED;
    private boolean _autoRetryFailedConnections = false;

	// Statements to validate connections and perform shutdown ...
	private String _pingSql = null;
	private String _shutdownSql = null;

	/**
	 * Constructor for JDBCConnectionDescriptor.
	 */
	public JDBCConnectionDescriptor() {
		super();
	}
    
    /**
     * Constructor for JDBCConnectionDescriptor
     * @param loader The classloader to use for finding the driver classes.
     */
    public JDBCConnectionDescriptor(ClassLoader loader) {
        super();
        WrappedConnection.setDriverClassLoader(loader);
    }

	/**
	 * Indicates the auto-commit status for connections created using
	 * the descriptor; the default is true.
	 */
	public boolean getAutoCommit() {
		return _autoCommit;
	}

	/**
	 * Returns the qualified class name for the configured JDBC driver;
	 * null if not assigned.
	 * @return String
	 */
	public String getDbDriver() {
		return _dbDriver;
	}

	/**
	 * Returns a string identifying the database platform;
	 * null if not assigned.
	 * @return String
	 */
	public String getDbPlatform() {
		return _dbPlatform;
	}

	/**
	 * Returns the password to use when initiating a JDBC connection;
	 * empty if not assigned.
	 * @return String
	 */
	public String getDbPwd() {
		if (_dbPwd == null)
			_dbPwd = "";
		return _dbPwd;
	}

	/**
	 * Returns the user ID to use when initiating a JDBC connection;
	 * empty if not assigned.
	 * @return String
	 */
	public String getDbUid() {
		if (_dbUid == null)
			_dbUid = "";
		return _dbUid;
	}

	/**
	 * Returns the string defining the URL to use when initiating a JDBC
	 * connection; null if not assigned.
	 * @return String
	 */
	public String getDbUrl() {
		return _dbUrl;
	}

	/**
	 * Returns the SQL string for a statement used to validate connections;
	 * null if not available.
	 * @return String
	 */
	public String getPingSQL() {
		return _pingSql;
	}

	/**
	 * Returns the SQL string for a statement used to close or dismount the database;
	 * null if not available.
	 * @return String
	 */
	public String getShutdownSQL() {
		return _shutdownSql;
	}

	/**
	 * Indicates the transaction isolation level for connections created using
	 * the descriptor; the default is READ_UNCOMMITTED.
	 */
	public int getTransactionIsolation() {
		return _isoLevel;
	}

	/**
	 * Indicates whether the receiver describes connections based on
	 * the ODBC connectivity standard.
	 * @return boolean
	 */
	public boolean isOdbc() {
		if (_isOdbc == null)
		_isOdbc =
				new Boolean(
					(getDbDriver() != null && getDbDriver().equals("sun.jdbc.odbc.JdbcOdbcDriver"))
						|| (getDbPlatform() != null && getDbPlatform().equalsIgnoreCase("msAccess")));		
		return _isOdbc.booleanValue();
	}

	/**
	 * Indicates the auto-commit status for connections created using
	 * the descriptor.
	 */
	public void setAutoCommit(boolean autoCommit) {
		_autoCommit = autoCommit;
	}

	/**
	 * Sets the qualified class name for the configured JDBC driver.
	 * @param className String
	 * @throws ClassNotFoundException
	 */
	public void setDbDriver(String className) throws ClassNotFoundException {
        _dbDriver = className;
        if (WrappedConnection.getDriverClassLoader() != null)
        {
            try
            {
                WrappedConnection.getDriverClassLoader().loadClass(_dbDriver).newInstance();
            }
            catch (InstantiationException e)
            {
                throw new ClassNotFoundException(_dbDriver, e);
            }
            catch (IllegalAccessException e)
            {
                throw new ClassNotFoundException(_dbDriver, e);
            }
        }
        else
        {
            Class.forName(_dbDriver);
        }
	}

	/**
	 * Sets a string identifying the database platform;
	 * null if not assigned.
	 * @param platform String
	 */
	public void setDbPlatform(String platform) {
		_dbPlatform = platform;
	}

	/**
	 * Sets the password to use when initiating a JDBC connection;
	 * empty or null if not applicable.
	 * @param pwd String
	 */
	public void setDbPwd(String pwd) {
		_dbPwd = pwd;
	}

	/**
	 * Sets the user ID to use when initiating a JDBC connection;
	 * empty or null if not applicable.
	 * @param uid String
	 */
	public void setDbUid(String uid) {
		_dbUid = uid;
	}

	/**
	 * Sets the string defining the URL to use when initiating a JDBC
	 * connection.
	 * @param url String
	 */
	public void setDbUrl(String url) {
		_dbUrl = url;
	}

	/**
	 * Sets the SQL string for the statement used to validate connections;
	 * null if not available.
	 * <p>
	 * Note: If provided, the returned statement should be as simple and
	 * efficient as possible since it is frequently evaluated in addition to the
	 * work normally performed by the application.
	 * @param sql String
	 */
	public void setPingSQL(String sql) {
		_pingSql = sql;
	}

	/**
	 * Sets the SQL string for a statement used to close or dismount the database;
	 * null if not available.
	 * @param sql String
	 */
	public void setShutdownSQL(String sql) {
		_shutdownSql = sql;
	}


	/**
	 * Indicates the transaction isolation level for connections created using
	 * the descriptor.
	 */
	public void setTransactionIsolation(int isoLevel) {
		_isoLevel = isoLevel;
	}
    /**
     * @return Returns the _autoRetryFailedConnections.
     */
    public boolean isAutoRetryFailedConnections()
    {
        return _autoRetryFailedConnections;
    }
    /**
     * @param retryFailedConnections The _autoRetryFailedConnections to set.
     */
    public void setAutoRetryFailedConnections(boolean retryFailedConnections)
    {
        _autoRetryFailedConnections = retryFailedConnections;
    }
    /**
     * @return Returns the _useUTF8.
     */
    public boolean isUseUTF8()
    {
        return _useUTF8;
    }
    /**
     * @param _useutf8 The _useUTF8 to set.
     */
    public void setUseUTF8(boolean _useutf8)
    {
        _useUTF8 = _useutf8;
    }
}