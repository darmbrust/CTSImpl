/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.managedobj.jdbc;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

import org.LexGrid.util.sql.DBUtility;
import org.LexGrid.util.sql.sqlReconnect.WrappedConnection;
import org.apache.commons.pool.BasePoolableObjectFactory;
import org.apache.log4j.Logger;

/**
 * Handles lifecycle events for pooled PreparedStatement objects.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class JDBCConnectionFactory extends BasePoolableObjectFactory {

    public final static Logger logger = Logger.getLogger("managedobj.service.jdbc.JDBCConnectionFactory");

	// JDBC database connection info
	JDBCConnectionDescriptor _dbDesc = null;

	/**
	 * Constructor for JDBCConnectionFactory.
	 */
	public JDBCConnectionFactory(JDBCConnectionDescriptor desc) {
		super();
		_dbDesc = desc;
	}

	/**
     * @see org.apache.commons.pool.PoolableObjectFactory#makeObject()
     */
	public Object makeObject() throws Exception {
        Connection c = null;

        if (_dbDesc.getDbUrl().indexOf("Microsoft Access Driver") != -1)
        {
            //check to see if the Access database exists, if not, create it.
            int x = _dbDesc.getDbUrl().indexOf("DBQ=");
            File temp = new File(_dbDesc.getDbUrl().substring(x + 4));
            {
                if (!temp.exists())
                {
                    DBUtility.createBlankAccessDB(temp);
                }
            }
        }
        
        if (_dbDesc.isAutoRetryFailedConnections())
        {
           c = new WrappedConnection(_dbDesc.getDbUid(),
                                    _dbDesc.getDbPwd(), 
                                    _dbDesc.getDbDriver(), 
                                    _dbDesc.getDbUrl(),
                                    _dbDesc.isUseUTF8()); 
        }
        else
        {
            Properties props = new Properties();
            props.setProperty("user", _dbDesc.getDbUid());
            props.setProperty("password", _dbDesc.getDbPwd());
            if (_dbDesc.isUseUTF8())
            {
                setUTFCharsetForDB(props, _dbDesc.getDbUrl());
            }
            c = DriverManager.getConnection(
				_dbDesc.getDbUrl(),
				props);
        }
				
		// Attempt to set commit & transaction levels, but
		// continue if unsupported (i.e. MS Access / ODBC).
		try { c.setAutoCommit(_dbDesc.getAutoCommit()); }
			catch (SQLException e) {
                logger.info("Unable to assign connection autoCommit mode >>> " + e);}

		try { c.setTransactionIsolation(_dbDesc.getTransactionIsolation()); }
			catch (SQLException e) {
                logger.info("Unable to assign connection transactionIsolation level >>> " + e);}
		return c;
	}
    
    public static void setUTFCharsetForDB(Properties props, String URL)
    {
        String tempURL = URL.toLowerCase();
        // access and postgres use this flag
        if (tempURL.indexOf("odbc") != -1 || tempURL.indexOf("postgresql") != -1)
        {
            props.setProperty("charSet", "utf-8");
        }
        // mysql uses this
        else if (tempURL.indexOf("mysql") != -1)
        {
            props.setProperty("characterEncoding", "UTF-8");
            props.setProperty("useUnicode", "true");
        }
        else
        {
            props.setProperty("charSet", "utf-8");
        }
    }

	/**
	 * @see org.apache.commons.pool.PoolableObjectFactory#destroyObject(java.lang.Object)
	 */
	public void destroyObject(Object arg0) throws Exception {
		Connection c = (Connection) arg0;
		if (!c.isClosed()) {
			c.commit();
			c.close();
		}
	}

	/**
	 * @see org.apache.commons.pool.PoolableObjectFactory#validateObject(java.lang.Object)
	 */
	public boolean validateObject(Object arg0) {
		try {
			Connection c = (Connection) arg0;
			if (!c.isClosed()) {
				ping((Connection) arg0);
				return true;
			}
		} catch (SQLException e) {
		}
		return false;
	}

	/**
	 * @see org.apache.commons.pool.PoolableObjectFactory#activateObject(java.lang.Object)
	 */
	public void activateObject(Object arg0) throws Exception {
		// Warnings can build up over time in some implementations
		// and result in significant overhead/problems...
		 ((Connection) arg0).clearWarnings();
	}

	/**
	 * @see org.apache.commons.pool.PoolableObjectFactory#passivateObject(java.lang.Object)
	 */
	public void passivateObject(Object arg0) throws Exception {
		// No action required
	}

	/**
	 * Test the connection and throw an exception if something goes wrong.
	 * @param conn
	 * @throws SQLException
	 */
	protected void ping(Connection conn) throws SQLException {
		PreparedStatement ps = null;
		try {
			String sql = _dbDesc.getPingSQL();
			if (sql != null) {
				ps = conn.prepareStatement(sql);
				ps.execute();
			}
		} finally {
			if (ps != null)
				ps.close();
		}
	}
}