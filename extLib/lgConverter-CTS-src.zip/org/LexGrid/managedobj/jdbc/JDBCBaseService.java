/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.managedobj.jdbc;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.MissingResourceException;

import org.LexGrid.managedobj.CachedService;
import org.LexGrid.managedobj.HomeServiceBroker;
import org.LexGrid.managedobj.ManagedObjException;
import org.LexGrid.managedobj.ManagedObjIterator;
import org.LexGrid.managedobj.ObjectAlreadyExistsException;
import org.LexGrid.managedobj.QueryException;
import org.LexGrid.managedobj.RemoveException;
import org.LexGrid.managedobj.ServiceInitException;
import org.LexGrid.managedobj.ServiceUnavailableException;
import org.LexGrid.managedobj.UnexpectedException;
import org.apache.log4j.Logger;
import org.apache.regexp.RE;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;

import com.crossdb.sql.DeleteQuery;
import com.crossdb.sql.SQLFactory;
import com.crossdb.sql.SelectQuery;

/**
 * Abstract superclass for all JDBC services.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public abstract class JDBCBaseService
	extends CachedService
	implements JDBCResultSetIteratorHelper {

    public final static Logger logger = Logger.getLogger("managedobj.service.jdbc.JDBCBaseService");
	// Database connection info
	protected static final String DEFAULT_DB_CONFIG = "repository.xml";
	protected JDBCConnectionDescriptor _dbDesc;
	protected File _dbFile = null;

	// SQL factory (CrossDB)
	private SQLFactory _sqlFactory = null;

	// SQL connection pooling (Jakarta Commons Pool)
	private JDBCConnectionPool _connPool = null;
	private JDBCConnectionPoolPolicy _connPolicy = null;

	private Map _sqlRegistry = null;

	// Common prepared statement keys
	protected static final String PS_DELETE = "delete";
	protected static final String PS_INSERT = "insert";
	protected static final String PS_UPDATE = "update";
	protected static final String PS_FIND_PRIMARY_KEY = "findByPrimaryKey";
	protected static final String PS_FIND_SECONDARY_KEY = "findBySecondaryKey";
	protected static final String PS_QUERY_ALL = "queryAll";
	protected static final String PS_REMOVE_ALL = "removeAll";

	// Statistics...
	// For now just simple running counts to provide a
	// sanity check on checked-in/checked-out statements.
	// Note: This should be extended to a more full-featured
	// approach that includes statement execution time,
	// averages, etc.
	private int _statCheckOutsAll = 0;
	private int _statCheckOutsNow = 0;

	/**
	 * Constructor for JDBCBaseService.
	 */
	protected JDBCBaseService() {
		super();
	}

	/**
	 * Constructor for JDBCBaseService.
	 * @param anchorService
	 * @throws ServiceInitException
	 */
	public JDBCBaseService(JDBCBaseService anchorService) throws ServiceInitException {
		this();
		setBroker(anchorService.getBroker());
		anchorService.internalRegisterNestedService(this);
		setAnchorService(anchorService);
		setConnectionDescriptor((anchorService).getConnectionDescriptor());
		setConnectionPoolPolicy((anchorService).getConnectionPoolPolicy());
		init();
	}

	/**
	 * Constructs a new instance that connects to the database defined by the
	 * default config file (repository.xml) using the default connection pooling
	 * policy.
	 * @param broker
	 * @throws ServiceInitException
	 */
	public JDBCBaseService(HomeServiceBroker broker) throws ServiceInitException {
		this(broker, new File(DEFAULT_DB_CONFIG));
	}

	/**
	 * Constructs a new instance that connects to the database defined by the
	 * given config file using the default connection pooling policy.
	 * @param broker
	 * @param xmlFile
	 * @throws ServiceInitException
	 */
	public JDBCBaseService(HomeServiceBroker broker, File xmlFile)
		throws ServiceInitException {
		this();
		setBroker(broker);
		setDbConfigFile(xmlFile);
		init();
	}

	/**
	 * Constructs a new instance that connects to the database defined by the
	 * given config file using a specific connection pooling policy.
	 * @param broker
	 * @param xmlFile
	 * @param connDescriptor
	 * @param connPoolPolicy
	 * @throws ServiceInitException
	 */
	public JDBCBaseService(
		HomeServiceBroker broker,
		File xmlFile,
		JDBCConnectionDescriptor connDescriptor,
		JDBCConnectionPoolPolicy connPoolPolicy)
		throws ServiceInitException {
		this();
		setBroker(broker);
		setDbConfigFile(xmlFile);
		setConnectionDescriptor(connDescriptor);
		setConnectionPoolPolicy(connPoolPolicy);
		init();
	}

	/**
	 * Adjust the given SQL string as required to compensate for
	 * various oddities in database implementation that were not
	 * addressed by the CrossDB support.
	 * @param sql
	 * @return String
	 */
	protected String adjustSQL(String sql) {
		String s = sql;
		s = adjustSQL_inClauseParens(s);
		s = adjustSQL_markerNormalization(s);
		return s;
	}

	/**
	 * Returns a string based on the given sql, ensuring that
	 * parameter markers for all IN clauses are encapsulated by
	 * parenthesis.
	 * <p>
	 * Note: The output from CrossDB, in the case of 'IN' clauses,
	 * does not appear to be standard (parameter markers are not
	 * enclosed in parenthesis), so we adjust here.
	 * @param sql
	 * @return String
	 */
	protected synchronized String adjustSQL_inClauseParens(String sql) {
		final RE re = new RE("^(.*)(IN *\\?)([,? ]*)(.*)");
		String s = sql;
		while (re.match(s))
			s = new StringBuffer(re.getParen(1))
				.append("IN (?")
				.append(re.getParen(3))
				.append(')')
				.append(re.getParen(4))
				.toString();
		return s;
	}

	/**
	 * Returns a string based on the given sql, ensuring that
	 * surrounding quotes are eliminated from parameter markers.
	 * <p>
	 * Note: Some database implementations (i.e. MySQL) appear
	 * to be sensitive in this area. 
	 * @param sql
	 * @return String
	 */
	protected synchronized String adjustSQL_markerNormalization(String sql) {
		final RE re = new RE("^(.*)(' *\\? *')(.*)");
		String s = sql;
		while (re.match(s)) {
			String sub1 = re.getParen(1);
			String sub3 = re.getParen(3);
			s = new StringBuffer(sub1)
				.append(" ? ")
				.append(sub3)
				.toString();
		}
		return s;
	}

	/**
     * Returns a prepared statement to the pool.
     * 
     * @param ps PreparedStatement
     */
    public void checkInPreparedStatement(PreparedStatement ps)
    {
        try
        {
            if (ps != null)
            {
                JDBCConnectionPool pool = getConnectionPool();
                Connection temp = ps.getConnection();
                if (temp != null && !pool.hasObjectBeenReturned(temp))
                {
                    _statCheckOutsNow--;

                    // to get paged results in postgres, I have to turn off autocommit.
                    // want to make sure it gets set back to what it was initialized to
                    // before returning it too the pool.
                    try
                    {
                        if (temp != null && temp.getAutoCommit() != _dbDesc.getAutoCommit())
                        {
                            temp.setAutoCommit(_dbDesc.getAutoCommit());
                        }
                    }
                    catch (RuntimeException e)
                    {
                        // do nothing... the connection has probably failed - so there is no point
                        //in worrying about setting the auto commit back.
                    }
                    pool.returnObject(temp);
                }
            }
            try
            {
                ps.close(); // closing the prepared statements is often required to free resources
                // have to return the connection to the pool before you
                // close the preparedStatement, however (don't remember why)
                //but I want to call this to ensure that this always gets closed.
            }
            catch (Exception e)
            {
                //don't report any errors on the close, nothing can be done about it anyway.
            }
        }
        catch (Exception e)
        {
            throw new UnexpectedException(e);
        }
    }

	/**
	 * Borrows a prepared statement (for the given text) and associated
	 * connection from the pool.
	 * <p>
	 * By default the statement is prepared with concurrency indicating that the
	 * result set cannot be updated, and the cursor can only move forward.
	 * 
	 * @param sql
	 * @return PreparedStatement
	 * @throws SQLException
	 */
	public PreparedStatement checkOutPreparedStatement(String sql) throws SQLException {
		return checkOutPreparedStatement(
			sql,
			ResultSet.TYPE_FORWARD_ONLY,
			ResultSet.CONCUR_READ_ONLY);
	}

	/**
	 * Borrows a prepared statement (for the given text) and associated
	 * connection from the pool.
	 * @param sql
	 * @param resultSetType
	 * @param resultSetConcurrency
	 * @return PreparedStatement
	 * @throws SQLException
	 */
	protected PreparedStatement checkOutPreparedStatement(
		String sql,
		int resultSetType,
		int resultSetConcurrency)
		throws SQLException {
		Connection c = null;
		PreparedStatement ps = null;
		try {
			c = (Connection) getConnectionPool().borrowObject();
			ps = c.prepareStatement(
					sql,
					resultSetType,
					resultSetConcurrency);
			_statCheckOutsAll++;
			_statCheckOutsNow++;
			return ps;
		} catch (SQLException e) {
			// MS ODBC driver does not support result set type & concurrency settings ...
			if (c != null && e.getErrorCode() == 106)
				try {
					ps = c.prepareStatement(sql);
					_statCheckOutsAll++;
					_statCheckOutsNow++;
					return ps;
				} catch (SQLException e1) {
					throw e1;
				}
			else
				throw e;
		} catch (Exception e) {
			throw new SQLException(e.toString());
		} finally {
			if (ps == null && c != null)
				try {
					getConnectionPool().returnObject(c);
				} catch (Exception e1) {
					logger.error("unexpected error", e1);
				}
		}
	}

	/**
	 * Borrows a prepared statement (for the text registered under the given
	 * key) and associated connection from the pool.
	 * <p>
	 * By default the statement is prepared with concurrency indicating that the
	 * result set cannot be updated, and the cursor can only move forward.
	 * @param key
	 * @return PreparedStatement
	 * @throws SQLException
	 */
	protected PreparedStatement checkOutRegisteredStatement(String key) throws SQLException {
		return checkOutPreparedStatement((String) getRegisteredSQL(key));
	}

	/**
	 * Borrows a prepared statement (for the text registered under the given
	 * key) and associated connection from the pool.
	 * @param key
	 * @param resultSetType
	 * @param resultSetConcurrency
	 * @return PreparedStatement
	 * @throws SQLException
	 */
	protected PreparedStatement checkOutRegisteredStatement(
		String key,
		int resultSetType,
		int resultSetConcurrency)
		throws SQLException {
		return checkOutPreparedStatement(
			(String) getRegisteredSQL(key),
			resultSetType,
			resultSetConcurrency);
	}

	/**
	 * @see org.LexGrid.managedobj.HomeServiceIF#closePrim()
	 */
	public void closePrim() {
		try {
			// Default superclass behavior (i.e. close nested services)
			super.closePrim();

			// Perform shutdown
			shutdown();

			// Release resources and close the connection pool
			if (_connPool != null)
				_connPool.close();

		} catch (Exception e) {
			throw new UnexpectedException(e);
		} finally {
			if (_statCheckOutsAll > 0 || _statCheckOutsNow > 0) {
				// Print diagnostics ...
//				System.out.println(">>> " + this.getClass().getName());
//				System.out.println(">>> Total # database statements checked out: " + _statCheckOutsAll);
//				System.out.println(">>>\tStatements not returned: " + _statCheckOutsNow);

				// Clear statistics ...
				_statCheckOutsAll = 0;
				_statCheckOutsNow = 0;
			}
		}
	}

	/**
	 * Returns an object defining the database connection. 
	 * @return JDBCConnectionDescriptor
	 */
	public JDBCConnectionDescriptor getConnectionDescriptor() {
		if (_dbDesc == null)
			_dbDesc = new JDBCConnectionDescriptor();
		return _dbDesc;
	}
    
    /**
     * Returns an object defining the database connection. 
     * @return JDBCConnectionDescriptor
     * param classLoader The class loader to use while loading drivers (only used if a descriptor
     * doesn't yet exist)
     */
    public JDBCConnectionDescriptor getConnectionDescriptor(ClassLoader classLoader) {
        if (_dbDesc == null)
            _dbDesc = new JDBCConnectionDescriptor(classLoader);
        return _dbDesc;
    }

	/**
	 * Returns an object pool used to manage JDBC connections.
	 * @return JDBCConnectionPool
	 */
	protected JDBCConnectionPool getConnectionPool() {
		if (_connPool == null)
			_connPool =
				new JDBCConnectionPool(
					new JDBCConnectionFactory(getConnectionDescriptor()),
					getConnectionPoolPolicy());
		return _connPool;
	}
    
    /**
     * Set the object pool used to manage JDBC connections.
     * @param pool
     */
    protected void setConnectionPool(JDBCConnectionPool pool) {
            _connPool = pool;
    }

	/**
	 * Returns the policy used to manage the connection pool.
	 * @return JDBCConnectionPoolPolicy
	 */
	public JDBCConnectionPoolPolicy getConnectionPoolPolicy() {
		if (_connPolicy == null)
			_connPolicy = new JDBCConnectionPoolPolicy();
		return _connPolicy;
	}

	/**
	 * Returns the file defining the database configuration;
	 * null if not assigned.
	 * @return File
	 */
	protected File getDbConfigFile() {
		return _dbFile;
	}

	/**
	 * Returns the name of the table holding instance data.
	 * @return String
	 */
	protected abstract String getDbTableName();

	/**
	 * Returns the SQL text registered for the given key;
	 * null if not available.
	 * @return String
	 */
	protected String getRegisteredSQL(String key) {
		return (String) getSQLRegistry().get(key);
	}

	/**
	 * Returns the associated CrossDB SQLFactory.
	 * @return SQLFactory
	 */
	protected SQLFactory getSQLFactory() {
		return _sqlFactory;
	}

	/**
	 * Returns a mapping of keys to SQL text.
	 * @return Map
	 */
	protected Map getSQLRegistry() {
		if (_sqlRegistry == null)
			_sqlRegistry = new HashMap();
		return _sqlRegistry;
	}
    
    /**
     * Set the mapping of keys to SQL text.
     * @param sqlRegistry
     */
    protected void setSQLRegistry(Map sqlRegistry) {
        _sqlRegistry = sqlRegistry;
    }

	/**
	 * Interprets the SQL exception and throws a corresponding
	 * ManagedObjException if an appropriate counterpart is found.
	 * If no counterpart is found, the SQL exception is rethrown.
	 * @param sqle
	 * @throws ManagedObjException
	 * @throws SQLException
	 */
	protected void handleSQLException(SQLException sqle)
		throws ManagedObjException, SQLException {
		int err = sqle.getErrorCode();
		String state = sqle.getSQLState();

		// Duplicate key errors :
		//   Hsqldb ............. -9, -104
		//   IBM DB2 (discovered on AIX/64 version) .... -803
		//   MySQL .............. 1062
		//   Sybase ............. 2601
		//   Microsoft Access ... S1000 (General Error from JDBC/ODBC driver)
		if (err == -9
			|| (err == -104)
			|| (err == -803)
			|| (err == 2601)
			|| (err == 1062)
			|| (err == 0 && "S1000".equals(state)))
			throw new ObjectAlreadyExistsException(sqle);

		// Index already exists :
		//   Hsqldb ............. -23 (State S0011)
		if (err == -23 && "S0011".equals(state))
			throw new DBIndexAlreadyExistsException(sqle);
			
		// Table already exists :
		//   Hsqldb ............. -21 (State S0001)
		if (err == -21 && "S0001".equals(state))
			throw new DBTableAlreadyExistsException(sqle);
		
		// Index not found (on drop) :
		//   Hsqldb ............. -26 (State S0012)
		if (err == -26 && "S0012".equals(state))
			throw new DBIndexNotFoundException(sqle);

		// Table not found (on drop) :
		//   Hsqldb ............. -22 (State S0002)
		if (err == -22 && "S0002".equals(state))
			throw new DBTableNotFoundException(sqle);

		// Unknown ...
		logger.error(
			new StringBuffer(256)
				.append("*** Unhandled SQL error code: '").append(sqle.getErrorCode())
				.append("' state: '").append(state).append('\'')
				.toString());
		throw sqle;
	}

	/**
	 * Initializes the service.
	 * @throws ServiceInitException
	 */
	protected void init() throws ServiceInitException {
		// Alter based on settings in the xml file, if available...
		JDBCConnectionDescriptor desc = getConnectionDescriptor();
		File configFile = getDbConfigFile();
		if (configFile != null)
			try {
				// Open and parse the config file...
				SAXBuilder builder = new SAXBuilder();
				Document doc = builder.build(configFile);

				// Map the configured platform to a specific CrossDB factory...
				// Note that we utilize this on the service during statement
				// definition, but do not carry over any dependencies to
				// statement preparation or execution.
				Element jdbcConfig = doc.getRootElement().getChild("jdbc-connection-descriptor");
				String platform = jdbcConfig.getAttributeValue("platform");
				setSQLFactory(CrossDBUtil.newSQLFactory(platform));
				desc.setDbPlatform(platform);

				// Set the driver class and reflect on it to allow
				// registration to the DriverManager...
				String dbDriver = jdbcConfig.getAttributeValue("driver");
				try { desc.setDbDriver(dbDriver); }
					catch (ClassNotFoundException e) {
						throw new MissingResourceException(e.toString(), dbDriver, "");
					}

				// Set authentication info...
				desc.setDbUid(jdbcConfig.getAttributeValue("username"));
				desc.setDbPwd(jdbcConfig.getAttributeValue("password"));

				// Set the database location...
				String protocol = jdbcConfig.getAttributeValue("protocol");
				String subprotocol = jdbcConfig.getAttributeValue("subprotocol");
				String dbalias = jdbcConfig.getAttributeValue("dbalias");
				desc.setDbUrl(protocol + ':' + subprotocol + ':' + dbalias);

				// Set the auto-commit level...
				String autoCommit = jdbcConfig.getAttributeValue("useAutoCommit");
				if (autoCommit != null)
					desc.setAutoCommit(autoCommit.equals("1"));

				// Set the auto-commit level...
				String tiLevel = jdbcConfig.getAttributeValue("transactionIsolationLevel");
				if (tiLevel != null) {
					tiLevel = tiLevel.trim().toUpperCase();
					if (tiLevel.equals("TRANSACTION_NONE")) desc.setTransactionIsolation(Connection.TRANSACTION_NONE);
					else if (tiLevel.equals("TRANSACTION_READ_COMMITTED")) desc.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
					else if (tiLevel.equals("TRANSACTION_READ_UNCOMMITTED")) desc.setTransactionIsolation(Connection.TRANSACTION_READ_UNCOMMITTED);
					else if (tiLevel.equals("TRANSACTION_REPEATABLE_READ")) desc.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);
					else if (tiLevel.equals("TRANSACTION_SERIALIZABLE")) desc.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
					else logger.warn("Unrecognized transaction isolation level >>> "+tiLevel);
				}

				// Set the SQL registered to close or dismount the database
				desc.setShutdownSQL(jdbcConfig.getAttributeValue("shutdownQuery"));

				// Allow registration of referenced SQL strings by key
				initRegisteredSQL();

				// Override connection pool policy with any settings
				// provided in the external config file ...
				Element cp = jdbcConfig.getChild("connection-pool");
				if (cp != null) {
					JDBCConnectionPoolPolicy pol = getConnectionPoolPolicy();
					String val;
					if ((val = cp.getAttributeValue("maxActive")) != null)
						try {
							pol.maxActive = Integer.parseInt(val);
						} catch (RuntimeException e1) {
							e1.printStackTrace();
						}
					if ((val = cp.getAttributeValue("maxIdle")) != null)
						try {
							pol.maxIdle = Integer.parseInt(val);
						} catch (RuntimeException e1) {
							e1.printStackTrace();
						}
					if ((val = cp.getAttributeValue("maxWait")) != null)
						try {
							pol.maxWait = Integer.parseInt(val);
						} catch (RuntimeException e1) {
							e1.printStackTrace();
						}
					if ((val = cp.getAttributeValue("minEvictableIdleTimeMillis")) != null)
						try {
							pol.minEvictableIdleTimeMillis = Integer.parseInt(val);
						} catch (RuntimeException e1) {
							e1.printStackTrace();
						}
					if ((val = cp.getAttributeValue("numTestsPerEvictionRun")) != null)
						try {
							pol.numTestsPerEvictionRun = Integer.parseInt(val);
						} catch (RuntimeException e1) {
							e1.printStackTrace();
						}
					if ((val = cp.getAttributeValue("testOnBorrow")) != null)
						try {
							pol.testOnBorrow = val.equalsIgnoreCase("true");
						} catch (RuntimeException e1) {
							e1.printStackTrace();
						}
					if ((val = cp.getAttributeValue("testOnReturn")) != null)
						try {
							pol.testOnReturn = val.equalsIgnoreCase("true");
						} catch (RuntimeException e1) {
							e1.printStackTrace();
						}
					if ((val = cp.getAttributeValue("testWhileIdle")) != null)
						try {
							pol.testWhileIdle = val.equalsIgnoreCase("true");
						} catch (RuntimeException e1) {
							e1.printStackTrace();
						}
					if ((val = cp.getAttributeValue("timeBetweenEvictionRunsMillis")) != null)
						try {
							pol.timeBetweenEvictionRunsMillis = Integer.parseInt(val);
						} catch (RuntimeException e1) {
							e1.printStackTrace();
						}
					if ((val = cp.getAttributeValue("whenExhaustedAction")) != null)
						try {
							pol.whenExhaustedAction = Byte.parseByte(val);
						} catch (RuntimeException e1) {
							e1.printStackTrace();
						}
					if ((val = cp.getAttributeValue("validationQuery")) != null)
						desc.setPingSQL(val);
				}
			} catch (Exception e) {
				throw new ServiceInitException(e);
			}
		// Pick up any global init...
		super.init();
	}

	/**
	 * Provides an extension point to register SQL statements when the service
	 * is initialized. Subclasses may override as appropriate.
	 */
	protected void initRegisteredSQL() {
		// Query all instances
		SelectQuery sq = getSQLFactory().getSelectQuery();
		sq.addTable(getDbTableName());
		registerSQL(PS_QUERY_ALL, sq.toString());

		// Remove all
		DeleteQuery dq = getSQLFactory().getDeleteQuery();
		dq.setTable(getDbTableName());
		registerSQL(PS_REMOVE_ALL, dq.toString());
	}

	
	/**
	 * Assigns a long parameter value to the given prepared statement.
	 * <p>
	 * Note: We treat as an int when using ODBC connectivity since there
	 * appear to be issues with parameters being ignored or dropped when treated
	 * as a long.
	 * @param ps
	 * @param parm
	 * @param val
	 * @throws SQLException
	 */
	protected void psSetLong(PreparedStatement ps, int parm, long val) throws SQLException {
		if (getConnectionDescriptor().isOdbc())
			ps.setInt(parm, (int) val);
		else
			ps.setLong(parm, val);
	}

	/**
	 * Returns an iterator over all available instances.
	 * @return ManagedObjIterator
	 */
	public ManagedObjIterator query() throws QueryException {
		if (this instanceof JDBCResultSetIteratorHelper) {
			ManagedObjIterator it = null;
			PreparedStatement ps = null;
			try {
				ps = checkOutRegisteredStatement(PS_QUERY_ALL);
				it = new JDBCResultSetIterator(this, ps);
			} catch (SQLException sqle) {
				try {
					handleSQLException(sqle);
				} catch (QueryException qe) {
					throw qe;
				} catch (Exception e) {
					throw new QueryException(e);
				}
			} finally {
				// Note: The JDBCResultSetIterator is responsible for
				// check-in of the prepared statement on error or
				// completed iteration.
			}
			return it;
		} else
			throw new ServiceUnavailableException("query");
	}

	/**
	 * Returns a variation of the given string encapsulated
	 * by quotation (') marks.
	 * @param s
	 * @return String
	 */
	protected String quote(String s) {
		return new StringBuffer(s.length() + 2)
			.append('\'').append(s).append('\'')
			.toString();
	}
	
	/**
	 * Returns a variation of the given string with all parameter markers
	 * encapsulated by quotation (') marks.
	 * @param s
	 * @return String
	 */
	protected String quoteParameterMarkers(String s) {
		StringBuffer sb = new StringBuffer(s.length() + 32);
		char ch;
		for (int i = 0; i < s.length(); i++)
			if ((ch = s.charAt(i)) == '?')
				sb.append("'?'");
			else
				sb.append(ch);
		return sb.toString();		
	}

	/**
	 * Registers SQL statement text by key. If necessary, the statement text is
	 * adjusted to satisfy implementation requirements.
	 * @param key
	 * @param sql
	 */
	protected void registerSQL(String key, String sql) {
		getSQLRegistry().put(key, adjustSQL(sql));
	}

	/* (non-Javadoc)
	 * @see org.LexGrid.tracking.LgTrackingEntryServiceIF#removeAll()
	 */
	public void removeAll() throws RemoveException {
		PreparedStatement ps = null;
		try {
			ps = checkOutRegisteredStatement(PS_REMOVE_ALL);
			ps.execute();
		} catch (SQLException sqle) {
			throw new RemoveException(sqle);
		} finally {
			checkInPreparedStatement(ps);
		}
	}

	/**
	 * Returns a list of managed objects based on information derived from
	 * evaluation of all rows in the result set.
	 * @param rs
	 * @return List
	 * @throws SQLException
	 */
	protected List rows2ManagedObj(ResultSet rs) throws SQLException {
		List objs = new ArrayList();
		while (rs.next())
			objs.add(row2ManagedObj(rs));
		return objs;
	}

	/**
	 * Returns a long parameter value from the given prepared statement.
	 * <p>
	 * Note: We treat as an int when using ODBC connectivity since there
	 * appear to be issues with parameters being ignored or dropped when treated
	 * as a long.
	 * @param rs
	 * @param parm
	 * @return long
	 * @throws SQLException
	 */
	protected long rsGetLong(ResultSet rs, int parm) throws SQLException {
		return getConnectionDescriptor().isOdbc()
			? (long) rs.getInt(parm)
			: rs.getLong(parm);
	}

	/**
	 * Returns a string parameter value from the given prepared statement.
	 * <p>
	 * Note: Introduced to handle situations where some implementations
	 * issue a non-specific SQL exception when null values are encountered
	 * in null-capable fields. This method will return null if an
	 * error occurs; no exception is externalized.
	 * @param rs
	 * @param parm
	 * @return String
	 * @throws SQLException
	 */
	protected String rsGetString(ResultSet rs, int parm) {
		String s = null;
		try {
			s = rs.getString(parm);
		} catch (SQLException e) {
		}
		return s;
	}

	/**
	 * Sets the object defining the database connection. 
	 * @param desc JDBCConnectionDescriptor
	 */
	public void setConnectionDescriptor(JDBCConnectionDescriptor desc) {
		_dbDesc = desc;
	}

	/**
	 * Sets the policy used to manage the connection pool.
	 * @param policy JDBCConnectionPoolPolicy
	 */
	public void setConnectionPoolPolicy(JDBCConnectionPoolPolicy policy) {
		_connPolicy = policy;
	}

	/**
	 * Sets the file defining the database configuration.
	 * <p>
	 * Note: Must be set prior to initialization in order to be
	 * recognized by the service.
	 * @return File
	 */
	protected void setDbConfigFile(File f) {
		_dbFile = f;
	}

	/**
	 * Sets the associated CrossDB SQLFactory.
	 * @param factory SQLFactory
	 */
	protected void setSQLFactory(SQLFactory factory) {
		_sqlFactory = factory;
	}

	/**
	 * Sets the SQL platform identity (should correspond to a value
	 * recognized by the CrossDB utilities).
	 * @param platform String
	 */
	public void setSQLPlatform(String platform) {
		setSQLFactory(CrossDBUtil.newSQLFactory(platform));
	}
		
	/**
	 * Shutdown the database; ignore if the database is already
	 * closed or dismounted.
	 */
	protected void shutdown() {
		JDBCConnectionDescriptor dbDesc = getConnectionDescriptor();
		String sql = dbDesc.getShutdownSQL();
		if (sql != null && sql.length() > 0)
			try {
				Connection c =
					DriverManager.getConnection(
						dbDesc.getDbUrl(),
						dbDesc.getDbUid(),
						dbDesc.getDbPwd());
				PreparedStatement ps = c.prepareStatement(sql);
				ps.execute();
			} catch (SQLException e) {
				logger.error("Error on shutdown: " + e.getMessage(), e);
			}
	}
	
}