/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.managedobj.jdbc;

import org.LexGrid.managedobj.ServiceUnavailableException;

import com.crossdb.sql.SQLFactory;

/**
 * Provides common functions related to the CrossDB framework.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
class CrossDBUtil {

	/**
	 * Generates and returns a new CrossDB SQL factory corresponding
	 * to the given repository platform.
	 * <p>
	 * Supported platforms are:
	 * <ul>
	 * <li>hsqldb</li>
	 * <li>mssqlserver</li>
	 * <li>mysql</li>
	 * <li>oracle</li>
	 * <li>sybase</li>
	 * </ul>
	 * @param platform
	 * @return SQLFactory
	 * @throws ServiceUnavailableException
	 */
	static SQLFactory newSQLFactory(String platform)
		throws ServiceUnavailableException {
		SQLFactory factory = null;
		try {
			if (platform.equalsIgnoreCase("hsqldb"))
				factory =
					(SQLFactory) Class
						.forName("com.spaceprogram.sql.hsqldb.HsqldbFactory")
						.newInstance();
			else if (platform.equalsIgnoreCase("mssqlserver"))
				factory =
					(SQLFactory) Class
						.forName("com.thinkvirtual.sql.sqlserver.SQLServerFactory")
						.newInstance();
			else if (platform.equalsIgnoreCase("mysql"))
				factory =
					(SQLFactory) Class
						.forName("com.spaceprogram.sql.mysql.MySQLFactory")
						.newInstance();
			else if (platform.equalsIgnoreCase("oracle"))
				factory =
					(SQLFactory) Class
						.forName("com.thinkvirtual.sql.oracle.OracleSQLFactory")
						.newInstance();
			// Default to sybase
			else
				factory =
					(SQLFactory) Class
						.forName("com.thinkvirtual.sql.sybase.SybaseFactory")
						.newInstance();
		} catch (InstantiationException e) {
		} catch (IllegalAccessException e) {
		} catch (ClassNotFoundException e) {
		}
		return factory;
	}
}