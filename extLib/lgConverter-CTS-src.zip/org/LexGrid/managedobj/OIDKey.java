/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.managedobj;

/**
 * Defines objects to be used as primary keys for OIDBasedObj instances.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public class OIDKey {
	private int _oid = 0;

	/**
	 * Constructor for OIDKey.
	 */
	public OIDKey() {
		super();
	}

	/**
	 * Constructs a new instance based on the oid.
	 * @param oid int
	 */
	public OIDKey(int oid) {
		super();
		setOid(oid);
	}

	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object obj) {
		return getClass().equals(obj.getClass())
			&& hashCode() == obj.hashCode();
	}

	/**
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		return _oid;
	}

	/**
	 * Returns the object identifier.
	 * @return int
	 */
	public int getOid() {
		return _oid;
	}

	/**
	 * Sets the object identifier.
	 * @param oid ing
	 */
	public void setOid(int oid) {
		_oid = oid;
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return new StringBuffer().append(getOid()).toString();
	}

}