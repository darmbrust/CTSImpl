/*
 * Copyright: (c) 2004-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.LexGrid.managedobj;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Abstract superclass in supporting concrete implementations of home services.
 * <p>
 * The home context encapsulates all services required to fulfill
 * the above responsibilities. However, actual implementation is delegated
 * to a specific service provider. This allows for alternative implementations
 * and persistence mechanisms (i.e. LDAP vs JDBC) to be substituted
 * without affecting callers.
 * <p>
 * This superclass implements all methods enforced by the interface
 * and provides a default implementation to throw an exception indicating that
 * the service is not provided. Most, if not all, of these methods will
 * typically be overridden by each concrete subclass.
 * <p>
 * Note: It is anticipated that parameter values will be verified centrally by the
 * object home, when possible, prior to respective calls to the service layer.
 *
 * @author <A HREF="mailto:johnson.thomas@mayo.edu">Thomas M Johnson</A>
 */
public abstract class BaseService implements HomeServiceIF {

	// Broker through which this service is externalized.
	private HomeServiceBroker _broker = null;
	// The parent service, if instantiated relative to another service.
	private BaseService _anchorService = null;
	// Registered services created relative to this service.
	private Map _nServiceMap = null;
	// Cached copy of nested services.
	private List _nServiceCache = null;
	// Track active/close status.
	private boolean _closed = false;

	/**
	 * Default constructor.
	 */
	protected BaseService() {
		super();
	}

	/**
	 * Construct a new instance associated with the given broker.
	 * @param broker
	 * @throws ServiceInitException
	 */
	public BaseService(HomeServiceBroker broker) throws ServiceInitException {
		this();
		setBroker(broker);
		init();
	}

	/**
	 * Constructs a new instance relative to the given service. Connections to
	 * the repository and associated policy are controlled by the anchor
	 * service.
	 * <p>
	 * Note: Relative instances are not directly registered against the
	 * broker, and therefore not directly accessible by applications. Services
	 * are merely provided on behalf of a root service, which is registered
	 * and accessible. In addition, the lifecycle of the relative instance is
	 * tied to its root service (i.e. sub-level services are closed when the
	 * root is closed).
	 * @param anchorService
	 * @throws ServiceInitException
	 */
	public BaseService(BaseService anchorService) throws ServiceInitException {
		this();
		setBroker(anchorService.getBroker());
		anchorService.internalRegisterNestedService(this);
		setAnchorService(anchorService);
		init();
	}

	/**
	 * Notifies the receiver that it is being shutdown and is to release
	 * associated resources and perform required cleanup.
	 * <p>
	 * Note: Superclass method is final. It checks the current state of
	 * the service and, if still active, invokes the closePrim() method to
	 * carry out any specific functions required on service termination.
	 * <p>
	 * Subclasses should override the closePrim() method as appropriate.
	 */
	public final void close() {
		if (!_closed)
			try {
				closePrim();
			} finally {
				_closed = true;
			}
	}

	/**
	 * Primitive method invoked on closure to perform specific
	 * functions required to terminate and cleanup the service.
	 * <p>
	 * Note: Superclass implementation performs cascading closure
	 * of nested services. Subclasses should override as appropriate
	 * to perform additional cleanup.
	 */
	protected void closePrim() {
		try {
			BaseService[] ns = (BaseService[]) getNestedServices().toArray(new BaseService[0]);
			for (int i = 0; i < ns.length; i++) {
				BaseService serv = ns[i];
				serv.close();
			}
		} catch (RuntimeException e) {
			throw new UnexpectedException(e);
		} finally {
			_anchorService = null;
			_broker = null;
			getNestedServiceMap().clear();
			getNestedServices().clear();
		}
	}

	/**
	 * Deregisters a service created and maintained relative to this service;
	 * does nothing if the given service is not registered.
	 * @param service
	 */
	protected void deregisterNestedService(BaseService service) {
		Map classToService = getNestedServiceMap();
		Class clazz = service.getInstanceClass();
		if (classToService.containsKey(clazz))
			classToService.remove(clazz);
	}

	/**
	 * @see java.lang.Object#finalize()
	 */
	protected void finalize() throws Throwable {
		close();
		super.finalize();
	}

	/**
	 * @see org.LexGrid.managedobj.HomeIF#findByPrimaryKey(java.lang.Object)
	 */
	public ManagedObjIF findByPrimaryKey(Object key) throws FindException {
		throw new ServiceUnavailableException();
	}

	/**
	 * @see org.LexGrid.managedobj.HomeIF#findBySecondaryKey(java.lang.Object)
	 */
	public ManagedObjIF findBySecondaryKey(Object key) throws FindException {
		throw new ServiceUnavailableException();
	}

	/**
	 * If nested, returns the service which this service is relative to; null if
	 * this is a top-level service.
	 * @return BaseService
	 */
	public BaseService getAnchorService() {
		return _anchorService;
	}

	/**
	 * Returns the broker against which the service is registered.
	 * @return HomeServiceBroker
	 */
	public HomeServiceBroker getBroker() {
		return _broker;
	}

	/**
	 * Returns the class of object being managed by the service.
	 * @return Class
	 */
	protected abstract Class getInstanceClass();

	/**
	 * Returns the supplemental service registered to handle instances of the
	 * given type.
	 * <p>
	 * Nested services are first checked by exact match (instance class of the
	 * nested service is equal to the given class). If an exact match is not
	 * found, the service managing the nearest possible subsuming class, if any,
	 * is considered a match.
	 * @param clazz
	 * @return BaseService
	 * @throws ServiceUnavailableException
	 */
	public BaseService getNestedService(Class clazz) {
		BaseService match = null;
		Map serviceMap = getNestedServiceMap();
		BaseService exact_lookup = (BaseService) serviceMap.get(clazz);
		if (exact_lookup == null) {
			Class match_class = null;
			int match_proximity = Integer.MAX_VALUE;
			// Obtain possible matching classes
			Iterator classes = serviceMap.keySet().iterator();
			// Process one by one to find closest match,
			// or stop if we encountered an immediate superclass ...
			while (classes.hasNext() && match_proximity > 1) {
				Class c = (Class) classes.next();
				if (c == clazz) {
					match_class = c;
					match_proximity = 1;
				} else if (c.isAssignableFrom(clazz)) {
					Class ctemp = clazz;
					int proximity = 2;
					while ((ctemp = ctemp.getSuperclass()) != c
						&& ctemp != null)
						proximity++;
					// Was this match closer than any previous?
					if (match_proximity >= proximity) {
						match_class = ctemp;
						match_proximity = proximity;
					}
				}
			}
			// If found, remember in order to bypass proximity checking
			// on future requests...
			if (match_class != null) {
				match = (BaseService) serviceMap.get(match_class);
				serviceMap.put(clazz, match = match.getNestedService(clazz));
			}
		} else
			match = exact_lookup;
		if (match == null)
			throw new ServiceUnavailableException(
				"Nested service not registered for class " + clazz.getName());
		return match;
	}

	/**
	 * Returns a mapping from contained object types to the services used to
	 * maintain them.
	 * @return Map
	 */
	protected Map getNestedServiceMap() {
		if (_nServiceMap == null)
			_nServiceMap = new HashMap();
		return _nServiceMap;
	}

	/**
	 * Returns the collection of services created relative to this instance.
	 * <p>
	 * Note: Relative instances are not directly registered against the broker,
	 * and therefore not directly accessible by applications. Services are
	 * merely provided on behalf of the root service, which is registered and
	 * accessible. In addition, the lifecycle of the relative instance is
	 * managed by the root service (i.e. sub-level services are closed when the
	 * root is closed).
	 * @return List
	 */
	public List getNestedServices() {
		if (_nServiceCache == null) {
			_nServiceCache = new ArrayList(32);
			Collection immediateChildren = getNestedServiceMap().values();
			_nServiceCache.addAll(immediateChildren);
			Iterator children = immediateChildren.iterator();
			while (children.hasNext())
				_nServiceCache.addAll(
					((BaseService) children.next()).getNestedServices());
		}
		return _nServiceCache;
	}

	/**
	 * Invoked during construction to initialize the service.
	 * @throws ServiceInitException
	 */
	protected void init() throws ServiceInitException {
		initNestedServices();
	}

	/**
	 * Extension point for subclasses to initialize nested services required
	 * for resolution and maintenance of managed objects.
	 * @throws ServiceInitException
	 */
	protected void initNestedServices() throws ServiceInitException {
	}

	/**
	 * Registers a service created and maintained relative to this service.
	 * <p>
	 * Note: This is an internal helper method, invoked during object construction,
	 * and is not intended for general consumption.
	 * <p>
	 * Note: Nested services are registered under the object type maintained by
	 * the service. An exception is signalled if another service has already
	 * been registered for the object type handled by the given service.
	 * @param service
	 */
	public void internalRegisterNestedService(BaseService service) {
		Class clazz = service.getInstanceClass();
		if (getNestedServiceMap().get(clazz) != null)
			throw new ServiceAlreadyRegisteredException(
				"Nested service already registered for class "
					+ clazz.getName());
		getNestedServiceMap().put(clazz, service);
		_nServiceCache = null;
	}

	/**
	 * @see org.LexGrid.managedobj.HomeIF#insert(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public void insert(ManagedObjIF obj)
		throws InsertException, ObjectAlreadyExistsException {
		throw new ServiceUnavailableException();
	}

	/**
	 * @see org.LexGrid.managedobj.HomeServiceIF#newInstance()
	 */
	public ManagedObjIF newInstance() {
		ManagedObjIF obj = null;
		try {
			obj = (ManagedObjIF) getInstanceClass().newInstance();
		} catch (InstantiationException e) {
		} catch (IllegalAccessException e) {
		}
		return obj;
	}

	/**
	 * @see org.LexGrid.managedobj.HomeIF#remove(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public void remove(ManagedObjIF obj)
		throws RemoveException, ObjectNotFoundException {
		throw new ServiceUnavailableException();
	}

	/**
	 * Returns the service responsible for inserting, updating, and removing
	 * objects of the given type.
	 * <p>
	 * If the immediate service is not an exact match, all registered services
	 * (nested and top-level) are checked. If an exact match is found, that
	 * service is returned. If a compatible service is found, it is returned.
	 * Otherwise, the immediate service is returned.
	 * @param clazz Class
	 * @return BaseService
	 */
	protected BaseService serviceFor(Class clazz) {
		BaseService match = null;
		if (getInstanceClass() != clazz)
			try {
				match = getNestedService(clazz);
				if (match == null) {
					Iterator it = getBroker().getServices().iterator();
					BaseService bs;
					while (it.hasNext()) {
						bs = (BaseService) it.next();
						if (bs.getInstanceClass().equals(clazz))
							return bs;
					}
				}
			} catch (ServiceUnavailableException e) {
			}
		return match != null ? match : this;
	}

	/**
	 * If nested, sets the service which this service is relative to; null if
	 * this is a top-level service.
	 * @param service BaseService
	 */
	protected void setAnchorService(BaseService service) {
		_anchorService = service;
	}

	/**
	 * Sets the broker against which the service is registered.
	 * @param broker HomeServiceBroker
	 */
	protected void setBroker(HomeServiceBroker broker) {
		_broker = broker;
	}

	/**
	 * @see org.LexGrid.managedobj.HomeIF#update(org.LexGrid.managedobj.ManagedObjIF)
	 */
	public void update(ManagedObjIF obj)
		throws UpdateException, ObjectNotFoundException {
		throw new ServiceUnavailableException();
	}

	/**
	 * Ensures that the returned iterator implements the
	 * ManagedObjIterator interface.
	 * @param candidate
	 * @return ManagedObjIterator
	 */
	protected ManagedObjIterator manage(Iterator candidate) {
		return
			candidate == null
				? null
				: (candidate instanceof ManagedObjIterator
					? (ManagedObjIterator) candidate
					: new ManagedObjIteratorWrapper(candidate));
	}
	
}