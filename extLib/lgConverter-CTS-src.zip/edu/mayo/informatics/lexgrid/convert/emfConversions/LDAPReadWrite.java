/*
 * Copyright: (c) 2004-2005 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.mayo.informatics.lexgrid.convert.emfConversions;

import java.util.Hashtable;

import javax.naming.Context;

import org.LexGrid.emf.codingSchemes.CodingSchemeType;
import org.LexGrid.emf.codingSchemes.CodingschemesFactory;
import org.LexGrid.emf.codingSchemes.persistence.CodingSchemeHome;
import org.LexGrid.managedobj.HomeServiceBroker;
import org.LexGrid.managedobj.ObjectNotFoundException;
import org.LexGrid.managedobj.ServiceInitException;
import org.LexGrid.managedobj.jndi.LdapContextDescriptor;
import org.LexGrid.messaging.LgMessageDirectorIF;
import org.LexGrid.persistence.LgModelPersistence;
import org.LexGrid.persistence.ldap.CodingSchemeService;
import org.apache.log4j.Logger;

import edu.mayo.informatics.lexgrid.convert.emfConversions.emfInterfaces.EMFRead;
import edu.mayo.informatics.lexgrid.convert.emfConversions.emfInterfaces.EMFWrite;
import edu.mayo.informatics.lexgrid.convert.utility.Constants;

/**
 * Reads and writes LDAP <-> EMF
 * 
 * @author <A HREF="mailto:armbrust.daniel@mayo.edu">Dan Armbrust</A>
 * @version subversion $Revision: 3959 $ checked in on $Date: 2006-11-26 20:25:58 -0600 (Sun, 26 Nov 2006) $
 */
public class LDAPReadWrite implements EMFRead, EMFWrite
{
    private static Logger log = Logger.getLogger("convert.LdapReadWrite");

    String                ldapUserName, ldapPassword, ldapAddress, ldapService;
    LgMessageDirectorIF   messages_;

    public LDAPReadWrite(String ldapUsername, String ldapPassword, String ldapAddress, String ldapService,
            LgMessageDirectorIF messages)
    {
        this.ldapUserName = ldapUsername;
        this.ldapPassword = ldapPassword;
        this.ldapAddress = ldapAddress;
        this.ldapService = ldapService;
        this.messages_ = messages;

    }

    public CodingSchemeType readCodingScheme(String codingScheme) throws Exception
    {
        try
        {
            HomeServiceBroker broker = new HomeServiceBroker();

            CodingSchemeHome context = new CodingSchemeHome(broker);
            broker.registerService(context, getService(broker));

             try
            {
                // Get the source scheme (complete representation) from original context
                CodingSchemeType scheme = (CodingSchemeType) context.findByPrimaryKey(codingScheme);
                return scheme;

            }
            finally
            {
                broker.close();
            }
        }
        catch (Exception e)
        {
            log.error("Failed...", e);
            messages_.fatalAndThrowException("Failed - " + e.toString() + " see log file.", e);
            return null;
        }
    }

    public void writeCodingScheme(CodingSchemeType codingScheme) throws Exception
    {
        try
        {
            HomeServiceBroker broker = new HomeServiceBroker();

            CodingSchemeHome context = new CodingSchemeHome(broker);
            broker.registerService(context, getService(broker));

            try
            {
                // Insert to destination context
                context.insert(codingScheme);
            }
            finally
            {
                broker.close();
            }
        }
        catch (Exception e)
        {
            log.error("Failed...", e);
            messages_.fatalAndThrowException("Failed - " + e.toString() + " see log file.", e);
        }
    }

    public void clearCodingScheme(String codingScheme) throws Exception
    {
        try
        {
            HomeServiceBroker broker = new HomeServiceBroker();

            CodingSchemeHome context = new CodingSchemeHome(broker);
            broker.registerService(context, getService(broker));

            try
            {
                try
                {
                    CodingSchemeType temp = CodingschemesFactory.eINSTANCE.createCodingSchemeType();
                    temp.setCodingScheme(codingScheme);
                    context.remove(temp);
                }
                catch (ObjectNotFoundException e)
                {
                    messages_.info("*** Nothing found ... continuing");
                }

            }
            finally
            {
                broker.close();
            }
        }
        catch (Exception e)
        {
            log.error("Failed...", e);
            messages_.fatalAndThrowException("Failed - " + e.toString() + " see log file.", e);
        }
    }

    private LgModelPersistence getService(HomeServiceBroker broker) throws ServiceInitException
    {
        //make sure that the service and address don't end up with extra slashes
        while (ldapService.charAt(0) == '/' || ldapService.charAt(0) == '\\')
        {
            ldapService = ldapService.substring(1, ldapService.length());
        }
        
        while (ldapAddress.charAt(ldapAddress.length() - 1) == '/' || ldapAddress.charAt(ldapAddress.length() -1) == '\\')
        {
            ldapAddress = ldapAddress.substring(0, ldapAddress.length() - 1);
        }
        
        LdapContextDescriptor desc = new LdapContextDescriptor();
        Hashtable env = desc.getEnvironment();
        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.PROVIDER_URL, ldapAddress + "/dc=codingSchemes," + ldapService);
        env.put(Context.SECURITY_PRINCIPAL, ldapUserName);
        env.put(Context.SECURITY_CREDENTIALS, ldapPassword);
        // Note: final 'false' provides up-front resolution of features.
        // We do this in this particular program because the test relies on
        // a complete scheme representation for insertion to the destination context.
        // Basically, we can't associate the same object with two contexts,
        // where on-demand resolution is performed within one context and insertion
        // is carried out in another context.
        CodingSchemeService temp = new CodingSchemeService(broker, null, desc, null, false);
        
        temp.setPageSize(Constants.ldapPageSize);
        return temp;
    }

    public CodingSchemeType readCodingScheme() throws Exception
    {
          throw new java.lang.UnsupportedOperationException(
              "Method readCodingScheme not yet implemented.");
    }

    public CodingSchemeType[] readAllCodingSchemes() throws Exception
    {
          throw new java.lang.UnsupportedOperationException(
              "Method readAllCodingSchemes not yet implemented.");
    }

}