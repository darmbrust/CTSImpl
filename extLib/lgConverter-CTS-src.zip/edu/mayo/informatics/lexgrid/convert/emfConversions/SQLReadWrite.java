/*
 * Copyright: (c) 2004-2005 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.mayo.informatics.lexgrid.convert.emfConversions;

import org.LexGrid.emf.codingSchemes.CodingSchemeType;
import org.LexGrid.emf.codingSchemes.CodingschemesFactory;
import org.LexGrid.emf.codingSchemes.persistence.CodingSchemeHome;
import org.LexGrid.managedobj.HomeServiceBroker;
import org.LexGrid.managedobj.ServiceInitException;
import org.LexGrid.managedobj.jdbc.JDBCConnectionDescriptor;
import org.LexGrid.messaging.LgMessageDirectorIF;
import org.LexGrid.persistence.LgModelPersistence;
import org.LexGrid.persistence.sql.CodingSchemeService;
import org.apache.log4j.Logger;

import edu.mayo.informatics.lexgrid.convert.emfConversions.emfInterfaces.EMFRead;
import edu.mayo.informatics.lexgrid.convert.emfConversions.emfInterfaces.EMFWrite;
import edu.mayo.informatics.lexgrid.convert.utility.Constants;
import edu.mayo.informatics.lexgrid.convert.utility.MessageRedirector;

/**
 * Reads and Writes SQL <-> EMF
 * 
 * @author <A HREF="mailto:armbrust.daniel@mayo.edu">Dan Armbrust</A>
 * @version subversion $Revision: 3959 $ checked in on $Date: 2006-11-26 20:25:58 -0600 (Sun, 26 Nov 2006) $
 */
public class SQLReadWrite implements EMFRead, EMFWrite
{
    private static Logger log = Logger.getLogger("convert.SQLReadWrite");
    LgMessageDirectorIF   messages_;

    private String        sqlServer, sqlDriver, sqlUsername, sqlPassword, tablePrefix;
    boolean failOnAllErrors;

    public SQLReadWrite(String sqlServer, String sqlDriver, String sqlUsername, String sqlPassword, String tablePrefix, boolean failOnAllErrors,
            LgMessageDirectorIF messages)
    {
        this.sqlServer = sqlServer;
        this.sqlDriver = sqlDriver;
        this.sqlUsername = sqlUsername;
        this.sqlPassword = sqlPassword;
        this.tablePrefix = tablePrefix;
        this.messages_ = messages;
        this.failOnAllErrors = failOnAllErrors;
    }

    /*
     * (non-Javadoc)
     * 
     * @see edu.mayo.informatics.lexgrid.convert.emfConversions.read.EMFRead#readCodingScheme(java.lang.String)
     */
    public CodingSchemeType readCodingScheme(String codingScheme) throws Exception
    {
        try
        {
            HomeServiceBroker broker = new HomeServiceBroker();
            CodingSchemeHome context = new CodingSchemeHome(broker);
            broker.registerService(context, getService(broker));

            try
            {
                // Get the source scheme (complete representation) from original context
                CodingSchemeType scheme = (CodingSchemeType) context.findByPrimaryKey(codingScheme);
                return scheme;
            }
            finally
            {
                broker.close();
            }
        }
        catch (Exception e)
        {
            log.error("Failed...", e);
            messages_.fatalAndThrowException("Failed - " + e.toString() + " see log file.", e);
            return null;
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see edu.mayo.informatics.lexgrid.convert.emfConversions.read.EMFWrite#writeCodingScheme(org.lexgrid.commons.emf.codingschemes.CodingScheme)
     */
    public void writeCodingScheme(CodingSchemeType codingScheme) throws Exception
    {
        try
        {
            HomeServiceBroker broker = new HomeServiceBroker();

            CodingSchemeHome context = new CodingSchemeHome(broker);
            broker.registerService(context, getService(broker));
            try
            {
                // Insert to destination context
                context.insert(codingScheme);

            }
            finally
            {
                broker.close();
            }
        }
        catch (Exception e)
        {
            log.error("Failed...", e);
            messages_.fatalAndThrowException("Failed - " + e.toString() + " see log file.", e);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see edu.mayo.informatics.lexgrid.convert.emfConversions.read.EMFWrite#clearCodingScheme(java.lang.String)
     */
    public void clearCodingScheme(String codingScheme) throws Exception
    {
        try
        {
            HomeServiceBroker broker = new HomeServiceBroker();

            CodingSchemeHome context = new CodingSchemeHome(broker);
            broker.registerService(context, getService(broker));
            try
            {
                CodingSchemeType foo = CodingschemesFactory.eINSTANCE.createCodingSchemeType();
                foo.setCodingScheme(codingScheme);
                context.remove(foo);
                context.close();
            }
            finally
            {
                broker.close();
            }
        }
        catch (Exception e)
        {
            log.error("Failed...", e);
            messages_.fatalAndThrowException("Failed - " + e.toString() + " see log file.", e);
        }
    }

    private LgModelPersistence getService(HomeServiceBroker broker) throws ServiceInitException
    {
        JDBCConnectionDescriptor desc = new JDBCConnectionDescriptor();
        desc.setDbUid(sqlUsername);
        desc.setDbPwd(sqlPassword);
        desc.setDbUrl(sqlServer);
        desc.setUseUTF8(true);
        desc.setAutoRetryFailedConnections(true);
        try
        {
            desc.setDbDriver(sqlDriver);
        }
        catch (ClassNotFoundException e)
        {
            throw new ServiceInitException("The requested driver was not found on the classpath");
        }

        CodingSchemeService temp = new CodingSchemeService(broker, desc, false, tablePrefix, failOnAllErrors,
                new MessageRedirector(messages_));
        temp.setPageSize(Constants.mySqlBatchSize);
        return temp;
    }

    public CodingSchemeType readCodingScheme() throws Exception
    {
        throw new java.lang.UnsupportedOperationException("Method readCodingScheme not yet implemented.");
    }

    public CodingSchemeType[] readAllCodingSchemes() throws Exception
    {
        throw new java.lang.UnsupportedOperationException("Method readAllCodingSchemes not yet implemented.");
    }

}