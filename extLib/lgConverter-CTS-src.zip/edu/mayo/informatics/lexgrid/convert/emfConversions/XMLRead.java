/*
 * Copyright: (c) 2004-2005 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.mayo.informatics.lexgrid.convert.emfConversions;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;

import org.LexGrid.emf.base.xml.LgXMLResourceImpl;
import org.LexGrid.emf.codingSchemes.CodingSchemeType;
import org.LexGrid.emf.codingSchemes.impl.CodingSchemeTypeImpl;
import org.LexGrid.emf.codingSchemes.impl.CodingSchemesTypeImpl;
import org.LexGrid.messaging.LgMessageDirectorIF;
import org.apache.log4j.Logger;
import org.eclipse.emf.common.util.URI;

import edu.mayo.informatics.lexgrid.convert.emfConversions.emfInterfaces.EMFRead;

/**
 * Reads XML -> EMF
 * 
 * @author <A HREF="mailto:armbrust.daniel@mayo.edu">Dan Armbrust</A>
 * @version subversion $Revision: 4178 $ checked in on $Date: 2006-12-13 15:27:16 -0600 (Wed, 13 Dec 2006) $
 */
public class XMLRead implements EMFRead
{
    private String              xmlFileLocation;
    private InputStream         inputStream_;
    private static Logger       log = Logger.getLogger("convert.XMLReadWrite");
    private LgMessageDirectorIF messages_;

    public XMLRead(String xmlFileLocation, LgMessageDirectorIF messages, boolean failOnAllErrors)
    {
        //TODO failOnAllErrors should be used.
        this.xmlFileLocation = xmlFileLocation;
        this.messages_ = messages;
    }
    
    public XMLRead(InputStream  inputStream, LgMessageDirectorIF messages, boolean failOnAllErrors)
    {
        //TODO failOnAllErrors should be used.
        this.inputStream_ = inputStream;;
        this.messages_ = messages;
    }

    public CodingSchemeType[] readAllCodingSchemes() throws Exception
    {
        LgXMLResourceImpl xml = null;
        try
        {
            // Get the source scheme (complete representation) from original context

            if (xmlFileLocation != null)
            {
                xml = new LgXMLResourceImpl(URI.createFileURI(xmlFileLocation));
                xml.load();
            }
            else if (inputStream_ != null)
            {
                xml = new LgXMLResourceImpl();
                xml.doLoad(inputStream_, xml.getDefaultLoadOptions());
            }
            else
            {
                throw new Exception("User error");
            }

            if (xml.getContents().get(0) instanceof CodingSchemeTypeImpl)
            {
                return new CodingSchemeType[]{(CodingSchemeTypeImpl) xml.getContents().get(0)};
            }
            else if (xml.getContents().get(0) instanceof CodingSchemesTypeImpl)
            {
                CodingSchemesTypeImpl temp = (CodingSchemesTypeImpl) xml.getContents().get(0);

                ArrayList allCodingSchemes = new ArrayList();

                Iterator codingSchemes = temp.getCodingScheme().iterator();
                while (codingSchemes.hasNext())
                {
                    allCodingSchemes.add((CodingSchemeTypeImpl) codingSchemes.next());
                }

                return (CodingSchemeType[]) allCodingSchemes.toArray(new CodingSchemeType[allCodingSchemes.size()]);

            }
            else
            {
                return new CodingSchemeType[]{};
            }
        }

        catch (Exception e)
        {
            log.error("Failed...", e);
            messages_.fatalAndThrowException("Failed - " + e.toString() + " see log file.", e);
            return null;
        }
    }

    public CodingSchemeType readCodingScheme(String codingScheme) throws Exception
    {
        throw new java.lang.UnsupportedOperationException("Method readCodingScheme not yet implemented.");
    }

    public CodingSchemeType readCodingScheme() throws Exception
    {
        throw new java.lang.UnsupportedOperationException("Method readCodingScheme not yet implemented.");
    }

}