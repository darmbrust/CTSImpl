/*
 * Copyright: (c) 2002-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.mayo.informatics.lexgrid.convert.indexer;

import org.apache.commons.codec.language.DoubleMetaphone;
import org.apache.log4j.Logger;
import org.apache.lucene.analysis.PerFieldAnalyzerWrapper;

import edu.mayo.informatics.indexer.api.IndexerService;
import edu.mayo.informatics.indexer.api.exceptions.InternalErrorException;
import edu.mayo.informatics.indexer.api.generators.DocumentFromStringsGenerator;
import edu.mayo.informatics.indexer.lucene.analyzers.EncoderAnalyzer;
import edu.mayo.informatics.indexer.lucene.analyzers.NormAnalyzer;
import edu.mayo.informatics.indexer.lucene.analyzers.SnowballAnalyzer;
import edu.mayo.informatics.indexer.lucene.analyzers.StringAnalyzer;
import edu.mayo.informatics.indexer.lucene.analyzers.WhiteSpaceLowerCaseAnalyzer;
import edu.mayo.informatics.lexgrid.convert.utility.Constants;

/**
 * Base Lucene Loader code.
 * 
 * @author <A HREF="mailto:armbrust.daniel@mayo.edu">Dan Armbrust</A>
 */

public abstract class LuceneLoaderCode
{

    protected IndexerService             indexerService_;
    protected String                     simpleIndexName_;
    // protected String normIndexName_;
    protected boolean                    useCompoundFile_        = false;
    private DocumentFromStringsGenerator generator_;
    private int                          indexDocCount           = 0;
    protected boolean                    normEnabled_            = true;
    protected boolean                    doubleMetaphoneEnabled_ = true;
    protected boolean                    stemmingEnabled_        = true;
    protected final Logger               logger                  = Logger.getLogger("CTS.loader");
    private final String                 normPrefix_             = "norm_";
    private final String                 doubleMetaphonePrefix_  = "dm_";
    private final String                 stemmingPrefix_         = "stem_";
    
    private String                       lastConceptCode         = "";
    protected boolean                    createBoundryDocuments  = true;

    public static final String           STRING_TOKEINZER_TOKEN  = "<:>";
    public static final String           QUALIFIER_NAME_VALUE_SPLIT_TOKEN = ":";
    
    //TODO add a GUI option for the codeBoundry stuff.

    protected void openIndexesClearExisting(String[] codingSchemes) throws Exception
    {
        indexerService_.forceUnlockIndex(simpleIndexName_);
        indexerService_.openBatchRemover(simpleIndexName_);

        for (int i = 0; i < codingSchemes.length; i++)
        {
            logger.info("clearing index of code system " + codingSchemes[i]);
            indexerService_.removeDocument(simpleIndexName_, "codingSchemeName", codingSchemes[i]);
        }

        indexerService_.closeBatchRemover(simpleIndexName_);
        openIndexes();
    }

    protected void openIndexes() throws Exception
    {
        indexerService_.forceUnlockIndex(simpleIndexName_);
        indexerService_.openWriter(simpleIndexName_, false);
        indexerService_.setUseCompoundFile(simpleIndexName_, useCompoundFile_);
        indexerService_.setMaxBufferedDocs(simpleIndexName_, 500);
        indexerService_.setMergeFactor(simpleIndexName_, 20);
    }

    protected void closeIndexes() throws Exception
    {
        indexerService_.optimizeIndex(simpleIndexName_);
        indexerService_.closeWriter(simpleIndexName_);
    }

    protected void addConcept(String codingSchemeName, String codingSchemeId, String conceptCode, String propertyType,
            String property, String propertyValue, Boolean isActive, String presentationFormat, String language,
            Boolean isPreferred, String conceptStatus, String propertyId, String degreeOfFidelity,
            Boolean matchIfNoContext, String representationalForm, String[] sources, String[] usageContexts,
            Qualifier[] qualifiers) throws Exception
    {
        if (createBoundryDocuments)
        {
            String key = codingSchemeName + ":" + codingSchemeId + ":" + conceptCode;

            if (!lastConceptCode.equals(key))
            {
                addConceptBoundryDocument(codingSchemeName, codingSchemeId);
                lastConceptCode = key;
            }
        }
         
        StringBuffer fields = new StringBuffer();
        generator_.startNewDocument(codingSchemeName + "-" + indexDocCount);
        generator_.addTextField("codingSchemeName", codingSchemeName, true, true, false);
        fields.append("codingSchemeName ");
        generator_.addTextField("codingSchemeId", codingSchemeId, true, true, false);
        fields.append("codingSchemeId ");
        generator_.addTextField("conceptCodeTokenized", conceptCode, false, true, true);
        fields.append("conceptCodeTokenized ");
        generator_.addTextField("conceptCode", conceptCode, true, true, false);
        fields.append("conceptCode ");
        generator_.addTextField("conceptCodeLC", conceptCode.toLowerCase(), false, true, false);
        fields.append("conceptCodeLC ");

        String tempPropertyType;
        if (propertyType == null || propertyType.length() == 0)
        {
            if (property.equalsIgnoreCase("textualPresentation"))
            {
                tempPropertyType = "presentation";
            }
            else if (property.equals("definition"))
            {
                tempPropertyType = "definition";
            }
            else if (property.equals("comment"))
            {
                tempPropertyType = "comment";
            }
            else if (property.equals("instruction"))
            {
                tempPropertyType = "instruction";
            }
            else
            {
                tempPropertyType = "property";
            }
        }
        else
        {
            tempPropertyType = propertyType;
        }
        generator_.addTextField("propertyType", tempPropertyType, true, true, false);
        fields.append("propertyType ");
        
        generator_.addTextField("property", property, true, true, false);
        fields.append("property ");

        if (propertyValue != null && propertyValue.length() > 0)
        {
            generator_.addTextField("propertyValue", propertyValue, true, true, true);
            fields.append("propertyValue ");
            
            // This copy of the content is required for making "startsWith" or "exactMatch" types of queries
            generator_.addTextField("untokenizedLCPropertyValue", propertyValue.toLowerCase(), false, true, false);
            fields.append("untokenizedLCPropertyValue ");
            
            if (normEnabled_)
            {
                generator_.addTextField(normPrefix_ + "propertyValue", propertyValue, false, true, true);
                fields.append(normPrefix_ + "propertyValue ");
            }
            
            if (doubleMetaphoneEnabled_)
            {
                generator_.addTextField(doubleMetaphonePrefix_ + "propertyValue", propertyValue, false, true, true);
                fields.append(doubleMetaphonePrefix_ + "propertyValue ");
            }
            
            if (stemmingEnabled_)
            {
                generator_.addTextField(stemmingPrefix_ + "propertyValue", propertyValue, false, true, true);
                fields.append(stemmingPrefix_ + "propertyValue ");
            }
        }

        if (isActive != null)
        {
            if (isActive.booleanValue())
            {
                generator_.addTextField("isActive", "T", true, true, false);
            }
            else
            {
                generator_.addTextField("isActive", "F", true, true, false);
            }

            fields.append("isActive ");
        }
        if (isPreferred != null)
        {
            if (isPreferred.booleanValue())
            {
                generator_.addTextField("isPreferred", "T", true, true, false);
            }
            else
            {
                generator_.addTextField("isPreferred", "F", true, true, false);
            }
            fields.append("isPreferred ");
        }
        if (presentationFormat != null && presentationFormat.length() > 0)
        {
            generator_.addTextField("presentationFormat", presentationFormat, true, true, false);
            fields.append("presentationFormat ");
        }

        // in ldap and sql, languages are optional (missing means default. But we don't allow that here
        // you must supply the lanaguage (send in the default if a concept doesn't have one)
        if (language != null && language.length() > 0)
        {
            generator_.addTextField("language", language, true, true, false);
            fields.append("language ");
        }
        else
        {
            throw new Exception("Language is required");
        }

        if (conceptStatus != null && conceptStatus.length() > 0)
        {
            generator_.addTextField("conceptStatus", conceptStatus, true, true, false);
            fields.append("conceptStatus ");
        }

        if (propertyId != null && propertyId.length() > 0)
        {
            generator_.addTextField("propertyId", propertyId, true, true, false);
            fields.append("propertyId ");
        }

        if (degreeOfFidelity != null && degreeOfFidelity.length() > 0)
        {
            generator_.addTextField("degreeOfFidelity", degreeOfFidelity, true, true, false);
            fields.append("degreeOfFidelity ");
        }

        if (representationalForm != null && representationalForm.length() > 0)
        {
            generator_.addTextField("representationalForm", representationalForm, true, true, false);
            fields.append("representationalForm ");
        }

        if (matchIfNoContext != null)
        {
            if (matchIfNoContext.booleanValue())
            {
                generator_.addTextField("matchIfNoContext", "T", true, true, false);
            }
            else
            {
                generator_.addTextField("matchIfNoContext", "F", true, true, false);
            }

            fields.append("matchIfNoContext ");
        }
        
        if (sources != null && sources.length > 0)
        {
            StringBuffer temp = new StringBuffer();
            for (int i = 0; i < sources.length; i++)
            {
                temp.append(sources[i]);
                if (i + 1 < sources.length)
                {
                    temp.append(STRING_TOKEINZER_TOKEN);
                }
            }
            generator_.addTextField("sources", temp.toString(), false, true, true);
            fields.append("sources ");
        }
        
        if (usageContexts != null && usageContexts.length > 0)
        {
            StringBuffer temp = new StringBuffer();
            for (int i = 0; i < usageContexts.length; i++)
            {
                temp.append(usageContexts[i]);
                if (i + 1 < usageContexts.length)
                {
                    temp.append(STRING_TOKEINZER_TOKEN);
                }
            }
            generator_.addTextField("usageContexts", temp.toString(), false, true, true);
            fields.append("usageContexts ");
        }
        
        if (qualifiers != null && qualifiers.length > 0)
        {
            StringBuffer temp = new StringBuffer();
            for (int i = 0; i < qualifiers.length; i++)
            {
                temp.append(qualifiers[i].qualifierName + QUALIFIER_NAME_VALUE_SPLIT_TOKEN + qualifiers[i].qualifierValue);
                if (i + 1 < qualifiers.length)
                {
                    temp.append(STRING_TOKEINZER_TOKEN);
                }
            }
            generator_.addTextField("qualifiers", temp.toString(), false, true, true);
            fields.append("qualifiers ");
        }

        generator_.addTextField("fields", fields.toString(), true, true, true);

        logger.debug(indexDocCount + "  " + generator_.toString());
        indexerService_.addDocument(simpleIndexName_, generator_.getDocument());

        indexDocCount++;
    }
 
    /*
     * caGrid used these "boundry" documents to speed up multiple successive queries.
     * A boundry document should be added whenever a new concept code is started.
     */
    protected void addConceptBoundryDocument(String codingSchemeName, String codingSchemeId) throws Exception
    {
        StringBuffer fields = new StringBuffer();
        generator_.startNewDocument(codingSchemeName + "-" + indexDocCount);
        generator_.addTextField("codingSchemeName", codingSchemeName, true, true, false);
        fields.append("codingSchemeName ");
        generator_.addTextField("codingSchemeId", codingSchemeId, true, true, false);
        fields.append("codingSchemeId ");
        generator_.addTextField("codeBoundry", "T", false, true, false);
        fields.append("codeBoundry ");
       

        generator_.addTextField("fields", fields.toString(), true, true, true);

        logger.debug(indexDocCount + "  " + generator_.toString());
        indexerService_.addDocument(simpleIndexName_, generator_.getDocument());

        indexDocCount++;
    }

    protected void initIndexes(String indexName, String indexLocation) throws InternalErrorException
    {
        indexerService_ = new IndexerService(indexLocation, false);
        simpleIndexName_ = indexName;
        // normIndexName_ = indexName + "_Normed";

        // no stop words, default character removal set.
        PerFieldAnalyzerWrapper analyzer = new PerFieldAnalyzerWrapper(new WhiteSpaceLowerCaseAnalyzer(new String[]{},
                WhiteSpaceLowerCaseAnalyzer.getDefaultCharRemovalSet(), Constants.lexGridWhiteSpaceIndexSet));

        if (doubleMetaphoneEnabled_)
        {
            EncoderAnalyzer temp = new EncoderAnalyzer(new DoubleMetaphone(), new String[]{},
                    WhiteSpaceLowerCaseAnalyzer.getDefaultCharRemovalSet(), Constants.lexGridWhiteSpaceIndexSet);
            analyzer.addAnalyzer(doubleMetaphonePrefix_ + "propertyValue", temp);
        }

        if (normEnabled_)
        {
            try
            {
                NormAnalyzer temp = new NormAnalyzer(false, new String[]{}, WhiteSpaceLowerCaseAnalyzer
                        .getDefaultCharRemovalSet(), Constants.lexGridWhiteSpaceIndexSet);
                analyzer.addAnalyzer(normPrefix_ + "propertyValue", temp);
            }
            catch (NoClassDefFoundError e)
            {
                // norm is not available
                normEnabled_ = false;
                logger
                        .warn(
                              "Normalized index will not be built becaues Norm could not be launched.  Is Norm (lvg) on the classpath?",
                              e);
            }
        }
        
        if (stemmingEnabled_)
        {
            SnowballAnalyzer temp = new SnowballAnalyzer(false, "English", new String[]{},
                    WhiteSpaceLowerCaseAnalyzer.getDefaultCharRemovalSet(), Constants.lexGridWhiteSpaceIndexSet);
            analyzer.addAnalyzer(stemmingPrefix_ + "propertyValue", temp);
        }
        
        //these fields just get simple analyzing.
        StringAnalyzer sa = new StringAnalyzer(STRING_TOKEINZER_TOKEN);
        analyzer.addAnalyzer("sources", sa);
        analyzer.addAnalyzer("usageContexts", sa);
        analyzer.addAnalyzer("qualifiers", sa);

        indexerService_.createIndex(simpleIndexName_, analyzer);

        generator_ = new DocumentFromStringsGenerator();
    }
    
    protected class Qualifier
    {
        String qualifierName;
        String qualifierValue;
        
        public Qualifier(String qualifierName, String qualifierValue)
        {
            this.qualifierName = qualifierName;
            this.qualifierValue = qualifierValue;
        }
    }

}
