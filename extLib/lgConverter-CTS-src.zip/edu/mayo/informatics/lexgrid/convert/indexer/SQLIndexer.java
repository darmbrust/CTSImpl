/*
 * Copyright: (c) 2002-2006 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.mayo.informatics.lexgrid.convert.indexer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Hashtable;

import org.LexGrid.messaging.LgMessageDirectorIF;
import org.LexGrid.util.sql.DBUtility;
import org.LexGrid.util.sql.GenericSQLModifier;
import org.LexGrid.util.sql.lgTables.SQLTableConstants;
import org.LexGrid.util.sql.lgTables.SQLTableUtilities;

import edu.mayo.informatics.lexgrid.convert.utility.Constants;

/**
 * Code for building Lucene index from LexGrid SQL tables.
 * 
 * @author <A HREF="mailto:armbrust.daniel@mayo.edu">Dan Armbrust</A>
 */

public class SQLIndexer extends LuceneLoaderCode
{
    private Connection         sqlConnection_;
    private SQLTableConstants  stc_;
    private GenericSQLModifier gsm_;
    private int                batchSize_ = 5000;
    private String             defaultLanguage_;
    private String             codingSchemeId_;
    private LgMessageDirectorIF    messageDirector_;

//    /**
//     * Build a Lucene index from a SQL table, all parameters are loaded from a properties file.
//     * Used for comman line execution, mostly.
//     * @throws Exception
//     */
//    public SQLLoader() throws Exception
//    {
//        messageDirector_ = new MessageDirector(true, null, null);
//        Properties props = null;
//
//        try
//        {
//            props = PropertiesUtility.locateAndLoadPropFileConfigureLog4J("sqlIndexLoader.props", "ITS_LOADER_LOG4J_CONTROL_FILES");
//        }
//        catch (Exception e)
//        {
//            org.apache.log4j.BasicConfigurator.configure();
//            System.out.println("ERROR:  Unable to load props file.  Fatal error.");
//            System.exit(1);
//        }
//        
//        String compound = (String)props.get("COMPOUND_FILE");
//        if (compound != null)
//        {
//            useCompoundFile_ = new Boolean(compound).booleanValue();
//        }
//        
//        String codingSchemesString = props.get("CODING_SCHEMES").toString();
//        String[] codingSchemes = WordUtility.getWords(codingSchemesString, ",");
//
//        index(props.get("INDEX_NAME").toString(), props.get("INDEX_LOCATION").toString(), props.get("SQL_USERNAME")
//                .toString(), props.get("SQL_PASSWORD").toString(), props.get("SQL_SERVER").toString(), props
//                .get("SQL_DRIVER").toString(), codingSchemes);
//    }
    
    /**
     * Build a lucene index from the LexGrid SQL tables supplied in the parameters.
     * 
     * @param indexName The name to use for the Index.
     * @param indexLocation The full path to the index location on the system.
     * @param codingSchemes The coding schemes to index from the sql tables.
     * @throws Exception
     */
    public SQLIndexer(String indexName, String indexLocation, String sqlUserName, String sqlPassword, String sqlServer,
            String sqlDriver, String tablePrefix, String[] codingSchemes, LgMessageDirectorIF messageDirector, boolean addNormFields,
            boolean addDoubleMetaphoneFields, boolean addStemFields, boolean useCompoundFile) throws Exception
    {
        normEnabled_ = addNormFields;
        doubleMetaphoneEnabled_ = addDoubleMetaphoneFields;
        stemmingEnabled_ = addStemFields;
        messageDirector_ = messageDirector;
        useCompoundFile_ = useCompoundFile;
        batchSize_ = Constants.mySqlBatchSize;
        index(indexName, indexLocation, sqlUserName, sqlPassword, sqlServer, sqlDriver, tablePrefix, codingSchemes);
    }

    private void index(String indexName, String indexLocation, String sqlUserName, String sqlPassword,
            String sqlServer, String sqlDriver, String tablePrefix, String[] codingSchemes) throws Exception
    {

        initIndexes(indexName, indexLocation);

        // connect SQL
        sqlConnection_ = DBUtility.connectToDatabase(sqlServer, sqlDriver, sqlUserName, sqlPassword); 

        gsm_ = new GenericSQLModifier(sqlConnection_.getMetaData().getDatabaseProductName(), false);
        stc_ = new SQLTableUtilities(sqlConnection_, tablePrefix).getSQLTableConstants();

//        loadStopWords();
        SimpleDateFormat temp = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss");
        
        openIndexesClearExisting(codingSchemes);
        for (int j = 0; j < codingSchemes.length; j++)
        {
            logger.info("Now indexing " + codingSchemes[j] + " " + temp.format(new Date(System.currentTimeMillis())));
            messageDirector_.info("Now indexing " + codingSchemes[j] + " " + temp.format(new Date(System.currentTimeMillis())));
            Date start = new Date(System.currentTimeMillis());
            String version = loadCodedEntries(codingSchemes[j]);
            indexerService_.getMetaData().setIndexMetaDataValue(codingSchemes[j] + "[:]" + version, indexName);
            indexerService_.getMetaData().setIndexMetaDataValue(indexName, "codingScheme", codingSchemes[j]);
            indexerService_.getMetaData().setIndexMetaDataValue(indexName, "version", version);
            indexerService_.getMetaData().setIndexMetaDataValue(indexName, "has 'Norm' fields", normEnabled_ + "");
            indexerService_.getMetaData().setIndexMetaDataValue(indexName, "has 'Double Metaphone' fields", doubleMetaphoneEnabled_ + "");
            indexerService_.getMetaData().setIndexMetaDataValue(indexName, "indexing started", temp.format(start));
            indexerService_.getMetaData().setIndexMetaDataValue(indexName, "indexing finished", temp.format(new Date(System.currentTimeMillis())));
        }
        messageDirector_.info("Closing Indexes " + temp.format(new Date(System.currentTimeMillis())));
        sqlConnection_.close();
        closeIndexes();
        messageDirector_.info("Finished " + temp.format(new Date(System.currentTimeMillis())));
    }

    /*
     * Returns the version of the code system
     */
    private String loadCodedEntries(String codingSchemeName) throws Exception
    {
        logger.debug("loadCodedEntries called for " + codingSchemeName);

        PreparedStatement getDefaultLanguage = sqlConnection_
                .prepareStatement("SELECT defaultLanguage, registeredName, representsVersion FROM " + stc_.getTableName(stc_.CODING_SCHEME) + " WHERE codingSchemeName = ?");
        getDefaultLanguage.setString(1, codingSchemeName);

        ResultSet results = getDefaultLanguage.executeQuery();
        if (!results.next())
        {
            throw new Exception("No row could be found in the coding scheme table for '" + codingSchemeName + "'");
        }
        defaultLanguage_ = results.getString("defaultLanguage");
        codingSchemeId_ = results.getString("registeredName");
        
        String version = results.getString("representsVersion");
 
        results.close();
        getDefaultLanguage.close();

        boolean continueOutsideLoop = true;
        int start = 0;
        int codeCount = 0;
        
        //Access requires parenthesis, other dbs dont.
        PreparedStatement getConcepts;
        if (stc_.supports2006Model())
        {
            //2006 model has one less table, slightly different structure.
            getConcepts = sqlConnection_
                .prepareStatement(gsm_
                      .modifySQL("SELECT a.isActive, a.conceptStatus, a.isAnonymous, b.*, c.typeName, c.attributeValue, c.val1 FROM "
                           + (gsm_.getDatabaseType().equals("ACCESS") ? "(" : "")
                           + stc_.getTableName(stc_.CONCEPT) + " {AS} a " 
                           + " inner join " + stc_.getTableName(stc_.CONCEPT_PROPERTY)  + " {AS} b "
                           + " on a.codingSchemeName = b.codingSchemeName AND a.conceptCode = b.conceptCode"
                           + (gsm_.getDatabaseType().equals("ACCESS") ? ")" : "")
                           + " left join " + stc_.getTableName(stc_.CONCEPT_PROPERTY_MULTI_ATTRIBUTES)  + " {AS} c "
                           + " on b.codingSchemeName = c.codingSchemeName AND b.conceptCode = c.conceptCode AND b.propertyId = c.propertyId "
                           + " WHERE a.codingSchemeName = ? " 
                           + " ORDER BY a.conceptCode {LIMIT}"));
        }
        else
        {
            getConcepts = sqlConnection_
                .prepareStatement(gsm_
                    .modifySQL("SELECT a.isActive, a.conceptStatus, a.isAnonymous, b.*, c.qualifierName, c.qualifierValue, d.attributeName, d.attributeValue FROM "
                               + (gsm_.getDatabaseType().equals("ACCESS") ? "((" : "")
                               + stc_.getTableName(stc_.CONCEPT) + " {AS} a " 
                               + " inner join " + stc_.getTableName(stc_.CONCEPT_PROPERTY)  + " {AS} b "
                               + " on a.codingSchemeName = b.codingSchemeName AND a.conceptCode = b.conceptCode"
                               + (gsm_.getDatabaseType().equals("ACCESS") ? ")" : "")
                               + " left join " + stc_.getTableName(stc_.CONCEPT_PROPERTY_QUALIFIERS)  + " {AS} c "
                               + " on b.codingSchemeName = c.codingSchemeName AND b.conceptCode = c.conceptCode AND b.propertyId = c.propertyId "
                               + (gsm_.getDatabaseType().equals("ACCESS") ? ")" : "")
                               + " left join " + stc_.getTableName(stc_.CONCEPT_PROPERTY_MULTI_ATTRIBUTES)  + " {AS} d "
                               + " on b.codingSchemeName = d.codingSchemeName AND b.conceptCode = d.conceptCode AND b.propertyId = d.propertyId "
                               + " WHERE a.codingSchemeName = ? " 
                               + " ORDER BY a.conceptCode {LIMIT}"));
        }
        String lastCode = null;
        String lastPropertyId = null;
        Boolean isActive = null;
        String conceptStatus = null;
        Boolean isAnonymous = null;
        
        String property = null;
        String language = null;
        String presentationFormat = null;
        String propertyType = null;
        String degreeOfFidelity = null;
        String representationalForm = null;
        String propertyValue = null;
        Boolean isPreferred = null;
        Boolean matchIfNoContext = null;
        
        HashSet sources = null;
        HashSet usageContexts = null;
        Hashtable qualifiers = null;

        // This while loop is for mysql - it gets results by a batch at a time.
        // this loop will only run once with other databases.
        while (continueOutsideLoop)
        {
            logger.debug("Getting a results from sql (a page if using mysql)");
            messageDirector_.info("Getting a results from sql (a page if using mysql)");

            getConcepts.setString(1, codingSchemeName);

            // mysql doesn't stream results - the {LIMIT above and this is for getting limits on mysql code}
            if (gsm_.getDatabaseType().equals("MySQL"))
            {
                getConcepts.setInt(2, start);
                getConcepts.setInt(3, batchSize_);
                start += batchSize_;
            }
            else if (gsm_.getDatabaseType().equals("PostgreSQL"))
            {
                //postgres properly streams results, we can just set the fetch size, and only loop once
                getConcepts.setFetchSize(batchSize_);
                sqlConnection_.setAutoCommit(false);
                continueOutsideLoop = false;
            }
            else
            {
                continueOutsideLoop = false;
                try
                {
                    getConcepts.setFetchSize(batchSize_);
                }
                catch (SQLException e)
                {
                    // ignore this...  access doesn't support fetch sizes.
                }
            }

            results = getConcepts.executeQuery();

            logger.debug("query finished - processing results");

            boolean foundResults = false;
             
            // Since I have left joined all of these tables together, its a bit tricky to interperit the 
            //results of the query.
            while (results.next())
            {
                foundResults = true;
                
                String newCode = results.getString("conceptCode");
                String newId =  results.getString("propertyId");
                if (lastPropertyId == null || !lastPropertyId.equals(newId) || lastCode == null || !lastCode.equals(newCode))
                {
                    //If the propertyId or code is different - index the last item.
                    if (lastPropertyId != null)
                    {
                        if (isAnonymous == null || !isAnonymous.booleanValue())
                        {
                            try
                            {
                                addConcept(codingSchemeName, codingSchemeId_, lastCode, propertyType, property, propertyValue,
                                           isActive, presentationFormat, language, isPreferred, conceptStatus,
                                           lastPropertyId,  degreeOfFidelity, matchIfNoContext,
                                           representationalForm,
                                           (String[]) sources.toArray(new String[sources.size()]),
                                           (String[]) usageContexts.toArray(new String[usageContexts.size()]),
                                           (Qualifier[]) qualifiers.values().toArray(new Qualifier[qualifiers.size()]));
                            }
                            catch (Exception e)
                            {
                                messageDirector_.fatalAndThrowException("Problem indexing concept", e);
                            }
                        }
                    }
                    
                    sources = new HashSet();
                    usageContexts = new HashSet();
                    qualifiers = new Hashtable();
                    lastPropertyId = newId;
                    
                    if (lastCode == null || !lastCode.equals(newCode))
                    {
                        //only read these properties when we see a different code (no need to read them 
                        //other times, because they will be the same as before)
                        lastCode = newCode;
                        isAnonymous = DBUtility.getBooleanFromResultSet(results, "isAnonymous");
                        if (isAnonymous != null && isAnonymous.booleanValue())
                        {
                            continue;
                            // skip this one - dont' need to read any other properties
                        }
                        isActive = DBUtility.getBooleanFromResultSet(results, "isActive");
                        conceptStatus = results.getString("conceptStatus");
                        
                        
                        if (codeCount % 1000 == 0)
                        {
                            messageDirector_.info("Indexed " + codeCount + " concepts.");
                        }
                        
                        if (codeCount++ % 50 == 0)
                        {
                            messageDirector_.busy();
                        }
                    }
                    
                    //read the properties for the next (new) item
                    property = results.getString("property");
                    if (stc_.supports2006Model())
                    {
                        propertyType = results.getString("propertyType");
                    }
                    language = results.getString("language");
                    if (language == null || language.length() == 0)
                    {
                        language = defaultLanguage_;
                    }
                    presentationFormat = results.getString("presentationFormat");
                    isPreferred = DBUtility.getBooleanFromResultSet(results, "isPreferred");
                    degreeOfFidelity = results.getString("degreeOfFidelity");
                    matchIfNoContext = DBUtility.getBooleanFromResultSet(results, "matchIfNoContext");
                    representationalForm = results.getString("representationalForm");
                    propertyValue = results.getString("propertyValue");
                }
                //these values always have the potential to be unique.  Always read these.
                
                String type = null;
                String value = null;
                String val1 = null;
                
                String exType = null;
                String exValue = null;
                String exVal1 = null;
                
                if (stc_.supports2006Model())
                {
                    type = results.getString("typeName");
                    value = results.getString("attributeValue");
                    val1 = results.getString("val1");
                }
                else
                {
                    String qualifierName = results.getString("qualifierName");
                    String qualifierValue = results.getString("qualifierValue");
                    String attributeName = results.getString("attributeName");
                    String attributeValue = results.getString("attributeValue");
                    
                    //have to use a second set of variables because the join could put
                    //2 unique values in here at once 
                    if (attributeName != null)
                    {
                        type = attributeName;
                        value = attributeValue;
                    }
                    if (qualifierName != null)
                    {
                        exType = "qualifier";
                        exValue = qualifierName;
                        exVal1 = qualifierValue;
                    }
                    
                }
 
                //tables don't allow dupes, but the join creates some.  So I need to use hashes to get rid of dupes.
                if (type != null)
                {
                    if (type.equalsIgnoreCase("source"))
                    {
                        sources.add(value);
                    }
                    else if (type.equalsIgnoreCase("usageContext"))
                    {
                        usageContexts.add(value);
                    }
                    else if (type.equalsIgnoreCase("qualifier"))
                    {
                        qualifiers.put(value + ":" + val1, new Qualifier(value, val1));
                    }
                    else
                    {
                        messageDirector_.error("Unexpected value in conceptPropertyMultiAttribs table" + type + ":" + value, null);
                    }
                }
                if (exType != null)
                {
                    if (exType.equalsIgnoreCase("qualifier"))
                    {
                        qualifiers.put(exValue + ":" + exVal1, new Qualifier(exValue, exVal1));
                    }
                    else
                    {
                        messageDirector_.error("Unexpected value in conceptPropertyMultiAttribs table" + exType + ":" + exValue, null);
                    }
                }
            }
            
            if (!foundResults)
            {
                continueOutsideLoop = false;
            }
            
            if (gsm_.getDatabaseType().equals("PostgreSQL"))
            {
                //turn autocommit back on.
                sqlConnection_.setAutoCommit(true);
            }

            results.close();
             
            if (!gsm_.getDatabaseType().equals("MySQL"))
            {
                // only do the while loop and limit thing if using mysql
                break;
            }
        }
        
        getConcepts.close();
        
        //load the last row (if there was one)
        if (lastCode != null && (isAnonymous == null || !isAnonymous.booleanValue()))
        {
            try
            {
                addConcept(codingSchemeName, codingSchemeId_, lastCode, propertyType, property, propertyValue, isActive,
                           presentationFormat, language, isPreferred, conceptStatus, lastPropertyId, 
                           degreeOfFidelity, matchIfNoContext, representationalForm, (String[]) sources
                                   .toArray(new String[sources.size()]), (String[]) usageContexts
                                   .toArray(new String[usageContexts.size()]), (Qualifier[]) qualifiers.values()
                                   .toArray(new Qualifier[qualifiers.size()]));
            }
            catch (Exception e)
            {
                messageDirector_.fatalAndThrowException("Problem indexing concept", e);
            }
        }

        
        logger.info("loaded " + codeCount + " concept Codes");
        messageDirector_.info("loaded " + codeCount + " concept Codes");
        return version;
    }

//    public static void main(String[] args) throws Exception
//    {
//        new SQLLoader();
//    }

}