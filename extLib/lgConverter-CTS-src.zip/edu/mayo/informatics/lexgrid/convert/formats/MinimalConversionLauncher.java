/*
 * Copyright: (c) 2004-2005 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.mayo.informatics.lexgrid.convert.formats;

import org.LexGrid.emf.codingSchemes.CodingSchemeType;
import org.LexGrid.messaging.LgMessageDirectorIF;

import edu.mayo.informatics.lexgrid.convert.directConversions.SQLToLdap;
import edu.mayo.informatics.lexgrid.convert.directConversions.SQLToSQLLite;
import edu.mayo.informatics.lexgrid.convert.emfConversions.LDAPReadWrite;
import edu.mayo.informatics.lexgrid.convert.emfConversions.SQLReadWrite;
import edu.mayo.informatics.lexgrid.convert.emfConversions.XMLRead;
import edu.mayo.informatics.lexgrid.convert.emfConversions.emfInterfaces.EMFRead;
import edu.mayo.informatics.lexgrid.convert.emfConversions.emfInterfaces.EMFWrite;
import edu.mayo.informatics.lexgrid.convert.formats.inputFormats.LexGridLDAP;
import edu.mayo.informatics.lexgrid.convert.formats.inputFormats.LexGridSQL;
import edu.mayo.informatics.lexgrid.convert.formats.inputFormats.LexGridSQLLite;
import edu.mayo.informatics.lexgrid.convert.formats.inputFormats.LexGridXML;
import edu.mayo.informatics.lexgrid.convert.formats.outputFormats.IndexLexGridDatabase;
import edu.mayo.informatics.lexgrid.convert.formats.outputFormats.LexGridLDAPOut;
import edu.mayo.informatics.lexgrid.convert.formats.outputFormats.LexGridSQLLiteOut;
import edu.mayo.informatics.lexgrid.convert.formats.outputFormats.LexGridSQLOut;
import edu.mayo.informatics.lexgrid.convert.indexer.SQLIndexer;
import edu.mayo.informatics.lexgrid.convert.utility.Constants;

/**
 * Tool to take a pair of input and output formats, map them to the appropriate conversion tool, and run the
 * conversion.
 * 
 * This is a subset of the Conversion Launcher class - only supports a subset of conversions
 * as required by CTS.  Helps trim down the package and dependencies for CTS.
 * 
 * @author <A HREF="mailto:armbrust.daniel@mayo.edu">Dan Armbrust</A>
 * @version subversion $Revision: 3797 $ checked in on $Date: 2006-11-02 20:48:47 +0000 (Thu, 02 Nov 2006) $
 */
public class MinimalConversionLauncher
{
    /**
     * Execute the conversion
     * @param inputFormat
     * @param outputFormat
     * @param codingSchemes
     * @param options
     * @param md
     * @return The coding schemes that were converted - this can be useful in cases where the 
     * conversion doesn't take in any coding schemes (for example, owl).  In the case of RRF, 
     * this actually returns the table names that were created.
     * @throws Exception
     */
    public static String[] startConversion(InputFormatInterface inputFormat, OutputFormatInterface outputFormat,
            String[] codingSchemes, OptionHolder options, LgMessageDirectorIF md) throws Exception
    {
        if (options == null)
        {
            options = new OptionHolder();
        }

        // Has an override flag been set to do a direct conversion with EMF instead?
        Option overrideOption = options.get(Option.getNameForType(Option.DO_WITH_EMF));
        if (overrideOption != null)
        {
            if (((Boolean) overrideOption.getOptionValue()).booleanValue())
            {
                return doEMFConversion(inputFormat, outputFormat, codingSchemes, options, md);
            }
        }

        if (inputFormat.getDescription().equals(LexGridSQL.description))
        {
            // LexGridSQL inputformat
            LexGridSQL in = (LexGridSQL) inputFormat;
            if (outputFormat.getDescription().equals(IndexLexGridDatabase.description))
            {
                // custom sql lucene indexer
                IndexLexGridDatabase out = (IndexLexGridDatabase) outputFormat;

                String fetchSize = getStringOption(options, Option.SQL_FETCH_SIZE);

                try
                {
                    int temp = Integer.parseInt(fetchSize);
                    Constants.mySqlBatchSize = temp;
                }
                catch (NumberFormatException e)
                {
                    md.info("Invalid SQL Fetch Size - using default");
                }

                boolean buildDBMeta = getBooleanOption(options, Option.BUILD_DB_METAPHONE);
                boolean useCompoundFormat = getBooleanOption(options, Option.USE_COMPOUND_FMT);
                boolean buildStem = getBooleanOption(options, Option.BUILD_STEM);

                edu.mayo.informatics.indexer.lucene.analyzers.NormAnalyzer.LVG_CONFIG_FILE_ABSOLUTE = out
                        .getNormConfigFile();

                new SQLIndexer(out.getIndexName(), out.getIndexLocation(), in.getUsername(), in.getPassword(), in
                        .getServer(), in.getDriver(), in.getTablePrefix(), codingSchemes, md, out.isNormEnabled(), buildDBMeta,
                        buildStem, useCompoundFormat);
                return codingSchemes;
            }
            else if (outputFormat.getDescription().equals(LexGridSQLLiteOut.description))
            {
                // custom SQL -> sql lite converter.

                boolean enforceIntegrity;
                try
                {
                    enforceIntegrity = getBooleanOption(options, Option.ENFORCE_INTEGRITY);

                    String fetchSize = getStringOption(options, Option.SQL_FETCH_SIZE);

                    try
                    {
                        int temp = Integer.parseInt(fetchSize);
                        Constants.mySqlBatchSize = temp;
                    }
                    catch (NumberFormatException e)
                    {
                        md.info("Invalid SQL Fetch Size - using default");
                    }
                }
                catch (RuntimeException e)
                {
                    throw new Exception("Converter implementation error - required option is missing");
                }

                LexGridSQLLiteOut out = (LexGridSQLLiteOut) outputFormat;
                for (int i = 0; i < codingSchemes.length; i++)
                {
                    new SQLToSQLLite(out.getServer(), out.getDriver(), out.getUsername(), out.getPassword(), in
                            .getServer(), in.getDriver(), in.getUsername(), in.getPassword(), in.getTablePrefix(),codingSchemes[i], md,
                            enforceIntegrity);
                }
                return codingSchemes;

            }
            else if (outputFormat.getDescription().equals(LexGridLDAPOut.description))
            {
                // custom sql to ldap converter
                LexGridLDAPOut out = (LexGridLDAPOut) outputFormat;
                boolean failOnErrors = getBooleanOption(options, Option.FAIL_ON_ERROR);

                String fetchSize = getStringOption(options, Option.SQL_FETCH_SIZE);

                try
                {
                    int temp = Integer.parseInt(fetchSize);
                    Constants.mySqlBatchSize = temp;
                }
                catch (NumberFormatException e)
                {
                    md.info("Invalid SQL Fetch Size - using default");
                }

                for (int i = 0; i < codingSchemes.length; i++)
                {
                    new SQLToLdap(in.getServer(), in.getDriver(), in.getUsername(), in.getPassword(),
                            in.getTablePrefix(), out.getUsername(), out.getPassword(), out.getAddress(), out.getServiceDN(),
                            codingSchemes[i], failOnErrors, md);

                }
                return codingSchemes;
            }
        }
       
        // End of specific direct conversions. Havent found a match yet - can we do it with EMF?
        return doEMFConversion(inputFormat, outputFormat, codingSchemes, options, md);

    }

    private static String[] doEMFConversion(InputFormatInterface inputFormat, OutputFormatInterface outputFormat,
            String[] codingSchemes, OptionHolder options, LgMessageDirectorIF md) throws Exception
    {
        // TODO figure out how to pass the read size options into EMF - EMF issue.
        EMFRead emfIn;
        if (inputFormat.getDescription().equals(LexGridSQL.description))
        {
            LexGridSQL in = (LexGridSQL) inputFormat;

            boolean failOnErrors = getBooleanOption(options, Option.FAIL_ON_ERROR);

            String fetchSize = getStringOption(options, Option.SQL_FETCH_SIZE);

            try
            {
                int temp = Integer.parseInt(fetchSize);
                Constants.mySqlBatchSize = temp;
            }
            catch (NumberFormatException e)
            {
                md.info("Invalid SQL Fetch Size - using default");
            }

            emfIn = new SQLReadWrite(in.getServer(), in.getDriver(), in.getUsername(), in.getPassword(), in.getTablePrefix(), failOnErrors,
                    md);
        }
        else if (inputFormat.getDescription().equals(LexGridXML.description))
        {
            LexGridXML in = (LexGridXML) inputFormat;
            boolean failOnErrors = getBooleanOption(options, Option.FAIL_ON_ERROR);
            emfIn = new XMLRead(in.getFileLocation(), md, failOnErrors);
        }
        else
        {
            throw new Exception("The conversion that you are attempting to do is not yet possible.");
        }
        return doEMFConversionHelper(emfIn, outputFormat, codingSchemes, options, md);
    }

    private static String[] doEMFConversionHelper(EMFRead emfIn, OutputFormatInterface outputFormat,
            String[] codingSchemes, OptionHolder options, LgMessageDirectorIF md) throws Exception
    {
        EMFWrite emfOut = null;
        if (outputFormat.getDescription().equals(LexGridLDAPOut.description))
        {
            LexGridLDAPOut out = (LexGridLDAPOut) outputFormat;
            emfOut = new LDAPReadWrite(out.getUsername(), out.getPassword(), out.getAddress(), out.getServiceDN(), md);
        }
        else if (outputFormat.getDescription().equals(LexGridSQLOut.description))
        {
            LexGridSQLOut out = (LexGridSQLOut) outputFormat;

            boolean failOnErrors = getBooleanOption(options, Option.FAIL_ON_ERROR);

            emfOut = new SQLReadWrite(out.getServer(), out.getDriver(), out.getUsername(), out.getPassword(), out.getTablePrefix(),
                    failOnErrors, md);
        }
        else
        {
            throw new Exception("The conversion that you are attempting to do is not yet possible.");
        }

        md
                .info("This is an in-memory transformation - you need to have enough RAM to hold the entire coding scheme in memory at once.");

        String[] convertedCodingSchemes;
        
        try
        {
            if (codingSchemes == null || codingSchemes.length == 0)
            {
                throw new UnsupportedOperationException();
            }
            for (int i = 0; i < codingSchemes.length; i++)
            {
                long ms = System.currentTimeMillis();
                md.info("Reading from source of " + codingSchemes[i] + "...");
                CodingSchemeType temp = emfIn.readCodingScheme(codingSchemes[i]);
                md.info("Read Time (ms): " + (System.currentTimeMillis() - ms));

                ms = System.currentTimeMillis();
                md.info("Clearing target of " + codingSchemes[i] + "...");
                emfOut.clearCodingScheme(codingSchemes[i]);
                md.info("Clear Time (ms): " + (System.currentTimeMillis() - ms));

                ms = System.currentTimeMillis();
                md.info("Writing to target...");
                emfOut.writeCodingScheme(temp);
                md.info("Write Time (ms): " + (System.currentTimeMillis() - ms));
            }
            convertedCodingSchemes = codingSchemes;
        }
        catch (UnsupportedOperationException e)
        {
            try
            {
                // read of a particular coding scheme is not implemented - lets try reading without specifying
                // the coding scheme (obo and nci reader do this)
                long ms = System.currentTimeMillis();
                md.info("Reading from source...");
                CodingSchemeType temp = emfIn.readCodingScheme();
                md.info("Read Time (ms): " + (System.currentTimeMillis() - ms));

                ms = System.currentTimeMillis();
                md.info("Clearing target of " + temp.getCodingScheme() + "...");
                String codingSchemeName = temp.getCodingScheme();
                emfOut.clearCodingScheme(codingSchemeName);
                md.info("Clear Time (ms): " + (System.currentTimeMillis() - ms));

                ms = System.currentTimeMillis();
                md.info("Writing " + temp.getCodingScheme() + " to target...");
                emfOut.writeCodingScheme(temp);
                md.info("Write Time (ms): " + (System.currentTimeMillis() - ms));
                convertedCodingSchemes = new String[] {codingSchemeName};
            }
            catch (UnsupportedOperationException e1)
            {
                // read without specifying a coding scheme also not implemented. try reading all
                // xml reader does this
                long ms = System.currentTimeMillis();
                // md.info("Reading from source..."); //don't need to say this - it will have been
                // said above - before the exception.
                CodingSchemeType[] allCodingSchemes = emfIn.readAllCodingSchemes();
                convertedCodingSchemes = new String[allCodingSchemes.length];
                md.info("Read Time (ms): " + (System.currentTimeMillis() - ms));

                for (int i = 0; i < allCodingSchemes.length; i++)
                {
                    ms = System.currentTimeMillis();
                    md.info("Clearing target of " + allCodingSchemes[i].getCodingScheme() + "...");
                    emfOut.clearCodingScheme(allCodingSchemes[i].getCodingScheme());
                    convertedCodingSchemes[i] = allCodingSchemes[i].getCodingScheme();
                    md.info("Clear Time (ms): " + (System.currentTimeMillis() - ms));

                    ms = System.currentTimeMillis();
                    md.info("Writing " + allCodingSchemes[i].getCodingScheme() + " to target...");
                    emfOut.writeCodingScheme(allCodingSchemes[i]);
                    md.info("Write Time (ms): " + (System.currentTimeMillis() - ms));
                }
            }
        }

        md.info("Conversion Finished.");
        return convertedCodingSchemes;
    }

     public static boolean willBeDoneWithEMF(InputFormatInterface inputFormat, OutputFormatInterface outputFormat,
            OptionHolder options)
    {
        if (inputFormat == null || outputFormat == null)
        {
            return false;
        }

        if (options == null)
        {
            options = new OptionHolder();
        }

        // Has an override flag been set to do a direct conversion with EMF instead?
        Option overrideOption = options.get(Option.getNameForType(Option.DO_WITH_EMF));
        if (overrideOption != null)
        {
            if (((Boolean) overrideOption.getOptionValue()).booleanValue())
            {
                return true;
            }
        }

        // first, figure out if it is a specific (non emf) conversion
        if (inputFormat.getDescription().equals(LexGridLDAP.description))
        {
            if (outputFormat.getDescription().equals(LexGridSQLLiteOut.description))
            {
                return false;
            }
            else if (outputFormat.getDescription().equals(IndexLexGridDatabase.description))
            {
                return false;
            }
        }
        else if (inputFormat.getDescription().equals(LexGridSQLLite.description))
        {
            // LexGridSQLLite inputformat
            if (outputFormat.getDescription().equals(LexGridLDAPOut.description))
            {
                return false;
            }
        }

        else if (inputFormat.getDescription().equals(LexGridSQL.description))
        {
            // LexGridSQL inputformat
            if (outputFormat.getDescription().equals(LexGridLDAPOut.description))
            {
                return false;
            }
            else if (outputFormat.getDescription().equals(LexGridSQLLiteOut.description))
            {
                return false;
            }
            else if (outputFormat.getDescription().equals(IndexLexGridDatabase.description))
            {
                return false;
            }
        }

        // End of specific direct conversions. Havent found a match yet - can we do it with EMF?
        return true;
    }

        private static String getStringOption(OptionHolder options, int option) throws Exception
    {
        try
        {
            return ((String) options.get(Option.getNameForType(option)).getOptionValue());
        }
        catch (RuntimeException e)
        {
            throw new Exception(
                    "Converter implementation error - required option is missing - needs a string option of "
                            + Option.getNameForType(option));
        }
    }

    private static boolean getBooleanOption(OptionHolder options, int option) throws Exception
    {
        try
        {
            return ((Boolean) options.get(Option.getNameForType(option)).getOptionValue()).booleanValue();
        }
        catch (RuntimeException e)
        {
            throw new Exception(
                    "Converter implementation error - required option is missing - needs a string option of "
                            + Option.getNameForType(option));
        }
    }
}