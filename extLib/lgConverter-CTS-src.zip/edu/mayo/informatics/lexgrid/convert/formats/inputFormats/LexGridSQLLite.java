/*
 * Copyright: (c) 2004-2005 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.mayo.informatics.lexgrid.convert.formats.inputFormats;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;

import org.LexGrid.util.sql.sqlReconnect.WrappedConnection;
import org.apache.log4j.Logger;

import edu.mayo.informatics.lexgrid.convert.exceptions.ConnectionFailure;
import edu.mayo.informatics.lexgrid.convert.exceptions.UnexpectedError;
import edu.mayo.informatics.lexgrid.convert.formats.InputFormatInterface;
import edu.mayo.informatics.lexgrid.convert.formats.Option;
import edu.mayo.informatics.lexgrid.convert.formats.baseFormats.SQLBase;
import edu.mayo.informatics.lexgrid.convert.formats.outputFormats.DeleteLexGridTerminology;
import edu.mayo.informatics.lexgrid.convert.formats.outputFormats.LexGridLDAPOut;
import edu.mayo.informatics.lexgrid.convert.utility.StringComparator;

/**
 * Details for connecting to SQL Lite.
 * 
 * @author <A HREF="mailto:armbrust.daniel@mayo.edu">Dan Armbrust</A>
 * @version subversion $Revision: 3711 $ checked in on $Date: 2006-11-01 21:19:33 +0000 (Wed, 01 Nov 2006) $
 */
public class LexGridSQLLite extends SQLBase implements InputFormatInterface
{
    protected static Logger      log         = Logger.getLogger("convert.gui");

    public static final String description = "LexGrid SQLLite Database";

    public LexGridSQLLite(String username, String password, String server, String driver)
    {
        this.username = username;
        this.password = password;
        this.server = server;
        this.driver = driver;
    }

    public LexGridSQLLite()
    {

    }

    public String getConnectionSummary()
    {
        return getConnectionSummary(description);
    }

    public String getDescription()
    {
        return description;
    }

    public String[] getSupportedOutputFormats()
    {
        return new String[]{LexGridLDAPOut.description, DeleteLexGridTerminology.description};
    }

    public Option[] getOptions()
    {
        return new Option[]{};
    }

    public String[] getAvailableTerminologies() throws ConnectionFailure, UnexpectedError
    {
        try
        {
            String[] terminologies = new String[]{};

            ArrayList temp = new ArrayList();

            DriverManager.setLoginTimeout(5);
            Connection sqlConnection;
            try
            {
                sqlConnection = new WrappedConnection(getUsername(), getPassword(), getDriver(), getServer());

            }
            catch (ClassNotFoundException e1)
            {
                log.error("The class you specified for your sql driver could not be found on the path.");
                throw new ConnectionFailure(
                        "The class you specified for your sql driver could not be found on the path.");
            }
            PreparedStatement getTerminologies = sqlConnection
                    .prepareStatement("Select codingSchemeName from codingScheme");
            ResultSet results = getTerminologies.executeQuery();
            while (results.next())
            {
                temp.add(results.getString("codingSchemeName"));
            }
            results.close();
            getTerminologies.close();
            sqlConnection.close();

            terminologies = (String[]) temp.toArray(new String[temp.size()]);
            Arrays.sort(terminologies, new StringComparator());

            return terminologies;
        }
        catch (ConnectionFailure e)
        {
            throw e;
        }
        catch (Exception e)
        {
            log.error("An error occurred while getting the terminologies.", e);
            throw new UnexpectedError("An error occurred while getting the terminologies.", e);
        }
    }
}