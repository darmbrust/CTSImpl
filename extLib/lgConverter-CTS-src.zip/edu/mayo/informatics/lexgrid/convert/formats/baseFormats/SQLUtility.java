/*
 * Copyright: (c) 2004-2005 Mayo Foundation for Medical Education and
 * Research (MFMER).  All rights reserved.  MAYO, MAYO CLINIC, and the
 * triple-shield Mayo logo are trademarks and service marks of MFMER.
 *
 * Except as contained in the copyright notice above, the trade names, 
 * trademarks, service marks, or product names of the copyright holder shall
 * not be used in advertising, promotion or otherwise in connection with
 * this Software without prior written authorization of the copyright holder.
 * 
 * Licensed under the Eclipse Public License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 * 
 * 		http://www.eclipse.org/legal/epl-v10.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.mayo.informatics.lexgrid.convert.formats.baseFormats;

import java.sql.Connection;

import org.LexGrid.util.sql.DBUtility;
import org.LexGrid.util.sql.lgTables.SQLTableUtilities;

import edu.mayo.informatics.lexgrid.convert.exceptions.ConnectionFailure;

/**
 * Utility stuff for formats that read or write to SQL.
 * 
 * @author <A HREF="mailto:armbrust.daniel@mayo.edu">Dan Armbrust</A>
 * @version subversion $Revision: 4042 $ checked in on $Date: 2006-12-04 13:25:09 -0600 (Mon, 04 Dec 2006) $
 */
public class SQLUtility
{

    public static String testSQLConnection(String username, String password, String server, String driver, String tablePrefix)
            throws ConnectionFailure

    {
        try
        {
            String warning = "";
            Connection c = DBUtility.connectToDatabase(server, driver, username, password);

            SQLTableUtilities stu = new SQLTableUtilities(c, tablePrefix);
            String version = stu.getExistingTableVersion();
            if (version == null)
            {
                //no tables present - they will be created - so no problem.
            }//current version and version 1.2 are supported
            else if (!version.equals(stu.versionString) && !version.equals("1.2") && !version.equals("1.3") && !version.equals("1.4"))
            {
                warning = "The existing LexGrid tables are an older (or newer) version than what this tool expects - you may get unexpected errors."
                        + System.getProperty("line.separator")
                        + "I was expecting "
                        + stu.versionString
                        + " but found "
                        + version;
            }

            c.close();
            return warning;
        }
        catch (Exception e)
        {
            throw new ConnectionFailure(e.toString());
        }
    }
}